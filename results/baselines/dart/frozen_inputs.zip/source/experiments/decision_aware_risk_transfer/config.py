"""One declared experiment; target results never select network checkpoints."""

from experiments.driving_benchmark.config import OUTPUT as DEVELOPMENT_BANKS, SUT_IDS
from methods.decision_aware_risk_transfer.config import ROOT, SEEDS

INDEPENDENT_BANKS = ROOT / "independent_bank"
INDEPENDENT_SEEDS = (860035, 860036)
VARIANTS = {
    "cg_brt": {},
    "full": {},
    "physical_kernel": {},
    "conventional_training": {},
    "greedy": {"lookahead": False},
    "unprotected": {"protection": False},
    "no_spatial_planning": {"spatial": False},
}
CONFIRMATION_VARIANTS = ("cg_brt", "full", "conventional_training", "greedy")
ACCEPTANCE_METRICS = ("H200", "high_risk_area_pct", "high_risk_recall_pct")
RETENTION_FLOOR = 0.9


def bank_root(stage):
    return DEVELOPMENT_BANKS if stage == "development" else INDEPENDENT_BANKS


def pools(stage):
    return (0, 1) if stage == "development" else (2,)


def variants(stage):
    return tuple(VARIANTS) if stage == "development" else CONFIRMATION_VARIANTS
