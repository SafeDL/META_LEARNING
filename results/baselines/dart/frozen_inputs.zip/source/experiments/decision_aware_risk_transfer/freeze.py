"""Freeze source and selected weights before any independent target measurement."""

from dataclasses import asdict
import importlib.metadata
import json
from pathlib import Path
import shutil

from experiments.driving_benchmark.config import sut_spec
from methods.decision_aware_risk_transfer import config as method_config
from methods.history_guided_testing.io import read_json, write_json

from .config import CONFIRMATION_VARIANTS, INDEPENDENT_SEEDS, ROOT, SEEDS, SUT_IDS

PROJECT = Path(__file__).resolve().parents[2]


def verify_freeze():
    protocol = read_json(ROOT / "protocol.json")
    for relative in protocol["source_files"]:
        if (PROJECT / relative).read_bytes() != (
            ROOT / "frozen_source" / relative
        ).read_bytes():
            raise ValueError(f"Frozen source changed before confirmation: {relative}")
    for name in protocol["model_files"]:
        if (ROOT / "models" / name).read_bytes() != (
            ROOT / "frozen_models" / name
        ).read_bytes():
            raise ValueError(f"Frozen model changed before confirmation: {name}")
    for relative in protocol["input_files"]:
        if (PROJECT / relative).read_bytes() != (
            ROOT / "frozen_input" / relative
        ).read_bytes():
            raise ValueError(f"Frozen historical input or kernel changed: {relative}")
    return protocol


def main():
    if (ROOT / "protocol.json").exists():
        return verify_freeze()
    source_files = []
    for directory in (
        "methods/decision_aware_risk_transfer",
        "experiments/decision_aware_risk_transfer",
        "methods/concordance_gated_bayesian_risk_transfer",
        "highway_sim_env/envs",
        "sut_algorithms/highway_env",
    ):
        source_files.extend(
            path.relative_to(PROJECT).as_posix()
            for path in (PROJECT / directory).glob("*.py")
        )
    source_files.extend(
        [
            "methods/history_guided_testing/gp.py",
            "methods/history_guided_testing/kernel.py",
            "methods/history_guided_testing/train.py",
            "methods/history_guided_testing/history.py",
            "methods/historical_expert_mixture/experts.py",
            "methods/history_guided_testing/config.py",
            "methods/history_guided_testing/measurements.py",
            "methods/history_guided_testing/risk.py",
            "experiments/driving_benchmark/config.py",
            "experiments/driving_benchmark/prepare.py",
            "highway_sim_env/build_spec.py",
            "methods/decision_aware_risk_transfer/requirements.txt",
        ]
    )
    model_files = [
        f"{mode}_{seed}.pt" for seed in SEEDS for mode in ("decision", "conventional")
    ]
    input_files = ["results/history_guided_testing/history/responses.npz"] + [
        f"results/history_guided_testing/models/seed_{seed}.pt" for seed in SEEDS
    ]
    for seed in SEEDS:
        for mode in ("decision", "conventional"):
            if (
                read_json(ROOT / "models" / f"training_{mode}_{seed}.json")["status"]
                != "complete"
            ):
                raise ValueError(
                    "Confirmation requires all declared training updates to be completed"
                )
    development = read_json(ROOT / "development_comparison.json")
    for relative in source_files:
        destination = ROOT / "frozen_source" / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(PROJECT / relative, destination)
    for name in model_files:
        destination = ROOT / "frozen_models" / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(ROOT / "models" / name, destination)
    for relative in input_files:
        destination = ROOT / "frozen_input" / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(PROJECT / relative, destination)
    settings = {
        name: getattr(method_config, name)
        for name in (
            "BUDGET",
            "INITIAL_QUERIES",
            "FANTASIES",
            "LOSS_FRACTION",
            "CANDIDATES_PER_RULE",
            "WIDTH",
            "HEADS",
            "FEATURES",
            "CONTEXT_PER_FAMILY",
            "MAX_AMPLITUDE",
            "INITIAL_AMPLITUDE",
            "SCALE_NODES",
            "TRAINING_STEPS",
            "VALIDATION_INTERVAL",
            "LEARNING_RATE",
            "SUPPORT_COUNTS",
        )
    }
    protocol = {
        "method": "decision-aware risk transfer",
        "settings": settings,
        "source_files": source_files,
        "model_files": model_files,
        "input_files": input_files,
        "independent_pool_seeds": list(INDEPENDENT_SEEDS),
        "suts": list(SUT_IDS),
        "target_builds": [asdict(sut_spec(s)) for s in SUT_IDS],
        "confirmation_variants": list(CONFIRMATION_VARIANTS),
        "selection_seeds": list(SEEDS),
        "physical_calls_planned": 12288,
        "online_feedback": "queried R only",
        "source_only_checkpoint_selection": True,
        "new_pool_used_for_selection": False,
        "development_retention": development["retention"],
        "development_effect_accepted": development["effect_accepted"],
        "guarantee_scope": "model-conditional same-history replacement; not full policy domination",
        "confirmation_scope": "new scenes in the same six systems, not new-system generalization",
        "package_versions": {
            name: importlib.metadata.version(name)
            for name in (
                "torch",
                "numpy",
                "scipy",
                "highway-env",
                "gymnasium",
                "stable-baselines3",
                "cupy-cuda11x",
            )
        },
    }
    write_json(ROOT / "protocol.json", json.loads(json.dumps(protocol)))
    return verify_freeze()


if __name__ == "__main__":
    main()
