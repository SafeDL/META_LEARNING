"""Run the declared research sequence without selecting on the untouched pool."""

from methods.decision_aware_risk_transfer.train import main as train
from methods.history_guided_testing.io import write_json

from . import evaluate, freeze, prepare, report, verify
from .config import ROOT


def main():
    stages = (
        "training",
        "development",
        "freeze",
        "measurement",
        "confirmation",
        "verification",
    )
    actions = (
        train,
        lambda: evaluate.run_parallel("development"),
        freeze.main,
        prepare.main,
        lambda: evaluate.run_parallel("confirmation"),
        verify.main,
    )
    for stage, action in zip(stages, actions):
        write_json(ROOT / "status.json", {"status": "running", "stage": stage})
        print(f"PIPELINE {stage}", flush=True)
        action()
        if stage in ("development", "confirmation"):
            report.main(stage)
    write_json(ROOT / "status.json", {"status": "complete", "stage": "complete"})


if __name__ == "__main__":
    main()
