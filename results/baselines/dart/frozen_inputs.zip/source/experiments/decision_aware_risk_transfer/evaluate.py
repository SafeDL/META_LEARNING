"""Selectors execute in a process that cannot access unqueried target responses."""

import multiprocessing as mp
from concurrent.futures import ProcessPoolExecutor
import time

import numpy as np
import torch
from threadpoolctl import threadpool_limits

from experiments.concordance_gated_bayesian_risk_transfer.evaluate import (
    RiskOracle,
)
from methods.concordance_gated_bayesian_risk_transfer import select as original_select
from methods.decision_aware_risk_transfer import select
from methods.decision_aware_risk_transfer.encoder import fixed_context
from methods.decision_aware_risk_transfer.train import load_encoder
from methods.historical_expert_mixture.experts import HistoricalExperts
from methods.history_guided_testing.history import load_history, split_indices, subset
from methods.history_guided_testing.io import read_json, write_json
from methods.history_guided_testing.train import load_kernel

from .config import ROOT, SEEDS, SUT_IDS, VARIANTS, bank_root, pools, variants


def worker(connection):
    try:
        torch.set_num_threads(1)
        with threadpool_limits(limits=1):
            while True:
                message, task = connection.recv()
                if message == "stop":
                    return
                policy = task.pop("policy")
                selector = original_select if policy == "cg_brt" else select
                result = selector(**task, oracle=RiskOracle(connection))
                connection.send(("result", result))
    except Exception as error:
        connection.send(("error", repr(error)))
        raise
    finally:
        connection.close()


def trace_path(stage, pool, sut, policy, seed):
    if stage == "development" and policy == "cg_brt":
        return (
            ROOT.parent
            / "concordance_gated_bayesian_risk_transfer"
            / "driving"
            / f"pool_{pool}"
            / sut
            / f"cg_brt_{seed}.json"
        )
    return ROOT / stage / f"pool_{pool}" / sut / f"{policy}_{seed}.json"


def disclose_risk(connection, task, risk, process):
    connection.send(("task", task))
    selected, disclosures = [], []
    while True:
        while not connection.poll(1.0):
            if not process.is_alive():
                raise RuntimeError("Selector process exited before returning a result")
        message, value = connection.recv()
        if message == "query":
            index = int(value)
            if (
                index not in range(len(risk))
                or index in selected
                or len(selected) >= 200
            ):
                raise ValueError("Invalid or repeated paid query")
            selected.append(index)
            disclosures.append(
                {"index": index, "risk": float(risk[index]), "collision": None}
            )
            connection.send(float(risk[index]))
        elif message == "result":
            if value["selected_indices"] != selected or len(selected) != 200:
                raise ValueError(
                    "Selector returned an incomplete or different paid trajectory"
                )
            for actual, reported in zip(disclosures, value["queries"]):
                if (
                    actual["index"] != reported["index"]
                    or actual["risk"] != reported["risk"]
                ):
                    raise ValueError("Returned risk differs from the disclosure")
            return {**value, "disclosures": disclosures}
        else:
            raise RuntimeError(value)


def main(stage="development", selection_seeds=SEEDS):
    if stage == "confirmation":
        from .freeze import verify_freeze

        verify_freeze()
    torch.set_num_threads(1)
    history = load_history()
    train, _ = split_indices(next(iter(history.values()))["x"])
    sources = subset(history, train)
    experts = HistoricalExperts(sources)
    parent, child = mp.get_context("spawn").Pipe()
    process = mp.get_context("spawn").Process(target=worker, args=(child,))
    process.start()
    child.close()
    planned = (
        len(pools(stage)) * len(selection_seeds) * len(SUT_IDS) * len(variants(stage))
    )
    completed = 0
    try:
        with threadpool_limits(limits=1):
            for seed in selection_seeds:
                context = fixed_context(sources, seed)
                encoders = {
                    mode: load_encoder(
                        seed, mode, "cuda" if torch.cuda.is_available() else "cpu"
                    )
                    for mode in ("decision", "conventional")
                }
                for pool in pools(stage):
                    folder = bank_root(stage) / f"pool_{pool}"
                    with np.load(folder / SUT_IDS[0] / "responses.npz") as bank:
                        x = bank["x"].copy()
                    prediction = experts.predict(x)
                    with torch.no_grad():
                        covariance = (
                            load_kernel(seed, "global_feedback").covariance(x).numpy()
                        )
                        learned = {
                            mode: model.covariance(x, context, covariance).cpu().numpy()
                            for mode, model in encoders.items()
                        }
                    common = {
                        "x": x,
                        "covariance": covariance,
                        "priors": prediction.mean,
                        "probability": prediction.group_weights,
                        "fixed_prior": prediction.fixed_mean(),
                        "seed": seed,
                    }
                    for sut in SUT_IDS:
                        with np.load(folder / sut / "responses.npz") as bank:
                            np.testing.assert_array_equal(x, bank["x"])
                            risk = bank["risk"].copy()
                        for policy in variants(stage):
                            path = trace_path(stage, pool, sut, policy, seed)
                            if not path.exists():
                                task = {**common, "policy": policy, **VARIANTS[policy]}
                                if policy != "cg_brt":
                                    mode = (
                                        "conventional"
                                        if policy == "conventional_training"
                                        else "decision"
                                    )
                                    task["proposal_covariance"] = (
                                        covariance
                                        if policy == "physical_kernel"
                                        else learned[mode]
                                    )
                                started = time.perf_counter()
                                result = disclose_risk(parent, task, risk, process)
                                result.update(
                                    method=policy,
                                    stage=stage,
                                    pool=pool,
                                    sut=sut,
                                    seed=seed,
                                    selector_elapsed_s=time.perf_counter() - started,
                                )
                                write_json(path, result)
                            completed += 1
                            write_json(
                                ROOT
                                / (
                                    f"{stage}_status.json"
                                    if len(selection_seeds) == len(SEEDS)
                                    else f"{stage}_seed_{seed}_status.json"
                                ),
                                {
                                    "status": (
                                        "complete"
                                        if completed == planned
                                        else "running"
                                    ),
                                    "completed": completed,
                                    "planned": planned,
                                    "scope_seeds": list(selection_seeds),
                                },
                            )
                            print(
                                f"EVALUATE {stage} {completed}/{planned} {policy} pool={pool} sut={sut} seed={seed}",
                                flush=True,
                            )
    finally:
        if process.is_alive():
            parent.send(("stop", None))
        parent.close()
        process.join(timeout=15)
        if process.is_alive():
            process.terminate()
            process.join()
        if process.exitcode != 0:
            raise RuntimeError("Isolated selector worker failed")


def evaluate_seed(arguments):
    stage, seed = arguments
    main(stage, (seed,))


def run_parallel(stage="development", selection_seeds=SEEDS):
    planned = (
        len(pools(stage)) * len(selection_seeds) * len(SUT_IDS) * len(variants(stage))
    )
    write_json(
        ROOT / f"{stage}_status.json",
        {
            "status": "running",
            "scope_seeds": list(selection_seeds),
            "planned": planned,
        },
    )
    with ProcessPoolExecutor(
        max_workers=3, mp_context=mp.get_context("spawn")
    ) as executor:
        list(executor.map(evaluate_seed, [(stage, seed) for seed in selection_seeds]))
    write_json(
        ROOT / f"{stage}_status.json",
        {
            "status": "complete",
            "scope_seeds": list(selection_seeds),
            "completed": planned,
            "planned": planned,
        },
    )


if __name__ == "__main__":
    run_parallel()
