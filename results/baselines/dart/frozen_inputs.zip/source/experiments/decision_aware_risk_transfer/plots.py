"""Export quantitative figures directly from the declared comparison records."""

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from .config import ROOT


def plot_report(report):
    stage = report["stage"]
    aggregate = report["aggregate"]
    rows = report["rows"]
    figure, axes = plt.subplots(2, 2, figsize=(11, 7.5), constrained_layout=True)
    for policy in ("cg_brt", "full", "conventional_training", "greedy"):
        curves = np.asarray(
            [r["high_risk_curve"] for r in rows if r["policy"] == policy]
        )
        axes[0, 0].plot(np.arange(1, 201), curves.mean(0), label=policy)
    axes[0, 0].set(xlabel="Paid risk queries", ylabel="Mean high-risk discoveries")
    axes[0, 0].legend(fontsize=8)
    policies = list(aggregate)
    baseline = aggregate["cg_brt"]["H200"]
    ratios = [aggregate[p]["H200"] / baseline for p in policies]
    axes[0, 1].barh(
        policies,
        ratios,
        color=["#777777" if p == "cg_brt" else "#2678ad" for p in policies],
    )
    axes[0, 1].axvline(0.9, color="#c65b43", linestyle="--", label="Acceptance floor")
    axes[0, 1].set(
        xlabel="H200 / paired CG-BRT mean", xlim=(0, max(1.15, max(ratios) + 0.05))
    )
    axes[0, 1].legend(fontsize=8)
    full = [r for r in rows if r["policy"] == "full"]
    predicted = [r["posterior_same_history_loss"] for r in full]
    actual = [r["actual_same_history_loss"] for r in full]
    axes[1, 0].scatter(predicted, actual, alpha=0.7, s=22)
    bound = max([1.0, *predicted, *actual])
    axes[1, 0].plot([0, bound], [0, bound], color="#777777", linestyle="--")
    axes[1, 0].set(
        xlabel="Sum of predicted replacement losses",
        ylabel="Evaluator-only realized losses",
    )
    systems = list(report["by_sut"])
    system_retention = [
        report["by_sut"][s]["full"]["H200"] / report["by_sut"][s]["cg_brt"]["H200"]
        for s in systems
    ]
    axes[1, 1].barh(systems, system_retention, color="#2678ad")
    axes[1, 1].axvline(0.9, color="#c65b43", linestyle="--")
    axes[1, 1].set(
        xlabel="Per-system H200 retention",
        xlim=(0, max(1.15, max(system_retention) + 0.05)),
    )
    figure.suptitle(f"Decision-aware risk transfer: {stage}")
    figure.savefig(ROOT / f"{stage}_results.png", dpi=200)
    figure.savefig(ROOT / f"{stage}_results.pdf")
    plt.close(figure)
