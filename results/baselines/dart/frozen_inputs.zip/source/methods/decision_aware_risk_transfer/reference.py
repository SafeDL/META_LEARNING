"""Original CG-BRT advice, updated exclusively with the executed queries."""

import numpy as np

from methods.concordance_gated_bayesian_risk_transfer.decision import choose_candidate
from methods.concordance_gated_bayesian_risk_transfer.gate import (
    RankingGate,
    gated_log_probabilities,
)
from methods.concordance_gated_bayesian_risk_transfer.posterior import RiskPosterior
from methods.history_guided_testing.gp import clipped_risk_ei


class ReferencePolicy:
    def __init__(
        self,
        covariance,
        priors,
        probability,
        fixed_prior,
        seed,
        budget,
        initial_queries,
    ):
        self.model = RiskPosterior(covariance, priors, probability, fixed_prior)
        self.gate = RankingGate()
        self.seed, self.budget, self.initial_queries = seed, budget, initial_queries

    def recommend(self, remaining, step):
        self.transfer, self.reference = self.model.log_probabilities()
        self.gated = gated_log_probabilities(
            self.transfer, self.reference, self.gate.trust
        )
        if step < self.initial_queries:
            score = clipped_risk_ei(self.model.mean, self.model.variance, 0.0)
            score[~remaining] = -np.inf
            return int(np.argmax(score)), {"reason": "common_initialization"}
        return choose_candidate(
            self.model,
            remaining,
            self.gated,
            self.transfer,
            self.gate.trust,
            self.budget - step,
            19011 + self.seed + step,
            self.budget,
        )

    def observe(self, index, risk, high_risk):
        record = self.gate.observe(index, high_risk, self.transfer, self.reference)
        self.model.observe(index, risk)
        return {**self.model.evidence[-1], **record}
