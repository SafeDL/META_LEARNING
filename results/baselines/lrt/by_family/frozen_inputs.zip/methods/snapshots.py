"""Compare retained source snapshots after the package-name reorganization.

This mapping is used only by artifact verification. Runtime imports use the
current package names directly; the original archives remain unchanged.
"""

import re

RENAMES = (
    ("decision_aware_risk_transfer/selective", "lrt"),
    ("decision_aware_risk_transfer.selective", "lrt"),
    ("concordance_gated_bayesian_risk_transfer", "cg_brt"),
    ("decision_aware_risk_transfer", "dart"),
    ("history_guided_testing", "hgt"),
    ("historical_expert_mixture", "hem"),
    ("scale_adaptive_expert_mixture", "saem"),
)

BASELINES = ("cg_brt", "dart", "hem", "hgt", "ras_frt_uq", "response_baselines", "saem")


def current_path(name):
    for old, new in RENAMES:
        name = name.replace(old, new)
    for package in BASELINES:
        for area in ("methods", "tests"):
            name = name.replace(f"{area}/{package}", f"{area}/baselines/{package}")
            name = name.replace(f"{area}.{package}", f"{area}.baselines.{package}")
    for area in ("methods", "tests"):
        name = name.replace(f"{area}/baselines/cg_brt", f"{area}/lrt/cg_brt")
        name = name.replace(f"{area}.baselines.cg_brt", f"{area}.lrt.cg_brt")
    name = name.replace(
        "methods/baselines/dart/reference.py", "methods/lrt/cg_brt/reference.py"
    ).replace("methods.baselines.dart.reference", "methods.lrt.cg_brt.reference")
    return name


def current_source(data, name):
    """Apply the declared import/path edits to an original Python source."""
    if not name.endswith(".py"):
        return data
    source = current_path(data.decode("utf-8"))
    if current_path(name) == "methods/lrt/__init__.py":
        # Component imports must not eagerly load the full selector.
        source = source.splitlines()[0] + "\n"
    if current_path(name) == "methods/baselines/dart/selection.py":
        source = source.replace(
            "from .reference import ReferencePolicy",
            "from methods.lrt.cg_brt.reference import ReferencePolicy",
        )
    if current_path(name) == "methods/lrt/config.py":
        source = source.replace("parents[3]", "parents[2]")
    if current_path(name).startswith(("methods/baselines/", "methods/lrt/cg_brt/")):
        source = re.sub(
            r"Path\(__file__\)\.resolve\(\)\.parents\[(\d+)\]",
            lambda match: match.group(0).replace(
                f"[{match.group(1)}]", f"[{int(match.group(1)) + 1}]"
            ),
            source,
        )
    return source.encode("utf-8")
