"""Effectiveness, matched discovery costs and amortization by scenario family."""

import math

import numpy as np

from methods.baselines.hgt.io import read_json, write_json

from .by_family import BUDGET, INITIAL, METHODS, REUSE, ROOT, SUT_IDS, TARGET_FRACTIONS

NAMES = {
    "lrt": "本文方法 LRT",
    "cg_brt": "一致性门控贝叶斯风险迁移 CG-BRT",
    "dart": "决策相关风险迁移 DART",
    "hgt": "历史引导高斯过程风险测试 HGT",
    "gp_ei": "高斯过程期望改进 GP-EI",
    "rf_bo": "随机森林贝叶斯优化 RF-BO",
    "uniform_random": "均匀随机测试",
    "no_value_learning": "本文方法取消动作价值学习",
}
SYSTEMS = dict(zip(SUT_IDS, ("IDM", "FVDM", "MOBIL", "VI", "MCTS", "PPO")))


def mean(values):
    values = [value for value in values if value is not None]
    return float(np.mean(values)) if values else None


def hit_query(trace, fraction):
    if trace["positives"] == 0:
        return None
    target = math.ceil(fraction * min(trace["positives"], BUDGET))
    return next(
        (
            i + 1
            for i, count in enumerate(trace["found"])
            if i + 1 >= INITIAL and count >= target
        ),
        None,
    )


def construction_cost(ledger, method):
    if method in ("uniform_random", "gp_ei", "rf_bo"):
        return 0.0
    stages = ["kernel"]
    if method not in ("cg_brt", "hgt"):
        stages.append("encoder")
    if method == "lrt":
        stages.extend(("branch_labels", "value"))
    return sum(ledger["stages"][stage]["elapsed_s"] for stage in stages)


def pool_cost(preparation, method):
    if method in ("uniform_random", "gp_ei", "rf_bo"):
        return 0.0
    result = preparation["base"]
    if method not in ("cg_brt", "hgt"):
        result += preparation["encoder"]
    if method in ("lrt", "no_value_learning"):
        result += preparation["archive"]
    return result


def task_cost(trace, query):
    compute = trace["timing"]["task_initialization_s"] + sum(
        trace["timing"]["query_compute_s"][:query]
    )
    return {
        "compute_s": compute,
        "execution_s": sum(trace["execution_s"][:query]),
        "queries": query,
    }


def break_even(upfront_difference, recurring_saving):
    if recurring_saving > 0:
        return max(1, math.floor(upfront_difference / recurring_saving) + 1)
    if recurring_saving == 0 and upfront_difference < 0:
        return 1
    return None


def paired_costs(rows, build, preparation, baseline, fraction):
    pairs, outcomes = [], {
        "both_reached": 0,
        "lrt_only": 0,
        "baseline_only": 0,
        "neither": 0,
    }
    for pool in (0, 1, 2):
        for sut in SUT_IDS:
            left, right = rows[pool, sut, "lrt"], rows[pool, sut, baseline]
            a, b = hit_query(left, fraction), hit_query(right, fraction)
            outcome = (
                "both_reached"
                if a is not None and b is not None
                else (
                    "lrt_only"
                    if a is not None
                    else "baseline_only" if b is not None else "neither"
                )
            )
            outcomes[outcome] += 1
            if outcome != "both_reached":
                continue
            cost_a, cost_b = task_cost(left, a), task_cost(right, b)
            upfront_a = construction_cost(build, "lrt") + pool_cost(
                preparation[pool], "lrt"
            )
            upfront_b = construction_cost(build, baseline) + pool_cost(
                preparation[pool], baseline
            )
            recurring_a = cost_a["compute_s"] + cost_a["execution_s"]
            recurring_b = cost_b["compute_s"] + cost_b["execution_s"]
            pairs.append(
                {
                    "pool": pool,
                    "sut": sut,
                    "lrt_queries": a,
                    "baseline_queries": b,
                    "saved_queries": b - a,
                    "upfront_difference_s": upfront_a - upfront_b,
                    "recurring_saving_s": recurring_b - recurring_a,
                    "reuse": {
                        str(m): {
                            "lrt_s": upfront_a / m + recurring_a,
                            "baseline_s": upfront_b / m + recurring_b,
                            "saving_s": (upfront_b - upfront_a) / m
                            + recurring_b
                            - recurring_a,
                        }
                        for m in REUSE
                    },
                    "break_even_tasks": break_even(
                        upfront_a - upfront_b, recurring_b - recurring_a
                    ),
                    "equal_duration_break_even_s": (
                        max(
                            0.0,
                            (
                                (upfront_a - upfront_b) / 100
                                + cost_a["compute_s"]
                                - cost_b["compute_s"]
                            )
                            / (b - a),
                        )
                        if b > a
                        else None
                    ),
                }
            )
    upfront = mean([p["upfront_difference_s"] for p in pairs])
    recurring = mean([p["recurring_saving_s"] for p in pairs])
    reuse = {}
    for m in REUSE:
        a = mean([p["reuse"][str(m)]["lrt_s"] for p in pairs])
        b = mean([p["reuse"][str(m)]["baseline_s"] for p in pairs])
        reuse[str(m)] = {
            "lrt_s": a,
            "baseline_s": b,
            "saving_pct": 100 * (b - a) / b if b else None,
        }
    return {
        "baseline": baseline,
        "fraction": fraction,
        "outcomes": outcomes,
        "mean_saved_queries": mean([p["saved_queries"] for p in pairs]),
        "break_even_tasks": break_even(upfront, recurring) if pairs else None,
        "equal_duration_break_even_s": mean(
            [p["equal_duration_break_even_s"] for p in pairs]
        ),
        "reuse": reuse,
        "pairs": pairs,
    }


def verify_trace(trace):
    indices = trace["selected_indices"]
    if len(indices) != BUDGET or len(set(indices)) != BUDGET:
        raise ValueError("A formal trajectory must contain 200 unique paid queries")
    if len(trace["timing"]["query_compute_s"]) != BUDGET:
        raise ValueError("Missing per-query compute timings")
    expected = np.cumsum([row["risk"] > 0.5 for row in trace["queries"]]).tolist()
    if trace["found"] != expected:
        raise ValueError("Discovery curve differs from the disclosed risks")
    if trace["method"] in ("lrt", "dart", "no_value_learning"):
        charged = sum(d["loss_charged"] for d in trace["decisions"])
        if abs(charged + trace["loss_budget_remaining"] - 20) > 1e-7:
            raise ValueError("Replacement loss ledger does not balance")
        for decision in trace["decisions"][INITIAL:]:
            if (
                decision["selected_index"] != decision["reference_index"]
                and abs(
                    decision["loss_charged"] - decision["posterior_replacement_loss"]
                )
                > 1e-9
            ):
                raise ValueError("An executed deviation was not charged")


def historical_counts(folder):
    counts = {"behavior": 0, "branches": 0, "encoder_support": 0}
    for path in (folder / "historical").rglob("*.json"):
        data = read_json(path)
        if path.stem.endswith("_returns"):
            counts["branches"] += sum(
                row["paid_replay_queries"]
                for state in data.values()
                for row in state.values()
            )
        else:
            counts["behavior"] += len(data["queries"])
    for path in (folder / "encoder/historical_support").glob("*.json"):
        counts["encoder_support"] += len(read_json(path)["queries"])
    encoder = read_json(folder / "encoder/models/training_decision_11.json")
    value = read_json(folder / "models/training_full_11.json")
    counts["encoder_validation"] = sum(
        len(row["by_source"]) * 40 for row in encoder["curve"]
    )
    counts["value_validation"] = sum(len(row["rows"]) * 40 for row in value["curve"])
    counts["total_replay_queries"] = sum(counts.values())
    counts["physical_calls"] = 0
    write_json(folder / "historical_queries.json", counts)
    return counts


def family_summary(folder):
    build = read_json(folder / "build_cost.json")
    preparation = {
        pool: read_json(folder / "pool_cache" / f"pool_{pool}.json")
        for pool in (0, 1, 2)
    }
    rows = {}
    for pool in (0, 1, 2):
        for sut in SUT_IDS:
            for method in METHODS:
                trace = read_json(
                    folder / "trajectories" / f"pool_{pool}" / sut / f"{method}_11.json"
                )
                verify_trace(trace)
                rows[pool, sut, method] = trace
            starts = [
                rows[pool, sut, method]["selected_indices"][:INITIAL]
                for method in METHODS
            ]
            if any(start != starts[0] for start in starts):
                raise ValueError("Initialization differs between methods")
    effects = []
    for label, pools in (("original", (0, 1)), ("third", (2,)), ("all", (0, 1, 2))):
        for sut in (*SUT_IDS, "macro"):
            systems = SUT_IDS if sut == "macro" else (sut,)
            for method in METHODS:
                traces = [
                    rows[pool, system, method] for pool in pools for system in systems
                ]
                effects.append(
                    {
                        "scope": label,
                        "sut": sut,
                        "method": method,
                        "positives": mean([r["positives"] for r in traces]),
                        "H200": mean([r["H200"] for r in traces]),
                        "recall": mean([r["recall"] for r in traces]),
                    }
                )
    acceptance, differences = {}, []
    for scope in ("original", "third"):
        selected = {
            r["method"]: r
            for r in effects
            if r["scope"] == scope and r["sut"] == "macro"
        }
        acceptance[scope] = {
            "H200_retained": selected["lrt"]["H200"] / selected["cg_brt"]["H200"],
            "recall_retained": selected["lrt"]["recall"] / selected["cg_brt"]["recall"],
        }
        acceptance[scope]["accepted"] = min(acceptance[scope].values()) >= 0.9
    for baseline in ("cg_brt", "hgt"):
        for metric in ("H200", "recall"):
            pairs = [
                rows[p, s, "lrt"][metric] - rows[p, s, baseline][metric]
                for p in (0, 1, 2)
                for s in SUT_IDS
            ]
            differences.append(
                {
                    "baseline": baseline,
                    "metric": metric,
                    "mean_difference": mean(pairs),
                    "wins": sum(v > 1e-12 for v in pairs),
                    "ties": sum(abs(v) <= 1e-12 for v in pairs),
                    "losses": sum(v < -1e-12 for v in pairs),
                }
            )
    mechanism = []
    for pool in (0, 1, 2):
        for sut in SUT_IDS:
            trace = rows[pool, sut, "lrt"]
            mechanism.append(
                {
                    "pool": pool,
                    "sut": sut,
                    "replacements": sum(
                        d["selected_index"] != d["reference_index"]
                        for d in trace["decisions"]
                    ),
                    "spent_loss": 20 - trace["loss_budget_remaining"],
                    "different_queries_without_value": len(
                        set(trace["selected_indices"])
                        - set(rows[pool, sut, "no_value_learning"]["selected_indices"])
                    ),
                }
            )
    costs = [
        paired_costs(rows, build, preparation, method, fraction)
        for fraction in TARGET_FRACTIONS
        for method in METHODS
        if method != "lrt"
    ]
    fixed_costs = []
    for method in METHODS:
        for reuse in REUSE:
            values = []
            for pool in (0, 1, 2):
                for sut in SUT_IDS:
                    current = task_cost(rows[pool, sut, method], BUDGET)
                    values.append(
                        (
                            construction_cost(build, method)
                            + pool_cost(preparation[pool], method)
                        )
                        / reuse
                        + current["compute_s"]
                        + current["execution_s"]
                    )
            fixed_costs.append(
                {"method": method, "reuse": reuse, "mean_s": mean(values)}
            )
    curves = {
        method: np.mean(
            [rows[p, s, method]["found"] for p in (0, 1, 2) for s in SUT_IDS], axis=0
        ).tolist()
        for method in METHODS
    }
    result = {
        "family": folder.name,
        "trajectory_count": len(rows),
        "effects": effects,
        "build": build,
        "construction_s": {m: construction_cost(build, m) for m in METHODS},
        "pool_preparation": preparation,
        "costs": costs,
        "fixed_budget_costs": fixed_costs,
        "paired_differences": differences,
        "mechanism": mechanism,
        "acceptance": acceptance,
        "curves": curves,
    }
    write_json(folder / "summary.json", result)
    return result


def number(value, digits=2):
    return "—" if value is None else f"{value:.{digits}f}"


def render(families):
    lines = [
        "# 按功能场景独立测试：发现效果与完整成本",
        "",
        "切入、前车制动分别从本类历史构建模型。每条轨迹使用种子 11、200 次查询和共同的 10 次初始化。"
        "危险定义为实测风险 R>0.5。三个响应池均为已有场景池。",
        "",
        "成本采用同步实测的构建与计算时间，加上逐场景档案耗时重建串行等效执行时间。"
        "主情景为同类模型与同一候选池复用 100 个任务；复用次数是部署情景。",
        "",
    ]
    for result in families:
        title = "切入" if result["family"] == "cutin" else "前车制动"
        lines.extend((f"## {title}", ""))
        for scope, label in (("original", "原有两池平均"), ("third", "第三池")):
            lines.extend(
                (
                    f"### {label}",
                    "",
                    "| 系统 | 危险总数 | 方法 | H200 | Recall |",
                    "|---|---:|---|---:|---:|",
                )
            )
            for row in result["effects"]:
                if row["scope"] == scope:
                    lines.append(
                        f"| {SYSTEMS.get(row['sut'], '宏平均')} | {number(row['positives'], 1)} | {NAMES[row['method']]} | {number(row['H200'])} | {number(100 * row['recall'])}% |"
                    )
            gate = result["acceptance"][scope]
            lines.extend(
                (
                    "",
                    f"相对 CG-BRT，H200 保留 {gate['H200_retained']:.2%}、Recall 保留 {gate['recall_retained']:.2%}；"
                    + (
                        "达到预设 90% 门槛。"
                        if gate["accepted"]
                        else "本类结果未达到预设 90% 门槛。"
                    ),
                    "",
                )
            )
        lines.extend(
            ("### 从零构建成本", "", "| 阶段 | 时间（秒） | 占比 |", "|---|---:|---:|")
        )
        for stage, row in result["build"]["stages"].items():
            label = {
                "kernel": "基础核",
                "encoder": "编码器及历史支持轨迹",
                "branch_labels": "历史分支与训练特征",
                "value": "价值训练、自身状态补充与验证",
            }[stage]
            lines.append(
                f"| {label} | {row['elapsed_s']:.2f} | {row['elapsed_s'] / result['construction_s']['lrt']:.1%} |"
            )
        lines.extend(
            (
                f"| 本文完整方法合计 | {result['construction_s']['lrt']:.2f} | 100% |",
                "",
                "### 相同发现目标的成本",
                "",
                "目标取 ceil(比例 × min(池内危险总数, 200))。例如有 3 个危险场景时，主要目标为 3 个；"
                "有 770 个时，主要目标为 160 个。从第 10 次查询开始判定达标。"
                "下表时间只比较双方均达标的配对任务，同时完整列出未达标情况。",
                "",
                "| 比例 | 对照 | 双方达标 | 仅本文达标 | 仅对照达标 | 均未达标 | 平均少测次数 | 本文总秒/任务 | 对照总秒/任务 | 节省比例 | 回本任务数 |",
                "|---:|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|",
            )
        )
        for row in result["costs"]:
            outcomes, reuse = row["outcomes"], row["reuse"]["100"]
            lines.append(
                f"| {row['fraction']:.0%} | {NAMES[row['baseline']]} | {outcomes['both_reached']} | {outcomes['lrt_only']} | {outcomes['baseline_only']} | {outcomes['neither']} | {number(row['mean_saved_queries'])} | {number(reuse['lrt_s'])} | {number(reuse['baseline_s'])} | {number(reuse['saving_pct'])}% | {row['break_even_tasks'] or '无持续回本点'} |"
            )
        lines.extend(
            (
                "",
                "### 复用次数敏感性（主要发现目标）",
                "",
                "| 对照 | 复用次数 | 本文秒/任务 | 对照秒/任务 | 节省比例 |",
                "|---|---:|---:|---:|---:|",
            )
        )
        for row in result["costs"]:
            if row["fraction"] != 0.8 or row["baseline"] not in ("cg_brt", "hgt"):
                continue
            for reuse, costs in row["reuse"].items():
                lines.append(
                    f"| {NAMES[row['baseline']]} | {reuse} | {number(costs['lrt_s'])} | {number(costs['baseline_s'])} | {number(costs['saving_pct'])}% |"
                )
            lines.extend(
                (
                    "",
                    f"相对 {row['baseline']}，在本文少测的配对任务上，按统一单次执行耗时计算的平均收支平衡点为 "
                    f"{number(row['equal_duration_break_even_s'])} 秒/次。",
                    "",
                )
            )
        lines.extend(
            (
                f"平均每条轨迹偏离参照 {mean([r['replacements'] for r in result['mechanism']]):.2f} 次；"
                f"取消价值学习后，平均有 {mean([r['different_queries_without_value'] for r in result['mechanism']]):.2f} 个查询发生变化。",
                "",
                f"发现曲线：[图片]({result['family']}/discovery.png)。完整逐任务成本、达标状态和配对差异见本类 summary.json。",
                "",
            )
        )
        if "historical_validation" in result:
            validation = result["historical_validation"]
            lines.extend(
                (
                    f"历史验证选中第 {validation['selected_step']} 次更新的价值网络；"
                    f"H40={validation['validation']['H40']:.2f}，覆盖率={validation['validation']['recall']:.2%}，"
                    f"归一化收益差预测误差={validation['validation']['gain_mse']:.6f}。",
                    (
                        "满足历史检查点条件。"
                        if validation["validation"]["eligible"]
                        else "保留验证误差最小的诊断模型，未达到历史检查点条件。"
                    ),
                    "",
                )
            )
    lines.extend(
        (
            "## 使用说明",
            "",
            "H200 和 Recall 是主要效果指标。等发现目标的成本由完整轨迹前缀复算，"
            "不向选择器提供池内危险总数。未达标任务保留在达标率统计中。负节省比例表示在当前耗时条件下总成本更高。"
            "更换候选池需要重新支付该池准备费用；更换同类被测版本复用既有模型与池缓存。",
            "",
        )
    )
    return "\n".join(lines)


def main():
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    families = [family_summary(ROOT / family) for family in ("cutin", "brake")]
    for result in families:
        result["historical_replay"] = historical_counts(ROOT / result["family"])
        training = read_json(ROOT / result["family"] / "models/training_full_11.json")
        result["historical_validation"] = next(
            row for row in reversed(training["curve"]) if row["selected"]
        )
        result["historical_validation"]["selected_step"] = result[
            "historical_validation"
        ]["step"]
        write_json(ROOT / result["family"] / "summary.json", result)
        fig, ax = plt.subplots(figsize=(8, 5))
        for method, values in result["curves"].items():
            label = {
                "lrt": "LRT",
                "cg_brt": "CG-BRT",
                "dart": "DART",
                "hgt": "HGT",
                "gp_ei": "GP-EI",
                "rf_bo": "RF-BO",
                "uniform_random": "Random",
                "no_value_learning": "LRT without value learning",
            }[method]
            ax.plot(np.arange(1, BUDGET + 1), values, label=label)
        ax.set(
            xlabel="Paid queries",
            ylabel="Dangerous scenarios found",
            title="Cut-in" if result["family"] == "cutin" else "Lead-vehicle braking",
        )
        ax.legend(fontsize=8)
        ax.grid(alpha=0.2)
        fig.tight_layout()
        fig.savefig(ROOT / result["family"] / "discovery.png", dpi=180)
        plt.close(fig)
    (ROOT / "comparison.md").write_text(render(families), encoding="utf-8")
    write_json(
        ROOT / "comparison.json",
        {
            "families": families,
            "physical_calls": 0,
            "trajectories": sum(r["trajectory_count"] for r in families),
        },
    )


if __name__ == "__main__":
    main()
