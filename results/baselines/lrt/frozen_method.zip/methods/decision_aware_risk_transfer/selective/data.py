"""Historical pseudo-target tasks, branch labels and continuation features."""

from concurrent.futures import ProcessPoolExecutor
import multiprocessing as mp
import time

import numpy as np
import torch
from threadpoolctl import threadpool_limits

from methods.concordance_gated_bayesian_risk_transfer import select as cg_select
from methods.decision_aware_risk_transfer.encoder import fixed_context
from methods.decision_aware_risk_transfer.selection import select as previous_select
from methods.decision_aware_risk_transfer.train import HistoricalOracle, load_encoder
from methods.historical_expert_mixture.experts import HistoricalExperts
from methods.history_guided_testing.config import PROFILES, group_of
from methods.history_guided_testing.history import load_history, split_indices, subset
from methods.history_guided_testing.io import read_json, write_json
from methods.history_guided_testing.train import load_kernel

from .config import (
    ARCHIVES,
    ROOT,
    SEEDS,
    TRAIN_BUDGET,
    TRAIN_INITIAL,
    TRAIN_MODES,
    TRAIN_STATES,
    VALID_BUDGET,
    VALID_INITIAL,
    VALID_STATES,
    options,
)
from .posterior import model_set
from .prior import build_prior, visible_history
from .teacher import branch_return, replay_reference, training_candidates
from .value import make_features


def assemble(x, sources, seed):
    sources = {
        profile.name: sources[profile.name]
        for profile in PROFILES
        if profile.name in sources
    }
    prediction = HistoricalExperts(sources).predict(x)
    with torch.no_grad():
        base = load_kernel(seed, "global_feedback").covariance(x).numpy()
        encoder = load_encoder(
            seed, device="cuda" if torch.cuda.is_available() else "cpu"
        )
        enhanced = (
            encoder.covariance(x, fixed_context(sources, seed), base).cpu().numpy()
        )
    common = {
        "x": x,
        "covariance": base,
        "priors": prediction.mean,
        "probability": prediction.group_weights,
        "fixed_prior": prediction.fixed_mean(),
        "seed": seed,
    }
    return common, build_prior(x, sources, enhanced)


def historical_case(name, condition, seed, split):
    history = load_history()
    x = history[name]["x"]
    train, validation = split_indices(x)
    indices = train if split == "train" else validation
    sources = {
        key: value
        for key, value in subset(history, train).items()
        if group_of(key) != group_of(name)
    }
    sources = visible_history(sources, condition, seed)
    common, prior = assemble(x[indices], sources, seed)
    return common, prior, history[name]["risk"][indices]


def task_settings(split):
    return (
        (TRAIN_BUDGET, TRAIN_INITIAL, TRAIN_STATES)
        if split == "train"
        else (VALID_BUDGET, VALID_INITIAL, VALID_STATES)
    )


def behavior_trace(common, prior, truth, name, condition, split, behavior):
    path = (
        ROOT
        / "historical"
        / str(common["seed"])
        / split
        / f"{name}_{condition}_{behavior}.json"
    )
    if path.exists():
        return read_json(path), path
    budget, initial, _ = task_settings(split)
    selector = cg_select if behavior == "cg_brt" else previous_select
    kwargs = (
        {}
        if behavior == "cg_brt"
        else {"proposal_covariance": prior.enhanced_covariance}
    )
    result = selector(
        **common,
        oracle=HistoricalOracle(truth),
        budget=budget,
        initial_queries=initial,
        **kwargs,
    )
    result.update(
        pseudo_target=name, condition=condition, split=split, behavior=behavior
    )
    write_json(path, result)
    return result, path


def dataset_path(seed, mode, split, name, condition, behavior):
    return (
        ROOT
        / "datasets"
        / str(seed)
        / mode
        / split
        / f"{name}_{condition}_{behavior}.pt"
    )


def records_for_trace(
    common, prior, truth, trace, label_path, mode, states, budget, initial
):
    labels = read_json(label_path) if label_path.exists() else {}
    models = model_set(prior, **options(mode))
    anchor, remaining = replay_reference(common, [], budget, initial)
    records = []
    for step, observation in enumerate(trace["queries"]):
        reference_index, _ = anchor.recommend(remaining, step)
        if step in states:
            seed = 630031 + common["seed"] + step
            candidates = training_candidates(
                models, remaining, np.exp(anchor.gated[0]), reference_index, seed
            )
            label = labels.setdefault(str(step), {})
            for index in candidates:
                key = str(index)
                if key not in label:
                    found, selected = branch_return(
                        anchor, remaining, int(index), truth
                    )
                    label[key] = {"found": found, "paid_replay_queries": len(selected)}
            write_json(label_path, labels)
            losses = np.stack(
                [model.losses(candidates, reference_index) for model in models]
            )
            features = make_features(
                models,
                remaining,
                candidates,
                np.exp(anchor.gated[0]),
                anchor.gate.trust,
                budget - step,
                step,
                losses,
                seed,
            )
            records.append(
                {
                    "features": features,
                    "returns": [label[str(i)]["found"] for i in candidates],
                    "reference_position": int(
                        np.flatnonzero(candidates == reference_index)[0]
                    ),
                    "candidate_indices": candidates.tolist(),
                    "step": step,
                }
            )
        index, risk = observation["index"], observation["risk"]
        anchor.observe(index, risk, risk > 0.5)
        for model in models:
            model.observe(index, risk)
        remaining[index] = False
    return records


def generate_case(task):
    seed, name, condition, split = task
    torch.set_num_threads(1)
    with threadpool_limits(limits=1):
        paths = [
            dataset_path(seed, mode, split, name, condition, behavior)
            for behavior in ("cg_brt", "previous")
            for mode in TRAIN_MODES
        ]
        if all(p.exists() for p in paths):
            return task
        common, prior, truth = historical_case(name, condition, seed, split)
        budget, initial, states = task_settings(split)
        for behavior in ("cg_brt", "previous"):
            trace, path = behavior_trace(
                common, prior, truth, name, condition, split, behavior
            )
            label_path = path.with_name(path.stem + "_returns.json")
            for mode in TRAIN_MODES:
                destination = dataset_path(seed, mode, split, name, condition, behavior)
                if destination.exists():
                    continue
                records = records_for_trace(
                    common,
                    prior,
                    truth,
                    trace,
                    label_path,
                    mode,
                    states,
                    budget,
                    initial,
                )
                destination.parent.mkdir(parents=True, exist_ok=True)
                torch.save(
                    {
                        "pseudo_target": name,
                        "group": group_of(name),
                        "condition": condition,
                        "behavior": behavior,
                        "mode": mode,
                        "records": records,
                    },
                    destination,
                )
                print(
                    f"DATA {seed} {split} {name} {condition} {behavior} {mode}",
                    flush=True,
                )
    return task


def generate(seed):
    tasks = [
        (seed, name, condition, split)
        for split in ("train", "validation")
        for name in load_history()
        for condition in ARCHIVES
    ]
    started = time.perf_counter()
    with ProcessPoolExecutor(
        max_workers=4, mp_context=mp.get_context("spawn")
    ) as executor:
        for count, task in enumerate(executor.map(generate_case, tasks), 1):
            write_json(
                ROOT / "data_status.json",
                {
                    "status": "complete" if count == len(tasks) else "running",
                    "seed": seed,
                    "completed_cases": count,
                    "planned_cases": len(tasks),
                    "last_case": list(task),
                    "elapsed_s": time.perf_counter() - started,
                },
            )


def generate_on_policy(task):
    seed, mode, name, condition = task
    destination = dataset_path(seed, mode, "train", name, condition, "on_policy")
    if destination.exists():
        return
    from .selection import select
    from .value import ContinuationValue

    torch.set_num_threads(1)
    with threadpool_limits(limits=1):
        common, prior, truth = historical_case(name, condition, seed, "train")
        network = ContinuationValue().to("cuda" if torch.cuda.is_available() else "cpu")
        weights = torch.load(
            ROOT / "models" / f"on_policy_{mode}_{seed}.pt",
            weights_only=True,
            map_location=next(network.parameters()).device,
        )
        network.load_state_dict(weights)
        network.eval().requires_grad_(False)
        records = []

        def capture(step, models, anchor, remaining, reference_index):
            if step not in TRAIN_STATES:
                return
            sampling_seed = 630031 + seed + step
            candidates = training_candidates(
                models,
                remaining,
                np.exp(anchor.gated[0]),
                reference_index,
                sampling_seed,
            )
            returns = [
                branch_return(anchor, remaining, int(index), truth)[0]
                for index in candidates
            ]
            losses = np.stack([m.losses(candidates, reference_index) for m in models])
            features = make_features(
                models,
                remaining,
                candidates,
                np.exp(anchor.gated[0]),
                anchor.gate.trust,
                TRAIN_BUDGET - step,
                step,
                losses,
                sampling_seed,
            )
            records.append(
                {
                    "features": features,
                    "returns": returns,
                    "reference_position": int(
                        np.flatnonzero(candidates == reference_index)[0]
                    ),
                    "candidate_indices": candidates.tolist(),
                    "step": step,
                }
            )

        result = select(
            **common,
            oracle=HistoricalOracle(truth),
            transfer_prior=prior,
            value_model=network,
            budget=TRAIN_BUDGET,
            initial_queries=TRAIN_INITIAL,
            variant=mode,
            on_state=capture,
        )
        write_json(
            ROOT
            / "historical"
            / str(seed)
            / "train"
            / f"{name}_{condition}_on_policy_{mode}.json",
            result,
        )
        destination.parent.mkdir(parents=True, exist_ok=True)
        torch.save(
            {
                "pseudo_target": name,
                "group": group_of(name),
                "condition": condition,
                "behavior": "on_policy",
                "mode": mode,
                "records": records,
            },
            destination,
        )
        print(f"ON_POLICY {seed} {mode} {name} {condition}", flush=True)


def collect_on_policy(seed, mode):
    tasks = [
        (seed, mode, name, condition)
        for name in load_history()
        for condition in ARCHIVES
    ]
    with ProcessPoolExecutor(
        max_workers=2, mp_context=mp.get_context("spawn")
    ) as executor:
        list(executor.map(generate_on_policy, tasks))


def main():
    for seed in SEEDS:
        generate(seed)


if __name__ == "__main__":
    main()
