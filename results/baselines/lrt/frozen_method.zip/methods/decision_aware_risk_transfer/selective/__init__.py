"""Local historical transfer with learned CG-BRT continuation values."""

from .selection import select

__all__ = ["select"]
