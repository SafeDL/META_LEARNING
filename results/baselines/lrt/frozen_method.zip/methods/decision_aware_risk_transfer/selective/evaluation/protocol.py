"""Immutable baseline verification and a dated, explicit experiment protocol."""

from datetime import datetime
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

from methods.decision_aware_risk_transfer.evaluation.freeze import verify_freeze
from methods.history_guided_testing.io import read_json, write_json

from ..config import ARCHIVES, MODELS, ROOT, SEEDS, TRAIN_MODES, VARIANTS

PROJECT = Path(__file__).resolve().parents[4]


def initialize():
    baseline = verify_freeze()
    path = ROOT / "protocol.json"
    if path.exists():
        return read_json(path)
    protocol = {
        "created_at": datetime.now().isoformat(),
        "method": "local transfer and CG-BRT continuation learning",
        "metrics": ["H200", "high_risk_recall_pct"],
        "retention_floor": 0.9,
        "budget": 200,
        "initial_queries": 10,
        "loss_budget": 20,
        "model_set": MODELS,
        "seeds": SEEDS,
        "training_variants": TRAIN_MODES,
        "variants": VARIANTS,
        "training_archives": ARCHIVES,
        "new_physical_calls": 0,
        "existing_pools": [0, 1, 2],
        "all_target_pools_are_previously_observed": True,
        "target_results_select_weights": False,
        "baseline_frozen_sources": len(baseline["decision_source_files"]),
        "stress_interpretation": "Deployment archive visibility changes; pretrained representations remain frozen",
        "guarantee_scope": "Conditional error bounds; empirical validation does not certify target conditional coverage",
    }
    write_json(path, protocol)
    return protocol


def freeze():
    initialize()
    destination = ROOT / "frozen_method.zip"
    sources = sorted(
        (PROJECT / "methods/decision_aware_risk_transfer/selective").rglob("*.py")
    )
    weights = [
        ROOT / "models" / f"{mode}_{seed}.pt" for mode in TRAIN_MODES for seed in SEEDS
    ]
    if destination.exists():
        with ZipFile(destination) as archive:
            for path in sources + weights:
                if (
                    archive.read(path.relative_to(PROJECT).as_posix())
                    != path.read_bytes()
                ):
                    raise ValueError(f"Frozen selective input changed: {path}")
        return
    for mode in TRAIN_MODES:
        for seed in SEEDS:
            report = read_json(ROOT / "models" / f"training_{mode}_{seed}.json")
            if report["status"] != "complete" or report["executed_steps"] != 4000:
                raise ValueError(
                    "Target evaluation requires all historical training updates"
                )
    with ZipFile(destination, "w", ZIP_DEFLATED) as archive:
        for path in sources + weights:
            archive.write(path, path.relative_to(PROJECT).as_posix())
        archive.write(ROOT / "protocol.json", "protocol.json")
