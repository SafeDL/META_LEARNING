"""Risk-isolated replay of traces archived before the exact CDF acceleration."""

from concurrent.futures import ProcessPoolExecutor
import json
import multiprocessing as mp
import time
from zipfile import ZipFile

import numpy as np
import torch
from threadpoolctl import threadpool_limits

from methods.driving_benchmark.risk_channel import disclose_risk
from methods.history_guided_testing.history import load_history, split_indices, subset
from methods.history_guided_testing.io import write_json

from ..config import ROOT
from ..data import assemble
from ..train import load_value
from .evaluate import bank_path, selector_worker

ARCHIVE = ROOT / "implementation_checks" / "cdf_original_traces.zip"


def reproduce(relative_path):
    with ZipFile(ARCHIVE) as archive:
        original = json.loads(archive.read(relative_path))
    pool, sut, seed = (original[k] for k in ("pool", "sut", "seed"))
    torch.set_num_threads(1)
    with threadpool_limits(limits=1):
        history = load_history()
        train, _ = split_indices(next(iter(history.values()))["x"])
        with np.load(bank_path(pool, sut)) as bank:
            x, risk = bank["x"].copy(), bank["risk"].copy()
        common, prior = assemble(x, subset(history, train), seed)
        parent, child = mp.get_context("spawn").Pipe()
        process = mp.get_context("spawn").Process(target=selector_worker, args=(child,))
        process.start()
        child.close()
        task = {
            **common,
            "policy": "full",
            "variant": "full",
            "transfer_prior": prior,
            "value_model": load_value(seed),
        }
        started = time.perf_counter()
        try:
            result = disclose_risk(parent, task, risk, process)
            elapsed = time.perf_counter() - started
        finally:
            if process.is_alive():
                parent.send(("stop", None))
            parent.close()
            process.join(timeout=15)
            if process.is_alive():
                process.terminate()
                process.join()
        assert process.exitcode == 0
    assert result["selected_indices"] == original["selected_indices"]
    assert result["queries"] == original["queries"]
    maximum = 0.0
    for actual, expected in zip(result["decisions"], original["decisions"]):
        for key in (
            "reference_index",
            "candidate_indices",
            "candidate_feasible",
            "loss_charged",
            "source_weights",
        ):
            assert actual.get(key) == expected.get(key), key
        first = np.asarray(actual.get("candidate_values", []), dtype=float)
        second = np.asarray(expected.get("candidate_values", []), dtype=float)
        finite = np.isfinite(first)
        np.testing.assert_array_equal(finite, np.isfinite(second))
        if finite.any():
            maximum = max(maximum, float(np.max(abs(first[finite] - second[finite]))))
    assert maximum == 0.0
    result.update(
        **{k: original[k] for k in ("pool", "sut", "seed", "condition", "method")},
        selector_elapsed_s=elapsed,
        numerical_backend="integer_student_cdf",
    )
    check = {
        "pool": pool,
        "sut": sut,
        "seed": seed,
        "queries_equal": True,
        "reference_and_loss_ledgers_equal": True,
        "maximum_value_difference": maximum,
        "original_runtime_s": original["selector_elapsed_s"],
        "optimized_runtime_s": elapsed,
    }
    print(f"CDF_REPLAY {pool} {sut} {seed} identical", flush=True)
    return relative_path, result, check


def main():
    with ZipFile(ARCHIVE) as archive:
        names = archive.namelist()
    with ProcessPoolExecutor(
        max_workers=6, mp_context=mp.get_context("spawn")
    ) as executor:
        results = list(executor.map(reproduce, names))
    for relative, trace, _ in results:
        write_json(ROOT / relative, trace)
    write_json(
        ROOT / "implementation_checks" / "cdf_trajectory_equivalence.json",
        {
            "status": "complete",
            "trajectories": len(results),
            "queries": len(results) * 200,
            "checks": [r[2] for r in results],
            "weights_or_statistical_settings_changed": False,
            "original_traces_retained": ARCHIVE.name,
        },
    )


if __name__ == "__main__":
    main()
