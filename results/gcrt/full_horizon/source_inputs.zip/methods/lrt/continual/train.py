"""Historical count training, causal correction and one selective-label update."""

import copy

import numpy as np
import torch

from methods.baselines.hgt.io import read_json, write_json
from methods.driving_benchmark.timing import now
from methods.lrt.adaptive.model import count_log_prob, expected_count

from .config import (
    BATCH_SIZE,
    LEARNING_RATE,
    ROOT,
    SEED,
    TRAIN_STEPS,
    UPDATE_STEPS,
    horizons,
)
from .controller import StopController, block_scores, threshold
from .data import load_tasks, returns
from .model import RemainingDiscoveries, log_pmf, tilted_log_pmf, weighted_loss


def balanced(rows, field):
    groups = sorted({r["group"] for r in rows})
    return float(
        np.mean([np.mean([r[field] for r in rows if r["group"] == g]) for g in groups])
    )


@torch.no_grad()
def validate(network, tasks):
    network.eval()
    rows = []
    for task in tasks:
        nll, mse = [], []
        for state in task["records"]:
            lengths, truth = returns(task, state)
            parameters = network.predict(state, lengths)
            y = parameters.new_tensor(truth)
            nll.append(float(-count_log_prob(parameters, lengths, y).mean().cpu()))
            mse.append(
                float(
                    (
                        (
                            (expected_count(parameters, lengths) - y)
                            / parameters.new_tensor(lengths)
                        )
                        ** 2
                    )
                    .mean()
                    .cpu()
                )
            )
        rows.append({"group": task["group"], "nll": np.mean(nll), "mse": np.mean(mse)})
    return {key: balanced(rows, key) for key in ("nll", "mse")}


def sample_task(tasks, generator):
    group = generator.choice(sorted({t["group"] for t in tasks}))
    sources = sorted({t["source"] for t in tasks if t["group"] == group})
    source = generator.choice(sources)
    choices = [t for t in tasks if t["source"] == source]
    return choices[generator.integers(len(choices))]


@torch.no_grad()
def cache_features(network, tasks):
    network.eval()
    for task in tasks:
        for state in task["records"]:
            if "encoded" not in state:
                lengths = horizons(state["budget"] - state["step"])
                state["encoded"] = network.features(state, lengths).detach()
                state["encoded_lengths"] = lengths


@torch.no_grad()
def forecast_task(network, task, penalty, *, correction=True):
    controller = StopController(network, 1.0, penalty, correction=correction)
    forecast, nll = [], []
    for state, label in zip(task["records"], task["labels"]):
        if state["step"] >= task["initial"]:
            row = controller.evaluate_state(state)
            lengths, truth = returns(task, state)
            parameters = network.predict(state, lengths)
            losses = []
            for p, b, y in zip(parameters, lengths, truth):
                distribution = tilted_log_pmf(log_pmf(p, b), controller.u)
                losses.append(float(-distribution[y].cpu()))
            row["count_nll"] = float(np.mean(losses))
            nll.append(row["count_nll"])
            forecast.append(row)
        base = log_pmf(network.predict(state, [1])[0], 1)
        controller.pending = float((base[1] - base[0]).cpu())
        controller.observe(float(label), state["step"] + 1)
    return {
        "forecast": forecast,
        "full_found": int(task["labels"].sum()),
        "group": task.get("group", task.get("sut")),
        "source": task.get("source"),
        "sut": task.get("sut"),
        "count_nll": float(np.mean(nll)) if nll else 0.0,
    }


def train(workspace):
    folder = ROOT / workspace.root.name
    torch.manual_seed(SEED)
    generator = np.random.default_rng(SEED)
    device = "cuda" if torch.cuda.is_available() else "cpu"
    network = RemainingDiscoveries().to(device)
    optimizer = torch.optim.AdamW(network.parameters(), lr=LEARNING_RATE)
    training = load_tasks(workspace.root.name, "train")
    validation = load_tasks(workspace.root.name, "validation")
    best, curve = None, []
    for step in range(1, TRAIN_STEPS + 1):
        network.train()
        optimizer.zero_grad()
        losses = []
        for _ in range(BATCH_SIZE):
            task = sample_task(training, generator)
            state = task["records"][generator.integers(len(task["records"]))]
            lengths, truth = returns(task, state)
            losses.append(
                weighted_loss(network.predict(state, lengths), lengths, truth)
            )
        torch.stack(losses).mean().backward()
        torch.nn.utils.clip_grad_norm_(network.parameters(), 5)
        optimizer.step()
        if step % 400 == 0:
            score = validate(network, validation)
            row = {"step": step, **score}
            curve.append(row)
            key = (score["nll"], score["mse"], step)
            if best is None or key < best:
                best = key
                torch.save(network.state_dict(), folder / "model.pt")
            print(
                f"COUNT {workspace.root.name} {step} NLL={score['nll']:.4f}", flush=True
            )
    network.load_state_dict(
        torch.load(folder / "model.pt", map_location=device, weights_only=True)
    )
    network.eval().requires_grad_(False)
    cache_features(network, validation)
    penalties = []
    for penalty in (0.1, 1.0, 10.0):
        forecasts = [forecast_task(network, task, penalty) for task in validation]
        penalties.append(
            {
                "penalty": penalty,
                "nll": balanced(forecasts, "count_nll"),
                "gamma": threshold(block_scores(forecasts).values()),
            }
        )
    chosen = min(penalties, key=lambda row: (row["nll"], row["penalty"]))
    write_json(
        folder / "training.json",
        {
            "status": "complete",
            "selected_step": best[2],
            "curve": curve,
            "penalty": chosen["penalty"],
            "collection_threshold": chosen["gamma"],
            "penalty_validation": penalties,
            "collection_threshold_scope": "historical budget-40 empirical threshold only",
        },
    )


def load_network(family, updated=False):
    network = RemainingDiscoveries().to("cuda" if torch.cuda.is_available() else "cpu")
    path = ROOT / family / ("updated.pt" if updated else "model.pt")
    network.load_state_dict(
        torch.load(
            path, map_location=next(network.parameters()).device, weights_only=True
        )
    )
    return network.eval().requires_grad_(False)


def update(family, incoming):
    started = now()
    folder = ROOT / family
    generator = np.random.default_rng(SEED)
    torch.manual_seed(SEED)
    network = load_network(family)
    network.head.requires_grad_(True)
    network.freeze_representation()
    old, validation = load_tasks(family, "train"), load_tasks(family, "validation")
    cache_features(network, [*old, *validation, *incoming])
    best_score = validate(network, validation)
    best = (best_score["nll"], best_score["mse"], 0)
    selected = copy.deepcopy(network.state_dict())
    optimizer = torch.optim.AdamW(network.head.parameters(), lr=LEARNING_RATE)
    curve = [{"step": 0, **best_score}]
    for step in range(1, UPDATE_STEPS + 1):
        optimizer.zero_grad()
        losses = []
        for slot in range(BATCH_SIZE):
            if slot < BATCH_SIZE // 2:
                task = sample_task(old, generator)
                state = task["records"][generator.integers(task["budget"])]
                lengths, truth = returns(task, state)
                loss = weighted_loss(network.predict(state, lengths), lengths, truth)
            else:
                sut = generator.choice(sorted({t["sut"] for t in incoming}))
                choices = [t for t in incoming if t["sut"] == sut]
                task = choices[generator.integers(len(choices))]
                t = int(generator.integers(task["budget"]))
                if t >= len(task["records"]):
                    # Missing states have zero contribution, not a zero count label.
                    losses.append(next(network.head.parameters()).sum() * 0)
                    continue
                state = task["records"][t]
                lengths = horizons(task["budget"] - t)
                visible = [t + b <= len(task["labels"]) for b in lengths]
                truth = [
                    int(task["labels"][t : t + b].sum()) if v else 0
                    for b, v in zip(lengths, visible)
                ]
                probability = [
                    1.0 if t + b <= task["natural_stop"] else 0.5 for b in lengths
                ]
                loss = weighted_loss(
                    network.predict(state, lengths),
                    lengths,
                    truth,
                    visible,
                    probability,
                )
            losses.append(loss)
        torch.stack(losses).mean().backward()
        torch.nn.utils.clip_grad_norm_(network.head.parameters(), 5)
        optimizer.step()
        if step % 200 == 0:
            score = validate(network, validation)
            curve.append({"step": step, **score})
            key = (score["nll"], score["mse"], step)
            if key < best:
                best, selected = key, copy.deepcopy(network.state_dict())
    torch.save(selected, folder / "updated.pt")
    report = {
        "selected_step": best[2],
        "curve": curve,
        "elapsed_s": now() - started,
        "training_controllers": sorted({t["sut"] for t in incoming}),
        "complete_probability": 0.5,
        "updates": UPDATE_STEPS,
    }
    write_json(folder / "update.json", report)
    return report
