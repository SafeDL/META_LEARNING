"""Causal state records; future counts live only in offline task labels."""

import numpy as np
import torch

from methods.baselines.dart.train import HistoricalOracle
from methods.baselines.hgt.config import group_of
from methods.baselines.hgt.io import read_json, write_json
from methods.driving_benchmark.timing import now
from methods.lrt.data import historical_case, task_settings

from .config import ROOT, SEED, horizons
from .model import snapshot
from .selection import select


class StateRecorder:
    def __init__(self, clock=None):
        self.records = []
        self.clock = clock
        self.seconds = []

    def before_query(self, index, **context):
        started = now()
        self.records.append(snapshot(index=index, **context))
        elapsed = now() - started
        self.seconds.append(elapsed)
        if self.clock is not None:
            self.clock.paused += elapsed


def save_task(path, records, trace, **metadata):
    labels = np.asarray([q["risk"] > 0.5 for q in trace["queries"]], dtype=np.int64)
    path.parent.mkdir(parents=True, exist_ok=True)
    torch.save({"records": records, "labels": labels, **metadata}, path)


def generate(workspace):
    folder = ROOT / workspace.root.name
    parameters = read_json(folder / "prior.json")["selected"]
    for split in ("train", "validation"):
        budget, initial, _ = task_settings(split)
        for name in workspace.history:
            for condition in workspace.archives:
                path = folder / "historical" / split / f"{name}_{condition}.pt"
                if path.exists() and path.with_suffix(".json").exists():
                    continue
                started = now()
                common, prior, truth = historical_case(
                    name, condition, SEED, split, workspace=workspace
                )
                recorder = StateRecorder()
                trace = select(
                    prior,
                    HistoricalOracle(truth),
                    seed=SEED,
                    budget=budget,
                    initial_indices=common["initial_indices"],
                    recorder=recorder,
                    **parameters,
                )
                save_task(
                    path,
                    recorder.records,
                    trace,
                    source=name,
                    group=group_of(name),
                    split=split,
                    condition=condition,
                    budget=budget,
                    initial=initial,
                    positives=int((truth > 0.5).sum()),
                )
                write_json(
                    path.with_suffix(".json"),
                    {
                        "selected_indices": trace["selected_indices"],
                        "queries": trace["queries"],
                        "elapsed_s": now() - started,
                        "physical_calls": 0,
                        "budget": budget,
                    },
                )
                print(
                    f"HISTORY {workspace.root.name} {split} {name} {condition}",
                    flush=True,
                )


def load_tasks(family, split):
    return [
        torch.load(p, map_location="cpu", weights_only=False)
        for p in sorted((ROOT / family / "historical" / split).glob("*.pt"))
    ]


def returns(task, state):
    t = state["step"]
    lengths = horizons(state["budget"] - t)
    labels = task["labels"]
    return lengths, [int(labels[t : t + b].sum()) for b in lengths]
