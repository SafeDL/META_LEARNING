"""Audit retained sources after package moves and declared API extensions.

This mapping is used only by artifact verification. Runtime imports use the
current package names directly; the original archives remain unchanged.
"""

import re
from pathlib import Path
from zipfile import ZipFile


API_EXTENSIONS = {
    "methods/baselines/dart/encoder.py",
    "methods/baselines/dart/objectives.py",
    "methods/baselines/dart/selection.py",
    "methods/baselines/dart/train.py",
    "methods/baselines/hgt/baseline.py",
    "methods/baselines/hgt/search.py",
    "methods/baselines/hgt/train.py",
    "methods/lrt/data.py",
    "methods/lrt/prior.py",
    "methods/lrt/selection.py",
    "methods/lrt/teacher.py",
    "methods/lrt/train.py",
    "methods/lrt/cg_brt/reference.py",
    "methods/lrt/cg_brt/selection.py",
}
ADDED_SOURCES = {
    "methods/driving_benchmark/initialization.py",
    "methods/driving_benchmark/timing.py",
    "methods/lrt/workspace.py",
}
ADAPTIVE_INTERFACES = {
    "methods/lrt/selection.py",
    "methods/driving_benchmark/timing.py",
    "methods/driving_benchmark/risk_channel.py",
}


def verify_source(project, relative, original):
    """Check original bytes or the declared API revision frozen before evaluation.

    The original archives are retained. Only listed interface extensions may use
    the newer source snapshot; weights, data and unlisted code stay exact checks.
    Default query behavior is checked separately against the retained selectors.
    """
    relative = current_path(relative)
    actual = (Path(project) / relative).read_bytes()
    if original is not None and actual == original:
        return False
    if relative not in API_EXTENSIONS | ADDED_SOURCES | ADAPTIVE_INTERFACES or (
        original is None and relative not in ADDED_SOURCES
    ):
        raise ValueError(f"Frozen source or input changed: {relative}")
    snapshot = Path(project) / "results/lrt/by_family/frozen_inputs.zip"
    adaptive = Path(project) / "results/lrt/adaptive/reviewed_interfaces.zip"
    for name in {relative, *ADDED_SOURCES}:
        selected = (
            adaptive
            if adaptive.exists() and name in ADAPTIVE_INTERFACES | ADDED_SOURCES
            else snapshot
        )
        with ZipFile(selected) as archive:
            if archive.read(name) != (Path(project) / name).read_bytes():
                raise ValueError(f"Reviewed interface source changed: {name}")
    return True


RENAMES = (
    ("decision_aware_risk_transfer/selective", "lrt"),
    ("decision_aware_risk_transfer.selective", "lrt"),
    ("concordance_gated_bayesian_risk_transfer", "cg_brt"),
    ("decision_aware_risk_transfer", "dart"),
    ("history_guided_testing", "hgt"),
    ("historical_expert_mixture", "hem"),
    ("scale_adaptive_expert_mixture", "saem"),
)

BASELINES = ("cg_brt", "dart", "hem", "hgt", "ras_frt_uq", "response_baselines", "saem")


def current_path(name):
    for old, new in RENAMES:
        name = name.replace(old, new)
    for package in BASELINES:
        for area in ("methods", "tests"):
            name = name.replace(f"{area}/{package}", f"{area}/baselines/{package}")
            name = name.replace(f"{area}.{package}", f"{area}.baselines.{package}")
    for area in ("methods", "tests"):
        name = name.replace(f"{area}/baselines/cg_brt", f"{area}/lrt/cg_brt")
        name = name.replace(f"{area}.baselines.cg_brt", f"{area}.lrt.cg_brt")
    name = name.replace(
        "methods/baselines/dart/reference.py", "methods/lrt/cg_brt/reference.py"
    ).replace("methods.baselines.dart.reference", "methods.lrt.cg_brt.reference")
    return name


def current_source(data, name):
    """Apply the declared import/path edits to an original Python source."""
    if not name.endswith(".py"):
        return data
    source = current_path(data.decode("utf-8"))
    if current_path(name) == "methods/lrt/__init__.py":
        # Component imports must not eagerly load the full selector.
        source = source.splitlines()[0] + "\n"
    if current_path(name) == "methods/baselines/dart/selection.py":
        source = source.replace(
            "from .reference import ReferencePolicy",
            "from methods.lrt.cg_brt.reference import ReferencePolicy",
        )
    if current_path(name) == "methods/lrt/config.py":
        source = source.replace("parents[3]", "parents[2]")
    if current_path(name).startswith(("methods/baselines/", "methods/lrt/cg_brt/")):
        source = re.sub(
            r"Path\(__file__\)\.resolve\(\)\.parents\[(\d+)\]",
            lambda match: match.group(0).replace(
                f"[{match.group(1)}]", f"[{int(match.group(1)) + 1}]"
            ),
            source,
        )
    return source.encode("utf-8")
