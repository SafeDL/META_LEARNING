"""Historical transfer and continual discovery prediction."""

from .selection import select

__all__ = ["select"]
