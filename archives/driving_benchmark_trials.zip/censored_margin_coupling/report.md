# 混合余量反馈的有限筛查

六固定 SUT、两共享池、200 次唯一查询及共同十次初始化；两步排程和发现额度不变。
二元与混合模型共享历史事件概率、正余量均值及全部先验核；只改变无碰撞反馈的观测似然。
无碰撞代理值为 1−Risk，碰撞只提供非正潜在余量约束；潜变量是工作模型，不是实际车距或原 Risk 的物理截断。
Gaussian ADF 为近似推断，不自动提供未知 SUT 上的校准保证。

| 方法 | Area % | Recall % | 平均 F200 |
|---|---:|---:|---:|
| frozen_reference | 52.837 | 76.885 | 118.92 |
| binary_margin_response | 52.387 | 76.162 | 117.08 |
| censored_margin_response | 52.443 | 76.435 | 117.75 |

| 池 | SUT | 方法 | Area % | Recall % | F200 |
|---|---|---|---:|---:|---:|
| 0 | idm_ref | frozen_reference | 12.402 | 24.968 | 197.00 |
| 0 | idm_ref | binary_margin_response | 12.174 | 24.715 | 195.00 |
| 0 | idm_ref | censored_margin_response | 12.174 | 24.715 | 195.00 |
| 0 | fvdm_target | frozen_reference | 69.812 | 100.000 | 88.00 |
| 0 | fvdm_target | binary_margin_response | 70.494 | 98.864 | 87.00 |
| 0 | fvdm_target | censored_margin_response | 69.909 | 98.864 | 87.00 |
| 0 | mobil_ref_v2 | frozen_reference | 79.913 | 100.000 | 69.00 |
| 0 | mobil_ref_v2 | binary_margin_response | 80.109 | 100.000 | 69.00 |
| 0 | mobil_ref_v2 | censored_margin_response | 80.210 | 100.000 | 69.00 |
| 0 | vi_ttc_ref_audit_v4 | frozen_reference | 26.585 | 53.145 | 169.00 |
| 0 | vi_ttc_ref_audit_v4 | binary_margin_response | 25.211 | 50.629 | 161.00 |
| 0 | vi_ttc_ref_audit_v4 | censored_margin_response | 25.687 | 52.201 | 166.00 |
| 0 | mcts_cv_ref_audit_v4 | frozen_reference | 54.899 | 87.097 | 108.00 |
| 0 | mcts_cv_ref_audit_v4 | binary_margin_response | 53.194 | 87.097 | 108.00 |
| 0 | mcts_cv_ref_audit_v4 | censored_margin_response | 53.315 | 87.097 | 108.00 |
| 0 | ppo_ref_v2 | frozen_reference | 76.675 | 100.000 | 83.00 |
| 0 | ppo_ref_v2 | binary_margin_response | 76.681 | 100.000 | 83.00 |
| 0 | ppo_ref_v2 | censored_margin_response | 76.645 | 100.000 | 83.00 |
| 1 | idm_ref | frozen_reference | 12.519 | 25.031 | 199.00 |
| 1 | idm_ref | binary_margin_response | 12.519 | 25.031 | 199.00 |
| 1 | idm_ref | censored_margin_response | 12.519 | 25.031 | 199.00 |
| 1 | fvdm_target | frozen_reference | 65.723 | 97.872 | 92.00 |
| 1 | fvdm_target | binary_margin_response | 65.574 | 96.809 | 91.00 |
| 1 | fvdm_target | censored_margin_response | 65.617 | 97.872 | 92.00 |
| 1 | mobil_ref_v2 | frozen_reference | 78.021 | 100.000 | 73.00 |
| 1 | mobil_ref_v2 | binary_margin_response | 78.062 | 100.000 | 73.00 |
| 1 | mobil_ref_v2 | censored_margin_response | 78.342 | 100.000 | 73.00 |
| 1 | vi_ttc_ref_audit_v4 | frozen_reference | 27.249 | 54.662 | 170.00 |
| 1 | vi_ttc_ref_audit_v4 | binary_margin_response | 25.944 | 51.768 | 161.00 |
| 1 | vi_ttc_ref_audit_v4 | censored_margin_response | 26.122 | 52.412 | 163.00 |
| 1 | mcts_cv_ref_audit_v4 | frozen_reference | 53.016 | 79.839 | 99.00 |
| 1 | mcts_cv_ref_audit_v4 | binary_margin_response | 51.504 | 79.032 | 98.00 |
| 1 | mcts_cv_ref_audit_v4 | censored_margin_response | 51.560 | 79.032 | 98.00 |
| 1 | ppo_ref_v2 | frozen_reference | 77.225 | 100.000 | 80.00 |
| 1 | ppo_ref_v2 | binary_margin_response | 77.175 | 100.000 | 80.00 |
| 1 | ppo_ref_v2 | censored_margin_response | 77.212 | 100.000 | 80.00 |

36 条曲线、7200 次披露与混合似然、原参照及全程计数界核对通过。
未通过筛查，不补种子。
