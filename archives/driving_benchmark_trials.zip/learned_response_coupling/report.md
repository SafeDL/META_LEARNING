# 冻结原方法参照上的受限纠正

六固定 SUT、两共享池、选择种子 [11]、200 次唯一查询和共同原参照前十次初始化。
原参照使用同一冻结核、历史划分和风险反馈；候选与去耦合对照使用同一共享响应 GP、历史资料和实际风险／事件反馈。

候选局部相关性使用原历史训练核并归一化；初始均值、边缘方差和任务模式保持不变，不新增训练。

| 方法 | Area % | Recall % | F200 | 平均偏离参照查询数 |
|---|---:|---:|---:|---:|
| frozen_reference | 52.837 | 76.885 | 118.92 | 0.00 |
| uncoupled_response | 51.540 | 75.851 | 118.33 | 182.25 |
| coupled_response | 52.680 | 76.769 | 118.92 | 39.92 |

| 池 | SUT | 方法 | Area % | Recall % | F200 | 不同序列数 |
|---|---|---|---:|---:|---:|---:|
| 0 | idm_ref | frozen_reference | 12.402 | 24.968 | 197.00 | 1 |
| 0 | idm_ref | uncoupled_response | 12.738 | 25.349 | 200.00 | 1 |
| 0 | idm_ref | coupled_response | 12.738 | 25.349 | 200.00 | 1 |
| 0 | fvdm_target | frozen_reference | 69.812 | 100.000 | 88.00 | 1 |
| 0 | fvdm_target | uncoupled_response | 68.494 | 97.727 | 86.00 | 1 |
| 0 | fvdm_target | coupled_response | 69.761 | 98.864 | 87.00 | 1 |
| 0 | mobil_ref_v2 | frozen_reference | 79.913 | 100.000 | 69.00 | 1 |
| 0 | mobil_ref_v2 | uncoupled_response | 79.261 | 100.000 | 69.00 | 1 |
| 0 | mobil_ref_v2 | coupled_response | 79.486 | 100.000 | 69.00 | 1 |
| 0 | vi_ttc_ref_audit_v4 | frozen_reference | 26.585 | 53.145 | 169.00 | 1 |
| 0 | vi_ttc_ref_audit_v4 | uncoupled_response | 25.599 | 53.145 | 169.00 | 1 |
| 0 | vi_ttc_ref_audit_v4 | coupled_response | 26.327 | 52.830 | 168.00 | 1 |
| 0 | mcts_cv_ref_audit_v4 | frozen_reference | 54.899 | 87.097 | 108.00 | 1 |
| 0 | mcts_cv_ref_audit_v4 | uncoupled_response | 49.815 | 87.097 | 108.00 | 1 |
| 0 | mcts_cv_ref_audit_v4 | coupled_response | 54.480 | 87.097 | 108.00 | 1 |
| 0 | ppo_ref_v2 | frozen_reference | 76.675 | 100.000 | 83.00 | 1 |
| 0 | ppo_ref_v2 | uncoupled_response | 76.151 | 100.000 | 83.00 | 1 |
| 0 | ppo_ref_v2 | coupled_response | 76.235 | 100.000 | 83.00 | 1 |
| 1 | idm_ref | frozen_reference | 12.519 | 25.031 | 199.00 | 1 |
| 1 | idm_ref | uncoupled_response | 12.519 | 25.031 | 199.00 | 1 |
| 1 | idm_ref | coupled_response | 12.519 | 25.031 | 199.00 | 1 |
| 1 | fvdm_target | frozen_reference | 65.723 | 97.872 | 92.00 | 1 |
| 1 | fvdm_target | uncoupled_response | 62.809 | 85.106 | 80.00 | 1 |
| 1 | fvdm_target | coupled_response | 65.330 | 97.872 | 92.00 | 1 |
| 1 | mobil_ref_v2 | frozen_reference | 78.021 | 100.000 | 73.00 | 1 |
| 1 | mobil_ref_v2 | uncoupled_response | 77.562 | 100.000 | 73.00 | 1 |
| 1 | mobil_ref_v2 | coupled_response | 78.041 | 100.000 | 73.00 | 1 |
| 1 | vi_ttc_ref_audit_v4 | frozen_reference | 27.249 | 54.662 | 170.00 | 1 |
| 1 | vi_ttc_ref_audit_v4 | uncoupled_response | 27.582 | 55.305 | 172.00 | 1 |
| 1 | vi_ttc_ref_audit_v4 | coupled_response | 27.109 | 54.341 | 169.00 | 1 |
| 1 | mcts_cv_ref_audit_v4 | frozen_reference | 53.016 | 79.839 | 99.00 | 1 |
| 1 | mcts_cv_ref_audit_v4 | uncoupled_response | 49.496 | 81.452 | 101.00 | 1 |
| 1 | mcts_cv_ref_audit_v4 | coupled_response | 52.730 | 79.839 | 99.00 | 1 |
| 1 | ppo_ref_v2 | frozen_reference | 77.225 | 100.000 | 80.00 | 1 |
| 1 | ppo_ref_v2 | uncoupled_response | 76.456 | 100.000 | 80.00 | 1 |
| 1 | ppo_ref_v2 | coupled_response | 77.400 | 100.000 | 80.00 | 1 |

36 条曲线、7200 次披露核对通过。
独立参照与既有冻结路径完全一致；回放只使用已测反馈。每个实际前缀的全程计数界、终点与累计面积界通过核对。
相对 frozen_reference：Area -0.157、Recall -0.116 个百分点。
相对 uncoupled_response：Area +1.140、Recall +0.918 个百分点。

单种子筛查未通过，不扩大重复。
全程计数界保证相对原参照最多少一个发现，不保证严格增益；新增物理仿真为 0。
