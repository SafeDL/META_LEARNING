# 风险与碰撞反馈通道的固定配置验证

既定 12 个验证配置、同六来源先验、pool_0、种子 11、200 次预算与共同 10 次初始化。
两方法都获取同次风险与碰撞；区别是风险反馈是否更新全局响应模型。不训练新的收益模型，不晋升此前失败的耦合候选。

| 方法 | Area % | Recall % | 平均 F200 |
|---|---:|---:|---:|
| greedy_reference | 48.864 | 77.159 | 129.00 |
| event_only_search | 51.868 | 80.799 | 135.92 |

| 配置 | 方法 | Area % | Recall % | F200 |
|---|---|---:|---:|---:|
| idm_12 | greedy_reference | 69.266 | 100.000 | 94 |
| idm_12 | event_only_search | 72.441 | 100.000 | 94 |
| idm_13 | greedy_reference | 72.122 | 100.000 | 86 |
| idm_13 | event_only_search | 73.581 | 98.837 | 85 |
| idm_14 | greedy_reference | 66.268 | 97.938 | 95 |
| idm_14 | event_only_search | 69.593 | 97.938 | 95 |
| idm_15 | greedy_reference | 61.518 | 96.330 | 105 |
| idm_15 | event_only_search | 66.647 | 98.165 | 107 |
| idm_16 | greedy_reference | 35.416 | 67.557 | 177 |
| idm_16 | event_only_search | 36.521 | 70.611 | 185 |
| idm_17 | greedy_reference | 78.586 | 100.000 | 64 |
| idm_17 | event_only_search | 81.336 | 100.000 | 64 |
| fvdm_12 | greedy_reference | 32.465 | 64.865 | 168 |
| fvdm_12 | event_only_search | 36.533 | 71.815 | 186 |
| fvdm_13 | greedy_reference | 38.158 | 64.851 | 131 |
| fvdm_13 | event_only_search | 41.899 | 81.188 | 164 |
| fvdm_14 | greedy_reference | 57.551 | 93.220 | 110 |
| fvdm_14 | event_only_search | 61.627 | 98.305 | 116 |
| fvdm_15 | greedy_reference | 45.544 | 82.313 | 121 |
| fvdm_15 | event_only_search | 52.847 | 93.878 | 138 |
| fvdm_16 | greedy_reference | 13.810 | 27.601 | 199 |
| fvdm_16 | event_only_search | 13.698 | 27.462 | 198 |
| fvdm_17 | greedy_reference | 15.661 | 31.230 | 198 |
| fvdm_17 | event_only_search | 15.694 | 31.388 | 199 |

仅事件更新相对联合更新：Area +3.004、Recall +3.640 个百分点。
24 条曲线、4800 次唯一反馈披露核对；新增物理执行为 0。
结果只适用于当前公开 IDM/FVDM 配置验证，不能推广到六代表 SUT 或宣称显著优势。
收益与损失需分别评价；加入更多反馈不保证错误指定的跨通道模型获得更好的危险排序。
