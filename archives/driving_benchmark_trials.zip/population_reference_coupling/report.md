# 冻结原方法参照上的受限纠正

六固定 SUT、两共享池、选择种子 [11]、200 次唯一查询和共同原参照前十次初始化。
候选及去耦合对照共享三十来源响应先验、学习核和实际风险／事件反馈；冻结参照保持原六来源历史划分及风险权限。

复用的二十四个配置属于既有 IDM/FVDM 两族，不是新驾驶算法；参数只用于评估端数据审计，不进入响应推断。
风险与事件用不同映射，允许非单调关系；有限历史后验不是真实概率保证，发现损失由独立参照回放控制。

| 方法 | Area % | Recall % | F200 | 平均偏离参照查询数 |
|---|---:|---:|---:|---:|
| frozen_reference | 52.837 | 76.885 | 118.92 | 0.00 |
| uncoupled_response | 50.290 | 76.293 | 117.33 | 184.58 |
| coupled_response | 52.723 | 76.758 | 118.83 | 38.58 |

| 池 | SUT | 方法 | Area % | Recall % | F200 | 不同序列数 |
|---|---|---|---:|---:|---:|---:|
| 0 | idm_ref | frozen_reference | 12.402 | 24.968 | 197.00 | 1 |
| 0 | idm_ref | uncoupled_response | 12.620 | 25.222 | 199.00 | 1 |
| 0 | idm_ref | coupled_response | 12.620 | 25.222 | 199.00 | 1 |
| 0 | fvdm_target | frozen_reference | 69.812 | 100.000 | 88.00 | 1 |
| 0 | fvdm_target | uncoupled_response | 64.688 | 97.727 | 86.00 | 1 |
| 0 | fvdm_target | coupled_response | 69.665 | 98.864 | 87.00 | 1 |
| 0 | mobil_ref_v2 | frozen_reference | 79.913 | 100.000 | 69.00 | 1 |
| 0 | mobil_ref_v2 | uncoupled_response | 78.348 | 100.000 | 69.00 | 1 |
| 0 | mobil_ref_v2 | coupled_response | 79.616 | 100.000 | 69.00 | 1 |
| 0 | vi_ttc_ref_audit_v4 | frozen_reference | 26.585 | 53.145 | 169.00 | 1 |
| 0 | vi_ttc_ref_audit_v4 | uncoupled_response | 23.907 | 50.314 | 160.00 | 1 |
| 0 | vi_ttc_ref_audit_v4 | coupled_response | 26.327 | 52.830 | 168.00 | 1 |
| 0 | mcts_cv_ref_audit_v4 | frozen_reference | 54.899 | 87.097 | 108.00 | 1 |
| 0 | mcts_cv_ref_audit_v4 | uncoupled_response | 46.585 | 85.484 | 106.00 | 1 |
| 0 | mcts_cv_ref_audit_v4 | coupled_response | 54.480 | 87.097 | 108.00 | 1 |
| 0 | ppo_ref_v2 | frozen_reference | 76.675 | 100.000 | 83.00 | 1 |
| 0 | ppo_ref_v2 | uncoupled_response | 75.355 | 100.000 | 83.00 | 1 |
| 0 | ppo_ref_v2 | coupled_response | 76.446 | 100.000 | 83.00 | 1 |
| 1 | idm_ref | frozen_reference | 12.519 | 25.031 | 199.00 | 1 |
| 1 | idm_ref | uncoupled_response | 12.519 | 25.031 | 199.00 | 1 |
| 1 | idm_ref | coupled_response | 12.519 | 25.031 | 199.00 | 1 |
| 1 | fvdm_target | frozen_reference | 65.723 | 97.872 | 92.00 | 1 |
| 1 | fvdm_target | uncoupled_response | 65.559 | 97.872 | 92.00 | 1 |
| 1 | fvdm_target | coupled_response | 66.096 | 97.872 | 92.00 | 1 |
| 1 | mobil_ref_v2 | frozen_reference | 78.021 | 100.000 | 73.00 | 1 |
| 1 | mobil_ref_v2 | uncoupled_response | 76.068 | 100.000 | 73.00 | 1 |
| 1 | mobil_ref_v2 | coupled_response | 77.952 | 100.000 | 73.00 | 1 |
| 1 | vi_ttc_ref_audit_v4 | frozen_reference | 27.249 | 54.662 | 170.00 | 1 |
| 1 | vi_ttc_ref_audit_v4 | uncoupled_response | 24.611 | 50.804 | 158.00 | 1 |
| 1 | vi_ttc_ref_audit_v4 | coupled_response | 26.986 | 54.341 | 169.00 | 1 |
| 1 | mcts_cv_ref_audit_v4 | frozen_reference | 53.016 | 79.839 | 99.00 | 1 |
| 1 | mcts_cv_ref_audit_v4 | uncoupled_response | 48.198 | 83.065 | 103.00 | 1 |
| 1 | mcts_cv_ref_audit_v4 | coupled_response | 52.641 | 79.839 | 99.00 | 1 |
| 1 | ppo_ref_v2 | frozen_reference | 77.225 | 100.000 | 80.00 | 1 |
| 1 | ppo_ref_v2 | uncoupled_response | 75.019 | 100.000 | 80.00 | 1 |
| 1 | ppo_ref_v2 | coupled_response | 77.331 | 100.000 | 80.00 | 1 |

36 条曲线、7200 次披露核对通过。
独立参照与既有冻结路径完全一致；回放只使用已测反馈。每个实际前缀的全程计数界、终点与累计面积界通过核对。
相对 frozen_reference：Area -0.114、Recall -0.127 个百分点。
相对 uncoupled_response：Area +2.434、Recall +0.465 个百分点。

单种子筛查未通过，不扩大重复。
全程计数界保证相对原参照最多少一个发现，不保证严格增益；新增物理仿真为 0。
