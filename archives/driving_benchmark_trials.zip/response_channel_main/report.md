# 六 SUT 的响应通道与共享任务结构比较

原定六 SUT、两个共享池、五个选择种子、200 次预算及共同 10 次初始化。三方法获得同一已查询风险／碰撞反馈。
目标参数、身份和未查询标签不进入独立选择进程；只使用原六来源历史，不使用额外配置监督。
局部事件 GP 保持相同历史事件均值、初始边缘概率和物理长度尺度，去除跨场景的共享响应模式。

| 方法 | Area % | Recall % | 平均 F200 |
|---|---:|---:|---:|
| joint_risk_response | 49.831 | 74.881 | 117.75 |
| shared_event_response | 51.601 | 74.781 | 115.58 |
| local_event_gp | 51.857 | 74.732 | 115.83 |

| 池 | SUT | 方法 | Area % | Recall % | F200 | 不同选择序列/5 |
|---|---|---|---:|---:|---:|---:|
| 0 | idm_ref | joint_risk_response | 12.485 | 25.095 | 198.00 | 1 |
| 0 | idm_ref | shared_event_response | 12.372 | 24.968 | 197.00 | 1 |
| 0 | idm_ref | local_event_gp | 12.372 | 24.968 | 197.00 | 1 |
| 0 | fvdm_target | joint_risk_response | 64.750 | 98.864 | 87.00 | 1 |
| 0 | fvdm_target | shared_event_response | 71.909 | 98.864 | 87.00 | 1 |
| 0 | fvdm_target | local_event_gp | 70.642 | 94.318 | 83.00 | 1 |
| 0 | mobil_ref_v2 | joint_risk_response | 76.145 | 100.000 | 69.00 | 1 |
| 0 | mobil_ref_v2 | shared_event_response | 80.275 | 100.000 | 69.00 | 1 |
| 0 | mobil_ref_v2 | local_event_gp | 80.312 | 100.000 | 69.00 | 1 |
| 0 | vi_ttc_ref_audit_v4 | joint_risk_response | 28.209 | 57.547 | 183.00 | 1 |
| 0 | vi_ttc_ref_audit_v4 | shared_event_response | 25.105 | 50.943 | 162.00 | 1 |
| 0 | vi_ttc_ref_audit_v4 | local_event_gp | 25.730 | 52.201 | 166.00 | 1 |
| 0 | mcts_cv_ref_audit_v4 | joint_risk_response | 48.577 | 79.839 | 99.00 | 1 |
| 0 | mcts_cv_ref_audit_v4 | shared_event_response | 49.548 | 80.645 | 100.00 | 1 |
| 0 | mcts_cv_ref_audit_v4 | local_event_gp | 50.177 | 78.226 | 97.00 | 1 |
| 0 | ppo_ref_v2 | joint_risk_response | 73.217 | 98.795 | 82.00 | 1 |
| 0 | ppo_ref_v2 | shared_event_response | 75.741 | 100.000 | 83.00 | 1 |
| 0 | ppo_ref_v2 | local_event_gp | 74.976 | 97.590 | 81.00 | 1 |
| 1 | idm_ref | joint_risk_response | 12.517 | 25.031 | 199.00 | 1 |
| 1 | idm_ref | shared_event_response | 12.411 | 24.906 | 198.00 | 1 |
| 1 | idm_ref | local_event_gp | 12.287 | 24.780 | 197.00 | 1 |
| 1 | fvdm_target | joint_risk_response | 60.707 | 85.106 | 80.00 | 1 |
| 1 | fvdm_target | shared_event_response | 65.037 | 85.106 | 80.00 | 1 |
| 1 | fvdm_target | local_event_gp | 68.809 | 96.809 | 91.00 | 1 |
| 1 | mobil_ref_v2 | joint_risk_response | 73.966 | 100.000 | 73.00 | 1 |
| 1 | mobil_ref_v2 | shared_event_response | 78.808 | 100.000 | 73.00 | 1 |
| 1 | mobil_ref_v2 | local_event_gp | 78.096 | 100.000 | 73.00 | 1 |
| 1 | vi_ttc_ref_audit_v4 | joint_risk_response | 27.138 | 54.984 | 171.00 | 1 |
| 1 | vi_ttc_ref_audit_v4 | shared_event_response | 24.666 | 50.482 | 157.00 | 1 |
| 1 | vi_ttc_ref_audit_v4 | local_event_gp | 25.915 | 52.090 | 162.00 | 1 |
| 1 | mcts_cv_ref_audit_v4 | joint_risk_response | 46.415 | 75.806 | 94.00 | 1 |
| 1 | mcts_cv_ref_audit_v4 | shared_event_response | 46.544 | 81.452 | 101.00 | 1 |
| 1 | mcts_cv_ref_audit_v4 | local_event_gp | 46.694 | 75.806 | 94.00 | 1 |
| 1 | ppo_ref_v2 | joint_risk_response | 73.844 | 97.500 | 78.00 | 1 |
| 1 | ppo_ref_v2 | shared_event_response | 76.800 | 100.000 | 80.00 | 1 |
| 1 | ppo_ref_v2 | local_event_gp | 76.281 | 100.000 | 80.00 | 1 |

## 冻结基线的同池比较

冻结方法保持原反馈权限；行为模型使用额外历史配置。机制归因依靠上面的同反馈对照。

| 冻结基线 | Area % | Recall % | 共享事件响应 ΔArea | ΔRecall |
|---|---:|---:|---:|---:|
| uniform_random | 5.331 | 10.247 | +46.270 | +64.533 |
| farthest_first | 6.167 | 11.774 | +45.435 | +63.007 |
| knn_history | 36.580 | 50.192 | +15.022 | +24.589 |
| gp_ucb | 14.479 | 25.422 | +37.123 | +49.359 |
| gp_ei | 41.822 | 68.795 | +9.779 | +5.986 |
| bop_elites | 29.371 | 43.589 | +22.230 | +31.192 |
| bas | 4.385 | 9.278 | +47.217 | +65.502 |
| rf_bo | 40.695 | 71.275 | +10.906 | +3.506 |
| ras_frt_uq | 52.203 | 74.062 | -0.602 | +0.718 |
| frozen_original | 52.858 | 77.062 | -1.256 | -2.281 |
| previous_best | 52.984 | 76.661 | -1.382 | -1.881 |
| risk_conditioned | 50.367 | 67.804 | +1.235 | +6.977 |
| behavior_posterior | 49.735 | 66.920 | +1.867 | +7.861 |
| matched_collision_gp | 52.424 | 75.686 | -0.822 | -0.905 |

180 条曲线、36000 次披露重算完成；新增物理执行为 0。
重复种子不构成独立 SUT 或确认样本，已有池属于开发；不据此宣布显著优势。
