# 冻结原方法参照上的受限纠正

六固定 SUT、两共享池、选择种子 [11]、200 次唯一查询和共同原参照前十次初始化。
三方法使用完全相同的历史风险划分、训练核与初始风险先验；候选的风险 GP 接收全部实际反馈，参照只接收独立前缀。

目标事件反馈约束每类场景的风险阈值解释；只有所有相容解释支持更高预测碰撞概率才纠正，解释冲突或未统一则回到参照。
这是工作风险模型下的决策支持，不是真实碰撞概率置信界；全程发现损失另由已测事件计数控制。

| 方法 | Area % | Recall % | F200 | 平均偏离参照查询数 |
|---|---:|---:|---:|---:|
| frozen_reference | 52.837 | 76.885 | 118.92 | 0.00 |
| uncoupled_response | 52.733 | 76.573 | 118.67 | 30.17 |
| coupled_response | 52.804 | 76.790 | 118.83 | 7.75 |

| 池 | SUT | 方法 | Area % | Recall % | F200 | 不同序列数 |
|---|---|---|---:|---:|---:|---:|
| 0 | idm_ref | frozen_reference | 12.402 | 24.968 | 197.00 | 1 |
| 0 | idm_ref | uncoupled_response | 12.402 | 24.968 | 197.00 | 1 |
| 0 | idm_ref | coupled_response | 12.402 | 24.968 | 197.00 | 1 |
| 0 | fvdm_target | frozen_reference | 69.812 | 100.000 | 88.00 | 1 |
| 0 | fvdm_target | uncoupled_response | 68.256 | 95.455 | 84.00 | 1 |
| 0 | fvdm_target | coupled_response | 69.812 | 98.864 | 87.00 | 1 |
| 0 | mobil_ref_v2 | frozen_reference | 79.913 | 100.000 | 69.00 | 1 |
| 0 | mobil_ref_v2 | uncoupled_response | 79.949 | 100.000 | 69.00 | 1 |
| 0 | mobil_ref_v2 | coupled_response | 79.891 | 100.000 | 69.00 | 1 |
| 0 | vi_ttc_ref_audit_v4 | frozen_reference | 26.585 | 53.145 | 169.00 | 1 |
| 0 | vi_ttc_ref_audit_v4 | uncoupled_response | 26.557 | 53.145 | 169.00 | 1 |
| 0 | vi_ttc_ref_audit_v4 | coupled_response | 26.524 | 53.145 | 169.00 | 1 |
| 0 | mcts_cv_ref_audit_v4 | frozen_reference | 54.899 | 87.097 | 108.00 | 1 |
| 0 | mcts_cv_ref_audit_v4 | uncoupled_response | 54.718 | 87.097 | 108.00 | 1 |
| 0 | mcts_cv_ref_audit_v4 | coupled_response | 54.758 | 87.097 | 108.00 | 1 |
| 0 | ppo_ref_v2 | frozen_reference | 76.675 | 100.000 | 83.00 | 1 |
| 0 | ppo_ref_v2 | uncoupled_response | 76.608 | 100.000 | 83.00 | 1 |
| 0 | ppo_ref_v2 | coupled_response | 76.657 | 100.000 | 83.00 | 1 |
| 1 | idm_ref | frozen_reference | 12.519 | 25.031 | 199.00 | 1 |
| 1 | idm_ref | uncoupled_response | 12.519 | 25.031 | 199.00 | 1 |
| 1 | idm_ref | coupled_response | 12.519 | 25.031 | 199.00 | 1 |
| 1 | fvdm_target | frozen_reference | 65.723 | 97.872 | 92.00 | 1 |
| 1 | fvdm_target | uncoupled_response | 66.287 | 97.872 | 92.00 | 1 |
| 1 | fvdm_target | coupled_response | 65.654 | 97.872 | 92.00 | 1 |
| 1 | mobil_ref_v2 | frozen_reference | 78.021 | 100.000 | 73.00 | 1 |
| 1 | mobil_ref_v2 | uncoupled_response | 78.034 | 100.000 | 73.00 | 1 |
| 1 | mobil_ref_v2 | coupled_response | 78.034 | 100.000 | 73.00 | 1 |
| 1 | vi_ttc_ref_audit_v4 | frozen_reference | 27.249 | 54.662 | 170.00 | 1 |
| 1 | vi_ttc_ref_audit_v4 | uncoupled_response | 27.249 | 54.662 | 170.00 | 1 |
| 1 | vi_ttc_ref_audit_v4 | coupled_response | 27.249 | 54.662 | 170.00 | 1 |
| 1 | mcts_cv_ref_audit_v4 | frozen_reference | 53.016 | 79.839 | 99.00 | 1 |
| 1 | mcts_cv_ref_audit_v4 | uncoupled_response | 53.016 | 80.645 | 100.00 | 1 |
| 1 | mcts_cv_ref_audit_v4 | coupled_response | 53.012 | 79.839 | 99.00 | 1 |
| 1 | ppo_ref_v2 | frozen_reference | 77.225 | 100.000 | 80.00 | 1 |
| 1 | ppo_ref_v2 | uncoupled_response | 77.200 | 100.000 | 80.00 | 1 |
| 1 | ppo_ref_v2 | coupled_response | 77.138 | 100.000 | 80.00 | 1 |

36 条曲线、7200 次披露核对通过。
独立参照与既有冻结路径完全一致；回放只使用已测反馈。每个实际前缀的全程计数界、终点与累计面积界通过核对。
相对 frozen_reference：Area -0.032、Recall -0.095 个百分点。
相对 uncoupled_response：Area +0.071、Recall +0.217 个百分点。

单种子筛查未通过，不扩大重复。
全程计数界保证相对原参照最多少一个发现，不保证严格增益；新增物理仿真为 0。
