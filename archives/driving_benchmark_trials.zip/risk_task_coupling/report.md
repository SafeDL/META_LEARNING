# 冻结原方法参照上的受限纠正

六固定 SUT、两共享池、选择种子 [11]、200 次唯一查询和共同原参照前十次初始化。
候选及去耦合对照使用同六来源、同历史训练划分、同核和实际风险／事件反馈；冻结参照保持原风险权限。

风险 GP 只由实际风险更新；历史风险到事件的平均映射经目标场景事件残差修正，允许同风险有不同碰撞响应。
事件残差采用 probit 拉普拉斯近似；风险映射的常量段精确积分，线性段在概率域作十六节点积分，不读取未查询标签。

事件残差同时包含场景类内共享校准偏差和局部变化，两项归一化后保持与上一轮相同的初始边缘方差。

候选风险 GP 加入同一六来源的经验响应差异协方差；初始风险均值、噪声、学习核与事件推断保持不变。

| 方法 | Area % | Recall % | F200 | 平均偏离参照查询数 |
|---|---:|---:|---:|---:|
| frozen_reference | 52.837 | 76.885 | 118.92 | 0.00 |
| uncoupled_response | 52.655 | 76.546 | 119.50 | 175.00 |
| coupled_response | 52.710 | 76.847 | 119.17 | 49.58 |

| 池 | SUT | 方法 | Area % | Recall % | F200 | 不同序列数 |
|---|---|---|---:|---:|---:|---:|
| 0 | idm_ref | frozen_reference | 12.402 | 24.968 | 197.00 | 1 |
| 0 | idm_ref | uncoupled_response | 12.738 | 25.349 | 200.00 | 1 |
| 0 | idm_ref | coupled_response | 12.738 | 25.349 | 200.00 | 1 |
| 0 | fvdm_target | frozen_reference | 69.812 | 100.000 | 88.00 | 1 |
| 0 | fvdm_target | uncoupled_response | 69.227 | 97.727 | 86.00 | 1 |
| 0 | fvdm_target | coupled_response | 69.438 | 98.864 | 87.00 | 1 |
| 0 | mobil_ref_v2 | frozen_reference | 79.913 | 100.000 | 69.00 | 1 |
| 0 | mobil_ref_v2 | uncoupled_response | 79.551 | 100.000 | 69.00 | 1 |
| 0 | mobil_ref_v2 | coupled_response | 79.594 | 100.000 | 69.00 | 1 |
| 0 | vi_ttc_ref_audit_v4 | frozen_reference | 26.585 | 53.145 | 169.00 | 1 |
| 0 | vi_ttc_ref_audit_v4 | uncoupled_response | 26.965 | 54.717 | 174.00 | 1 |
| 0 | vi_ttc_ref_audit_v4 | coupled_response | 26.901 | 53.774 | 171.00 | 1 |
| 0 | mcts_cv_ref_audit_v4 | frozen_reference | 54.899 | 87.097 | 108.00 | 1 |
| 0 | mcts_cv_ref_audit_v4 | uncoupled_response | 54.355 | 87.903 | 109.00 | 1 |
| 0 | mcts_cv_ref_audit_v4 | coupled_response | 54.573 | 87.097 | 108.00 | 1 |
| 0 | ppo_ref_v2 | frozen_reference | 76.675 | 100.000 | 83.00 | 1 |
| 0 | ppo_ref_v2 | uncoupled_response | 76.572 | 100.000 | 83.00 | 1 |
| 0 | ppo_ref_v2 | coupled_response | 76.422 | 100.000 | 83.00 | 1 |
| 1 | idm_ref | frozen_reference | 12.519 | 25.031 | 199.00 | 1 |
| 1 | idm_ref | uncoupled_response | 12.519 | 25.031 | 199.00 | 1 |
| 1 | idm_ref | coupled_response | 12.519 | 25.031 | 199.00 | 1 |
| 1 | fvdm_target | frozen_reference | 65.723 | 97.872 | 92.00 | 1 |
| 1 | fvdm_target | uncoupled_response | 63.633 | 85.106 | 80.00 | 1 |
| 1 | fvdm_target | coupled_response | 65.548 | 97.872 | 92.00 | 1 |
| 1 | mobil_ref_v2 | frozen_reference | 78.021 | 100.000 | 73.00 | 1 |
| 1 | mobil_ref_v2 | uncoupled_response | 77.356 | 100.000 | 73.00 | 1 |
| 1 | mobil_ref_v2 | coupled_response | 77.904 | 100.000 | 73.00 | 1 |
| 1 | vi_ttc_ref_audit_v4 | frozen_reference | 27.249 | 54.662 | 170.00 | 1 |
| 1 | vi_ttc_ref_audit_v4 | uncoupled_response | 27.733 | 55.627 | 173.00 | 1 |
| 1 | vi_ttc_ref_audit_v4 | coupled_response | 26.987 | 54.341 | 169.00 | 1 |
| 1 | mcts_cv_ref_audit_v4 | frozen_reference | 53.016 | 79.839 | 99.00 | 1 |
| 1 | mcts_cv_ref_audit_v4 | uncoupled_response | 53.976 | 87.097 | 108.00 | 1 |
| 1 | mcts_cv_ref_audit_v4 | coupled_response | 52.645 | 79.839 | 99.00 | 1 |
| 1 | ppo_ref_v2 | frozen_reference | 77.225 | 100.000 | 80.00 | 1 |
| 1 | ppo_ref_v2 | uncoupled_response | 77.231 | 100.000 | 80.00 | 1 |
| 1 | ppo_ref_v2 | coupled_response | 77.256 | 100.000 | 80.00 | 1 |

36 条曲线、7200 次披露核对通过。
独立参照与既有冻结路径完全一致；回放只使用已测反馈。每个实际前缀的全程计数界、终点与累计面积界通过核对。
相对 frozen_reference：Area -0.126、Recall -0.037 个百分点。
相对 uncoupled_response：Area +0.056、Recall +0.301 个百分点。

单种子筛查未通过，不扩大重复。
全程计数界保证相对原参照最多少一个发现，不保证严格增益；新增物理仿真为 0。
