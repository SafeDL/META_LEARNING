# 同轨迹事件证据评分诊断

使用 12 条已付费 EP 轨迹、2400 个查询前组件预测，重算仅按碰撞事件更新的影子权重。组件后验仍来自原实际轨迹，未模拟改变选例后的轨迹；本诊断不能报告新的 Area 或 Recall。[完整记录](summary.json)。

安全事件评分仍支持 FVDM、MOBIL、PPO 的历史组件，只是强度比安全数值密度小。因此，排除数值密度并不自动选中中性组件，也未改善同轨迹总体事件对数损失。原候选／参照建议保持固定时，影子权重改变了 23 个参照时段的二元支持结论，实际策略影响须另行验证。

影子混合的累计二元对数损失恒等式在全部前缀通过：`L_mix=−log(sum_h exp(−L_h)/2)≤min_h L_h+log(2)`。它只约束共同实际查询轨迹上的预测损失，不约束独立策略的发现曲线。在线专家聚合依据见 [Vovk 1998](https://www.sciencedirect.com/science/article/pii/S0022000097915567)；模块反馈控制动机见 [Carmona 与 Nicholls 2020](https://proceedings.mlr.press/v108/carmona20a.html)。
