# 方法与必要基线

唯一主方法是[CG-BRT](concordance_gated_bayesian_risk_transfer/README.md)，目标严格为R>0.5。旧碰撞主链已从代码目录删除。

| 目录 | 职责 |
|---|---|
| [concordance_gated_bayesian_risk_transfer](concordance_gated_bayesian_risk_transfer/README.md) | 当前风险后验、执行前排序门控及集合决策 |
| [history_guided_testing](history_guided_testing/README.md) | 历史数据、原风险GP、核、场景和标准基线 |
| [historical_expert_mixture](historical_expert_mixture/README.md) | 六来源历史均值与旧高斯混合对照 |
| [scale_adaptive_expert_mixture](scale_adaptive_expert_mixture/README.md) | Student-t证据数学及旧尺度混合对照 |
| [ras_frt_uq](ras_frt_uq/README.md) | RAS-FRT-UQ文献基线 |
| [response_baselines](response_baselines/README.md) | 冻结响应基线及必要推断输入 |
| [egfd](egfd/README.md) | 冻结碰撞基线与Gaussian/Student/事件符号控制；不属于当前主链依赖 |

保留代码对应当前比较或数据依赖。旧条件碰撞主方法、无效路由与阶段试验入口仅在[恢复归档](../archives/README.md)中保留。
