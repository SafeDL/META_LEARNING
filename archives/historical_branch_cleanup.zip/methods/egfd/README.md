# EGFD冻结碰撞对照

本目录保留Evidence-Guided Failure Discovery及Gaussian/Student/事件符号控制，作为已有对照。当前唯一主方法是[CG-BRT](../concordance_gated_bayesian_risk_transfer/README.md)，不依赖本目录。

EGFD使用已查询的R和C，更新历史响应解释、碰撞倾向及独立参照保护。它与只使用R的CG-BRT属于不同反馈通道的方法比较。

```python
from methods.egfd import select
```

`select(x, risk_prior, margin_prior, oracle, seed=11)`接收返回R/C的oracle。预算200与初始化10在[config.py](config.py)中锁定。[selection.py](selection.py)、[evidence.py](evidence.py)及事件/边际响应模块保留原数值机制；[controls.py](controls.py)提供Gaussian和Student控制接口。

过时阶段运行脚本和多层耦合结果目录已归档删除。必要冻结查询记录已复制到统一`pool_*/SUT/baselines/`目录，当前[完整比较](../../results/concordance_gated_bayesian_risk_transfer/comparison.md)重新读取这些记录。数值测试见[tests/egfd](../../tests/egfd)，恢复来源见[archives](../../archives/README.md)。
