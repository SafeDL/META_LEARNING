# 冻结响应基线

本目录集中旧研究中仍用于统一比较的响应推断代码。当前研究主线见[CG-BRT](../concordance_gated_bayesian_risk_transfer/README.md)，EGFD作为冻结参照保留。

| 方法 | 实现 |
|---|---|
| previous_best | 六来源历史响应网络、响应相似度核及风险／碰撞读出 |
| behavior_posterior | 冻结行为条件网络、连续行为假设后验、稳定概率排序 |
| risk_conditioned | 同一行为后验及风险残差条件化碰撞读出 |
| matched_collision_gp | 同历史行为预测器下的碰撞得分 GP |

`selectors.py` 提供统一选择入口；`history_model.py`、`behavior_model.py`、`prediction.py` 仅保留在线推断。核、校准和后验会话分别按职责命名。RAS 与原冻结风险测试继续调用它们原有实现。

冻结模型与协议位于 [results/response_baselines](../../results/response_baselines/README.md)。行为类模型使用额外历史配置，在 [统一比较](../../results/concordance_gated_bayesian_risk_transfer/comparison.md) 中作为工程参照单列，不与六来源候选混为同信息对照。

通过 `python -B -m experiments.driving_benchmark.baselines` 执行已有基线；已有日志会直接复用。原训练、开发、确认、失败尝试与源码均在 [完整归档](../../archives/method_selection.zip)；本目录没有再次启动这些试验的入口。
