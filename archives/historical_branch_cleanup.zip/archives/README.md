# 清理与恢复归档

当前唯一主方法是[CG-BRT](../methods/concordance_gated_bayesian_risk_transfer/README.md)。原始响应池、历史数据、核检查点和必要基线保留在活动目录。

| 归档 | 内容 |
|---|---|
| [risk_method_convergence.zip](risk_method_convergence.zip) | 本轮旧碰撞主链、过时结果阶段、独立MoE/尺度结果、中性消融、首次风险门控草稿和修改前公共来源 |
| [risk_method_convergence.json](risk_method_convergence.json) | 本轮精确归档清单、删除范围与保留范围 |
| [risk_method_convergence_audit.json](risk_method_convergence_audit.json) | 依赖与必要对比文件核对 |
| [retired_method_trials.zip](retired_method_trials.zip) | 上轮退役的前瞻、条件专家和无效神经路由等分支 |
| [method_selection.zip](method_selection.zip) | 更早研究分支与基线迁移快照 |
| [retired_experiments.zip](retired_experiments.zip) | 原单目标试验及其他早期冻结记录 |
| [retired_research_chains](retired_research_chains/README.md) | 独立论文复现与历史冻结资料 |

本轮归档501个文件，删除前逐字节核对；432个旧代码/结果文件和60条已被纠正实现替代的草稿轨迹从活动树删除。原主方法60条对照与96条单种子控制复制到统一baselines目录并核对内容，未删除物理响应池或当前源码。

活动目录保留一份新方法设计文档和一条主方法实现。新结果的`source_inputs.zip`是当前34份源码和6份历史/核输入的精确快照，与旧恢复归档分开。

恢复旧内容时，解压到独立目录检查：

```powershell
Expand-Archive -LiteralPath archives/risk_method_convergence.zip -DestinationPath archives/restored_risk_method
```

压缩包保留原相对路径；它们不是当前运行依赖。大型恢复归档仅保存在本地，已加入Git忽略规则。本轮最终检查见[cleanup.json](../results/concordance_gated_bayesian_risk_transfer/cleanup.json)。
