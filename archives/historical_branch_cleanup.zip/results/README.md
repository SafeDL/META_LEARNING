# 当前数据与结果

| 目录 | 内容 |
|---|---|
| [concordance_gated_bayesian_risk_transfer](concordance_gated_bayesian_risk_transfer/README.md) | CG-BRT唯一主结果、完整比较、核验和来源快照 |
| [driving_benchmark](driving_benchmark/README.md) | 原始响应池及集中保留的必要基线轨迹 |
| [history_guided_testing](history_guided_testing/README.md) | 原历史数据、冻结核与原单FVDM记录；旧设置独立保留 |
| [response_baselines](response_baselines/README.md) | 冻结基线推断所需模型、校准和输入快照 |

旧碰撞主链、独立MoE结果目录、尺度探索与多个耦合阶段结果已归档删除。必要对照轨迹已复制并逐字节核对，统一放入`driving_benchmark/pool_*/SUT/baselines/`；未删除原始实测响应和实际需要的模型。

高风险严格按R>0.5计数，碰撞单独报告。最新完整表见[统一比较](concordance_gated_bayesian_risk_transfer/comparison.md)，清理和恢复见[archives](../archives/README.md)。
