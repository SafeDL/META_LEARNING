"""Recompute the common benchmark from existing curves, including retired ones."""
from contextlib import ExitStack
import json
import re
from zipfile import ZipFile

import numpy as np

from methods.history_guided_testing.io import read_json, write_json
from methods.response_baselines.config import SELECTION_ARCHIVE

from .config import BUDGET, OUTPUT, SUT_IDS
from .evaluation import metrics


EXTRA_METHODS = {
    "gaussian_unprotected": ("earned_discovery_credit_coupling", "uncoupled_response"),
    "ep_event_score": ("event_evidence_prior_coupling", "event_evidence_prior"),
    "event_signs_protected": ("safe_risk_order_coupling/event_sign", "report_binary_prior"),
    "safe_risk_order": ("safe_risk_order_coupling/safe_order", "safe_risk_order_prior"),
    "adaptive_scope": ("evidence_scope_coupling/adaptive", "adaptive_scope_prior"),
}
EXTRA_HISTORY = {"risk_conditioned", "behavior_posterior", "matched_collision_gp",
                 "pooled_full_history"}
MATCHED_CANDIDATES = {
    "student_protected", "student_unprotected", "gaussian_unprotected",
    "ep_mixed_score", "adf_loss_supported", "ep_event_score",
    "event_signs_protected", "safe_risk_order", "adaptive_scope",
}


def main():
    old = read_json(OUTPUT / "matched_first_seed_comparison/summary.json")
    paths = {(r["method"], r["pool"], r["sut"]): r["path"].replace("\\", "/")
             for r in old["rows"]}
    for method, (stage, filename) in EXTRA_METHODS.items():
        for pool in (0, 1):
            for sut in SUT_IDS:
                paths[method, pool, sut] = f"{stage}/pool_{pool}/{sut}/{filename}_11.json"
    registered = set(paths.values())
    historical_methods = set()
    discovery = {}
    with ZipFile(OUTPUT / "retired_experiments.zip") as old_archive, ZipFile(SELECTION_ARCHIVE) as selection_archive:
        names = set(old_archive.namelist())
        # Frozen archives retain their original member paths.
        prefix = "research/representative_sut_testing/results/"
        names.update(n[len(prefix):] for n in selection_archive.namelist() if n.startswith(prefix))
        names.update(p.relative_to(OUTPUT).as_posix() for p in OUTPUT.rglob("*_11.json"))
        for name in sorted(names):
            match = re.fullmatch(r"(.*?)/?pool_([01])/([^/]+)/(.*)_11\.json", name)
            if not match or match[3] not in SUT_IDS or name in registered:
                continue
            stage, pool, sut, method_path = match.groups()
            if method_path == "frozen_reference" or method_path.startswith("baselines/"):
                continue
            method = stage + "/" + method_path
            discovery.setdefault(method, {})[int(pool), sut] = name
    for method, entries in discovery.items():
        if set(entries) != {(p, s) for p in (0, 1) for s in SUT_IDS}:
            continue
        historical_methods.add(method)
        paths.update({(method, pool, sut): name for (pool, sut), name in entries.items()})
    rows, initialization_checks = [], 0
    with ExitStack() as stack:
        old_archive = stack.enter_context(ZipFile(OUTPUT / "retired_experiments.zip"))
        selection_archive = stack.enter_context(ZipFile(SELECTION_ARCHIVE))
        for pool in (0, 1):
            for sut in SUT_IDS:
                with np.load(OUTPUT / f"pool_{pool}/{sut}/responses.npz") as bank:
                    reference = read_json(OUTPUT / f"pool_{pool}/{sut}/baselines/frozen_original_11.json")
                    for method in sorted({key[0] for key in paths}):
                        name = paths[method, pool, sut]
                        path = OUTPUT / name
                        if path.exists():
                            run = read_json(path)
                        elif name in old_archive.namelist():
                            run = json.loads(old_archive.read(name))
                        else:
                            run = json.loads(selection_archive.read(
                                "research/representative_sut_testing/results/" + name))
                        selected = run["selected_indices"]
                        if len(selected) != BUDGET or len(set(selected)) != BUDGET:
                            raise ValueError(f"Invalid unique query budget: {name}")
                        actual = metrics(bank["collision"], selected)
                        for key in ("area_200", "recall_200", "F200", "curve"):
                            if key in run and run[key] != actual[key]:
                                raise ValueError(f"Saved metric mismatch: {name}, {key}")
                        if method in MATCHED_CANDIDATES:
                            if selected[:10] != reference["selected_indices"][:10]:
                                raise ValueError(f"Different matched initialization: {name}")
                            initialization_checks += 1
                        rows.append({"method": method, "pool": pool, "sut": sut,
                                     "path": name, "area_pct": 100 * actual["area_200"],
                                     "recall_pct": 100 * actual["recall_200"],
                                     **{f"F{n}": actual["curve"][n - 1] for n in (10, 30, 50, 100, 150, 200)}})
    keys = ("area_pct", "recall_pct", "F10", "F30", "F50", "F100", "F150", "F200")
    aggregate = {}
    by_sut = {}
    for method in sorted({r["method"] for r in rows}):
        by_sut[method] = {sut: {key: float(np.mean([r[key] for r in rows
                        if r["method"] == method and r["sut"] == sut])) for key in keys}
                          for sut in SUT_IDS}
        aggregate[method] = {key: float(np.mean([by_sut[method][sut][key] for sut in SUT_IDS]))
                             for key in keys}
    matched = sorted(MATCHED_CANDIDATES)
    frontier = [method for method in matched if not any(
        all(aggregate[other][k] >= aggregate[method][k] for k in ("area_pct", "recall_pct"))
        and any(aggregate[other][k] > aggregate[method][k] for k in ("area_pct", "recall_pct"))
        for other in matched if other != method)]
    summary = {
        "budget": BUDGET, "seed": 11, "suts": SUT_IDS, "pools": [0, 1],
        "verified_curves": len(rows), "matched_initialization_checks": initialization_checks,
        "aggregate": aggregate, "by_sut": by_sut, "rows": rows,
        "matched_candidate_frontier": frontier,
        "other_common_benchmark_methods": sorted(historical_methods),
        "selected_research_method": "egfd",
        "method_name": "Evidence-Guided Failure Discovery",
        "selected_result_key": "event_signs_protected",
        "retained_controls": ["frozen_original", "student_protected", "student_unprotected",
                              "gaussian_unprotected", "ep_event_score"],
        "selection_basis": "closest implemented mechanism to feedback-supported correction and fallback; highest matched Area; other frontier methods retained as controls",
        "information_limits": "extra-history methods are separated; frozen reference and most external baselines receive R only, RAS receives C only; matched candidates receive R and C and share the frozen first ten queries",
        "scope": "retrospective development selection, not independent confirmation; no additional runs",
        "significant_advantage_established": False, "new_physical_calls": 0,
    }
    write_json(OUTPUT / "unified_comparison.json", summary)
    lines = ["# 统一基准的方法取舍", "",
             "六个固定 SUT、两个共享实测池、选择种子 11；200 次唯一查询，初始化计入预算。",
             "从完整实测碰撞标签重算全部已有曲线；先在 SUT 内平均两个池，再对六个 SUT 等权汇总。",
             "候选共享原参照前十次初始化。外部基线沿用原冻结初始化和反馈权限；这张表不把所有方法称为同信息消融。", "",
             "保留事件符号纠正为唯一研究主线：机制直接回应反馈是否支持改选、证据不足时如何回退，且其同信息开发面积最高。",
             "Student-t 保留为受保护强对照，高斯无保护版本保留最高召回控制。没有单一方法双指标最好，也没有新的显著优势结论。", "",
             "| 方法 | Area % | Recall % | F50 | F100 | F200 | 用途 |",
             "|---|---:|---:|---:|---:|---:|---|"]
    for method, value in aggregate.items():
        if method in EXTRA_HISTORY or method in historical_methods:
            continue
        role = "研究主线" if method == "event_signs_protected" else (
            "必要对照" if method in summary["retained_controls"] else
            "归档" if method in MATCHED_CANDIDATES else "冻结基线")
        display = "EGFD (event_signs_protected)" if method == "event_signs_protected" else method
        lines.append(f"| {display} | {value['area_pct']:.3f} | {value['recall_pct']:.3f} | "
                     f"{value['F50']:.2f} | {value['F100']:.2f} | {value['F200']:.2f} | {role} |")
    lines += ["", "额外历史数据工程参照如下；目标池、预算相同，离线信息及初始化不同。", "",
              "| 方法 | Area % | Recall % | F200 |", "|---|---:|---:|---:|"]
    for method in sorted(EXTRA_HISTORY):
        value = aggregate[method]
        lines.append(f"| {method} | {value['area_pct']:.3f} | {value['recall_pct']:.3f} | {value['F200']:.2f} |")
    lines += ["", "其余已完成、覆盖同十二实测池的历史分支如下。不同分支的反馈、历史数据与保护规则由原协议确定，不据此宣称同信息创新收益。", "",
              "| 历史分支／方法 | Area % | Recall % | F200 |", "|---|---:|---:|---:|"]
    for method in sorted(historical_methods):
        value = aggregate[method]
        lines.append(f"| {method} | {value['area_pct']:.3f} | {value['recall_pct']:.3f} | {value['F200']:.2f} |")
    lines += ["", f"共核对 {len(rows)} 条已有曲线；同信息候选双指标前沿为：" + ", ".join(frontier) + "。",
              "五种子基线完整表仍见 [baseline_comparison.md](baseline_comparison.md)，不与单种子候选均值混用。",
              "旧 IDM/FVDM 参数族实验、元适配、前瞻与推断元学习使用不同数据，不能将其均值插入本表。",
              "已失败的元适配／前瞻／推断元学习依据原同信息对照退役，不声称它们已在六 SUT 基准下重跑。",
              "归档包含原源码、协议、模型和完整结果：[method_selection.zip](../../archives/method_selection.zip)。",
              "本次没有训练、物理仿真或新增性能实验。"]
    (OUTPUT / "unified_comparison.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print({"verified_curves": len(rows), "matched_frontier": frontier})


if __name__ == "__main__":
    main()
