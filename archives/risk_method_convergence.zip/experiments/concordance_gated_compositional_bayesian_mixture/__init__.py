"""Frozen matched controls for joint-feedback active search."""
