"""Evaluate the retained policy using the locked banks and feedback interface."""
import itertools
import multiprocessing as mp
import time

import numpy as np
import torch
from threadpoolctl import threadpool_limits

from experiments.driving_benchmark.config import OUTPUT, SUT_IDS
from experiments.driving_benchmark.evaluation import disclose, metrics
from .config import CONTROLS, METRICS, POLICY, ROOT
from methods.concordance_gated_compositional_bayesian_mixture import select
from methods.concordance_gated_compositional_bayesian_mixture.readout import fit_readout
from methods.historical_expert_mixture.config import FALLBACK_PRIOR
from methods.historical_expert_mixture.experts import HistoricalExperts
from methods.history_guided_testing.config import ROOT as HISTORY_ROOT, SEEDS
from methods.history_guided_testing.experiment import RemoteOracle
from methods.history_guided_testing.history import load_history, split_indices, subset
from methods.history_guided_testing.io import read_json, write_json
from methods.history_guided_testing.train import load_kernel


def exact_sign_randomization(deltas):
    observed = float(np.mean(deltas))
    null = [
        float(np.mean(np.asarray(signs) * deltas))
        for signs in itertools.product((-1, 1), repeat=len(deltas))
    ]
    return {
        "mean_delta": observed,
        "p_value": sum(value >= observed - 1e-15 for value in null) / len(null),
    }


def summarize(rows):
    aggregate = {
        method: {
            metric: float(np.mean([row[metric] for row in rows if row["method"] == method]))
            for metric in METRICS
        }
        for method in (POLICY, *CONTROLS)
    }
    comparisons = {}
    for metric, control in (("area_pct", "previous_best"), ("recall_pct", "frozen_original")):
        deltas = np.asarray([
            np.mean([row[metric] for row in rows if row["method"] == POLICY and row["sut"] == sut])
            - np.mean([row[metric] for row in rows if row["method"] == control and row["sut"] == sut])
            for sut in SUT_IDS
        ])
        comparisons[metric] = {
            "control": control,
            "sut_block_deltas": dict(zip(SUT_IDS, deltas.tolist())),
            **exact_sign_randomization(deltas),
        }
    confirmed = (
        aggregate[POLICY]["area_pct"] > aggregate["previous_best"]["area_pct"]
        and aggregate[POLICY]["recall_pct"] > aggregate["frozen_original"]["recall_pct"]
        and comparisons["area_pct"]["p_value"] < .05
        and comparisons["recall_pct"]["p_value"] < .05
    )
    return aggregate, comparisons, confirmed


def result_row(pool, sut, seed, method, result, collision):
    measured = metrics(collision, result["selected_indices"])
    return {
        "pool": pool, "sut": sut, "seed": seed, "method": method,
        "area_pct": 100 * measured["area_200"],
        "recall_pct": 100 * measured["recall_200"],
        "F50": measured["checkpoints"]["50"],
        "F100": measured["checkpoints"]["100"], "F200": measured["F200"],
    }


def worker(connection):
    try:
        torch.set_num_threads(1)
        with threadpool_limits(limits=1):
            while True:
                message, task = connection.recv()
                if message == "stop":
                    return
                connection.send(("result", select(**task, oracle=RemoteOracle(connection))))
    except Exception as error:
        connection.send(("error", repr(error)))
        raise
    finally:
        connection.close()


def historical_inputs():
    history = load_history()
    train, _ = split_indices(next(iter(history.values()))["x"])
    experts = HistoricalExperts(subset(history, train))
    readout = [np.zeros((2, 2))]
    with np.load(HISTORY_ROOT / "history/responses.npz") as bank:
        for name in experts.history:
            parameters, _ = fit_readout(
                bank[name][train], bank[name + "_collision"][train],
                bank["x"][train, 4].astype(int),
            )
            readout.append(parameters)
    return experts, np.asarray(readout)


def main():
    experts, readout = historical_inputs()
    parent, child = mp.get_context("spawn").Pipe()
    process = mp.get_context("spawn").Process(target=worker, args=(child,))
    process.start()
    child.close()
    rows = []
    try:
        with threadpool_limits(limits=1):
            for seed in SEEDS:
                for pool in (0, 1):
                    with np.load(OUTPUT / f"pool_{pool}/{SUT_IDS[0]}/responses.npz") as bank:
                        x = bank["x"].copy()
                    prediction = experts.predict(x)
                    with torch.no_grad():
                        covariance = load_kernel(seed, "global_feedback").covariance(x).numpy()
                    for sut in SUT_IDS:
                        destination = ROOT / f"driving/pool_{pool}/{sut}/{POLICY}_{seed}.json"
                        with np.load(OUTPUT / f"pool_{pool}/{sut}/responses.npz") as bank:
                            np.testing.assert_array_equal(x, bank["x"])
                            reference = read_json(
                                OUTPUT / f"pool_{pool}/{sut}/baselines/frozen_original_{seed}.json"
                            )
                            if destination.exists():
                                result = read_json(destination)
                            else:
                                task = {
                                    "x": x, "covariance": covariance,
                                    "fixed_prior": prediction.fixed_mean(),
                                    "priors": np.column_stack((np.full(len(x), .5), prediction.mean)),
                                    "probability": np.r_[FALLBACK_PRIOR, (1 - FALLBACK_PRIOR) * prediction.group_weights],
                                    "readout": readout, "seed": seed,
                                }
                                started = time.perf_counter()
                                result = disclose(parent, task, bank["risk"], bank["collision"])
                                result.update(method=POLICY, selector_elapsed_s=time.perf_counter() - started)
                                write_json(destination, result)
                            if result["selected_indices"][:10] != reference["selected_indices"][:10]:
                                raise ValueError("Common paid initialization changed")
                            rows.append(result_row(pool, sut, seed, POLICY, result, bank["collision"]))
                            for control in CONTROLS:
                                control_result = read_json(
                                    OUTPUT / f"pool_{pool}/{sut}/baselines/{control}_{seed}.json"
                                )
                                rows.append(result_row(pool, sut, seed, control, control_result, bank["collision"]))
    finally:
        if process.is_alive():
            parent.send(("stop", None))
        parent.close()
        process.join(timeout=15)
        if process.is_alive():
            process.terminate()
            process.join()
        if process.exitcode != 0:
            raise RuntimeError("CG-CBM-FD selector failed")
    aggregate, comparisons, confirmed = summarize(rows)
    write_json(ROOT / "summary.json", {
        "status": "complete", "rows": rows, "aggregate": aggregate,
        "paired_comparisons": comparisons, "stability_confirmed": confirmed,
        "candidate_curves": 60, "new_physical_calls": 0,
    })
    print(aggregate)


if __name__ == "__main__":
    main()
