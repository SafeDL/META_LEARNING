# CG-CBM-FD评价与核验

本目录是CG-CBM-FD的唯一现行实验目录。方法、实验和结果采用同名目录，当前轨迹标识为`cg_cbm_fd`。

## 固定协议

- 六个SUT、两个2048点场景池和五个选择种子；
- 每条轨迹200次唯一查询，共同初始化10次并计入预算；
- 选择器请求某个索引后，才得到该场景的连续风险与碰撞标签；
- 当前高风险评价以严格`R > 0.5`为正例，报告高风险Area、Recall、H50、H100、H200及预算覆盖上限；
- 冻结碰撞指标另报Area、Recall、F50、F100和F200；当前选择器仍以碰撞C排序；
- 不新增物理仿真、控制器训练或场景池。

完整五种子结果保存在[当前结果](../../results/concordance_gated_compositional_bayesian_mixture/README.md)。核验重新读取60条候选轨迹和120条控制轨迹，检查唯一查询、共同初始化、指标和配对统计；七个核心模块的保留函数与冻结源码按语法树比较，明确排除五个已退役的采样/损失函数；17个未改变的实际方法依赖按字节比较，历史专家的简化实现则在两个完整候选池上与冻结预测逐元素比较。精确原源码保存在`confirmation/source_inputs.zip`中。

```powershell
conda activate metadrive
python -B -m experiments.concordance_gated_compositional_bayesian_mixture.verify
```

`evaluate.py`是主方法的五种子评价入口，采用固定配置并只接收请求后披露的目标反馈。`verify.py`仅核验已有轨迹与冻结来源；`compare.py`仅重算已有方法结果，不运行新选择轨迹。历史机制留出证据保存在结果目录的`historical_validation/`，旧形成阶段脚本已归档。

相同六SUT、两池、五种子和200次预算下的完整既有方法比较见[benchmark_comparison.md](../../results/concordance_gated_compositional_bayesian_mixture/benchmark_comparison.md)。主表同时披露每种方法使用的离线历史信息和在线反馈，额外48个行为配置的工程参照单独报告。

[compare.py](compare.py)直接检查15种方法的900条五种子轨迹，并补充核对9种方法的108条同种子轨迹，包含原始贝叶斯MoE、EGFD、Student-t和高斯控制。高风险与碰撞分别重算；高风险分母来自完整池，预算上限及固定初始化后的上限直接由实测标签与初始十次查询计算。仅重算既有记录：

```powershell
conda run -n metadrive python -B -m experiments.concordance_gated_compositional_bayesian_mixture.compare
```

方法定义与完整取舍见[唯一设计文档](../../docs/Failure_Discovery_Design.md)。

[ablate_neutral.py](ablate_neutral.py)仅运行一个固定种子11的中性分量删除消融：六SUT、两池、预算200，共12条轨迹。它直接复用冻结选择器，只改变组合后验的输入来源集合；既有门控和回退保持一致，逐次反馈来自锁定响应池。结果见[消融比较](../../results/concordance_gated_compositional_bayesian_mixture/components/historical_sources_only/README.md)。这组轨迹用于检查组件影响，不替换原五种子主结果。
