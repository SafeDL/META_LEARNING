"""Verify the frozen five-seed SECU-FD stability result."""

import ast
from pathlib import Path
import types
from zipfile import ZipFile

import numpy as np

from experiments.driving_benchmark.config import OUTPUT, SUT_IDS
from experiments.driving_benchmark.evaluation import metrics
from .config import CONTROLS, POLICY, ROOT
from .evaluate import summarize
from methods.history_guided_testing.config import SEEDS
from methods.history_guided_testing.io import read_json, write_json


PROJECT = Path(__file__).resolve().parents[2]
PACKAGE = PROJECT / "methods/concordance_gated_compositional_bayesian_mixture"
CORE_MODULES = (
    "composition",
    "concordance_gated",
    "posterior",
    "ranking",
    "set_equivalent_union",
    "supported",
    "set_equivalent_union_target",
)
RETIRED_FUNCTIONS = {
    "posterior": {"sampled_actions", "event_sources", "sampled_event_probability"},
    "composition": {"event_sources"},
    "ranking": {"conditional_ranking_loss"},
}


def active_syntax(source, module):
    tree = ast.parse(source)
    omitted = RETIRED_FUNCTIONS.get(module, set())
    tree.body = [node for node in tree.body if not isinstance(node, ast.FunctionDef) or node.name not in omitted]
    for node in tree.body:
        if isinstance(node, ast.ClassDef):
            node.body = [item for item in node.body if not isinstance(item, ast.FunctionDef) or item.name not in omitted]
    return ast.dump(tree)


def required_method_sources():
    sources = {
        path.relative_to(PROJECT).as_posix().removesuffix(".py").replace("/", ".").removesuffix(".__init__"): path
        for path in (PROJECT / "methods").rglob("*.py")
    }
    pending = [
        "methods.concordance_gated_compositional_bayesian_mixture.selection",
        "methods.historical_expert_mixture.experts",
        "methods.history_guided_testing.history",
        "methods.history_guided_testing.train",
    ]
    reached = set()
    while pending:
        module = pending.pop()
        if module in reached:
            continue
        reached.add(module)
        path = sources[module]
        package = module if path.name == "__init__.py" else module.rsplit(".", 1)[0]
        for node in ast.walk(ast.parse(path.read_text(encoding="utf-8-sig"))):
            if isinstance(node, ast.ImportFrom):
                prefix = package.split(".")[:len(package.split(".")) - node.level + 1] if node.level else []
                base = ".".join(prefix + (node.module.split(".") if node.module else []))
                imports = [base, *(f"{base}.{alias.name}" for alias in node.names)]
            elif isinstance(node, ast.Import):
                imports = [alias.name for alias in node.names]
            else:
                continue
            pending.extend(name for name in imports if name in sources and name not in reached)
    return {sources[name].relative_to(PROJECT).as_posix() for name in reached}


def verify_frozen_implementation(archive):
    for module in CORE_MODULES:
        original = archive.read(
            f"methods/feedback_value_search/{module}.py"
        ).decode("utf-8-sig")
        filename = "selection.py" if module == "set_equivalent_union_target" else f"{module}.py"
        current = (PACKAGE / filename).read_text(encoding="utf-8-sig")
        if active_syntax(original, module) != active_syntax(current, module):
            raise ValueError(f"Core algorithm changed after freezing: {module}")

    required = required_method_sources()
    dependencies = [
        name
        for name in archive.namelist()
        if name in required
        and not name.startswith("methods/feedback_value_search/")
    ]
    compared = 0
    for name in dependencies:
        if name in {
            "methods/historical_expert_mixture/config.py",
            "methods/historical_expert_mixture/experts.py",
        }:
            continue
        current = PROJECT / name
        if archive.read(name) != current.read_bytes():
            raise ValueError(f"Frozen method dependency changed: {name}")
        compared += 1
    original_readout = ast.parse(archive.read("methods/bayesian_active_search/readout.py").decode("utf-8-sig"))
    current_readout = ast.parse((PACKAGE / "readout.py").read_text(encoding="utf-8-sig"))
    original_fit = next(node for node in original_readout.body if isinstance(node, ast.FunctionDef) and node.name == "fit_readout")
    current_fit = next(node for node in current_readout.body if isinstance(node, ast.FunctionDef) and node.name == "fit_readout")
    if ast.dump(original_fit) != ast.dump(current_fit):
        raise ValueError("Historical readout fitting changed")
    from methods.concordance_gated_compositional_bayesian_mixture.readout import READOUT_PRIOR_SD
    if READOUT_PRIOR_SD != 20.:
        raise ValueError("Historical readout prior changed")
    verify_historical_predictions(archive)
    return compared


def verify_historical_predictions(archive):
    from methods.historical_expert_mixture import config
    from methods.historical_expert_mixture.experts import HistoricalExperts
    from methods.history_guided_testing.history import load_history, split_indices, subset

    frozen_config = types.ModuleType("frozen_historical_config")
    frozen_config.__file__ = str(PROJECT / "methods/historical_expert_mixture/config.py")
    exec(archive.read("methods/historical_expert_mixture/config.py"), frozen_config.__dict__)
    for name in ("BUDGET", "INITIAL_QUERIES", "NEIGHBORS", "NEIGHBOR_LENGTH", "NOISE", "JITTER", "FALLBACK_PRIOR"):
        if getattr(config, name) != getattr(frozen_config, name):
            raise ValueError(f"Historical prior setting changed: {name}")
    frozen = types.ModuleType("frozen_historical_experts")
    frozen.__package__ = "methods.historical_expert_mixture"
    exec(archive.read("methods/historical_expert_mixture/experts.py"), frozen.__dict__)
    history = load_history()
    train, _ = split_indices(next(iter(history.values()))["x"])
    history = subset(history, train)
    previous, current = frozen.HistoricalExperts(history), HistoricalExperts(history)
    for pool in (0, 1):
        with np.load(OUTPUT / f"pool_{pool}/{SUT_IDS[0]}/responses.npz") as bank:
            old_prediction, new_prediction = previous.predict(bank["x"]), current.predict(bank["x"])
            np.testing.assert_array_equal(old_prediction.mean, new_prediction.mean)
            np.testing.assert_array_equal(old_prediction.fixed_mean(), new_prediction.fixed_mean())
            np.testing.assert_array_equal(old_prediction.group_weights, new_prediction.group_weights)


def main():
    stored = read_json(ROOT / "summary.json")
    rows = []
    trajectories = 0
    for seed in SEEDS:
        for pool in (0, 1):
            for sut in SUT_IDS:
                candidate_path = ROOT / f"driving/pool_{pool}/{sut}/{POLICY}_{seed}.json"
                candidate = read_json(candidate_path)
                selected = candidate["selected_indices"]
                if len(selected) != 200 or len(set(selected)) != 200:
                    raise ValueError(f"Invalid trajectory: {candidate_path}")
                with np.load(OUTPUT / f"pool_{pool}/{sut}/responses.npz") as bank:
                    reference = read_json(
                        OUTPUT
                        / f"pool_{pool}/{sut}/baselines/"
                        f"frozen_original_{seed}.json"
                    )
                    if selected[:10] != reference["selected_indices"][:10]:
                        raise ValueError("Common initialization differs")
                    measured = metrics(bank["collision"], selected)
                    rows.append(
                        {
                            "pool": pool,
                            "sut": sut,
                            "seed": seed,
                            "method": POLICY,
                            "area_pct": 100 * measured["area_200"],
                            "recall_pct": 100 * measured["recall_200"],
                            "F50": measured["checkpoints"]["50"],
                            "F100": measured["checkpoints"]["100"],
                            "F200": measured["F200"],
                        }
                    )
                    for control in CONTROLS:
                        result = read_json(
                            OUTPUT
                            / f"pool_{pool}/{sut}/baselines/"
                            f"{control}_{seed}.json"
                        )
                        control_metrics = metrics(
                            bank["collision"], result["selected_indices"]
                        )
                        rows.append(
                            {
                                "pool": pool,
                                "sut": sut,
                                "seed": seed,
                                "method": control,
                                "area_pct": 100 * control_metrics["area_200"],
                                "recall_pct": 100
                                * control_metrics["recall_200"],
                                "F50": control_metrics["checkpoints"]["50"],
                                "F100": control_metrics["checkpoints"]["100"],
                                "F200": control_metrics["F200"],
                            }
                        )
                trajectories += 1

    aggregate, comparisons, confirmed = summarize(rows)
    if aggregate != stored["aggregate"]:
        raise ValueError("Recomputed aggregate differs")
    if comparisons != stored["paired_comparisons"]:
        raise ValueError("Recomputed paired tests differ")
    if confirmed != stored["stability_confirmed"]:
        raise ValueError("Recomputed gate differs")

    source_count = 0
    with ZipFile(ROOT / "confirmation/source_inputs.zip") as archive:
        dependency_count = verify_frozen_implementation(archive)
        for name in archive.namelist():
            if not archive.read(name):
                raise ValueError(f"Empty frozen source: {name}")
            source_count += 1

    verification = {
        "status": "complete",
        "candidate_trajectories_checked": trajectories,
        "candidate_queries_checked": trajectories * 200,
        "control_trajectories_checked": 2 * trajectories,
        "metrics_recomputed": True,
        "paired_tests_recomputed": True,
        "frozen_source_files_readable": source_count,
        "retained_core_modules_ast_identical": len(CORE_MODULES),
        "retired_unused_functions_excluded": sum(len(names) for names in RETIRED_FUNCTIONS.values()),
        "method_dependency_files_byte_identical": dependency_count,
        "historical_readout_fit_ast_identical": True,
        "historical_expert_predictions_exactly_match_frozen_pools": 2,
        "source_comparison_scope": (
            "core algorithm syntax and exact method dependencies; experiment orchestration paths were renamed"
        ),
        "stability_confirmed": confirmed,
        "new_physical_calls": 0,
    }
    write_json(ROOT / "verification.json", verification)
    print(verification)


if __name__ == "__main__":
    main()
