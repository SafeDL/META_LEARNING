"""One fixed-seed ablation of the composition's neutral risk/event components."""
import multiprocessing as mp
import time

import numpy as np
import torch
from threadpoolctl import threadpool_limits

from experiments.driving_benchmark.config import BUDGET, OUTPUT, SUT_IDS
from experiments.driving_benchmark.evaluation import disclose
from methods.history_guided_testing.io import read_json, write_json
from methods.history_guided_testing.train import load_kernel

from .compare import HIGH_RISK_METRICS, METRICS, measured_row
from .config import POLICY, ROOT
from .evaluate import historical_inputs, worker


SEED = 11
METHOD = "historical_sources_only"
DESTINATION = ROOT / "components" / METHOD


def main():
    experts, readout = historical_inputs()
    protocol = {
        "method": METHOD,
        "control": "CG-CBM-FD",
        "selection_seed": SEED,
        "suts": list(SUT_IDS),
        "pools": 2,
        "budget": BUDGET,
        "initial_queries": 10,
        "change": "remove neutral risk mean and neutral conditional-event component from composition",
        "retained": "six historical sources, same kernel, readouts, target R/C, gate, fallback, calibration and reference protection",
        "prior": "renormalized group-balanced six-source prior; same 0.5 diagonal/independent pair structure",
        "scope": "the existing fallback branch remains intact; this is not removal of every neutral prior in the algorithm",
        "frozen_core_source": "../../confirmation/source_inputs.zip",
        "new_physical_calls": 0,
    }
    write_json(DESTINATION / "protocol.json", protocol)
    parent, child = mp.get_context("spawn").Pipe()
    process = mp.get_context("spawn").Process(target=worker, args=(child,))
    process.start()
    child.close()
    rows = []
    new_runs = 0
    try:
        with threadpool_limits(limits=1):
            for pool in (0, 1):
                with np.load(OUTPUT / f"pool_{pool}/{SUT_IDS[0]}/responses.npz") as bank:
                    x = bank["x"].copy()
                prediction = experts.predict(x)
                with torch.no_grad():
                    covariance = load_kernel(SEED, "global_feedback").covariance(x).numpy()
                task = {
                    "x": x, "covariance": covariance,
                    "fixed_prior": prediction.fixed_mean(),
                    "priors": prediction.mean,
                    "probability": prediction.group_weights,
                    "readout": readout[1:], "seed": SEED,
                }
                for sut in SUT_IDS:
                    destination = DESTINATION / f"driving/pool_{pool}/{sut}/{METHOD}_{SEED}.json"
                    with np.load(OUTPUT / f"pool_{pool}/{sut}/responses.npz") as bank:
                        np.testing.assert_array_equal(x, bank["x"])
                        reference_path = ROOT / f"driving/pool_{pool}/{sut}/{POLICY}_{SEED}.json"
                        reference = read_json(reference_path)
                        if destination.exists():
                            result = read_json(destination)
                        else:
                            started = time.perf_counter()
                            result = disclose(parent, task, bank["risk"], bank["collision"])
                            result.update(method=METHOD, selector_elapsed_s=time.perf_counter() - started)
                            write_json(destination, result)
                            new_runs += 1
                        if result["selected_indices"][:10] != reference["selected_indices"][:10]:
                            raise ValueError("Ablation changed the common paid initialization")
                        if len(result["evidence"][-1]["composition"]["source_posterior"]) != 6:
                            raise ValueError("Neutral risk component was not removed")
                        if len(result["evidence"][-1]["composition"]["event_source_posterior"]) != 6:
                            raise ValueError("Neutral event component was not removed")
                        for method, path in (("CG-CBM-FD", reference_path), (METHOD, destination)):
                            rows.append(measured_row(
                                path, pool, sut, SEED, method, bank["risk"], bank["collision"],
                                (BUDGET, BUDGET),
                            ))
                    write_json(DESTINATION / "progress.json", {
                        "completed_ablation_trajectories": len(rows) // 2,
                        "planned_ablation_trajectories": 12,
                        "new_physical_calls": 0,
                    })
                    print(f"Completed pool={pool} sut={sut}: {len(rows) // 2}/12", flush=True)
    finally:
        if process.is_alive():
            parent.send(("stop", None))
        parent.close()
        process.join(timeout=15)
        if process.is_alive():
            process.terminate()
            process.join()
        if process.exitcode != 0:
            raise RuntimeError("Neutral-component ablation selector failed")
    aggregate = {
        method: {
            metric: float(np.mean([row[metric] for row in rows if row["method"] == method]))
            for metric in (*HIGH_RISK_METRICS, *METRICS)
        }
        for method in ("CG-CBM-FD", METHOD)
    }
    deltas = {
        metric: aggregate[METHOD][metric] - aggregate["CG-CBM-FD"][metric]
        for metric in (*HIGH_RISK_METRICS, *METRICS)
    }
    write_json(DESTINATION / "comparison.json", {
        "status": "complete", "protocol": protocol, "aggregate": aggregate,
        "without_minus_with_neutral": deltas, "trajectory_metrics": rows,
        "common_initialization_verified": True,
        "six_risk_and_six_event_components_verified": True,
        "paid_responses_match_locked_banks": True,
        "new_selector_runs": new_runs, "new_physical_calls": 0,
    })
    write_report(aggregate, rows)
    print(aggregate, flush=True)
    print({"without_minus_with_neutral": deltas}, flush=True)


def write_report(aggregate, rows):
    lines = [
        "# 组合模型中性分量消融", "",
        "固定六SUT、两池、种子11、预算200及共同十次初始化；只删除组合模型的中性风险与中性碰撞分量，历史来源先验重新归一化。风险—碰撞组合由7×7变成6×6；既有可信度门控、保守回退分支和参考保护均保留。", "",
        "本实验只新增12条选择器轨迹，逐次披露既有锁定响应，没有新增物理仿真调用。与原方法比较时统一取种子11，不与五种子均值混用。", "",
        "| 方法 | 高风险Area % | 高风险Recall % | H50 | H100 | H200 | 碰撞Area % | 碰撞Recall % | F50 | F100 | F200 |",
        "|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for method, values in aggregate.items():
        measured = " | ".join(f"{values[key]:.3f}" for key in (*HIGH_RISK_METRICS, *METRICS))
        lines.append(f"| {method} | {measured} |")
    lines.extend([
        "", "| SUT | 删除后高风险Area差值（百分点） | 删除后高风险Recall差值（百分点） | 删除后H200差值 |",
        "|---|---:|---:|---:|",
    ])
    for sut in SUT_IDS:
        values = {
            method: {
                key: float(np.mean([row[key] for row in rows if row["sut"] == sut and row["method"] == method]))
                for key in ("high_risk_area_pct", "high_risk_recall_pct", "H200")
            }
            for method in aggregate
        }
        differences = " | ".join(
            f"{values[METHOD][key] - values['CG-CBM-FD'][key]:+.3f}"
            for key in ("high_risk_area_pct", "high_risk_recall_pct", "H200")
        )
        lines.append(f"| {sut} | {differences} |")
    lines.extend([
        "", "差值为删除后减删除前。该单种子消融检查组件影响，不是新主方法的五种子确认。",
        "", "[完整比较](comparison.json)保存24条配对轨迹指标；[协议](protocol.json)记录唯一改动范围；[driving](driving/)保存12条新增查询轨迹。", "",
    ])
    (DESTINATION / "README.md").write_text("\n".join(lines), encoding="utf-8")


if __name__ == "__main__":
    main()
