"""Recompute the common five-seed benchmark from all existing query traces."""

import itertools
from pathlib import Path

import numpy as np

from experiments.driving_benchmark.config import BUDGET, INITIAL_QUERIES, OUTPUT, SUT_IDS
from experiments.driving_benchmark.evaluation import metrics
from methods.history_guided_testing.config import SEEDS
from methods.history_guided_testing.io import read_json, write_json

from .config import POLICY, ROOT


PROJECT = Path(__file__).resolve().parents[2]
DESTINATION = ROOT
METRICS = ("area_pct", "recall_pct", "F50", "F100", "F200")
HIGH_RISK_THRESHOLD = .5
HIGH_RISK_METRICS = ("high_risk_area_pct", "high_risk_recall_pct", "H50", "H100", "H200")


def measured_row(path, pool, sut, seed, method, risk, collision, expected_feedback):
    trace = read_json(path)
    selected = trace["selected_indices"]
    if len(selected) != BUDGET or len(set(selected)) != BUDGET:
        raise ValueError(f"Invalid budget or repeated queries: {path}")
    if not all(0 <= index < len(collision) for index in selected):
        raise ValueError(f"Query outside the shared pool: {path}")
    observations = trace.get("disclosures") or trace["queries"]
    if len(observations) != BUDGET:
        raise ValueError(f"Incomplete observation record: {path}")
    risk_count = collision_count = 0
    for index, observation in zip(selected, observations):
        if observation["index"] != index:
            raise ValueError(f"Observation order differs: {path}")
        if observation["risk"] is not None:
            risk_count += 1
            if observation["risk"] != float(risk[index]):
                raise ValueError(f"Disclosed risk differs from measured response: {path}")
        if observation["collision"] is not None:
            collision_count += 1
            if bool(observation["collision"]) != bool(collision[index]):
                raise ValueError(f"Disclosed collision differs from measured response: {path}")
    if (risk_count, collision_count) != expected_feedback:
        raise ValueError(f"Feedback channels differ from the method protocol: {path}")

    measured = metrics(collision, selected)
    high_risk = np.asarray(risk) > HIGH_RISK_THRESHOLD
    high_risk_measured = metrics(high_risk, selected)
    total_high_risk = int(high_risk.sum())
    initial_high_risk = int(high_risk[selected[:INITIAL_QUERIES]].sum())
    collision_mask = np.asarray(collision, dtype=bool)
    return {
        "pool": pool,
        "sut": sut,
        "seed": seed,
        "method": method,
        "area_pct": 100 * measured["area_200"],
        "recall_pct": 100 * measured["recall_200"],
        "F50": measured["checkpoints"]["50"],
        "F100": measured["checkpoints"]["100"],
        "F200": measured["F200"],
        "total_failures": measured["total_collisions"],
        "budget_recall_ceiling_pct": 100 * min(BUDGET, measured["total_collisions"]) / measured["total_collisions"],
        "budget_ceiling_attainment_pct": 100 * measured["terminal_ceiling_attainment"],
        "high_risk_area_pct": 100 * high_risk_measured["area_200"],
        "high_risk_recall_pct": 100 * high_risk_measured["recall_200"],
        "H50": high_risk_measured["checkpoints"]["50"],
        "H100": high_risk_measured["checkpoints"]["100"],
        "H200": high_risk_measured["F200"],
        "total_high_risk": total_high_risk,
        "initial_high_risk": initial_high_risk,
        "high_risk_budget_recall_ceiling_pct": 100 * min(BUDGET, total_high_risk) / total_high_risk,
        "high_risk_initialization_recall_ceiling_pct": (
            100 * min(total_high_risk, BUDGET - INITIAL_QUERIES + initial_high_risk) / total_high_risk
        ),
        "high_risk_budget_ceiling_attainment_pct": 100 * high_risk_measured["terminal_ceiling_attainment"],
        "high_risk_without_collision": int(np.count_nonzero(high_risk & ~collision_mask)),
        "collision_without_high_risk": int(np.count_nonzero(collision_mask & ~high_risk)),
        "risk_responses_recorded": risk_count,
        "collision_responses_recorded": collision_count,
        "trace": path.relative_to(PROJECT).as_posix(),
    }


def sign_randomization(deltas):
    observed = float(np.mean(deltas))
    null = [
        float(np.mean(np.asarray(signs) * deltas))
        for signs in itertools.product((-1, 1), repeat=len(deltas))
    ]
    return sum(value >= observed - 1e-15 for value in null) / len(null)


def main():
    report_path = DESTINATION / "benchmark_comparison.json"
    report = read_json(report_path)
    methods = [row["method"] for row in report["rows"]]
    rows = []
    for pool in (0, 1):
        coordinates = None
        for sut in SUT_IDS:
            with np.load(OUTPUT / f"pool_{pool}/{sut}/responses.npz") as bank:
                if coordinates is None:
                    coordinates = bank["x"].copy()
                np.testing.assert_array_equal(coordinates, bank["x"])
                for seed in SEEDS:
                    for method in methods:
                        if method == "CG-CBM-FD":
                            path = ROOT / f"driving/pool_{pool}/{sut}/{POLICY}_{seed}.json"
                        else:
                            path = OUTPUT / f"pool_{pool}/{sut}/baselines/{method}_{seed}.json"
                        expected_feedback = (BUDGET, BUDGET) if method == "CG-CBM-FD" else (
                            (0, BUDGET) if method == "ras_frt_uq" else (BUDGET, 0)
                        )
                        rows.append(
                            measured_row(
                                path, pool, sut, seed, method, bank["risk"], bank["collision"],
                                expected_feedback,
                            )
                        )

    aggregates = {}
    sut_blocks = {}
    for method in methods:
        sut_blocks[method] = {
            sut: {
                metric: float(np.mean([
                    row[metric] for row in rows
                    if row["method"] == method and row["sut"] == sut
                ]))
                for metric in (*METRICS, *HIGH_RISK_METRICS)
            }
            for sut in SUT_IDS
        }
        aggregates[method] = {
            metric: float(np.mean([block[metric] for block in sut_blocks[method].values()]))
            for metric in (*METRICS, *HIGH_RISK_METRICS)
        }

    candidate = aggregates["CG-CBM-FD"]
    for row in report["rows"]:
        computed = aggregates[row["method"]]
        for metric in METRICS:
            if not np.isclose(computed[metric], row[metric], atol=1e-10, rtol=0):
                raise ValueError(f"Published aggregate differs: {row['method']} {metric}")
        row.update(computed)
        row["cg_minus_area_pct"] = candidate["area_pct"] - computed["area_pct"]
        row["cg_minus_recall_pct"] = candidate["recall_pct"] - computed["recall_pct"]
        row["cg_minus_high_risk_area_pct"] = candidate["high_risk_area_pct"] - computed["high_risk_area_pct"]
        row["cg_minus_high_risk_recall_pct"] = candidate["high_risk_recall_pct"] - computed["high_risk_recall_pct"]

    comparisons = {}
    for method in methods:
        if method == "CG-CBM-FD":
            continue
        blocks = {
            sut: {
                "area_delta_pct": sut_blocks["CG-CBM-FD"][sut]["area_pct"]
                - sut_blocks[method][sut]["area_pct"],
                "recall_delta_pct": sut_blocks["CG-CBM-FD"][sut]["recall_pct"]
                - sut_blocks[method][sut]["recall_pct"],
                "high_risk_area_delta_pct": sut_blocks["CG-CBM-FD"][sut]["high_risk_area_pct"]
                - sut_blocks[method][sut]["high_risk_area_pct"],
                "high_risk_recall_delta_pct": sut_blocks["CG-CBM-FD"][sut]["high_risk_recall_pct"]
                - sut_blocks[method][sut]["high_risk_recall_pct"],
            }
            for sut in SUT_IDS
        }
        area = np.asarray([block["area_delta_pct"] for block in blocks.values()])
        recall = np.asarray([block["recall_delta_pct"] for block in blocks.values()])
        high_risk_area = np.asarray([block["high_risk_area_delta_pct"] for block in blocks.values()])
        high_risk_recall = np.asarray([block["high_risk_recall_delta_pct"] for block in blocks.values()])
        comparisons[method] = {
            "sut_block_deltas": blocks,
            "mean_area_delta_pct": float(np.mean(area)),
            "area_one_sided_signflip_p": sign_randomization(area),
            "mean_recall_delta_pct": float(np.mean(recall)),
            "recall_one_sided_signflip_p": sign_randomization(recall),
            "mean_high_risk_area_delta_pct": float(np.mean(high_risk_area)),
            "high_risk_area_one_sided_signflip_p": sign_randomization(high_risk_area),
            "mean_high_risk_recall_delta_pct": float(np.mean(high_risk_recall)),
            "high_risk_recall_one_sided_signflip_p": sign_randomization(high_risk_recall),
        }

    verification = {
        "status": "complete",
        "methods_compared": len(methods),
        "trajectories_checked": len(rows),
        "recorded_queries_checked": BUDGET * len(rows),
        "shared_candidate_coordinates_verified": True,
        "unique_queries_verified": True,
        "disclosed_responses_match_measured_banks": True,
        "feedback_channel_permissions_verified": True,
        "all_aggregates_recomputed_from_traces": True,
        "all_paired_tests_recomputed": True,
        "high_risk_positive_rule": "measured R > 0.5, strictly greater",
        "collision_metrics_preserved": True,
        "new_physical_calls": 0,
        "new_selector_runs": 0,
    }
    report.update(
        metric_definitions={
            "primary_evaluation": "high-risk discovery; H = 1[measured R > 0.5]",
            "high_risk_area_pct": "100 * sum(H_t, t=1..200) / (200 * full-pool high-risk count)",
            "high_risk_recall_pct": "100 * H200 / full-pool high-risk count",
            "H50_H100_H200": "cumulative counts of queried scenarios with measured R > 0.5",
            "area_pct_recall_pct_F50_F100_F200": "preserved frozen native-collision metrics, not high-risk metrics",
            "selection_target": "existing CG-CBM-FD selector still predicts native collision C; no selector changes or reruns",
            "aggregation": "equal mean over six SUTs, two pools and five selection seeds",
        },
        paired_sut_block_comparisons=comparisons,
        trajectory_metrics=rows,
        verification=verification,
        sources=[
            "results/driving_benchmark/pool_{pool}/{sut}/responses.npz",
            "results/driving_benchmark/pool_{pool}/{sut}/baselines/{method}_{seed}.json",
            "results/concordance_gated_compositional_bayesian_mixture/driving/pool_{pool}/{sut}/cg_cbm_fd_{seed}.json",
        ],
    )
    write_json(report_path, report)
    write_json(DESTINATION / "comparison_verification.json", verification)
    print(verification)
    components = compare_method_components(rows)
    audit = audit_recall(rows)
    write_high_risk_report(report, components, audit)
    status = read_json(ROOT / "status.json")
    status.update(
        aggregate_positive_rule="native collision C; preserved frozen metrics",
        high_risk_aggregate={
            **{metric: candidate[metric] for metric in HIGH_RISK_METRICS},
            **audit["high_risk"]["aggregate"],
        },
        current_evaluation_target="high-risk discovery: measured R > 0.5",
        selection_target="native collision C; frozen selector unchanged",
    )
    write_json(ROOT / "status.json", status)


def compare_method_components(full_rows):
    existing = read_json(OUTPUT / "unified_comparison.json")
    historical = PROJECT / "results/historical_expert_mixture"
    variants = {
        "fixed_mean": (historical, "risk R"),
        "bayesian_sources": (historical, "risk R"),
        "composition_myopic": (ROOT / "components/composition", "R + C"),
        "concordance_gated": (ROOT / "components/concordance", "R + C"),
    }
    controls = ("event_signs_protected", "student_protected", "student_unprotected", "gaussian_unprotected")
    rows = [row.copy() for row in full_rows if row["method"] == "CG-CBM-FD" and row["seed"] == 11]
    for pool in (0, 1):
        for sut in SUT_IDS:
            reference = read_json(OUTPUT / f"pool_{pool}/{sut}/baselines/frozen_original_11.json")
            paths = {
                method: source / f"driving/pool_{pool}/{sut}/{method}_11.json"
                for method, (source, _) in variants.items()
            }
            for method in controls:
                matched = next(
                    row for row in existing["rows"]
                    if row["method"] == method and row["pool"] == pool and row["sut"] == sut
                )
                paths[method] = OUTPUT / matched["path"]
            with np.load(OUTPUT / f"pool_{pool}/{sut}/responses.npz") as bank:
                for method, path in paths.items():
                    trace = read_json(path)
                    if trace["selected_indices"][:10] != reference["selected_indices"][:10]:
                        raise ValueError(f"Component comparison initialization differs: {path}")
                    rows.append(measured_row(
                        path, pool, sut, 11, method, bank["risk"], bank["collision"],
                        (BUDGET, BUDGET),
                    ))
    methods = ("CG-CBM-FD", *variants, *controls)
    aggregate = {
        method: {
            metric: float(np.mean([row[metric] for row in rows if row["method"] == method]))
            for metric in (*METRICS, *HIGH_RISK_METRICS)
        }
        for method in methods
    }
    result = {
        "scope": "same six SUTs, two pools, seed 11, 200 queries, and common ten-query initialization",
        "history": "same original six historical sources",
        "feedback_used": {
            "CG-CBM-FD": "R + C",
            **{method: info[1] for method, info in variants.items()},
            **{method: "R + C" for method in controls},
        },
        "feedback_note": "Risk-only MoE variants record C for evaluation but do not use C for inference.",
        "aggregate": aggregate,
        "trajectory_metrics": rows,
        "trajectories_checked": len(rows),
        "new_selector_runs": 0,
        "new_physical_calls": 0,
        "positive_rules": {"high_risk": "R > 0.5", "collision": "native collision C"},
    }
    write_json(DESTINATION / "component_comparison.json", result)
    print({"component_comparison_trajectories": len(rows), "new_selector_runs": 0})
    return result


def audit_recall(rows):
    candidate = [row for row in rows if row["method"] == "CG-CBM-FD"]
    collision_by_sut, high_risk_by_sut = {}, {}
    for sut in SUT_IDS:
        selected = [row for row in candidate if row["sut"] == sut]
        collision_by_sut[sut] = {
            "pool_positive_counts": {
                str(pool): next(row["total_failures"] for row in selected if row["pool"] == pool)
                for pool in (0, 1)
            },
            "mean_F200": float(np.mean([row["F200"] for row in selected])),
            "recall_pct": float(np.mean([row["recall_pct"] for row in selected])),
            "budget_recall_ceiling_pct": float(np.mean([row["budget_recall_ceiling_pct"] for row in selected])),
            "budget_ceiling_attainment_pct": float(np.mean([row["budget_ceiling_attainment_pct"] for row in selected])),
        }
        high_risk_by_sut[sut] = {
            "pool_positive_counts": {
                str(pool): next(row["total_high_risk"] for row in selected if row["pool"] == pool)
                for pool in (0, 1)
            },
            "mean_H200": float(np.mean([row["H200"] for row in selected])),
            **{
                metric: float(np.mean([row[f"high_risk_{metric}"] for row in selected]))
                for metric in (
                    "recall_pct", "budget_recall_ceiling_pct",
                    "initialization_recall_ceiling_pct", "budget_ceiling_attainment_pct",
                )
            },
            "pool_high_risk_without_collision": {
                str(pool): next(row["high_risk_without_collision"] for row in selected if row["pool"] == pool)
                for pool in (0, 1)
            },
            "pool_collision_without_high_risk": {
                str(pool): next(row["collision_without_high_risk"] for row in selected if row["pool"] == pool)
                for pool in (0, 1)
            },
        }
    result = {
        "aggregation": "equal mean over six SUTs, two pools, and five selection seeds",
        "budget_ceiling_definition": "min(200, full-pool positive count) / full-pool positive count",
        "initialization_ceiling_definition": "min(full-pool positive count, 190 + positives in the actual first ten queries) / full-pool positive count",
        "initialization_ceiling_scope": "ideal remaining choices after fixed initialization; no additional family or protection constraints imposed",
        "ceiling_attainment_definition": "found / min(200, full-pool positive count); distinct from Recall",
        "high_risk": {
            "positive_rule": "measured R > 0.5, strictly greater",
            "recall_definition": "H200 / all high-risk scenarios in the full candidate pool",
            "by_sut": high_risk_by_sut,
            "aggregate": {
                metric: float(np.mean([row[f"high_risk_{metric}"] for row in candidate]))
                for metric in (
                    "recall_pct", "budget_recall_ceiling_pct",
                    "initialization_recall_ceiling_pct", "budget_ceiling_attainment_pct",
                )
            },
        },
        "collision": {
            "positive_rule": "native simulator collision C",
            "recall_definition": "F200 / all collision scenarios in the full candidate pool",
            "by_sut": collision_by_sut,
            "aggregate": {
                metric: float(np.mean([row[metric] for row in candidate]))
                for metric in ("recall_pct", "budget_recall_ceiling_pct", "budget_ceiling_attainment_pct")
            },
        },
    }
    result["collision"]["aggregate"]["micro_recall_pct"] = (
        100 * sum(row["F200"] for row in candidate)
        / sum(row["total_failures"] for row in candidate)
    )
    result["high_risk"]["aggregate"].update(
        micro_recall_pct=100 * sum(row["H200"] for row in candidate) / sum(row["total_high_risk"] for row in candidate),
        mean_H200=float(np.mean([row["H200"] for row in candidate])),
    )
    write_json(DESTINATION / "recall_denominator_audit.json", result)
    print({label: result[label]["aggregate"] for label in ("high_risk", "collision")})
    return result


def write_high_risk_report(report, components, audit):
    path = DESTINATION / "benchmark_comparison.md"
    collision_section = path.read_text(encoding="utf-8").split("## 标准基准与主方法（实际碰撞）", 1)[1]
    lines = [
        "# CG-CBM-FD统一基准比较", "",
        "当前评价按`R > 0.5`定义高风险场景。全部高风险指标由既有查询顺序与锁定实测风险重算；选择器和原始轨迹保持冻结，当前CG-CBM-FD排序目标仍是实际碰撞C。", "",
        "完整比较使用六SUT、两个2048点场景池、五个选择种子和200次唯一查询；初始化十次计入预算。900条五种子轨迹和108条种子11补充轨迹均未重跑，新增物理测试为零。初始化规则、历史信息和用于推断的反馈通道沿用各自方法，属于相同测试成本比较。", "",
        "## 高风险发现：R > 0.5", "",
        "`H_t`为前t次测试中满足严格`R > 0.5`的场景数，`N_H`为全池高风险场景数。高风险Recall=`H200/N_H`；高风险Area=`sum(H_t)/(200*N_H)`。所有表中百分比均为逐轨迹归一化后的宏平均。", "",
    ]
    for title, rows in (
        ("标准历史信息", [row for row in report["rows"] if row["group"] != "extra-history engineering reference"]),
        ("额外48个参数配置的工程参照", [row for row in report["rows"] if row["group"] == "extra-history engineering reference"]),
    ):
        lines.extend([f"### {title}", "", "| 方法 | 历史信息 | 推断反馈 | 高风险Area % | 高风险Recall % | H50 | H100 | H200 |", "|---|---|---|---:|---:|---:|---:|---:|"])
        for row in sorted(rows, key=lambda row: row["high_risk_area_pct"], reverse=True):
            values = " | ".join(f"{row[key]:.3f}" for key in HIGH_RISK_METRICS)
            lines.append(f"| {row['method']} | {row['offline_history']} | {row['online_feedback']} | {values} |")
        lines.append("")
    lines.extend(["### 种子11的组件方法比较", "", "相同六SUT、两池、六历史来源及共同十次初始化；仅种子11。反馈记录与执行规则差异见[component_comparison.json](component_comparison.json)。", "", "| 方法 | 推断反馈 | 高风险Area % | 高风险Recall % | H50 | H100 | H200 |", "|---|---|---:|---:|---:|---:|---:|"])
    for method, row in sorted(components["aggregate"].items(), key=lambda item: item[1]["high_risk_area_pct"], reverse=True):
        values = " | ".join(f"{row[key]:.3f}" for key in HIGH_RISK_METRICS)
        lines.append(f"| {method} | {components['feedback_used'][method]} | {values} |")
    lines.extend(["", "### 预算200下的覆盖上限", "", "| SUT | 两池高风险总数 | CG平均H200 | CG覆盖率 % | 理想预算上限 % | 固定十次初始化后的上限 % |", "|---|---|---:|---:|---:|---:|"])
    for sut, row in audit["high_risk"]["by_sut"].items():
        counts = "/".join(str(value) for value in row["pool_positive_counts"].values())
        lines.append(f"| {sut} | {counts} | {row['mean_H200']:.3f} | {row['recall_pct']:.3f} | {row['budget_recall_ceiling_pct']:.3f} | {row['initialization_recall_ceiling_pct']:.3f} |")
    aggregate = audit["high_risk"]["aggregate"]
    original = next(row for row in report["rows"] if row["method"] == "frozen_original")
    candidate = next(row for row in report["rows"] if row["method"] == "CG-CBM-FD")
    area_delta = candidate["high_risk_area_pct"] - original["high_risk_area_pct"]
    recall_delta = candidate["high_risk_recall_pct"] - original["high_risk_recall_pct"]
    lines.extend([
        "", f"高风险宏平均Recall为{aggregate['recall_pct']:.3f}%，预算理论上限为{aggregate['budget_recall_ceiling_pct']:.3f}%；计入实际初始化后的理想上限为{aggregate['initialization_recall_ceiling_pct']:.3f}%。后者假设剩余查询可以理想地挑选高风险场景，未附加场景族和参考保护限制。预算上限达成率为{aggregate['budget_ceiling_attainment_pct']:.3f}%，微平均Recall为{aggregate['micro_recall_pct']:.3f}%，这些量均不替代宏平均Recall。", "",
        f"相对冻结原方法，CG-CBM-FD的高风险Area差值为{area_delta:+.3f}个百分点，末端高风险Recall差值为{recall_delta:+.3f}个百分点。高风险目标下并非所有指标最好；种子11补充比较也有控制方法取得更高高风险Area。", "",
        "风险阈值标签与碰撞标签不同。旧碰撞排名只支持碰撞发现结论；高风险排名和配对统计见[benchmark_comparison.json](benchmark_comparison.json)，完整分母及两类标签的差异见[recall_denominator_audit.json](recall_denominator_audit.json)。", "",
        "## 标准基准与主方法（实际碰撞）" + collision_section,
    ])
    path.write_text("\n".join(lines), encoding="utf-8")


if __name__ == "__main__":
    main()
