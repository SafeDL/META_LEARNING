"""Canonical locations and fixed identifiers for the retained method."""
from pathlib import Path


PROJECT = Path(__file__).resolve().parents[2]
ROOT = PROJECT / "results/concordance_gated_compositional_bayesian_mixture"
POLICY = "cg_cbm_fd"
CONTROLS = ("previous_best", "frozen_original")
METRICS = ("area_pct", "recall_pct", "F50", "F100", "F200")
