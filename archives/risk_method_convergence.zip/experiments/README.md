# 实验入口

本目录保留三个实验目录。

| 目录 | 职责 |
|---|---|
| [concordance_gated_compositional_bayesian_mixture](concordance_gated_compositional_bayesian_mixture/README.md) | 当前CG-CBM-FD选择器评价、冻结来源核验、统一方法比较及Recall分母检查 |
| [driving_benchmark](driving_benchmark/README.md) | 六SUT、两池、200次预算的物理数据、基线和隔离反馈接口 |
| [scale_adaptive_testing](scale_adaptive_testing/README.md) | Student-t尺度控制的数学与历史验证 |

当前方法数据统一保存到同名[结果目录](../results/concordance_gated_compositional_bayesian_mixture/README.md)。退役的前瞻、条件专家与神经Gate实验已归档并从本目录删除。设计与实现见[唯一设计文档](../docs/Failure_Discovery_Design.md)和[方法索引](../methods/README.md)。
