"""Two predeclared source-prior controls on the existing measured banks."""
import multiprocessing as mp
from pathlib import Path
import time
from zipfile import ZipFile

import numpy as np
import torch
from threadpoolctl import threadpool_limits

from experiments.driving_benchmark.config import OUTPUT, SUT_IDS
from experiments.driving_benchmark.evaluation import disclose, metrics
from methods.historical_expert_mixture.config import FALLBACK_PRIOR
from methods.historical_expert_mixture.experts import HistoricalExperts
from methods.history_guided_testing.experiment import RemoteOracle
from methods.history_guided_testing.history import load_history, split_indices, subset
from methods.history_guided_testing.io import read_json, write_json
from methods.history_guided_testing.train import load_kernel
from methods.scale_adaptive_expert_mixture import select
from methods.scale_adaptive_expert_mixture.posterior import PRIOR_DF

from .validate import ROOT


POLICIES = ("single_scale", "mixture_scale")
SEED = 11


def worker(connection):
    try:
        torch.set_num_threads(1)
        with threadpool_limits(limits=1):
            while True:
                message, task = connection.recv()
                if message == "stop":
                    return
                connection.send(("result", select(**task, oracle=RemoteOracle(connection))))
    except Exception as error:
        connection.send(("error", repr(error)))
        raise
    finally:
        connection.close()


def freeze():
    ROOT.mkdir(parents=True, exist_ok=True)
    protocol = {"method": "Scale-Adaptive Historical Expert Mixture", "seed": SEED,
                "policies": list(POLICIES), "budget": 200, "initial_queries": 10,
                "prior_df": PRIOR_DF, "prior_covariance_multiplier": 1,
                "posterior": "independent inverse-gamma scale per component; exact multivariate Student evidence",
                "acquisition": "expected clipped latent risk under exact Student mixture",
                "benchmark": "six locked SUTs, two original pools, same frozen global_feedback kernel",
                "feedback": "queried risk only; collision evaluation only", "update_interval": 1,
                "maximum_curves": 24, "hyperparameter_selection": "none; df5 fixed before target evaluation",
                "new_physical_calls": 0, "api_calls": 0}
    destination = ROOT/"protocol.json"
    if destination.exists() and read_json(destination) != protocol:
        raise ValueError("Frozen scale-mixture protocol changed")
    write_json(destination, protocol)
    root = Path(__file__).resolve().parents[2]
    sources = []
    for folder in ("methods/scale_adaptive_expert_mixture", "experiments/scale_adaptive_testing",
                   "methods/historical_expert_mixture", "methods/history_guided_testing"):
        sources.extend(sorted((root/folder).glob("*.py")))
    sources.extend(root/f"experiments/driving_benchmark/{n}.py" for n in ("config", "evaluation"))
    snapshot = ROOT/"source_inputs.zip"
    if not snapshot.exists():
        with ZipFile(snapshot, "w") as archive:
            for p in sources:
                archive.write(p, p.relative_to(root).as_posix())
    with ZipFile(snapshot) as archive:
        if set(archive.namelist()) != {p.relative_to(root).as_posix() for p in sources} or any(
            archive.read(n) != (root/n).read_bytes() for n in archive.namelist()
        ):
            raise ValueError("Scale-mixture source changed after freezing")


def main():
    freeze()
    torch.set_num_threads(1)
    history = load_history()
    train, _ = split_indices(next(iter(history.values()))["x"])
    experts = HistoricalExperts(subset(history, train))
    context = mp.get_context("spawn")
    parent, child = context.Pipe()
    process = context.Process(target=worker, args=(child,))
    process.start()
    child.close()
    rows = []
    try:
        with threadpool_limits(limits=1):
            for pool in (0, 1):
                with np.load(OUTPUT/f"pool_{pool}/{SUT_IDS[0]}/responses.npz") as bank:
                    x = bank["x"].copy()
                prediction = experts.predict(x)
                prior = prediction.fixed_mean()
                with torch.no_grad():
                    covariance = load_kernel(SEED, "global_feedback").covariance(x).numpy()
                for sut in SUT_IDS:
                    with np.load(OUTPUT/f"pool_{pool}/{sut}/responses.npz") as bank:
                        np.testing.assert_array_equal(x, bank["x"])
                        reference = read_json(OUTPUT/f"pool_{pool}/{sut}/baselines/frozen_original_11.json")
                        for policy in POLICIES:
                            destination = ROOT/f"driving/pool_{pool}/{sut}/{policy}_11.json"
                            if destination.exists():
                                result = read_json(destination)
                            else:
                                mixture = policy == "mixture_scale"
                                task = {"x": x, "covariance": covariance, "fixed_prior": prior, "seed": SEED,
                                        "priors": np.column_stack([np.full(len(x), .5), prediction.mean]) if mixture else prior[:, None],
                                        "probability": np.r_[FALLBACK_PRIOR, (1-FALLBACK_PRIOR)*prediction.group_weights] if mixture else np.ones(1)}
                                started = time.perf_counter()
                                result = disclose(parent, task, bank["risk"], bank["collision"])
                                result.update(method=policy, selector_elapsed_s=time.perf_counter()-started)
                                write_json(destination, result)
                            if result["selected_indices"][:10] != reference["selected_indices"][:10]:
                                raise ValueError("Frozen initialization changed")
                            measured = metrics(bank["collision"], result["selected_indices"])
                            for key in ("area_200", "recall_200", "F200", "curve"):
                                if measured[key] != result[key]:
                                    raise ValueError("Scale-mixture metrics differ from bank")
                            rows.append({"pool": pool, "sut": sut, "method": policy,
                                         "area_pct": 100*measured["area_200"], "recall_pct": 100*measured["recall_200"],
                                         "F200": measured["F200"], "F50": measured["checkpoints"]["50"],
                                         "F100": measured["checkpoints"]["100"], "seconds": result["selector_elapsed_s"]})
                            print("DONE", pool, sut, policy, round(rows[-1]["area_pct"], 4), round(rows[-1]["recall_pct"], 4), flush=True)
                            write_json(ROOT/"progress.json", {"completed": len(rows), "maximum": 24, "rows": rows})
    finally:
        if process.is_alive():
            parent.send(("stop", None))
        parent.close()
        process.join(timeout=15)
        if process.is_alive():
            process.terminate()
            process.join()
        if process.exitcode != 0:
            raise RuntimeError("Scale-mixture selector failed")
    aggregate = {p: {k: float(np.mean([r[k] for r in rows if r["method"] == p]))
                    for k in ("area_pct", "recall_pct", "F50", "F100", "F200", "seconds")} for p in POLICIES}
    write_json(ROOT/"summary.json", {"status": "complete", "aggregate": aggregate, "rows": rows,
               "target_disclosures": len(rows)*200, "new_physical_calls": 0, "candidate_promoted": False})
    print("AGGREGATE", aggregate, flush=True)


if __name__ == "__main__":
    main()
