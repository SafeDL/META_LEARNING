"""Same held-out tasks and kernels; compare exact predictive densities."""
from pathlib import Path

import numpy as np
from scipy.special import logsumexp, ndtr, stdtr
import torch
from threadpoolctl import threadpool_limits

from methods.historical_expert_mixture.config import FALLBACK_PRIOR, JITTER, NOISE, SUPPORT_COUNTS
from methods.historical_expert_mixture.experts import HistoricalExperts
from methods.historical_expert_mixture.posterior import EvidenceMixture
from methods.history_guided_testing.config import GROUPS, group_of
from methods.history_guided_testing.history import load_history, split_indices, subset
from methods.history_guided_testing.io import write_json
from methods.history_guided_testing.kernel import RiskKernel
from methods.scale_adaptive_expert_mixture.posterior import ScaleMixture, student_log_density


ROOT = Path(__file__).resolve().parents[2] / "results/scale_adaptive_expert_mixture"


def main():
    history = load_history()
    x = next(iter(history.values()))["x"]
    train, validation = split_indices(x)
    rows = []
    torch.set_num_threads(1)
    with threadpool_limits(limits=1):
        for group in GROUPS:
            allowed = sorted(set(GROUPS)-{group})
            experts = HistoricalExperts(subset(history, train, excluded_group=group))
            kernel = RiskKernel("global_feedback")
            path = ROOT.parent/"historical_expert_mixture/models"/f"kernel_{'_'.join(allowed)}.pt"
            kernel.load_state_dict(torch.load(path, map_location="cpu", weights_only=True)["state"])
            for name in [n for n in history if group_of(n) == group]:
                rng = np.random.default_rng(85011)
                support = rng.permutation(train)[:max(SUPPORT_COUNTS)]
                query = validation
                indices = np.r_[support, query]
                coordinates = x[indices]
                truth = history[name]["risk"][indices]
                prediction = experts.predict(coordinates, exclude_exact=True)
                priors = np.column_stack([np.full(len(indices), .5), prediction.mean])
                probability = np.r_[FALLBACK_PRIOR, (1-FALLBACK_PRIOR)*prediction.group_weights]
                with torch.no_grad():
                    covariance = kernel.covariance(coordinates).numpy()
                for count in SUPPORT_COUNTS:
                    for kind, model_class in (("gaussian", EvidenceMixture), ("scale_adaptive", ScaleMixture)):
                        model = model_class(covariance, priors, probability)
                        for index in range(count):
                            model.observe(index, truth[index])
                        mean = model.mean[-len(query):]
                        residual = truth[-len(query):, None]-mean
                        variance = model.variance[-len(query):, None]+NOISE+JITTER
                        if kind == "gaussian":
                            density = -.5*(residual**2/variance+np.log(2*np.pi*variance))
                            predictive_variance = np.broadcast_to(variance, mean.shape)
                            cdf = ndtr(residual/np.sqrt(variance))@model.probability
                        else:
                            density = student_log_density(residual, variance*model.beta/model.alpha, 2*model.alpha)
                            predictive_variance = variance*model.scale_mean
                            cdf = stdtr(2*model.alpha, residual/np.sqrt(variance*model.beta/model.alpha))@model.probability
                        prediction_mean = mean@model.probability
                        top = np.argsort(-prediction_mean, kind="stable")[:50]
                        rows.append({"group": group, "target": name, "support": count, "method": kind,
                                     "nll": -float(logsumexp(density+model.log_probability,axis=1).mean()),
                                     "rmse": float(np.sqrt(np.mean((np.clip(prediction_mean,0,1)-truth[-len(query):])**2))),
                                     "top50_mean_risk": float(truth[-len(query):][top].mean()),
                                     "coverage80": float(np.mean((cdf>=.1)&(cdf<=.9))),
                                     "coverage95": float(np.mean((cdf>=.025)&(cdf<=.975))),
                                     "mean_predictive_variance": float((predictive_variance@model.probability).mean())})
    aggregate = {kind: {metric: float(np.mean([
        np.mean([r[metric] for r in rows if r["method"]==kind and r["group"]==group]) for group in GROUPS]))
        for metric in ("nll", "rmse", "top50_mean_risk", "coverage80", "coverage95", "mean_predictive_variance")} for kind in ("gaussian", "scale_adaptive")}
    write_json(ROOT/"validation.json", {"scope": "four held-out mechanism groups; existing strictly excluded kernels; no target banks",
               "rows": rows, "aggregate": aggregate, "hyperparameters_selected": False})
    print(aggregate, flush=True)


if __name__ == "__main__":
    main()
