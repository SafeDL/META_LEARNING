# 组件残差尺度的固定比较

`python -B -m experiments.scale_adaptive_testing.validate` 在四个留出机制组和完整410个空间验证坐标上比较高斯混合与尺度混合，核与来源专家排除留出组。高斯控制逐项复现此前NLL、RMSE和top50结果。

`python -B -m experiments.scale_adaptive_testing.run` 在同六SUT、两池、种子11和预算200下执行固定的24条目标曲线：单一历史均值与保留历史专家两种控制。两者均学习残差尺度，使用相同核、原10次初始化、逐次更新和期望截断风险采集。自由度5事先固定，不根据目标结果调参。

[方法](../../methods/scale_adaptive_expert_mixture/README.md) · [结果目录](../../results/scale_adaptive_expert_mixture/README.md)
