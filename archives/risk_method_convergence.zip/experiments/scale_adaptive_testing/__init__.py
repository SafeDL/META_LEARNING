"""Characterize uncertainty calibration before a finite target comparison."""
