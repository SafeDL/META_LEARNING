# 方法

项目当前只保留一条论文主线：**Concordance-Gated Compositional Bayesian Mixture for Failure Discovery（CG-CBM-FD）**。方法、实验和当前结果使用同名目录；当前轨迹标识为`cg_cbm_fd`。

当前代码是以实际碰撞C为目标的冻结实现。评价按`R > 0.5`重算高风险发现；这一目标不需要独立学习风险到高风险标签的映射，下一步简化方向见唯一设计文档3.1.2节，尚未替换冻结实现。

| 层级 | 目录 | 当前职责 |
|---|---|---|
| 主方法 | [concordance_gated_compositional_bayesian_mixture](concordance_gated_compositional_bayesian_mixture/README.md) | 组合式贝叶斯专家后验、一致性门控和集合级不确定性决策 |
| 冻结参照 | [egfd](egfd/README.md) | Evidence-Guided Failure Discovery 参考策略与发现保护 |
| 公共执行 | [history_guided_testing](history_guided_testing/README.md) | 历史数据、GP、测试会话和标准基线 |
| 历史响应 | [response_baselines](response_baselines/README.md) | 冻结响应预测与工程对照所需校准 |
| 后验输入 | [historical_expert_mixture](historical_expert_mixture/README.md) | 历史专家预测、原始贝叶斯MoE原型和固定协议常量 |
| 现有文献基线 | [ras_frt_uq](ras_frt_uq/README.md) | 统一基准中的外部方法实现 |
| 尺度控制 | [scale_adaptive_expert_mixture](scale_adaptive_expert_mixture/README.md) | Student-t尺度积分与风险混合的数学控制 |

CG-CBM-FD的选择入口是[selection.py](concordance_gated_compositional_bayesian_mixture/selection.py)，五种子结果位于[当前结果](../results/concordance_gated_compositional_bayesian_mixture/README.md)，独立核验入口是[verify.py](../experiments/concordance_gated_compositional_bayesian_mixture/verify.py)。

本表列出的七个目录是当前保留范围。退役的前瞻、路由和条件专家分支已移入恢复归档并从工作目录删除。方法动机、公式、实验设置和结果解释统一见[设计文档](../docs/Failure_Discovery_Design.md)。
