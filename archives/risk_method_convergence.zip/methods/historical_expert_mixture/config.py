"""Locked settings for evidence-conditioned historical response mixtures."""
from pathlib import Path

from methods.history_guided_testing.config import BUDGET, FEEDBACK


ROOT = Path(__file__).resolve().parents[2] / "results/historical_expert_mixture"
SEED = 11
INITIAL_QUERIES = 10
NEIGHBORS = 8
NEIGHBOR_LENGTH = .15
NOISE = FEEDBACK["noise_variance"]
JITTER = 1e-8
FALLBACK_PRIOR = .2
SUPPORT_COUNTS = (0, 5, 10, 20, 50, 100)

