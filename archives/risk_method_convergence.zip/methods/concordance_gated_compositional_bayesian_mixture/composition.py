"""Bayesian recombination of risk sources and conditional failure mechanisms."""
import torch

from methods.historical_expert_mixture.config import JITTER, NOISE

from .posterior import FeedbackPosterior
from .ranking import discordant_probabilities


class CompositionalPosterior(FeedbackPosterior):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, joint=True, **kwargs)
        self.source_prior = self.state["log_weight"].exp()[0].clone()
        prior = .5 * torch.diag(self.source_prior) + .5 * torch.outer(self.source_prior, self.source_prior)
        self.state["log_pair"] = prior.log()[None]

    def update_weights(self, state, log_density, log_likelihood):
        pair = state["log_pair"] + log_density[:, :, None] + log_likelihood[:, None, :]
        pair = pair - torch.logsumexp(pair, dim=(-2, -1), keepdim=True)
        return {"log_pair": pair, "log_weight": torch.logsumexp(pair, -1)}

    def conditional_collision(self, state, point, index, risk):
        pair = state["log_pair"] + self.risk_log_density(state, point, risk)[:, :, None]
        pair = pair - torch.logsumexp(pair, dim=(-2, -1), keepdim=True)
        event_weight = torch.logsumexp(pair, dim=1).exp()
        variance = point["event_variance"] + self.report_noise[index, None]
        component = torch.special.ndtr((self.event_base(index, risk) + point["event_mean"]) / variance.sqrt())
        return (event_weight * component).sum(-1)

    def probabilities(self, state=None, destinations=None, *, fast=False):
        state = self.state if state is None else state
        destinations = torch.arange(len(self.parameters), device=self.device) if destinations is None else destinations
        scale = state["beta"][:, :, None] / self.precision[state["alpha"]]
        risk_variance = (state["variance"] + NOISE + JITTER)[:, :, None, None] * scale[:, None]
        probability = torch.zeros_like(state["variance"])
        for event in range(len(self.source_prior)):
            slope, intercept = self.parameters[destinations, event].unbind(-1)
            mean = slope[None, :, None] * state["mean"] + intercept[None, :, None] + state["event_mean"][:, event, :, None]
            variance = state["event_variance"][:, event] + self.report_noise[destinations]
            argument = mean[..., None] / torch.sqrt(variance[:, :, None, None] + slope[None, :, None, None] ** 2 * risk_variance)
            argument = argument.float() if fast else argument
            component = (torch.special.ndtr(argument) @ self.quadrature_weight.to(argument.dtype)).double()
            probability += (component * state["log_pair"][:, None, :, event].exp()).sum(-1)
        return probability


    @torch.no_grad()
    def selection_prediction(self):
        state = self.state
        scale = state["beta"][:, :, None] / self.precision[state["alpha"]]
        risk_variance = (state["variance"] + NOISE + JITTER)[:, :, None, None] * scale[:, None]
        probability, score = torch.zeros_like(state["variance"]), torch.zeros_like(state["variance"])
        for event in range(len(self.source_prior)):
            slope, intercept = self.parameters[:, event].unbind(-1)
            mean = slope[None, :, None] * state["mean"] + intercept[None, :, None] + state["event_mean"][:, event, :, None]
            variance = state["event_variance"][:, event] + self.report_noise
            z = mean[..., None] / torch.sqrt(variance[:, :, None, None] + slope[None, :, None, None].square() * risk_variance)
            weight = state["log_pair"][:, None, :, event].exp()
            probability += ((torch.special.ndtr(z) @ self.quadrature_weight) * weight).sum(-1)
            score += ((z @ self.quadrature_weight) * weight).sum(-1)
        return probability[0].cpu().numpy(), score[0].cpu().numpy()

    def joint_discovery_probabilities(self, first, second):
        return discordant_probabilities(self, first, second)

    @torch.no_grad()
    def observe(self, index, risk, collision):
        super().observe(index, risk, collision)
        pair = self.state["log_pair"].exp()[0]
        # A diagonal pair can originate from either structure, so diagonal mass alone is not the model probability.
        shared = (pair.diag() / (1 + self.source_prior)).sum()
        self.evidence[-1].update(event_source_posterior=pair.sum(0).cpu().tolist(),
                                 shared_source_probability=float(shared))
