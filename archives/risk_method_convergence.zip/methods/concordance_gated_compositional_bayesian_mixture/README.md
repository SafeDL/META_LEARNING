# CG-CBM-FD 方法实现

本目录的论文主方法是 **Concordance-Gated Compositional Bayesian Mixture for Failure Discovery（CG-CBM-FD）**。方法、实验与当前结果采用同名目录，轨迹标识为`cg_cbm_fd`。

方法通过三个相互关联的步骤工作：组合式贝叶斯后验分别推断风险来源与条件失效来源；目标碰撞排序的一致性证据决定是否信任历史组合；集合级后验决策只在联合收益支持时改变剩余预算候选集合。固定预算分段不属于主方法。

主选择器为[selection.py](selection.py)中的`select(...)`，包级入口也直接导出该选择器：

```python
from methods.concordance_gated_compositional_bayesian_mixture import select
```

## 核心文件

| 文件 | 职责 |
|---|---|
| [selection.py](selection.py) | 主选择器和完整在线查询循环 |
| [composition.py](composition.py) | 风险来源与条件失效来源二元组的贝叶斯后验 |
| [posterior.py](posterior.py) | Student-t风险GP与事件残差GP更新 |
| [readout.py](readout.py) | 按来源与场景族拟合历史probit条件失效映射 |
| [concordance_gated.py](concordance_gated.py) | 用目标碰撞排序证据更新迁移可信度并在证据不足时回退 |
| [set_equivalent_union.py](set_equivalent_union.py) | 候选前缀交集、后验并集和集合改变认证 |
| [ranking.py](ranking.py) | 保留相关性的联合增益与损失概率 |
| [supported.py](supported.py) | 冻结参考保护和发现信用执行层 |

## 高风险评价与冻结碰撞实现

当前高风险定义为严格`R > 0.5`。既有五种子轨迹重算的高风险Area为46.076%、高风险Recall为72.257%、H200为141.55；预算200下的理论宏平均上限为78.663%。当前选择器仍预测实际碰撞C，没有改成高风险尾概率选择器。若目标只需要发现`R > 0.5`，条件高风险标签已由R确定，下一步应简化独立条件碰撞专家；具体区别和设计方向见[设计文档3.1.2节](../../docs/Failure_Discovery_Design.md#312-为什么要分开以及什么时候不需要分开)。

以下为冻结的实际碰撞结果，F表示碰撞发现数：

| 方法 | Area@200 % ↑ | Recall@200 % ↑ | F50 ↑ | F100 ↑ | F200 ↑ |
|---|---:|---:|---:|---:|---:|
| **CG-CBM-FD** | **53.173** | **77.509** | 44.03 | **80.20** | **120.58** |
| `previous_best` | 52.984 | 76.661 | **45.83** | 76.18 | 116.90 |
| `frozen_original` | 52.858 | 77.062 | 43.83 | 79.73 | 119.20 |
| RAS-FRT-UQ | 52.203 | 74.062 | 43.40 | 76.80 | 113.65 |

CG-CBM-FD相对`previous_best`的Area提高0.189个百分点、Recall提高0.848个百分点、F200增加3.68。在已完成五种子评价的14个标准与工程基线中，它取得最高Area、Recall、F100和F200。另有9种方法的种子11补充比较，包含原始贝叶斯MoE、EGFD与同信息强控制；其中高斯无保护控制的Recall更高。六SUT块检验尚未达到0.05，因此不支持跨SUT显著领先的表述。

完整定义见[唯一设计文档](../../docs/Failure_Discovery_Design.md)，五种子结果位于[当前结果](../../results/concordance_gated_compositional_bayesian_mixture/README.md)，完整基线比较见[benchmark_comparison.md](../../results/concordance_gated_compositional_bayesian_mixture/benchmark_comparison.md)，核验入口为[verify.py](../../experiments/concordance_gated_compositional_bayesian_mixture/verify.py)。

主目录已移除旧前瞻采集、事件核学习、历史事件迁移和空间读出分支，以及五个不参与当前排序的采样/损失函数。保留的八个组件分别承担历史条件读出、后验、组合、可信度、联合概率、集合决策、保护与选择。

```powershell
conda activate metadrive
python -B -m experiments.concordance_gated_compositional_bayesian_mixture.verify
```
