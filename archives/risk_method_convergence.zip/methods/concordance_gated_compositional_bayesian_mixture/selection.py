"""Frozen-target policy for set-equivalent certified union discovery."""
import math

import numpy as np
import torch

from methods.egfd.censored_margin_response import historical_margin_prior
from methods.egfd.reference import ReferenceReplay
from methods.historical_expert_mixture.config import BUDGET, INITIAL_QUERIES
from methods.history_guided_testing.search import TestingSession

from .concordance_gated import ConcordanceGatedPosterior
from .set_equivalent_union import (
    ProbitCalibration,
    certify_set_change,
    union_proposal,
)
from .supported import run_supported_policy


def ranked_candidate(probability, score, head, available, family, tie):
    indices = np.flatnonzero(available & (family == family[head]))
    order = np.lexsort((tie[indices], -score[indices], -np.round(probability[indices], 12)))
    proposed = int(indices[order[0]])
    return proposed if probability[proposed] > probability[head] + 1e-12 else int(head)


def family_horizon(remaining_budget, family_available, total_available):
    if family_available < 1 or total_available < 1:
        raise ValueError("Target union requires an available reference family")
    return max(1, min(family_available,
                      int(math.ceil(remaining_budget * family_available / total_available))))


class SetEquivalentUnionPosterior(ConcordanceGatedPosterior):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.pcg_calibration, self.composition_calibration = ProbitCalibration(), ProbitCalibration()
        self.union_decisions = []

    @torch.no_grad()
    def propose(self, head, available, family, tie):
        pcg_probability, pcg_score = super().selection_prediction()
        composition_probability, composition_score = self.composition.selection_prediction()
        pcg_candidate = ranked_candidate(pcg_probability, pcg_score, head, available, family, tie)
        family_mask = available & (family == family[head])
        remaining_budget = BUDGET - len(self.evidence)
        horizon = family_horizon(remaining_budget, int(family_mask.sum()), int(available.sum()))
        proposed, record = union_proposal(
            pcg_probability, composition_probability, family_mask, horizon,
            self.pcg_calibration, self.composition_calibration,
            seed=19011 + len(self.evidence),
        )
        chosen, certificate = certify_set_change(
            self, proposed, pcg_candidate, record["in_pcg_prefix"], BUDGET,
        )
        record.update(query=len(self.evidence) + 1, egfd_reference_index=int(head),
                      pcg_candidate_index=pcg_candidate, proposed_index=proposed,
                      selected_proposal_index=chosen, family=int(family[head]), horizon=horizon,
                      remaining_budget=remaining_budget, **certificate)
        self.union_decisions.append(record)
        return int(chosen)

    @torch.no_grad()
    def observe(self, index, risk, collision):
        pcg_probability = super().selection_prediction()[0]
        composition_probability = self.composition.selection_prediction()[0]
        self.pcg_calibration.observe(pcg_probability[index], collision)
        self.composition_calibration.observe(composition_probability[index], collision)
        super().observe(index, risk, collision)


@torch.no_grad()
def select(x, covariance, priors, probability, fixed_prior, readout, oracle, seed=11):
    reference = ReferenceReplay(TestingSession(x, seed, mode="global_feedback", prior=fixed_prior))
    model = SetEquivalentUnionPosterior(
        reference, covariance, priors, probability, x[:, 4], readout, historical_margin_prior(x)
    )
    result = run_supported_policy(
        reference, model, x[:, 4], oracle, np.random.default_rng(seed).random(len(x)), BUDGET, INITIAL_QUERIES
    )
    result.update(
        evidence=model.evidence, union_decisions=model.union_decisions, updates_per_query=1,
        feedback_used="paid R/C updates both PCG and composition; only outside-PCG-prefix union proposals require pairwise certification",
        inference="SetEquivalentUnionPosterior with frozen PCG reference protection and budget-proportional family horizon",
    )
    return result
