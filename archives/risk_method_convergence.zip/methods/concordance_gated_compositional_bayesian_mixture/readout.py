"""Historical probit calibration for conditional failure experts."""
import math

import numpy as np
from scipy.optimize import minimize
from scipy.special import log_ndtr

READOUT_PRIOR_SD = 20.0


def fit_readout(risk, collision, family):
    parameters, diagnostics = [], []
    for group in (0, 1):
        mask = family == group
        values = risk[mask]
        sign = 2 * collision[mask].astype(float) - 1

        def objective(theta):
            z = sign * (theta[0] * values + theta[1])
            ratio = np.exp(-.5 * z ** 2 - .5 * math.log(2 * math.pi) - log_ndtr(z))
            loss = -log_ndtr(z).sum() + .5 * (theta @ theta) / READOUT_PRIOR_SD ** 2
            gradient = -np.array([(sign * ratio * values).sum(), (sign * ratio).sum()])
            return loss, gradient + theta / READOUT_PRIOR_SD ** 2

        fit = minimize(objective, np.array([8., -6.]), jac=True, method="L-BFGS-B",
                       bounds=((0, None), (None, None)), options={"ftol": 1e-12, "gtol": 1e-7})
        if not fit.success:
            raise RuntimeError(f"Historical event readout did not converge: {fit.message}")
        parameters.append(fit.x.tolist())
        diagnostics.append({"family": group, "samples": int(mask.sum()), "collisions": int(collision[mask].sum()),
                            "objective": float(fit.fun), "parameters": fit.x.tolist()})
    return np.asarray(parameters), diagnostics

