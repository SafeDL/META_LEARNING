"""Certify only union proposals that change the PCG remaining-budget set."""
import math

import numpy as np
from scipy.special import log_ndtr, ndtr, ndtri


def clipped_probability(probability):
    epsilon = np.finfo(float).eps
    return np.clip(np.asarray(probability, dtype=float), epsilon, 1 - epsilon)


class ProbitCalibration:
    def __init__(self):
        self.mean, self.variance = 0.0, 1.0

    def observe(self, probability, collision):
        base = float(ndtri(clipped_probability(probability)))
        sign = 1.0 if collision else -1.0
        denominator = 1 + self.variance
        z = sign * (base + self.mean) / math.sqrt(denominator)
        ratio = math.exp(-.5 * z * z - .5 * math.log(2 * math.pi) - float(log_ndtr(z)))
        strength = min(max(ratio * (ratio + z), 0.0), 1.0)
        self.mean += sign * self.variance / math.sqrt(denominator) * ratio
        self.variance = max(self.variance - self.variance ** 2 / denominator * strength, 0.0)

    def draws(self, count, generator):
        return self.mean + math.sqrt(self.variance) * generator.standard_normal(count)


def union_proposal(pcg_probability, composition_probability, remaining, horizon,
                   pcg_calibration, composition_calibration, *, samples=256, seed=11):
    pcg = clipped_probability(pcg_probability); composition = clipped_probability(composition_probability)
    available = np.flatnonzero(np.asarray(remaining, dtype=bool)); horizon = min(int(horizon), len(available))
    if horizon < 1:
        raise ValueError("Union proposal requires an available candidate")
    pcg_order = available[np.argsort(-pcg[available], kind="stable")]
    composition_order = available[np.argsort(-composition[available], kind="stable")]
    pcg_rank = {int(i): rank for rank, i in enumerate(pcg_order)}
    composition_rank = {int(i): rank for rank, i in enumerate(composition_order)}
    pcg_set = set(map(int, pcg_order[:horizon])); composition_set = set(map(int, composition_order[:horizon]))
    common = np.asarray(sorted(pcg_set & composition_set), dtype=int)
    if len(common):
        worst = np.asarray([max(pcg_rank[int(i)], composition_rank[int(i)]) for i in common])
        rank_sum = np.asarray([pcg_rank[int(i)] + composition_rank[int(i)] for i in common])
        chosen = int(common[np.lexsort((common, rank_sum, worst))[0]])
        return chosen, {"proposal_mode": "consensus", "intersection_size": len(common),
                        "union_size": len(pcg_set | composition_set), "in_pcg_prefix": True}
    union = np.asarray(sorted(pcg_set | composition_set), dtype=int)
    generator = np.random.default_rng(seed)
    pcg_offset = pcg_calibration.draws(samples, generator)
    composition_offset = composition_calibration.draws(samples, generator)
    draw = np.empty((len(union), samples))
    for row, index in enumerate(union):
        if int(index) in pcg_set:
            draw[row] = ndtr(ndtri(pcg[index]) + pcg_offset)
        else:
            draw[row] = ndtr(ndtri(composition[index]) + composition_offset)
    selected = np.argpartition(draw, -horizon, axis=0)[-horizon:]
    inclusion = np.bincount(selected.ravel(), minlength=len(union)) / samples
    reference = np.asarray([pcg[i] if int(i) in pcg_set else composition[i] for i in union])
    row = np.lexsort((union, -reference, -inclusion))[0]; chosen = int(union[row])
    return chosen, {"proposal_mode": "posterior_union", "intersection_size": 0,
                    "union_size": len(union), "inclusion_probability": float(inclusion[row]),
                    "in_pcg_prefix": chosen in pcg_set}


def certify_set_change(model, proposed, reference, in_pcg_prefix, budget):
    if proposed == reference:
        return reference, {"correction": False, "reason": "same_candidate"}
    if in_pcg_prefix:
        return proposed, {"correction": False, "reason": "set_equivalent_reordering"}
    composition_gain, composition_loss = model.composition.joint_discovery_probabilities(
        np.asarray([proposed]), np.asarray([reference]))
    _, pcg_loss = model.joint_discovery_probabilities(np.asarray([proposed]), np.asarray([reference]))
    composition_gain = float(composition_gain[0]); composition_loss = float(composition_loss[0])
    pcg_loss = float(pcg_loss[0]); allowance = 1 / math.sqrt(budget)
    supported = composition_gain > composition_loss + 1e-12 and pcg_loss <= allowance
    return (proposed if supported else reference), {
        "correction": bool(supported), "reason": "certified_set_change" if supported else "pcg_fallback",
        "composition_gain_probability": composition_gain,
        "composition_loss_probability": composition_loss,
        "pcg_replacement_loss_probability": pcg_loss, "loss_allowance": allowance,
    }


def set_equivalent_choice(model, pcg_probability, composition_probability, remaining, horizon,
                          pcg_calibration, composition_calibration, *, budget=50, seed=11):
    proposed, record = union_proposal(
        pcg_probability, composition_probability, remaining, horizon,
        pcg_calibration, composition_calibration, seed=seed,
    )
    score = np.asarray(pcg_probability, dtype=float).copy(); score[~np.asarray(remaining, bool)] = -np.inf
    reference = int(np.argmax(score))
    chosen, certificate = certify_set_change(model, proposed, reference, record["in_pcg_prefix"], budget)
    record.update(reference_index=reference, proposed_index=proposed, selected_index=chosen, **certificate)
    return chosen, record
