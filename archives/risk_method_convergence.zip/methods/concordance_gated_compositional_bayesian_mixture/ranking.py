"""Conditional failure comparisons under the full response mixture."""
import math

import numpy as np
import torch

from methods.historical_expert_mixture.config import JITTER, NOISE


CDF_NODES = 64
_NODES, _WEIGHTS = np.polynomial.legendre.leggauss(CDF_NODES)


class _BivariateNormalCDF(torch.autograd.Function):
    @staticmethod
    def forward(ctx, first, second, correlation):
        nodes = torch.as_tensor(_NODES, device=first.device, dtype=first.dtype)
        weights = torch.as_tensor(_WEIGHTS, device=first.device, dtype=first.dtype)
        angle = correlation.asin()
        theta = .5 * angle[..., None] * (nodes + 1)
        exponent = -.5 * ((first[..., None] - second[..., None] * theta.sin()).square()
                          / theta.cos().square() + second[..., None].square())
        correction = angle * (exponent.exp() @ weights) / (4 * math.pi)
        result = torch.special.ndtr(first) * torch.special.ndtr(second) + correction
        ctx.save_for_backward(first, second, correlation)
        return result.clamp(0, 1)

    @staticmethod
    def backward(ctx, gradient):
        first, second, correlation = ctx.saved_tensors
        variance = 1 - correlation.square()
        deviation = variance.sqrt()
        normalizer = math.sqrt(2 * math.pi)
        first_gradient = (-.5 * first.square()).exp() / normalizer * torch.special.ndtr(
            (second - correlation * first) / deviation)
        second_gradient = (-.5 * second.square()).exp() / normalizer * torch.special.ndtr(
            (first - correlation * second) / deviation)
        density = (-.5 * ((first - correlation * second).square() / variance + second.square())).exp()
        correlation_gradient = density / (2 * math.pi * deviation)
        return gradient * first_gradient, gradient * second_gradient, gradient * correlation_gradient


def bivariate_normal_cdf(first, second, correlation):
    """Angular Plackett quadrature with analytic CDF derivatives."""
    first, second, correlation = torch.broadcast_tensors(first, second, correlation)
    return _BivariateNormalCDF.apply(first, second, correlation)


def discordant_probabilities(model, first, second):
    """Return P(C_first=1,C_second=0) and its reverse for distinct points."""
    first = torch.as_tensor(first, device=model.device, dtype=torch.long)
    second = torch.as_tensor(second, device=model.device, dtype=torch.long)
    state = model.state
    scale = state["beta"][0, :, None] / model.precision[state["alpha"]]
    risk_first = (state["variance"][0, first] + NOISE + JITTER)[:, None, None] * scale
    risk_second = (state["variance"][0, second] + NOISE + JITTER)[:, None, None] * scale
    # Each source's scale is shared by both points; independent scale draws change the model.
    risk_cross = model.risk_covariance[first, second][:, None, None] * scale
    result = torch.zeros((2, len(first)), device=model.device, dtype=torch.float64)
    for event in range(len(model.source_prior)):
        slope_first, intercept_first = model.parameters[first, event].unbind(-1)
        slope_second, intercept_second = model.parameters[second, event].unbind(-1)
        mean_first = (slope_first[:, None] * state["mean"][0, first] + intercept_first[:, None]
                      + state["event_mean"][0, event, first, None])
        mean_second = (slope_second[:, None] * state["mean"][0, second] + intercept_second[:, None]
                       + state["event_mean"][0, event, second, None])
        variance_first = (state["event_variance"][0, event, first] + model.report_noise[first])[:, None, None]
        variance_second = (state["event_variance"][0, event, second] + model.report_noise[second])[:, None, None]
        deviation_first = (variance_first + slope_first[:, None, None].square() * risk_first).sqrt()
        deviation_second = (variance_second + slope_second[:, None, None].square() * risk_second).sqrt()
        cross = (slope_first * slope_second)[:, None, None] * risk_cross + model.event_covariance[event, first, second][:, None, None]
        correlation = cross / (deviation_first * deviation_second)
        z_first, z_second = mean_first[..., None] / deviation_first, mean_second[..., None] / deviation_second
        probability = bivariate_normal_cdf(torch.stack((z_first, -z_first)), torch.stack((-z_second, z_second)), -correlation)
        integrated = probability @ model.quadrature_weight
        result = result + (integrated * state["log_pair"][0, :, event].exp()).sum(-1)
    return result[0], result[1]


