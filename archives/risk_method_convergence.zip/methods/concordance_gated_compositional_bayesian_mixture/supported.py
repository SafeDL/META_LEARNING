"""Compositional response corrections with the frozen EGFD reference rules."""
import numpy as np
import torch

from methods.egfd.reference import ReferenceReplay
from methods.historical_expert_mixture.config import BUDGET, INITIAL_QUERIES
from methods.history_guided_testing.search import TestingSession

from .composition import CompositionalPosterior


def rank(model, head, available, family, tie):
    if hasattr(model, "propose"):
        return model.propose(head, available, family, tie)
    probability, score = model.selection_prediction()
    indices = np.flatnonzero(available & (family == family[head]))
    order = np.lexsort((tie[indices], -score[indices], -np.round(probability[indices], 12)))
    proposed = int(indices[order[0]])
    return proposed if probability[proposed] > probability[head] + 1e-12 else head


@torch.no_grad()
def discovery_support(model, proposed, head, budget):
    if hasattr(model, "support"):
        return model.support(proposed, head, budget)
    gain, loss = model.joint_discovery_probabilities([proposed], [head])
    gain, loss = float(gain[0]), float(loss[0])
    allowance = 1 / np.sqrt(budget)
    return {"proposed_index": proposed, "reference_index": head, "gain_probability": gain,
            "loss_probability": loss, "expected_immediate_gain": gain - loss, "loss_allowance": float(allowance),
            "supported": bool(loss <= allowance and gain - loss > 1e-12),
            "scope": "working compositional immediate binary loss, with shared scale and both GP covariances"}


def run_supported_policy(reference, model, family, oracle, tie, budget, initialization):
    available = np.ones(len(reference.session.remaining), dtype=bool)
    known, selected, observations, checks, support_checks = {}, [], [], [], []
    found = 0
    rate = 1 / np.sqrt(budget)
    for t in range(budget):
        reference.advance(known)
        before = reference.certificate(known)
        head = int(reference.head())
        scheduled = t >= initialization and (t - initialization) % 2 == 0
        allowed = bool(before["negative_extra_count"] + 1 <= 1 + rate * found + 1e-12)
        index, proposed, support = head, head, None
        if t >= initialization and allowed:
            proposed = rank(model, head, available, family, tie)
            if proposed != head: support = discovery_support(model, proposed, head, budget)
            index = proposed if not scheduled or support is not None and support["supported"] else head
        if not available[index]: raise ValueError("Supported composition repeats a paid query")
        support_checks.append({"query": t + 1, "reference_index": head, "proposed_index": proposed,
                               "chosen_index": index, "scheduled_reference": scheduled, "probe_credit_available": allowed,
                               "binary_support": support, "reference_observation_skipped": bool(scheduled and index != head)})
        observation = oracle.query(index)
        known[index] = float(observation.risk), bool(observation.collision)
        found += int(known[index][1])
        available[index] = False
        selected.append(index)
        observations.append({"index": index, "risk": known[index][0], "collision": known[index][1],
                             "model_feedback_used": True, "role": "initialization" if t < initialization else
                             "reference" if index == head else "alternative"})
        model.observe(index, *known[index])
        reference.advance(known)
        check = reference.certificate(known)
        check.update(query=t + 1, chosen_index=index, reference_index=head, found=found,
                     loss_credit=1 + rate * found, credit_before=1 + rate * (found - int(known[index][1])),
                     negative_extra_before=before["negative_extra_count"], probe_allowed=allowed,
                     credit_rate=float(rate), scheduled_reference=scheduled)
        if check["negative_extra_count"] > check["loss_credit"] + 1e-12:
            raise ValueError("Supported composition exceeded actual discovery credit")
        checks.append(check)
    return {"selected_indices": selected, "queries": observations,
            "coupling_checks": checks, "reference_prefix_indices": reference.order,
            "area_gain_lower": sum(c["discovery_gain_lower"] for c in checks),
            "terminal_gain_lower": checks[-1]["discovery_gain_lower"],
            "alternative_queries": sum(o["role"] == "alternative" for o in observations),
            "max_negative_extra_count": max(c["negative_extra_count"] for c in checks),
            "discovery_support_checks": support_checks,
            "reference_observations_skipped": sum(c["reference_observation_skipped"] for c in support_checks)}


@torch.no_grad()
def select(x, covariance, priors, probability, fixed_prior, readout, oracle, seed=11, *, posterior_class=CompositionalPosterior):
    reference = ReferenceReplay(TestingSession(x, seed, mode="global_feedback", prior=fixed_prior))
    model = posterior_class(covariance, priors, probability, x[:, 4], readout)
    result = run_supported_policy(reference, model, x[:, 4], oracle, np.random.default_rng(seed).random(len(x)), BUDGET, INITIAL_QUERIES)
    result.update(evidence=model.evidence, updates_per_query=1,
                  feedback_used="pair evidence p_j(R)*p_k(C|R); every queried pair updates risk and event GPs",
                  inference=f"{posterior_class.__name__}; frozen EGFD reference and discovery-credit rules")
    return result
