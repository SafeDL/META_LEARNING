"""Concordance-gated compositional Bayesian failure discovery."""
from .selection import select

__all__ = ["select"]
