"""Student risk evidence and Gaussian filtering of conditional event reports."""
import math

import numpy as np
from scipy.stats import gamma
import torch

from methods.historical_expert_mixture.config import JITTER, NOISE
from methods.scale_adaptive_expert_mixture.posterior import PRIOR_DF


SCALE_NODES = 16


class FeedbackPosterior:
    def __init__(self, covariance, priors, probability, family, readout, *, device="cuda", budget=200, joint=False):
        self.device = device
        self.budget = budget
        self.joint = joint
        self.risk_covariance = self.tensor(covariance).clone()
        deviation = torch.sqrt(self.risk_covariance.diag())
        correlation = self.risk_covariance / (deviation[:, None] * deviation[None])
        family = self.tensor(family).long()
        correlation = .5 * (correlation + (family[:, None] == family[None]))
        self.report_noise = NOISE / (self.risk_covariance.diag() + NOISE)
        signal = torch.sqrt(1 - self.report_noise)
        count = priors.shape[1] if joint else 2
        self.event_covariance = (correlation * signal[:, None] * signal[None]).repeat(count, 1, 1)
        self.parameters = self.tensor(readout)[:, family].permute(1, 0, 2) if joint else self.tensor(readout)[family]
        self.state = {
            "mean": self.tensor(priors)[None].clone(),
            "variance": self.risk_covariance.diag()[None].clone(),
            "log_weight": torch.log(self.tensor(probability))[None],
            "beta": torch.full((1, priors.shape[1]), (PRIOR_DF - 2) / 2, device=device, dtype=torch.float64),
            "alpha": PRIOR_DF / 2,
            "event_mean": torch.zeros((1, count, len(family)), device=device, dtype=torch.float64),
            "event_variance": self.event_covariance.diagonal(dim1=-2, dim2=-1)[None].clone(),
        }
        if not joint:
            self.transition = (1 - 1 / budget) * torch.eye(2, device=device, dtype=torch.float64) + 1 / (2 * budget)
            self.state["route"] = torch.full((1, 2), .5, device=device, dtype=torch.float64)
        self.state["log_weight"] -= torch.logsumexp(self.state["log_weight"], dim=-1, keepdim=True)
        nodes, weights = np.polynomial.legendre.leggauss(SCALE_NODES)
        self.quadrature_weight = self.tensor(.5 * weights)
        self.precision = {
            PRIOR_DF / 2 + step / 2: self.tensor(gamma.ppf(.5 * (nodes + 1), a=PRIOR_DF / 2 + step / 2))
            for step in range(budget + 3)
        }
        self.indices, self.evidence = [], []

    def tensor(self, value):
        return torch.as_tensor(value, device=self.device, dtype=torch.float64)

    @torch.no_grad()
    def probabilities(self, state=None, destinations=None, *, fast=False):
        state = self.state if state is None else state
        destinations = torch.arange(len(self.parameters), device=self.device) if destinations is None else destinations
        if self.joint:
            slope, intercept = self.parameters[destinations].unbind(-1)
            scale = state["beta"][:, :, None] / self.precision[state["alpha"]]
            risk_variance = (state["variance"] + NOISE + JITTER)[:, :, None, None] * scale[:, None]
            report_variance = state["event_variance"].transpose(1, 2) + self.report_noise[destinations][None, :, None]
            mean = slope * state["mean"] + intercept + state["event_mean"].transpose(1, 2)
            argument = mean[..., None] / torch.sqrt(report_variance[..., None] + slope[None, ..., None] ** 2 * risk_variance)
            argument = argument.float() if fast else argument
            component = (torch.special.ndtr(argument) @ self.quadrature_weight.to(argument.dtype)).double()
            return (component * state["log_weight"].exp()[:, None]).sum(-1)
        slope, intercept = self.parameters[destinations].T
        scale = state["beta"][:, :, None] / self.precision[state["alpha"]]
        risk_variance = (state["variance"] + NOISE + JITTER)[:, :, None, None] * scale[:, None]
        report_variance = state["event_variance"][:, 0] + self.report_noise[destinations]
        argument = (slope[None, :, None, None] * state["mean"][:, :, :, None]
                    + intercept[None, :, None, None] + state["event_mean"][:, 0, :, None, None])
        denominator = torch.sqrt(report_variance[:, :, None, None] + slope[None, :, None, None] ** 2 * risk_variance)
        # Only virtual CDFs use float32; belief updates and utility sums stay float64.
        argument = (argument / denominator).float() if fast else argument / denominator
        component = (torch.special.ndtr(argument) @ self.quadrature_weight.to(argument.dtype)).double()
        historical = (component * state["log_weight"].exp()[:, None]).sum(-1)
        neutral = torch.special.ndtr(state["event_mean"][:, 1] / torch.sqrt(
            state["event_variance"][:, 1] + self.report_noise[destinations]))
        return state["route"][:, 0, None] * historical + state["route"][:, 1, None] * neutral

    def point(self, state, index):
        batch = torch.arange(len(index), device=self.device)
        return {"mean": state["mean"][batch, index], "variance": state["variance"][batch, index],
                "event_mean": state["event_mean"][batch, :, index],
                "event_variance": state["event_variance"][batch, :, index]}

    def risk_log_density(self, state, point, risk):
        denominator = point["variance"] + NOISE + JITTER
        residual = risk[:, None] - point["mean"]
        df = 2 * state["alpha"]
        scale = state["beta"] / state["alpha"] * denominator[:, None]
        return (torch.lgamma(self.tensor((df + 1) / 2)) - torch.lgamma(self.tensor(df / 2))
                       - .5 * torch.log(df * math.pi * scale)
                       - .5 * (df + 1) * torch.log1p(residual ** 2 / (df * scale)))
    def event_base(self, index, risk):
        if self.joint:
            slope, intercept = self.parameters[index].unbind(-1)
            return slope * risk[:, None] + intercept
        slope, intercept = self.parameters[index].T
        return torch.stack((slope * risk + intercept, torch.zeros_like(risk)), dim=1)

    def conditional_collision(self, state, point, index, risk):
        variance = point["event_variance"] + self.report_noise[index, None]
        component = torch.special.ndtr((self.event_base(index, risk) + point["event_mean"]) / torch.sqrt(variance))
        # The observed risk changes source probabilities before C is integrated.
        weight = torch.softmax(state["log_weight"] + self.risk_log_density(state, point, risk), -1) if self.joint else state["route"]
        return (weight * component).sum(-1)

    def update_weights(self, state, log_density, log_likelihood):
        log_weight = state["log_weight"] + log_density
        if self.joint:
            log_weight = log_weight + log_likelihood
        log_weight -= torch.logsumexp(log_weight, -1, keepdim=True)
        return {"log_weight": log_weight}

    def advance(self, state, point, index, risk, collision, risk_cross, event_cross):
        denominator = point["variance"] + NOISE + JITTER
        residual = risk[:, None] - point["mean"]
        log_density = self.risk_log_density(state, point, risk)
        base = self.event_base(index, risk)
        report_variance = point["event_variance"] + self.report_noise[index, None]
        sign = 2 * collision - 1
        z = sign[:, None] * (base + point["event_mean"]) / torch.sqrt(report_variance)
        log_likelihood = torch.special.log_ndtr(z)
        ratio = torch.exp(-.5 * z ** 2 - .5 * math.log(2 * math.pi) - log_likelihood)
        strength = (ratio * (ratio + z)).clamp(0, 1)
        event_coefficient = strength / report_variance
        result = {
            "mean": state["mean"] + risk_cross[:, :, None] * residual[:, None] / denominator[:, None, None],
            "variance": (state["variance"] - risk_cross ** 2 / denominator[:, None]).clamp_min(0),
            **self.update_weights(state, log_density, log_likelihood),
            "beta": state["beta"] + .5 * residual ** 2 / denominator[:, None],
            "alpha": state["alpha"] + .5,
            "event_mean": state["event_mean"] + event_cross * (sign[:, None] * ratio / torch.sqrt(report_variance))[:, :, None],
            "event_variance": (state["event_variance"] - event_cross ** 2 * event_coefficient[:, :, None]).clamp_min(0),
        }
        details = {"denominator": denominator, "event_coefficient": event_coefficient,
                   "log_density": log_density, "log_likelihood": log_likelihood}
        if not self.joint:
            route = torch.softmax(torch.log(state["route"]) + log_likelihood, -1)
            result["route"] = route @ self.transition
            details["route_posterior"] = route
        return result, details

    @torch.no_grad()
    def observe(self, index, risk, collision):
        if index in self.indices or not np.isfinite(risk) or not 0 <= risk <= 1:
            raise ValueError("Invalid or duplicate actual feedback")
        index_tensor = torch.tensor([index], device=self.device)
        cross = self.risk_covariance[:, index][None].clone()
        event_cross = self.event_covariance[:, :, index][None].clone()
        old_weight = self.state["log_weight"].exp()[0].cpu().numpy().tolist()
        old_route = self.state["route"][0].cpu().numpy().tolist() if not self.joint else None
        self.state, details = self.advance(self.state, self.point(self.state, index_tensor), index_tensor,
                                          self.tensor([risk]), self.tensor([collision]), cross, event_cross)
        self.risk_covariance -= cross[0, :, None] * cross[0, None] / details["denominator"][0]
        self.event_covariance -= event_cross[0, :, :, None] * event_cross[0, :, None] * details["event_coefficient"][0, :, None, None]
        self.indices.append(index)
        evidence = {"index": index, "source_prior": old_weight,
                              "source_posterior": self.state["log_weight"].exp()[0].cpu().numpy().tolist(),
                              "risk_log_density": details["log_density"][0].cpu().numpy().tolist(),
                              "conditional_event_log_density": details["log_likelihood"][0].cpu().numpy().tolist()}
        if not self.joint:
            evidence.update(route_prior=old_route, route_posterior=details["route_posterior"][0].cpu().numpy().tolist())
        self.evidence.append(evidence)



