"""Decision-aligned Bayesian routing from paid pairwise ranking evidence."""
import math

import numpy as np
import torch
from scipy.special import logsumexp

from methods.egfd.censored_margin_response import historical_margin_prior
from methods.egfd.decision_support import discovery_loss_support
from methods.egfd.ep_margin_response import ExpectationPropagatedMargin
from methods.egfd.event_report_response import EventReportResponse
from methods.egfd.evidence import EvidenceWeightedResponse
from methods.egfd.reference import ReferenceReplay
from methods.history_guided_testing.search import TestingSession

from .composition import CompositionalPosterior
from .supported import run_supported_policy


def pairwise_log_score(probability, index, collision, records):
    opposite = [record["index"] for record in records if record["collision"] != collision]
    if not opposite:
        return np.zeros(len(probability)), 0
    probability = np.clip(np.asarray(probability), 1e-15, 1 - 1e-15)
    log_odds = np.log(probability) - np.log1p(-probability)
    if collision:
        difference = log_odds[:, index, None] - log_odds[:, opposite]
    else:
        difference = log_odds[:, opposite] - log_odds[:, index, None]
    return (-np.logaddexp(0, -difference)).mean(axis=1), len(opposite)


def posterior_excess_trust(model_probability):
    return float(max(0.0, 2 * model_probability - 1))


class ConcordanceGatedPosterior:
    def __init__(self, reference, covariance, priors, probability, family, readout, margin_prior, *, device="cuda"):
        self.composition = CompositionalPosterior(covariance, priors, probability, family, readout, device=device)
        event_report = EventReportResponse(reference, family, margin_prior, device=device)
        self.fallback = EvidenceWeightedResponse(
            reference, family, margin_prior, device=device,
            model_class=ExpectationPropagatedMargin, evidence_score="event", alternative_model=event_report,
        )
        self.log_model_weight = np.full(2, -math.log(2))
        self.records, self.evidence, self.device = [], [], device

    def weights(self):
        return np.exp(self.log_model_weight)

    def trust(self):
        return posterior_excess_trust(self.weights()[0])

    @torch.no_grad()
    def component_predictions(self):
        corrected_probability, corrected_score = self.composition.selection_prediction()
        fallback_probability = self.fallback.probabilities()
        standardized = np.asarray([
            -(model.mean / (model.covariance.diag() + model.noise).sqrt()).cpu().numpy()
            for model in self.fallback.models
        ])
        return corrected_probability, corrected_score, fallback_probability, self.fallback.selection_weights() @ standardized

    @torch.no_grad()
    def selection_prediction(self):
        corrected_p, corrected_score, fallback_p, fallback_score = self.component_predictions()
        trust = self.trust()
        return fallback_p + trust * (corrected_p - fallback_p), fallback_score + trust * (corrected_score - fallback_score)

    def probabilities(self):
        return torch.as_tensor(self.selection_prediction()[0], device=self.device, dtype=torch.float64)[None]

    @torch.no_grad()
    def joint_discovery_probabilities(self, first, second):
        corrected_gain, corrected_loss = self.composition.joint_discovery_probabilities(first, second)
        fallback_gain, fallback_loss = [], []
        for proposed, reference in zip(np.asarray(first), np.asarray(second)):
            support = discovery_loss_support(self.fallback, int(proposed), int(reference))
            fallback_gain.append(support["gain_probability"])
            fallback_loss.append(support["loss_probability"])
        fallback_gain = torch.as_tensor(fallback_gain, device=self.device, dtype=torch.float64)
        fallback_loss = torch.as_tensor(fallback_loss, device=self.device, dtype=torch.float64)
        trust = self.trust()
        return (fallback_gain + trust * (corrected_gain - fallback_gain),
                fallback_loss + trust * (corrected_loss - fallback_loss))

    @torch.no_grad()
    def observe(self, index, risk, collision):
        corrected, _, fallback, _ = self.component_predictions()
        likelihood, pair_count = pairwise_log_score(np.asarray([corrected, fallback]), index, collision, self.records)
        before, trust_before = self.weights(), self.trust()
        self.log_model_weight += likelihood
        self.log_model_weight -= logsumexp(self.log_model_weight)
        self.composition.observe(index, risk, collision)
        self.fallback.observe(index, risk, collision)
        self.records.append({"index": int(index), "collision": bool(collision)})
        self.evidence.append({
            "index": int(index), "risk": float(risk), "collision": bool(collision),
            "opposite_outcome_pairs": pair_count,
            "pairwise_log_predictive_likelihood": likelihood.tolist(),
            "model_weight_before": before.tolist(), "model_weight_after": self.weights().tolist(),
            "correction_trust_before": trust_before, "correction_trust_after": self.trust(),
            "composition": self.composition.evidence[-1], "fallback": self.fallback.evidence_records[-1],
        })


@torch.no_grad()
def select(x, covariance, priors, probability, fixed_prior, readout, oracle, seed=11):
    reference = ReferenceReplay(TestingSession(x, seed, mode="global_feedback", prior=fixed_prior))
    model = ConcordanceGatedPosterior(
        reference, covariance, priors, probability, x[:, 4], readout, historical_margin_prior(x)
    )
    result = run_supported_policy(
        reference, model, x[:, 4], oracle, np.random.default_rng(seed).random(len(x)), 200, 10
    )
    result.update(
        evidence=model.evidence, updates_per_query=1,
        feedback_used="paid outcomes update both response GPs and a prequential pairwise-concordance model posterior",
        inference="ConcordanceGatedPosterior; posterior-excess trust with event-sign fallback and frozen discovery protection",
    )
    return result
