# CG-CBM-FD当前结果

本目录与主方法、实验目录采用同名路径，当前轨迹标识为`cg_cbm_fd`。

| 文件或目录 | 内容 |
|---|---|
| [summary.json](summary.json) | 冻结碰撞指标：60条主方法轨迹及两个冻结控制；高风险统计见比较文件 |
| [driving](driving/) | 60条200次唯一查询轨迹，五种子均集中保存在此处 |
| [protocol.json](protocol.json) | 固定预算、SUT、选择种子和反馈通道 |
| [verification.json](verification.json) | 指标、查询顺序及核心实现来源核验 |
| [cleanup.json](cleanup.json) | 已删除分支、恢复归档及清理后的检查结果 |
| [benchmark_comparison.md](benchmark_comparison.md) | 高风险与碰撞分别报告：15种方法的五种子比较和9种方法的同种子补充比较 |
| [benchmark_comparison.json](benchmark_comparison.json) | 从900条原始轨迹重算的完整结果和逐SUT统计 |
| [component_comparison.json](component_comparison.json) | 108条同种子补充轨迹，包括贝叶斯MoE、组合后验、PCG和EGFD等 |
| [recall_denominator_audit.json](recall_denominator_audit.json) | 高风险/碰撞完整分母、宏/微平均、预算上限和固定初始化后的高风险上限 |
| [historical_validation](historical_validation/) | 主方法通过的历史机制留出验收证据 |
| [components](components/) | 组合式后验、一致性门控及中性分量删除的控制结果 |
| [中性分量消融](components/historical_sources_only/README.md) | 只删除组合模型中性风险/碰撞分量；六SUT、两池、种子11、预算200的配对比较 |
| [confirmation](confirmation/) | 原五种子协议、汇总和精确源码/输入快照 |
| [screening](screening/) | 原种子11筛选与来源核验记录 |

当前高风险评价以严格`R > 0.5`为正例，Recall=`H200 / 全池高风险数`。CG-CBM-FD宏平均覆盖率为72.257%，平均H200为141.55；预算200下的理论宏平均上限为78.663%，固定十次初始化后的上限为78.487%。高风险微平均为46.296%，预算上限达成率为93.064%，单独报告。

冻结碰撞Recall=`F200 / 全池碰撞数`，宏平均仍为77.509%，碰撞理论预算上限为81.476%。当前选择器仍预测碰撞C，本轮只按已有轨迹重算高风险评价；不能把此前碰撞最优结论扩展到高风险发现。

核验与比较入口分别为`experiments.concordance_gated_compositional_bayesian_mixture.verify`和`experiments.concordance_gated_compositional_bayesian_mixture.compare`。本轮清理没有新增物理测量或选择轨迹。
