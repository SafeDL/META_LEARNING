# 统一基准的方法取舍

六个固定 SUT、两个共享实测池、选择种子 11；200 次唯一查询，初始化计入预算。
从完整实测碰撞标签重算全部已有曲线；先在 SUT 内平均两个池，再对六个 SUT 等权汇总。
候选共享原参照前十次初始化。外部基线沿用原冻结初始化和反馈权限；这张表不把所有方法称为同信息消融。

保留事件符号纠正为唯一研究主线：机制直接回应反馈是否支持改选、证据不足时如何回退，且其同信息开发面积最高。
Student-t 保留为受保护强对照，高斯无保护版本保留最高召回控制。没有单一方法双指标最好，也没有新的显著优势结论。

| 方法 | Area % | Recall % | F50 | F100 | F200 | 用途 |
|---|---:|---:|---:|---:|---:|---|
| adaptive_scope | 53.070 | 77.011 | 43.67 | 80.58 | 119.50 | 归档 |
| adf_loss_supported | 53.052 | 76.915 | 43.75 | 80.33 | 119.08 | 归档 |
| bas | 4.232 | 9.318 | 5.33 | 9.67 | 20.50 | 冻结基线 |
| bop_elites | 29.892 | 44.696 | 29.75 | 54.58 | 80.75 | 冻结基线 |
| ep_event_score | 53.051 | 77.067 | 43.58 | 80.50 | 119.75 | 必要对照 |
| ep_mixed_score | 53.040 | 77.067 | 43.58 | 80.50 | 119.75 | 归档 |
| EGFD (event_signs_protected) | 53.088 | 77.011 | 43.67 | 80.67 | 119.50 | 研究主线 |
| farthest_first | 6.383 | 12.076 | 6.75 | 13.58 | 25.75 | 冻结基线 |
| frozen_original | 52.837 | 76.885 | 43.75 | 79.92 | 118.92 | 必要对照 |
| gaussian_unprotected | 52.987 | 77.592 | 44.50 | 79.83 | 118.67 | 必要对照 |
| gp_ei | 41.396 | 68.859 | 31.25 | 68.33 | 111.33 | 冻结基线 |
| gp_ucb | 15.504 | 26.662 | 18.75 | 30.00 | 50.58 | 冻结基线 |
| knn_history | 36.580 | 50.192 | 33.33 | 52.83 | 75.58 | 冻结基线 |
| previous_best | 52.966 | 76.592 | 45.75 | 76.75 | 116.75 | 冻结基线 |
| ras_frt_uq | 52.332 | 74.429 | 43.50 | 77.00 | 113.83 | 冻结基线 |
| rf_bo | 42.706 | 72.910 | 27.00 | 62.75 | 106.83 | 冻结基线 |
| safe_risk_order | 53.075 | 76.945 | 43.83 | 80.75 | 119.42 | 归档 |
| student_protected | 53.048 | 77.157 | 44.50 | 79.83 | 119.25 | 必要对照 |
| student_unprotected | 53.025 | 77.473 | 44.50 | 79.83 | 118.50 | 必要对照 |
| uniform_random | 5.433 | 11.256 | 6.00 | 14.00 | 26.58 | 冻结基线 |

额外历史数据工程参照如下；目标池、预算相同，离线信息及初始化不同。

| 方法 | Area % | Recall % | F200 |
|---|---:|---:|---:|
| behavior_posterior | 49.931 | 66.839 | 96.00 |
| matched_collision_gp | 52.262 | 74.936 | 114.08 |
| pooled_full_history | 53.294 | 77.752 | 121.50 |
| risk_conditioned | 50.335 | 67.744 | 98.08 |

其余已完成、覆盖同十二实测池的历史分支如下。不同分支的反馈、历史数据与保护规则由原协议确定，不据此宣称同信息创新收益。

| 历史分支／方法 | Area % | Recall % | F200 |
|---|---:|---:|---:|
| /local_mechanisms/pooled_reference | 52.340 | 75.631 | 117.92 |
| /local_mechanisms/ungated_correction | 51.545 | 75.048 | 116.42 |
| /local_mechanisms/verified_correction | 51.592 | 74.924 | 116.67 |
| /probit_mechanisms/pooled_reference | 52.671 | 75.289 | 116.17 |
| /probit_mechanisms/ungated_correction | 52.426 | 75.362 | 116.17 |
| /probit_mechanisms/verified_correction | 52.129 | 74.682 | 114.92 |
| /risk_relation_mechanisms/ungated_correction | 52.377 | 77.445 | 120.92 |
| /risk_relation_mechanisms/verified_correction | 52.414 | 77.228 | 120.83 |
| adaptive_margin_prior_coupling/initial_prior_selection | 52.966 | 76.902 | 119.08 |
| adaptive_margin_prior_coupling/online_prior_average | 53.005 | 76.902 | 119.08 |
| calibrated_risk_event_coupling/coupled_response | 52.735 | 76.726 | 118.58 |
| calibrated_risk_event_coupling/uncoupled_response | 52.543 | 76.756 | 118.75 |
| censored_margin_coupling/binary_margin_response | 52.387 | 76.162 | 117.08 |
| censored_margin_coupling/censored_margin_response | 52.443 | 76.435 | 117.75 |
| decision_value_coupling/coupled_response | 53.005 | 77.103 | 119.08 |
| decision_value_coupling/uncoupled_response | 52.856 | 77.242 | 118.42 |
| earned_discovery_credit_coupling/coupled_response | 53.036 | 77.022 | 119.08 |
| evidence_scope_coupling/family/family_evidence_prior | 53.005 | 77.011 | 119.50 |
| frozen_reference_coupling/coupled_response | 52.670 | 76.769 | 118.92 |
| frozen_reference_coupling/uncoupled_response | 49.992 | 74.013 | 116.00 |
| hierarchical_risk_event_coupling/coupled_response | 52.736 | 76.758 | 118.83 |
| hierarchical_risk_event_coupling/uncoupled_response | 52.273 | 75.463 | 117.67 |
| learned_response_coupling/coupled_response | 52.680 | 76.769 | 118.92 |
| learned_response_coupling/uncoupled_response | 51.540 | 75.851 | 118.33 |
| modular_reference_coupling/coupled_response | 52.801 | 76.726 | 118.58 |
| modular_reference_coupling/uncoupled_response | 51.019 | 74.500 | 114.17 |
| neutral_margin_prior_coupling/history_margin_response | 52.443 | 76.435 | 117.75 |
| neutral_margin_prior_coupling/neutral_margin_response | 52.638 | 76.813 | 119.00 |
| paired_reference_coupling/coupled_response | 52.853 | 76.942 | 119.25 |
| paired_reference_coupling/uncoupled_response | 52.857 | 77.077 | 119.42 |
| population_reference_coupling/coupled_response | 52.723 | 76.758 | 118.83 |
| population_reference_coupling/uncoupled_response | 50.290 | 76.293 | 117.33 |
| reference_feedback_ablation/coupled_response | 52.853 | 76.942 | 119.25 |
| reference_feedback_ablation/masked_reference_feedback | 52.750 | 77.169 | 119.58 |
| regime_anchored_coupling/coupled_response | 52.802 | 76.726 | 118.58 |
| regime_anchored_coupling/uncoupled_response | 52.987 | 77.592 | 118.67 |
| response_channel_main/joint_risk_response | 49.831 | 74.881 | 117.75 |
| response_channel_main/local_event_gp | 51.857 | 74.732 | 115.83 |
| response_channel_main/shared_event_response | 51.601 | 74.781 | 115.58 |
| risk_event_residual_coupling/coupled_response | 52.742 | 76.769 | 118.92 |
| risk_event_residual_coupling/uncoupled_response | 52.292 | 75.756 | 118.00 |
| risk_task_coupling/coupled_response | 52.710 | 76.847 | 119.17 |
| risk_task_coupling/uncoupled_response | 52.655 | 76.546 | 119.50 |
| task_mean_risk_coupling/coupled_response | 52.799 | 76.769 | 118.92 |
| task_mean_risk_coupling/uncoupled_response | 52.957 | 76.802 | 119.92 |
| threshold_reference_coupling/coupled_response | 52.804 | 76.790 | 118.83 |
| threshold_reference_coupling/uncoupled_response | 52.733 | 76.573 | 118.67 |

共核对 852 条已有曲线；同信息候选双指标前沿为：ep_event_score, event_signs_protected, gaussian_unprotected, student_protected, student_unprotected。
五种子基线完整表仍见 [baseline_comparison.md](baseline_comparison.md)，不与单种子候选均值混用。
旧 IDM/FVDM 参数族实验、元适配、前瞻与推断元学习使用不同数据，不能将其均值插入本表。
已失败的元适配／前瞻／推断元学习依据原同信息对照退役，不声称它们已在六 SUT 基准下重跑。
归档包含原源码、协议、模型和完整结果：[method_selection.zip](../../archives/method_selection.zip)。
本次没有训练、物理仿真或新增性能实验。
