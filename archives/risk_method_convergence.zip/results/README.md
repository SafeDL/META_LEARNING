# 数据与实验结果

| 目录 | 内容 |
|---|---|
| [driving_benchmark](driving_benchmark/README.md) | 当前六 SUT 统一基准的实测池、协议、查询日志、完整基线和方法比较 |
| [historical_expert_mixture](historical_expert_mixture/README.md) | 历史专家MoE：严格组留出、24条逐次反馈闭环、冻结输入与路由诊断 |
| [scale_adaptive_expert_mixture](scale_adaptive_expert_mixture/README.md) | 组件尺度的历史验证和24条目标曲线 |
| [concordance_gated_compositional_bayesian_mixture](concordance_gated_compositional_bayesian_mixture/benchmark_comparison.md) | CG-CBM-FD当前统一比较、统计结果和机器可读汇总 |
| [history_guided_testing](history_guided_testing/README.md) | 原冻结单 FVDM 实验、历史数据和公共模型；旧均值不与六 SUT 基准混用 |
| [response_baselines](response_baselines/README.md) | 冻结响应基线的模型、协议及原输入快照 |

本表六个目录是当前保留范围。CG-CBM-FD的60条轨迹、历史验收和两项组件控制已合并到同名目录；900条基准轨迹和108条补充轨迹所需的原始证据仍可核验。退役分支已从工作目录删除，恢复来源见[归档](../archives/README.md)。

当前高风险统计以严格`R > 0.5`为正例，已有轨迹重算结果和预算覆盖上限集中在[当前比较](concordance_gated_compositional_bayesian_mixture/benchmark_comparison.md)。冻结原碰撞结果单独标记；本轮没有修改选择器或重新执行测试。

方法实现位于[methods](../methods/README.md)，实验代码位于[experiments](../experiments/README.md)。
