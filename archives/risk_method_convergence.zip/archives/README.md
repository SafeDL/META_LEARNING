# 归档与恢复

当前研究主线为[CG-CBM-FD](../methods/concordance_gated_compositional_bayesian_mixture/README.md)。EGFD、历史引导方法及必要响应模型作为依赖与对照保留。

本轮[retired_method_trials.zip](retired_method_trials.zip)保存从工作目录删除的前瞻、条件专家、路由分支及其实验和结果。删除前逐文件解压并比较原内容；清理后再次核验了当前60条轨迹、15方法的900条基准轨迹和108条补充轨迹。未通过历史验收的神经Gate及16个检查点也包含在此归档。范围见[cleanup_manifest.json](cleanup_manifest.json)，依赖检查见[cleanup_dependency_audit.json](cleanup_dependency_audit.json)。

本轮 [method_selection.zip](method_selection.zip) 完整保存七个退役研究目录、五个退役结果阶段及重复高斯控制，共 18129 个移出活动树的原始文件；原相对路径保持不变，删除前逐字节核验。新位置的基线推断快照保存在包内 `runtime/`，迁移过程快照保存在 `retained_runtime/`；仍需在线使用的模型复制到 `results/response_baselines/`。本轮清单与验证见 [清理报告](../results/driving_benchmark/cleanup/report.md)。

|内容|位置|
|---|---|
|旧试验结果、原 S01/RAS 数据与旧入口|`retired_experiments.zip`，可恢复归档|
|AdaTE、DETOUR、FST、ScenarioFuzz 独立论文复现与结果|[retired_research_chains](retired_research_chains/README.md)|
|PEARL 合流历史基线|`pearl_learning/`|
|早期 SAC 场景挖掘基线|`sac_scenario_mining/`|

旧归档共 19,253 个文件，打包后逐文件解压并与原文件进行字节比对，全部一致。展开目录已清理，原相对路径保存在压缩包中。清理范围与核验记录见 [cleanup_review.json](../results/history_guided_testing/cleanup_review.json)。压缩包仅在本地保留，不随常规 Git 提交。

需要核对旧实验时，在仓库根目录解压到独立目录：

```powershell
Expand-Archive -LiteralPath archives/retired_experiments.zip -DestinationPath archives/restored_experiments
```

该命令恢复旧文件的内容和原相对目录结构，不会修改当前主链。当前历史响应、目标响应、GP 与 RAS 模型、80 条统一比较轨迹、关键失败结论和驾驶算法平台继续保留。
