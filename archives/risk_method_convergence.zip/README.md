# 有限预算驾驶系统失效测试

当前论文主方法为 **Concordance-Gated Compositional Bayesian Mixture for Failure Discovery（CG-CBM-FD，一致性门控的组合式贝叶斯专家混合失效发现）**。方法、实验和结果采用同名目录，当前轨迹标识为`cg_cbm_fd`；原实验标识保存在冻结来源记录中。

方法不把某一个历史SUT当作不可拆分的答案，而是分别推断哪个历史来源更能解释连续风险、哪个来源更能解释风险到碰撞的关系。每次目标测试得到的风险和碰撞都会更新来源二元组后验；碰撞与非碰撞的成对排序证据进一步决定历史组合能否影响选择。证据不足时，选择器回到保守分支。候选排序使用集合级后验增益和损失判断，不采用均值与标准差的固定加权。

当前评价以严格`R > 0.5`定义高风险。统一五种子结果中，CG-CBM-FD的高风险Area为46.076%、高风险Recall为72.257%、H200为141.55；高风险Area略高于冻结原方法，最终覆盖率略低。当前选择器仍以实际碰撞为排序目标，既有轨迹未重跑。原碰撞指标单独保留：Area为53.173%、碰撞Recall为77.509%、F200为120.58，不能将碰撞排名直接用于高风险发现结论。

统一基准使用highway-env、六个固定SUT、两个共享场景池和200次唯一查询；每池包含切入与前车制动各1024个场景，初始化十次计入预算。运行环境为`conda activate metadrive`。

| 目录／文件 | 职责 |
|---|---|
| [methods/concordance_gated_compositional_bayesian_mixture](methods/concordance_gated_compositional_bayesian_mixture/README.md) | CG-CBM-FD主方法、后验、门控和集合决策实现 |
| [设计文档](docs/Failure_Discovery_Design.md) | 唯一现行方法设计、公式、实验设置和结果取舍 |
| [五种子结果](results/concordance_gated_compositional_bayesian_mixture/) | CG-CBM-FD完整统一结果与冻结协议 |
| [公平比较](results/concordance_gated_compositional_bayesian_mixture/benchmark_comparison.md) | 相同六SUT、两池、五种子和200次预算下的15种方法比较 |
| [实验核验](experiments/concordance_gated_compositional_bayesian_mixture/README.md) | 现行选择器评价、已有结果核验和公平比较入口 |
| [methods/historical_expert_mixture](methods/historical_expert_mixture/README.md) | 历史风险预测和原始贝叶斯MoE控制 |
| [methods/egfd](methods/egfd/README.md) | 冻结参考策略与发现保护 |
| [methods/history_guided_testing](methods/history_guided_testing/README.md) | 历史数据、GP、测试会话和标准基线 |
| [统一比较](results/driving_benchmark/unified_comparison.md) | 统一基准下的完整方法比较 |
| [代码规范](docs/style.md) | 命名、简洁实现及目录约定 |

核对现有结果：

```powershell
conda activate metadrive
python -B -m experiments.concordance_gated_compositional_bayesian_mixture.verify
python -B -m pytest -q -p no:cacheprovider
```

预算200下，高风险宏平均覆盖的理论上限为78.663%，固定十次初始化后的理想上限为78.487%。高风险、碰撞分别使用完整候选池的对应正例数作分母，统计口径与逐SUT上限见[核验记录](results/concordance_gated_compositional_bayesian_mixture/recall_denominator_audit.json)。核验与比较只重算既有轨迹，没有新增选择轨迹或物理测量。

退役分支的代码、实验和结果已从工作目录删除；恢复来源和清理记录见[archives](archives/README.md)。
