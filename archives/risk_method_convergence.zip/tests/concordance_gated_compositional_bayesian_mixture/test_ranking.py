import itertools

import numpy as np
import torch

from methods.egfd.decision_support import bivariate_normal_probability
from methods.concordance_gated_compositional_bayesian_mixture.composition import CompositionalPosterior
from methods.concordance_gated_compositional_bayesian_mixture.ranking import bivariate_normal_cdf, discordant_probabilities
from methods.historical_expert_mixture.config import JITTER, NOISE


def make_model():
    x = np.zeros((6, 5)); x[:, 0] = np.linspace(0, 1, 6)
    covariance = .03 * np.exp(-((x[:, 0, None] - x[None, :, 0]) / .3) ** 2) + .001 * np.eye(6)
    model = CompositionalPosterior(covariance, np.column_stack((np.full(6, .5), np.linspace(.7, .9, 6))),
                                   [.2, .8], x[:, 4], [[[0., 0.]] * 2, [[3., -2.]] * 2], device="cpu", budget=5)
    model.observe(0, .7, True)
    model.observe(1, .73, False)
    return model


def test_bivariate_cdf_matches_independent_adaptive_quadrature():
    cases = np.asarray(list(itertools.product([-4., -1., 0., .5, 3.], repeat=2)))
    for correlation in [-.99, -.9, 0., .9, .99]:
        actual = bivariate_normal_cdf(torch.tensor(cases[:, 0]), torch.tensor(cases[:, 1]), torch.tensor(correlation, dtype=torch.float64))
        expected = [bivariate_normal_probability(a, b, correlation) for a, b in cases]
        np.testing.assert_allclose(actual.numpy(), expected, atol=2e-10, rtol=1e-8)


def test_bivariate_cdf_gradient_and_broadcasting():
    first = torch.tensor([-.4, .7], dtype=torch.float64, requires_grad=True)
    second = torch.tensor([.3, -1.2], dtype=torch.float64, requires_grad=True)
    correlation = torch.tensor(.7, dtype=torch.float64, requires_grad=True)
    assert torch.autograd.gradcheck(bivariate_normal_cdf, (first, second, correlation), eps=1e-5, atol=1e-7, rtol=1e-5)


def test_mixture_pair_identity_and_correlation_effect():
    model = make_model()
    first, second = np.array([2, 3, 4]), np.array([3, 5, 5])
    forward, reverse = discordant_probabilities(model, first, second)
    marginal = model.probabilities()[0]
    torch.testing.assert_close(forward - reverse, marginal[first] - marginal[second], atol=2e-10, rtol=1e-8)
    independent = marginal[first] * (1 - marginal[second])
    assert torch.max(torch.abs(forward - independent)) > .01
    expected_order = marginal[first] > marginal[second]
    torch.testing.assert_close(forward > reverse, expected_order)




@torch.no_grad()
def test_full_mixture_retains_shared_scale_and_both_gp_correlations():
    model = make_model()
    state = model.state
    expected = 0.
    first, second = 2, 4
    for source, event in itertools.product(range(2), repeat=2):
        slope = model.parameters[[first, second], event, 0].numpy()
        mean = (model.parameters[[first, second], event, 1] + state["event_mean"][0, event, [first, second]]
                + model.parameters[[first, second], event, 0] * state["mean"][0, [first, second], source]).numpy()
        for precision, weight in zip(model.precision[state["alpha"]], model.quadrature_weight):
            scale = float(state["beta"][0, source] / precision)
            covariance = model.event_covariance[event].numpy()[np.ix_([first, second], [first, second])].copy()
            covariance += np.diag(model.report_noise[[first, second]].numpy())
            risk_covariance = model.risk_covariance.numpy()[np.ix_([first, second], [first, second])].copy()
            risk_covariance += (NOISE + JITTER) * np.eye(2)
            covariance += np.outer(slope, slope) * scale * risk_covariance
            deviation = np.sqrt(np.diag(covariance))
            z = mean / deviation
            probability = bivariate_normal_probability(z[0], -z[1], -covariance[0, 1] / np.prod(deviation))
            expected += float(state["log_pair"][0, source, event].exp() * weight) * probability
    actual, _ = discordant_probabilities(model, [first], [second])
    np.testing.assert_allclose(actual.numpy(), [expected], rtol=1e-8, atol=2e-10)
