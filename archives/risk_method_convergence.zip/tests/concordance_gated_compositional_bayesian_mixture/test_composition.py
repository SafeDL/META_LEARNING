import numpy as np
from scipy.special import logsumexp
import torch

from methods.concordance_gated_compositional_bayesian_mixture.composition import CompositionalPosterior
from methods.concordance_gated_compositional_bayesian_mixture.posterior import FeedbackPosterior


def arguments():
    return (np.eye(4) * .001, np.array([[.8, .8], [.86, .7], [.72, .98], [.76, .88]]),
            [.5, .5], [0, 0, 0, 1], [[[20., -14.]] * 2, [[20., -18.]] * 2])


def test_diagonal_pair_support_exactly_recovers_shared_source_model():
    model = CompositionalPosterior(*arguments(), device="cpu")
    model.state["log_pair"] = torch.diag(model.source_prior).log()[None]
    reference = FeedbackPosterior(*arguments(), device="cpu", joint=True)
    for index, risk, collision in [(0, .8, True), (3, .85, False)]:
        model.observe(index, risk, collision)
        reference.observe(index, risk, collision)
        for key in reference.state:
            if key != "alpha":
                torch.testing.assert_close(model.state[key], reference.state[key], atol=2e-14, rtol=0)
        torch.testing.assert_close(model.probabilities(), reference.probabilities(), atol=2e-14, rtol=0)


def test_independent_pair_prior_preserves_factorized_posterior():
    model = CompositionalPosterior(*arguments(), device="cpu")
    model.state["log_pair"] = torch.outer(model.source_prior, model.source_prior).log()[None]
    for index, risk, collision in [(0, .8, True), (3, .85, False)]:
        model.observe(index, risk, collision)
        pair = model.state["log_pair"].exp()[0]
        torch.testing.assert_close(pair, torch.outer(pair.sum(1), pair.sum(0)), atol=2e-14, rtol=0)


def test_pair_likelihood_and_conditional_event_use_one_risk_observation():
    model = CompositionalPosterior(*arguments(), device="cpu")
    index = torch.tensor([1]); risk = model.tensor([.86]); point = model.point(model.state, index)
    old = model.state["log_pair"].numpy()[0].copy()
    lr = model.risk_log_density(model.state, point, risk).numpy()[0]
    variance = point["event_variance"] + model.report_noise[index, None]
    lc = torch.special.log_ndtr((model.event_base(index, risk) + point["event_mean"]) / variance.sqrt()).numpy()[0]
    expected = logsumexp(old + lr[:, None] + lc[None]) - logsumexp(old + lr[:, None])
    actual = model.conditional_collision(model.state, point, index, risk)
    np.testing.assert_allclose(actual.log(), expected, atol=2e-14)
    virtual, _ = model.advance(model.state, point, index, risk, model.tensor([1.]),
                               model.risk_covariance[:, 1][None].clone(), model.event_covariance[:, :, 1][None].clone())
    model.observe(1, .86, True)
    target = old + lr[:, None] + lc[None]; target -= logsumexp(target)
    np.testing.assert_allclose(model.state["log_pair"][0], target, atol=2e-14)
    for key in virtual:
        if key != "alpha": torch.testing.assert_close(virtual[key], model.state[key], rtol=0, atol=0)


def test_recombination_prevents_good_risk_fit_from_suppressing_correct_event_mechanism():
    model = CompositionalPosterior(*arguments(), device="cpu")
    updated = model.update_weights(model.state, model.tensor([[np.log(100), 0.]]), model.tensor([[np.log(.1), np.log(.9)]]))
    pair = updated["log_pair"].exp()[0]
    assert pair.sum(1)[0] > .9
    assert pair.sum(0)[1] > .7
    assert pair[0, 1] > pair[0, 0]


def test_structure_probability_matches_explicit_model_evidence():
    model = CompositionalPosterior(*arguments(), device="cpu")
    lr, lc = np.zeros(2), np.zeros(2)
    for index, risk, collision in [(0, .8, True), (3, .85, False)]:
        model.observe(index, risk, collision)
        e = model.evidence[-1]
        lr += e["risk_log_density"]; lc += e["conditional_event_log_density"]
        lp = np.log([.5, .5])
        shared = logsumexp(lp + lr + lc)
        separate = logsumexp(lp + lr) + logsumexp(lp + lc)
        np.testing.assert_allclose(e["shared_source_probability"], np.exp(shared - np.logaddexp(shared, separate)), atol=2e-14)


