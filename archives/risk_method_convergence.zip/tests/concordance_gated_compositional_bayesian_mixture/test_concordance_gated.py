import numpy as np

from methods.concordance_gated_compositional_bayesian_mixture.concordance_gated import pairwise_log_score, posterior_excess_trust


def test_pairwise_score_is_neutral_until_both_outcomes_are_observed():
    probability = np.array([[.8, .2], [.6, .4]])
    score, count = pairwise_log_score(probability, 0, True, [])
    np.testing.assert_array_equal(score, [0, 0])
    assert count == 0


def test_pairwise_score_rewards_the_better_failure_ordering():
    probability = np.array([[.9, .1], [.6, .4]])
    score, count = pairwise_log_score(probability, 0, True, [{"index": 1, "collision": False}])
    assert score[0] > score[1]
    assert count == 1
    reverse, _ = pairwise_log_score(probability, 1, False, [{"index": 0, "collision": True}])
    np.testing.assert_allclose(score, reverse)


def test_pairwise_score_averages_available_opposite_outcomes():
    probability = np.array([[.8, .2, .1], [.6, .4, .3]])
    records = [{"index": 1, "collision": False}, {"index": 2, "collision": False}]
    combined, count = pairwise_log_score(probability, 0, True, records)
    first, _ = pairwise_log_score(probability, 0, True, records[:1])
    second, _ = pairwise_log_score(probability, 0, True, records[1:])
    np.testing.assert_allclose(combined, (first + second) / 2)
    assert count == 2


def test_posterior_excess_trust_falls_back_under_ambiguity():
    assert posterior_excess_trust(.5) == 0
    assert posterior_excess_trust(.75) == .5
    assert posterior_excess_trust(1) == 1
