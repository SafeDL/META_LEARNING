import numpy as np

from methods.concordance_gated_compositional_bayesian_mixture.set_equivalent_union import certify_set_change


class PairModel:
    def __init__(self, gain=.3, composition_loss=.1, pcg_loss=.05):
        self.composition = self; self.values = gain, composition_loss, pcg_loss; self.calls = 0

    def joint_discovery_probabilities(self, first, second):
        self.calls += 1
        if self.calls == 1:
            return np.array([self.values[0]]), np.array([self.values[1]])
        return np.array([0.0]), np.array([self.values[2]])


def test_reordering_inside_pcg_prefix_requires_no_certificate():
    model = PairModel(pcg_loss=.9)
    chosen, record = certify_set_change(model, proposed=2, reference=1, in_pcg_prefix=True, budget=50)
    assert chosen == 2 and record["reason"] == "set_equivalent_reordering" and model.calls == 0


def test_external_candidate_requires_positive_low_loss_certificate():
    chosen, record = certify_set_change(PairModel(), 2, 1, False, 50)
    assert chosen == 2 and record["correction"]


def test_external_candidate_falls_back_when_pcg_loss_is_large():
    chosen, record = certify_set_change(PairModel(pcg_loss=.2), 2, 1, False, 50)
    assert chosen == 1 and record["reason"] == "pcg_fallback"
