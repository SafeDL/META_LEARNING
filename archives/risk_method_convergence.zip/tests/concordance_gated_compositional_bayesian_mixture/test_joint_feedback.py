import numpy as np
from scipy.integrate import quad
from scipy.special import log_ndtr, ndtr
from scipy.stats import invgamma
import torch

from methods.concordance_gated_compositional_bayesian_mixture.posterior import FeedbackPosterior
from methods.historical_expert_mixture.config import JITTER, NOISE
from methods.scale_adaptive_expert_mixture.posterior import ScaleMixture


def model():
    coordinate = np.linspace(0, 1, 8)
    covariance = .02 * np.exp(-((coordinate[:, None] - coordinate[None]) / .2) ** 2) + np.eye(8) * .001
    priors = np.column_stack((.7 + .2 * coordinate, .8 - .1 * coordinate))
    return FeedbackPosterior(covariance, priors, [.5, .5], np.zeros(8),
                             [[20., -15.], [20., -15.]], device="cpu", budget=8)


def test_risk_filter_matches_exact_student_scale_conditioning():
    posterior = model()
    reference = ScaleMixture(posterior.risk_covariance.numpy().copy(), posterior.state["mean"][0].numpy(), [.5, .5])
    for index, risk, collision in [(0, .83, True), (4, .72, False), (7, .93, True)]:
        posterior.observe(index, risk, collision)
        reference.observe(index, risk)
        np.testing.assert_allclose(posterior.state["mean"][0], reference.mean, atol=2e-13)
        np.testing.assert_allclose(posterior.state["variance"][0], reference.variance, atol=2e-13)
        np.testing.assert_allclose(posterior.state["beta"][0], reference.beta, atol=2e-13)
        np.testing.assert_allclose(posterior.state["log_weight"].exp()[0], reference.probability, atol=2e-13)


def test_conditional_event_filter_has_exact_one_observation_moments():
    posterior = model()
    cross = posterior.event_covariance[:, :, 0].numpy().copy()
    total_variance = posterior.state["event_variance"][0, :, 0].numpy() + posterior.report_noise[0].item()
    z = -np.array([20 * .81 - 15, 0.]) / np.sqrt(total_variance)
    ratio = np.exp(-.5 * z ** 2 - .5 * np.log(2 * np.pi) - log_ndtr(z))
    expected_mean = -cross * (ratio / np.sqrt(total_variance))[:, None]
    expected_variance = posterior.state["event_variance"][0].numpy() - cross ** 2 * (ratio * (ratio + z) / total_variance)[:, None]
    posterior.observe(0, .81, False)
    np.testing.assert_allclose(posterior.state["event_mean"][0], expected_mean, atol=2e-13)
    np.testing.assert_allclose(posterior.state["event_variance"][0], expected_variance, atol=2e-13)




def test_student_event_convolution_matches_independent_scale_integral():
    posterior = model()
    for index in (0, 3, 5):
        posterior.observe(index, .79 + index / 100, index != 3)
    actual = posterior.probabilities()[0].numpy()
    state = posterior.state
    expected = []
    for index in range(8):
        historical = 0.
        for component, weight in enumerate(state["log_weight"].exp()[0].numpy()):
            mean = 20 * state["mean"][0, index, component].item() - 15 + state["event_mean"][0, 0, index].item()
            report_variance = state["event_variance"][0, 0, index].item() + posterior.report_noise[index].item()
            risk_variance = state["variance"][0, index].item() + NOISE + JITTER
            scale = state["beta"][0, component].item()
            integral = quad(lambda value: ndtr(mean / np.sqrt(report_variance + 400 * risk_variance * value))
                            * invgamma.pdf(value, a=state["alpha"], scale=scale), 0, np.inf, epsabs=1e-10)[0]
            historical += weight * integral
        neutral = ndtr(state["event_mean"][0, 1, index].item() / np.sqrt(
            state["event_variance"][0, 1, index].item() + posterior.report_noise[index].item()))
        expected.append(state["route"][0, 0].item() * historical + state["route"][0, 1].item() * neutral)
    np.testing.assert_allclose(actual, expected, atol=2e-4)






def test_failure_feedback_can_correct_order_without_source_agreement():
    posterior = FeedbackPosterior(np.eye(3) * .001,
                                  np.array([[1., 1.], [.96, .98], [.95, .97]]), [.5, .5],
                                  [0, 0, 1], [[30., -24.], [30., -24.]], device="cpu", budget=200)
    before = posterior.probabilities()[0]
    assert before[1] > before[2]
    posterior.observe(0, 1., False)
    after = posterior.probabilities()[0]
    assert after[1] < after[2]
    np.testing.assert_allclose(posterior.state["log_weight"].exp()[0], [.5, .5], atol=1e-14)
    assert posterior.state["mean"][0, 1, 0] != posterior.state["mean"][0, 1, 1]
