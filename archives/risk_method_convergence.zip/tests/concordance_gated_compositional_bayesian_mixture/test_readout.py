import numpy as np

from methods.concordance_gated_compositional_bayesian_mixture.readout import fit_readout


def test_historical_readout_is_monotone_and_handles_separation():
    risk = np.tile(np.linspace(0, 1, 500), 2)
    family = np.repeat([0, 1], 500)
    collision = risk > np.where(family == 0, .75, .85)
    parameters, diagnostics = fit_readout(risk, collision, family)
    assert np.all(parameters[:, 0] > 0)
    assert all(d["samples"] == 500 for d in diagnostics)
    assert parameters[1, 1] / parameters[1, 0] < parameters[0, 1] / parameters[0, 0]
