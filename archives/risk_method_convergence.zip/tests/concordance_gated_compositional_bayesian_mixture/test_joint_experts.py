import numpy as np
from scipy.integrate import quad
from scipy.special import ndtr, softmax
from scipy.stats import invgamma, t
import torch

from methods.concordance_gated_compositional_bayesian_mixture.posterior import FeedbackPosterior
from methods.historical_expert_mixture.config import JITTER, NOISE
from methods.scale_adaptive_expert_mixture.posterior import ScaleMixture


def joint_model():
    return FeedbackPosterior(np.eye(3) * .001, np.array([[.8, .8], [.86, .70], [.72, .98]]),
                             [.5, .5], [0, 0, 0], [[[20., -14.]] * 2, [[20., -18.]] * 2],
                             device="cpu", budget=200, joint=True)


def test_one_collision_corrects_choice_when_risk_cannot_distinguish_sources():
    model = joint_model()
    before = model.probabilities()[0]
    assert before[1] < before[2]
    point = model.point(model.state, torch.tensor([0]))
    density = model.risk_log_density(model.state, point, model.tensor([.8]))
    assert density[0, 0] == density[0, 1]
    model.observe(0, .8, True)
    np.testing.assert_allclose(model.state["log_weight"].exp()[0], ndtr([2., -2.]), atol=1e-14)
    assert model.probabilities()[0, 1] > model.probabilities()[0, 2]
    np.testing.assert_array_equal(model.state["mean"][0, 1:], [[.86, .70], [.72, .98]])
    assert model.state["log_weight"].exp()[0, 1] > 0


def test_conditional_collision_uses_source_posterior_after_risk():
    model = joint_model()
    index = torch.tensor([1])
    point = model.point(model.state, index)
    risk = .86
    variance = .001 + NOISE + JITTER
    density = t.logpdf(risk, df=5, loc=[.86, .70], scale=np.sqrt(.6 * variance))
    expected = softmax(density) @ ndtr([20 * risk - 14, 20 * risk - 18])
    actual = model.conditional_collision(model.state, point, index, model.tensor([risk]))
    np.testing.assert_allclose(actual, expected, atol=1e-14)
    assert abs(expected - np.mean(ndtr([20 * risk - 14, 20 * risk - 18]))) > .2
    model.observe(1, risk, True)
    expected_weight = softmax(density + np.log(ndtr([20 * risk - 14, 20 * risk - 18])))
    np.testing.assert_allclose(model.state["log_weight"].exp()[0], expected_weight, atol=1e-14)


def test_risk_conditioning_is_unchanged_inside_each_joint_expert():
    model = joint_model()
    reference = ScaleMixture(model.risk_covariance.numpy().copy(), model.state["mean"][0].numpy(), [.5, .5])
    for index, risk, collision in [(0, .8, True), (1, .7, False)]:
        model.observe(index, risk, collision)
        reference.observe(index, risk)
        for key, expected in [("mean", reference.mean), ("variance", reference.variance), ("beta", reference.beta)]:
            np.testing.assert_allclose(model.state[key][0], expected, atol=2e-14)






def test_neutral_expert_can_take_over_when_conditional_relation_fails():
    model = FeedbackPosterior(np.eye(3) * .001, np.full((3, 2), .5), [.2, .8], [0, 0, 0],
                              [[[0., 0.]] * 2, [[30., -5.]] * 2], device="cpu", joint=True)
    model.observe(0, .5, False)
    assert model.state["log_weight"].exp()[0, 0] > .999
    assert model.probabilities()[0, 1] < .5


def test_joint_probability_integrates_each_sources_own_scale_and_event_gp():
    model = joint_model()
    model.observe(0, .81, False)
    expected = []
    state = model.state
    for index in range(3):
        probability = 0.
        for component in range(2):
            slope, intercept = model.parameters[index, component].numpy()
            mean = slope * state["mean"][0, index, component].item() + intercept + state["event_mean"][0, component, index].item()
            variance = state["event_variance"][0, component, index].item() + model.report_noise[index].item()
            risk_variance = state["variance"][0, index].item() + NOISE + JITTER
            integral = quad(lambda scale: ndtr(mean / np.sqrt(variance + slope ** 2 * scale * risk_variance))
                            * invgamma.pdf(scale, a=state["alpha"], scale=state["beta"][0, component].item()),
                            0, np.inf, epsabs=1e-10)[0]
            probability += state["log_weight"].exp()[0, component].item() * integral
        expected.append(probability)
    np.testing.assert_allclose(model.probabilities()[0], expected, atol=2e-4)
