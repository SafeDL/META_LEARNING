import itertools
from types import SimpleNamespace

import numpy as np

from methods.egfd import selection as frozen_policy
from methods.egfd.reference import ReferenceReplay
from methods.concordance_gated_compositional_bayesian_mixture import supported
from tests.egfd.test_reference import Candidate, Oracle, ReferenceSession
from tests.concordance_gated_compositional_bayesian_mixture.test_ranking import make_model


def test_prediction_preserves_the_original_compositional_probabilities():
    model = make_model()
    probability, score = model.selection_prediction()
    np.testing.assert_array_equal(probability, model.probabilities()[0].detach().numpy())
    assert np.isfinite(score).all()


def test_ranking_uses_reference_family_and_retains_equal_probability_head():
    model = SimpleNamespace(selection_prediction=lambda: (np.array([.2, .9, .3]), np.array([0., 3., 1.])))
    assert supported.rank(model, 0, np.ones(3, bool), np.array([0, 1, 0]), np.arange(3)) == 2
    model.selection_prediction = lambda: (np.array([.3, .9, .3]), np.array([0., 3., 1.]))
    assert supported.rank(model, 0, np.ones(3, bool), np.array([0, 1, 0]), np.arange(3)) == 0


def test_reference_and_credit_rules_match_frozen_egfd_on_all_risk_event_banks(monkeypatch):
    def rank(model, head, available, family, tie):
        return int(model.rank(available, tie_break=tie)[0])

    monkeypatch.setattr(supported, "rank", rank)
    for support in (False, True):
        monkeypatch.setattr(supported, "discovery_support", lambda *args: {"supported": support})
        monkeypatch.setattr(frozen_policy, "discovery_loss_support", lambda *args: {"supported": support})
        for risks in itertools.product((0., 1.), repeat=5):
            standalone = ReferenceSession(); order = []
            for _ in range(4):
                index = standalone.next_index(); order.append(index); standalone.observe(risks[index])
            for labels in itertools.product((False, True), repeat=5):
                oracle = Oracle(labels, risks)
                result = supported.run_supported_policy(ReferenceReplay(ReferenceSession()), Candidate(), np.zeros(5), oracle, np.arange(5), 4, 1)
                control = frozen_policy.run_supported_policy(ReferenceReplay(ReferenceSession()), Candidate(), Oracle(labels, risks), np.arange(5), 4, 1)
                assert result == control
                actual = np.cumsum([labels[i] for i in result["selected_indices"]])
                reference = np.cumsum([labels[i] for i in order])
                assert np.all(actual >= (reference - 1) / (1 + 1 / np.sqrt(4)))


def test_discovery_support_matches_pair_probabilities_and_budget_allowance():
    model = make_model()
    gain, loss = model.joint_discovery_probabilities([2], [4])
    check = supported.discovery_support(model, 2, 4, 200)
    assert check["gain_probability"] == float(gain[0])
    assert check["loss_probability"] == float(loss[0])
    assert check["supported"] == (float(loss[0]) <= 1 / np.sqrt(200) and float(gain[0] - loss[0]) > 1e-12)
