from methods.concordance_gated_compositional_bayesian_mixture.selection import family_horizon


def test_family_horizon_allocates_remaining_budget_by_available_share():
    assert family_horizon(190, 1024, 2038) == 96
    assert family_horizon(1, 100, 200) == 1


def test_family_horizon_never_exceeds_available_family():
    assert family_horizon(190, 3, 10) == 3
