from __future__ import annotations

import pytest

from simulation.metadrive.scenario.catalog import mvr_parameter_spaces
from simulation.metadrive.scenario.executor import ScenarioExecutor
from simulation.metadrive.scenario.parameter_space import NormalizedScenarioAction
from simulation.metadrive.scenario.registry import load_adapters
from simulation.metadrive.scenario.taskbook import load_taskbook


def test_candidate_relative_spawn_round_trips_the_outer_distance_controls() -> None:
    task = next(
        row for row in load_taskbook("simulation/metadrive/configs/taskbook.json")
        if row.task_id == "roundabout-g04-fast_small_gap-interaction_core"
    )
    action = NormalizedScenarioAction(2, (0.1, 0.2, 0.0, 0.0, 0.0))
    executor = ScenarioExecutor(load_adapters(), mvr_parameter_spaces())
    episode = executor.reset(task, action)
    try:
        scenario = episode.applied_scenario
        _, candidates = executor.enumerate_interactions(task)
        candidate = candidates[action.candidate_index]
        assert scenario.normalized_continuous == action.continuous
        assert scenario.adversary_distance_to_conflict_m == pytest.approx(
            candidate.adversary_distance_min_m + 0.55 * (
                candidate.adversary_distance_available_m - candidate.adversary_distance_min_m
            )
        )
        assert scenario.sut_distance_to_conflict_m == pytest.approx(
            candidate.sut_distance_min_m + 0.6 * (
                candidate.sut_distance_available_m - candidate.sut_distance_min_m
            )
        )
    finally:
        episode.env.close()
