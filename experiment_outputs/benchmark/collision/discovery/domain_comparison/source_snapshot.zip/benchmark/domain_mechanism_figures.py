"""Render the admitted domain experiment's matched historical/feedback curves."""

import numpy as np

from .discovery_config import read_json
from .domain_comparison import OUTPUT


def main():
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    if read_json(OUTPUT / "audit.json")["status"] != "passed":
        raise ValueError("Audit the complete paired experiment before plotting mechanism effects")
    curves = read_json(OUTPUT / "curves.json")
    figure, axes = plt.subplots(1, 2, figsize=(11, 4.3), constrained_layout=True)
    styles = (("gcrt", "H1F1", "-"), ("H0F1", "H0F1", "--"),
              ("H1F0", "H1F0", "-."), ("H0F0", "H0F0", ":"))
    for method, label, style in styles:
        for axis, metric in zip(axes, ("discovery_curve", "recall_curve")):
            axis.plot(np.arange(1, 129), curves[method][metric], style, label=label)
    axes[0].set(xlabel="Paid queries", ylabel="Unique collision groups")
    axes[1].set(xlabel="Paid queries", ylabel="Recall over complete finite pool", ylim=(0, 1.01))
    for axis in axes:
        axis.axvline(8, color="gray", linestyle=":", linewidth=0.8)
        axis.grid(alpha=0.2)
        axis.legend(fontsize=9)
    for extension in ("png", "svg", "pdf"):
        figure.savefig(OUTPUT / f"mechanism_curves.{extension}", dpi=180)
    plt.close(figure)


if __name__ == "__main__":
    main()
