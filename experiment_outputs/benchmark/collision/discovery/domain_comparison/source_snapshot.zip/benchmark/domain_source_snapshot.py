"""Preserve reproducible Stage B/C source before adding the independent task."""

import hashlib
import json
import subprocess
import zipfile

from .discovery_config import read_json, write_json
from .domain_comparison import OUTPUT
from .protocol import ROOT


def main():
    domain = read_json(OUTPUT / "protocol.json")
    covariance = read_json(OUTPUT / "covariance/protocol.json")
    diagonal = read_json(OUTPUT / "diagonal_controls/protocol.json")
    for contract in (domain["source_files"], covariance["source_files"], diagonal["source_files"]):
        for path, expected in contract.items():
            if hashlib.sha256((ROOT / path).read_bytes()).hexdigest() != expected:
                raise ValueError(f"Frozen source differs before archival: {path}")
    paths = subprocess.check_output(["rg", "--files", "-g", "*.py", "benchmark", "methods",
                                     "controllers", "simulation"], cwd=ROOT, text=True).splitlines()
    paths = sorted({p.replace("\\", "/") for p in paths} | {"environment.yml"})
    manifest = {"purpose": "replay completed B/C experiments; not the final method definition",
        "files": {p: hashlib.sha256((ROOT / p).read_bytes()).hexdigest() for p in paths},
        "domain_protocol_sha256": hashlib.sha256((OUTPUT / "protocol.json").read_bytes()).hexdigest(),
        "covariance_protocol_sha256": hashlib.sha256((OUTPUT / "covariance/protocol.json").read_bytes()).hexdigest(),
        "diagonal_control_protocol_sha256": hashlib.sha256((OUTPUT / "diagonal_controls/protocol.json").read_bytes()).hexdigest(),
        "replay": {"extract": "an empty directory outside the working source tree",
                   "directory_links_to_original_workspace": ["data", "results", "controllers/highway/checkpoints"],
                   "command": "python -B -m benchmark.domain_comparison audit"}}
    archive = OUTPUT / "source_snapshot.zip"
    with zipfile.ZipFile(archive, "x", compression=zipfile.ZIP_DEFLATED) as stream:
        for path in paths:
            stream.write(ROOT / path, path)
        stream.writestr("snapshot_manifest.json", json.dumps(manifest, indent=2))
    write_json(OUTPUT / "source_snapshot.json", {**manifest,
        "archive_sha256": hashlib.sha256(archive.read_bytes()).hexdigest(), "archive_bytes": archive.stat().st_size})
    print({"source_files": len(paths), "archive_bytes": archive.stat().st_size}, flush=True)
    return manifest


if __name__ == "__main__":
    main()
