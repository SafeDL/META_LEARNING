"""Measure an exact CPU replay before freezing independent execution placement."""

import time

import numpy as np
from threadpoolctl import threadpool_limits
import torch

from .discovery_config import development_tasks, read_json, write_json
from .domain_comparison import OUTPUT, public_task, run_path
from .domain_risk import disclose_driving_quality, disclose_impact
from .construction import load_construction
from .executions import ExecutionBank
from .protocol import DATA_ROOT
from .query import QueryLedger, run_isolated


def main():
    torch.set_num_threads(1)
    task = development_tasks()[0]
    with threadpool_limits(1):
        history, _ = load_construction(task["scenario"])
        bank = ExecutionBank(DATA_ROOT / "physical/development" / task["scenario"] / task["target_id"])
        expected = read_json(run_path(task, "gcrt"))["result"]
        selector, public = public_task(task, "gcrt", bank.candidates, history)
        public["device"] = "cpu"
        ledger = QueryLedger(bank.candidates, 128,
            lambda scene: disclose_driving_quality(disclose_impact(bank(scene))))
        started = time.perf_counter()
        actual = run_isolated(selector, public, ledger)
        duration = time.perf_counter() - started
        if actual["selected_indices"] != expected["selected_indices"]:
            raise ValueError("The CPU replay changed a paid acquisition")
        maximum = 0.0
        for a, b in zip(actual["queries"], expected["queries"]):
            for field in ("prequery_probability", "prequery_component_probabilities",
                          "prequery_component_weights", "component_weights_after_query"):
                difference = float(np.max(np.abs(np.asarray(a[field]) - np.asarray(b[field]))))
                if difference > 1e-7:
                    raise ValueError(f"CPU replay differs in {field}: {difference}")
                maximum = max(maximum, difference)
        report = {"status": "passed", "task": task, "queries": 128, "wall_s": duration,
                  "maximum_error": maximum, "new_physical_calls": 0,
                  "equivalent_validation_queries": 128, "acceptance_tolerance": 1e-7,
                  "tolerance_source": "the existing Stage A independent acquisition audit",
                  "previous_validation": {"queries": 128, "all_acquisitions_identical": True,
                      "initial_extra_strict_threshold": 1e-10,
                      "first_component_error_exceeding_extra_threshold": 1.1153866719126881e-10},
                  "result": actual}
        write_json(OUTPUT / "cpu_replay.json", report)
        print({k: v for k, v in report.items() if k != "result"}, flush=True)
    return report


if __name__ == "__main__":
    main()
