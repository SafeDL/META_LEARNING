"""Check absent risk feedback and rare-positive training episodes."""
import numpy as np
import torch

from .learn_transfer import CONTEXT_COUNTS, episode
from .train import TransferParameters


def example():
    rng = np.random.default_rng(11)
    x = np.column_stack((rng.uniform(size=(512, 4)), np.arange(512) % 2))
    risks, collisions = rng.uniform(0.01, 0.99, size=(2, 512, 3))
    truth_r = rng.uniform(size=512)
    truth_c = np.zeros(512, dtype=bool)
    truth_c[:24] = True
    model = TransferParameters("logit", positive_loading=True).cuda()
    logits = torch.nn.Parameter(
        torch.zeros((2, 6), dtype=torch.float64, device="cuda"))
    task = ("example", x, risks, collisions, [0, 2, 4], truth_r, truth_c)
    return model, logits, task


def test_empty_context_does_not_depend_on_target_risk_values():
    model, logits, task = example()
    seed = next(seed for seed in range(100)
                if np.random.default_rng(seed).choice(CONTEXT_COUNTS) == 0)
    first = episode(model, logits, task, np.random.default_rng(seed))
    changed = (*task[:5], 1 - task[5], task[6])
    second = episode(model, logits, changed, np.random.default_rng(seed))
    torch.testing.assert_close(first, second, atol=0, rtol=0)


def test_all_safe_training_episode_has_finite_loss_and_excluded_source_gradients(
):
    model, logits, task = example()
    task = (*task[:6], np.zeros_like(task[6]))
    loss = episode(model, logits, task, np.random.default_rng(23))
    assert torch.isfinite(loss)
    loss.backward()
    assert torch.isfinite(logits.grad).all()
    assert torch.count_nonzero(logits.grad[:, [1, 3, 5]]) == 0
    assert all(
        parameter.grad is not None and torch.isfinite(parameter.grad).all()
        for parameter in model.parameters())
