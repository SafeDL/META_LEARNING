"""Learn reference means and transfer parameters from historical and older development tasks."""
import numpy as np
import torch
from torch.nn import functional as F

from methods.history_guided_testing.config import GROUPS, ROOT as BASELINE
from methods.history_guided_testing.io import read_json, write_json
from research.history_response_testing.history_model import SOURCE_NAMES, predict

from .config import OUTPUT
from .history_validation import predictions
from .initial_prior import coordinates
from .model import joint_prior, risk_coordinate
from .train import QUERY_COUNT, TransferParameters

RESULTS = OUTPUT / "transfer_learning"
STEPS = 1200
CONTEXT_COUNTS = (0, 10, 30, 60, 100, 160)
PARAMETER_NAMES = ("source_scale", "risk_scale", "collision_scale", "noise",
                   "length", "sensitivity_regularization")


def tasks():
    rows = []
    with np.load(BASELINE / "history/responses.npz") as bank:
        for group, targets in GROUPS.items():
            names, risks, collisions = predictions(bank, group)
            for target in targets:
                rows.append(
                    (target, bank["x"].copy(), risks, collisions,
                     [SOURCE_NAMES.index(name) for name in names],
                     bank[target].copy(), bank[target + "_collision"].copy()))
    pools = [("original", BASELINE / "target/responses.npz")]
    pools += [(path.parent.name, path)
              for path in sorted((OUTPUT /
                                  "development_pools").glob("*/responses.npz"))
              ]
    for name, path in pools:
        with np.load(path) as bank:
            risks, collisions = predict(bank["x"], 11)
            rows.append((name, bank["x"].copy(), risks, collisions,
                         list(range(len(SOURCE_NAMES))), bank["risk"].copy(),
                         bank["collision"].copy()))
    assert len(rows) == 11
    return rows


def episode(model, mean_logits, task, rng):
    _, x, risks, collisions, source_indices, truth_r, truth_c = task
    context_count = int(rng.choice(CONTEXT_COUNTS))
    available = np.arange(len(x))
    proposal = np.argsort(-collisions.mean(1))[:600] if rng.integers(
        2) else available
    context = rng.choice(proposal, context_count, replace=False)
    remaining = np.setdiff1d(available, context)
    positive, negative = remaining[
        truth_c[remaining]], remaining[~truth_c[remaining]]
    count = min(QUERY_COUNT // 2, len(positive))
    query = np.concatenate((rng.choice(positive, count, replace=False),
                            rng.choice(negative,
                                       QUERY_COUNT - count,
                                       replace=False)))
    indices = np.concatenate((context, query))
    options = model.options()
    mr, _, rr, cr, cc, _ = joint_prior(x[indices], risks[indices],
                                       collisions[indices], options)
    family, _, collision = coordinates(x[indices], risks[indices],
                                       collisions[indices])
    weights = mean_logits[family][:, source_indices].softmax(1)
    mc = (collision * weights).sum(1) + model.offset[family]
    kernel = rr[:context_count, :context_count] + options["noise"] * torch.eye(
        context_count, dtype=mr.dtype, device=mr.device)
    cross = cr[context_count:, :context_count]
    residual = mr.new_tensor(risk_coordinate(truth_r[context],
                                             "logit")) - mr[:context_count]
    mean = mc[context_count:] + cross @ torch.linalg.solve(kernel, residual)
    variance = (cc[context_count:] -
                (cross * torch.linalg.solve(kernel, cross.T).T).sum(1)).clamp(
                    min=0)
    q = torch.special.ndtr(mean / (1 + variance).sqrt()).clamp(1e-8, 1 - 1e-8)
    prevalence = float(truth_c[remaining].mean())
    if count:
        score = torch.logit(q)
        ranking = F.softplus(score[count:][None, :] -
                             score[:count, None]).mean()
        calibration = (-prevalence * q[:count].log().mean() -
                       (1 - prevalence) * (1 - q[count:]).log().mean())
    else:
        ranking = q.sum() * 0
        calibration = -(1 - q).log().mean()
    return ranking + 0.1 * calibration


def initialized_parameters():
    base = read_json(OUTPUT /
                     "models/monotone_transfer/logit_600.json")["options"]
    learned = read_json(OUTPUT /
                        "initial_prior/models/collision_mean_600.json")
    assert learned["target_data_used"] is False
    model = TransferParameters("logit", positive_loading=True).cuda()
    with torch.no_grad():
        model.log_parameters.copy_(
            model.log_parameters.new_tensor(
                [base[name] for name in PARAMETER_NAMES]).log())
        model.loading.copy_(model.loading.new_tensor(base["loading"]))
        model.offset.copy_(model.offset.new_tensor(base["collision_offset"]))
    mean_logits = torch.nn.Parameter(
        model.offset.new_tensor(learned["mean_logits"])[1])
    return model, mean_logits


def main():
    torch.set_num_threads(1)
    if (RESULTS / "model.json").exists():
        return
    data = tasks()
    model, mean_logits = initialized_parameters()
    parameters = [*model.parameters(), mean_logits]
    optimizer = torch.optim.Adam(parameters, lr=0.003)
    rng = np.random.default_rng(20261008)
    curve = []
    for step in range(STEPS):
        loss = episode(model, mean_logits, data[int(rng.integers(len(data)))],
                       rng)
        assert torch.isfinite(loss)
        optimizer.zero_grad()
        loss.backward()
        assert all(parameter.grad is not None
                   and torch.isfinite(parameter.grad).all()
                   for parameter in parameters)
        torch.nn.utils.clip_grad_norm_(parameters, 10)
        optimizer.step()
        curve.append(float(loss.detach()))
        if (step + 1) % 100 == 0:
            print("DEVELOPMENT TRANSFER LEARNING",
                  step + 1,
                  round(float(np.mean(curve[-100:])), 4),
                  flush=True)
    state = {
        "options":
        model.serializable(),
        "mean_logits":
        torch.stack(
            (mean_logits.detach() * 0, mean_logits.detach())).cpu().tolist(),
        "source_names":
        SOURCE_NAMES,
        "curve":
        curve,
        "steps":
        STEPS,
        "learning_rate":
        0.003,
        "context_counts":
        CONTEXT_COUNTS,
        "query_count":
        QUERY_COUNT,
        "tasks": [task[0] for task in data],
        "prospective_cohort_used":
        False,
        "older_development_targets_used":
        True,
        "risk_reference":
        "empirical source mean; only collision reference logits learned",
        "scope":
        "Historical and earlier development training; needs fresh independent confirmation"
    }
    write_json(RESULTS / "model.json", state)
    print("DEVELOPMENT TRANSFER MODEL SAVED", state["options"], flush=True)


if __name__ == "__main__":
    main()
