"""Keep historical response hypotheses separate through continuous-risk conditioning."""
import time

import numpy as np
import torch

from methods.history_guided_testing.config import ROOT as BASELINE
from methods.history_guided_testing.io import read_json, write_json
from research.history_response_testing.history_model import predict

from .config import OUTPUT, SEEDS
from .develop import metrics
from .hypotheses import ResponseHypotheses


def main():
    torch.set_num_threads(1)
    candidates = []
    for transform, steps in [("raw", 300), ("raw", 1200), ("logit", 300),
                             ("logit", 600), ("logit", 1200)]:
        options = read_json(OUTPUT / "models" / "meta_transfer" /
                            f"{transform}_{steps}.json")["options"]
        for matched in (False, True):
            candidates.append((f"{transform}_{steps}_{matched}", {
                **options, "predictive_mean":
                "empirical_probability" if matched else None
            }))
    for path in sorted((OUTPUT / "models" / "hypotheses").glob("*.json")):
        if int(path.stem.rsplit("_", 1)[1]) in (300, 600, 1200):
            candidates.append(
                ("learned_" + path.stem, read_json(path)["options"]))
    pools = [("original", BASELINE / "target/responses.npz")]
    pools += [(path.parent.name, path)
              for path in sorted((OUTPUT /
                                  "development_pools").glob("*/responses.npz"))
              ]
    records = []
    for name, pool in pools:
        bank = np.load(pool)
        for seed in SEEDS:
            prediction = predict(bank["x"], seed)
            for method, options in candidates:
                path = OUTPUT / "hypothesis_development" / f"{name}_{method}_{seed}.json"
                if path.exists():
                    result = read_json(path)
                else:
                    started = time.perf_counter()
                    session = ResponseHypotheses(bank["x"], *prediction,
                                                 options)
                    selected = []
                    while (index := session.next_index()) is not None:
                        session.observe(float(bank["risk"][index]))
                        selected.append(index)
                    result = {
                        **metrics(bank["collision"], selected), "selected_indices":
                        selected,
                        "queries":
                        session.records,
                        "options":
                        options,
                        "elapsed_s":
                        time.perf_counter() - started,
                        "stage":
                        "development; queried continuous risk only"
                    }
                    write_json(path, result)
                records.append({
                    "pool": name,
                    "method": method,
                    "seed": seed,
                    "options": options,
                    **{
                        key: result[key]
                        for key in ("mean_cumulative_collisions", "F200", "pool_collisions", "recall")
                    }
                })
                print("HYPOTHESES",
                      name,
                      method,
                      seed,
                      round(result["mean_cumulative_collisions"], 3),
                      result["F200"],
                      flush=True)
            write_json(OUTPUT / "hypothesis_development" / "summary.json",
                       records)


if __name__ == "__main__":
    main()
