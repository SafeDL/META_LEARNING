"""Risk-only lookahead under historical response hypotheses."""
import time

import numpy as np
import torch

from methods.history_guided_testing.config import ROOT as BASELINE
from methods.history_guided_testing.io import read_json, write_json
from research.history_response_testing.history_model import predict

from .config import OUTPUT
from .develop import metrics
from .hypotheses import ResponseHypotheses

DEVELOPMENT_SEEDS = (11, )
HORIZONS = (1, 20)
PRIORS = (
    ("logit_transfer", "meta_transfer/logit_1200.json"),
    ("raw_family", "hypotheses/raw_family_False_300.json"),
    ("raw_global", "hypotheses/raw_global_False_1200.json"),
    ("logit_global", "hypotheses/logit_global_False_1200.json"),
)


def main():
    torch.set_num_threads(1)
    pools = [("original", BASELINE / "target/responses.npz")]
    pools += [(path.parent.name, path)
              for path in sorted((OUTPUT /
                                  "development_pools").glob("*/responses.npz"))
              ]
    records = []
    for seed in DEVELOPMENT_SEEDS:
        for name, pool in pools:
            bank = np.load(pool)
            prediction = predict(bank["x"], seed)
            for method, prior_path in PRIORS:
                prior = read_json(OUTPUT / "models" / prior_path)["options"]
                for horizon in HORIZONS:
                    options = {**prior, "lookahead": True, "horizon": horizon}
                    path = OUTPUT / "hypothesis_decision" / f"{name}_{method}_{horizon}_{seed}.json"
                    if path.exists():
                        result = read_json(path)
                    else:
                        started = time.perf_counter()
                        session = ResponseHypotheses(bank["x"], *prediction,
                                                     options)
                        selected = []
                        while (index := session.next_index()) is not None:
                            session.observe(float(bank["risk"][index]))
                            selected.append(index)
                        result = {
                            **metrics(bank["collision"], selected), "selected_indices":
                            selected,
                            "queries":
                            session.records,
                            "options":
                            options,
                            "elapsed_s":
                            time.perf_counter() - started,
                            "stage":
                            "development; queried risk only; equal endpoint and curve reward"
                        }
                        write_json(path, result)
                    records.append({
                        "pool": name,
                        "method": method,
                        "horizon": horizon,
                        "seed": seed,
                        **{
                            key: result[key]
                            for key in ("mean_cumulative_collisions", "F200", "pool_collisions", "recall")
                        }
                    })
                    print("MIXTURE_DECISION",
                          name,
                          method,
                          horizon,
                          seed,
                          round(result["mean_cumulative_collisions"], 3),
                          result["F200"],
                          flush=True)
            write_json(OUTPUT / "hypothesis_decision" / "summary.json",
                       records)


if __name__ == "__main__":
    main()
