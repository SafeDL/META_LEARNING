"""Learn a response mixture from risk contexts and historical failure supervision."""
import numpy as np
import torch
from torch import nn
from torch.nn import functional as F

from methods.history_guided_testing.config import GROUPS, ROOT as BASELINE
from methods.history_guided_testing.io import write_json

from .config import OUTPUT
from .history_validation import predictions
from .hypotheses import hypothesis_prior
from .model import risk_coordinate
from .train import CONTEXT_COUNTS, QUERY_COUNT, STEPS


class HypothesisParameters(nn.Module):

    def __init__(self, transform, scope, matched):
        super().__init__()
        self.transform, self.scope, self.matched = transform, scope, matched
        initial = ([0.25, 1, 0.0025, 0.05, 0.0025]
                   if transform == "raw" else [1, 0.25, 1, 0.5, 1])
        self.log_parameters = nn.Parameter(
            torch.tensor(np.log(initial), dtype=torch.float64))
        loading = torch.zeros((2, 6), dtype=torch.float64)
        loading[:, -1] = 1
        self.loading = nn.Parameter(loading)
        self.offset = nn.Parameter(torch.zeros(2, dtype=torch.float64))

    def options(self):
        values = self.log_parameters.exp()
        return {
            "transform":
            self.transform,
            "collision_transform":
            "probit",
            "residual_mode":
            "learned_sensitivity",
            "source_scale":
            0,
            "weight_scope":
            self.scope,
            "lookahead":
            False,
            "predictive_mean":
            "empirical_probability" if self.matched else None,
            **dict(
                zip(("risk_scale", "collision_scale", "noise", "length", "sensitivity_regularization"), values)), "loading":
            self.loading,
            "collision_offset":
            self.offset
        }

    def serializable(self):
        return {
            key:
            value.detach().cpu().tolist() if torch.is_tensor(value) else value
            for key, value in self.options().items()
        }


def posterior_probability(model, x, risks, collisions, context, query,
                          truth_r):
    indices = np.concatenate((context, query))
    options = model.options()
    mr, mc, rr, loading, variance = hypothesis_prior(
        x[indices],
        risks[indices],
        collisions[indices],
        options,
        device=model.log_parameters.device)
    count = len(context)
    kernel = rr[:count, :count] + options["noise"] * torch.eye(
        count, dtype=rr.dtype, device=rr.device)
    observed = mr.new_tensor(risk_coordinate(truth_r[context],
                                             model.transform))
    residual = observed[:, None] - mr[:count]
    solved = torch.linalg.solve(kernel, residual)
    cross = rr[count:, :count]
    posterior_mean = mc[count:] + loading[count:, None] * (cross @ solved)
    posterior_variance = variance[count:] - loading[count:].square() * (
        cross * torch.linalg.solve(kernel, cross.T).T).sum(1)
    component = torch.special.ndtr(posterior_mean /
                                   (1 + posterior_variance).sqrt()[:, None])
    if model.scope == "global":
        weights = (-0.5 * (residual * solved).sum(0)).softmax(0)
        return component @ weights
    # The risk GP is block diagonal across families, so likelihoods factor exactly.
    family = np.asarray(x)[indices, 4].astype(int)
    evidence = -0.5 * residual * solved
    weights = torch.stack(
        [evidence[family[:count] == f].sum(0).softmax(0) for f in (0, 1)])
    return (component * weights[family[count:]]).sum(1)


def episode(model, task, rng):
    x, risks, collisions, truth_r, truth_c = task
    context_count = int(rng.choice(CONTEXT_COUNTS))
    available = np.arange(len(x))
    proposal = np.argsort(-collisions.mean(1))[:600] if rng.integers(
        2) else available
    context = rng.choice(proposal, context_count, replace=False)
    remaining = np.setdiff1d(available, context)
    positive, negative = remaining[
        truth_c[remaining]], remaining[~truth_c[remaining]]
    count = min(QUERY_COUNT // 2, len(positive))
    query = np.concatenate((rng.choice(positive, count, replace=False),
                            rng.choice(negative,
                                       QUERY_COUNT - count,
                                       replace=False)))
    q = posterior_probability(model, x, risks, collisions, context, query,
                              truth_r).clamp(1e-8, 1 - 1e-8)
    score = torch.logit(q)
    ranking = F.softplus(score[count:][None, :] - score[:count, None]).mean()
    prevalence = float(truth_c[remaining].mean())
    calibration = -prevalence * q[:count].log().mean() - (1 - prevalence) * (
        1 - q[count:]).log().mean()
    return ranking + 0.1 * calibration


def main():
    torch.set_num_threads(1)
    bank = np.load(BASELINE / "history/responses.npz")
    tasks = []
    for group, targets in GROUPS.items():
        _, risks, collisions = predictions(bank, group)
        for target in targets:
            tasks.append((bank["x"], risks, collisions, bank[target],
                          bank[target + "_collision"]))
    for transform in ("raw", "logit"):
        for scope in ("global", "family"):
            for matched in (False, True):
                torch.manual_seed(11)
                model = HypothesisParameters(transform, scope, matched).cuda()
                optimizer = torch.optim.Adam(model.parameters(), lr=0.01)
                rng = np.random.default_rng(20261005)
                curve = []
                for step in range(STEPS):
                    loss = episode(model, tasks[int(rng.integers(len(tasks)))],
                                   rng)
                    optimizer.zero_grad()
                    loss.backward()
                    torch.nn.utils.clip_grad_norm_(model.parameters(), 10)
                    optimizer.step()
                    curve.append(float(loss.detach()))
                    if (step + 1) % 100 == 0:
                        name = f"{transform}_{scope}_{matched}_{step + 1}"
                        write_json(
                            OUTPUT / "models" / "hypotheses" /
                            (name + ".json"), {
                                "options":
                                model.serializable(),
                                "curve":
                                curve,
                                "steps":
                                step + 1,
                                "target_data_used":
                                False,
                                "historical_predictors_exclude_target_group":
                                True,
                                "loss":
                                "pair ranking plus population-corrected probability loss"
                            })
                        print("MIXTURE_META",
                              name,
                              round(float(np.mean(curve[-100:])), 4),
                              flush=True)


if __name__ == "__main__":
    main()
