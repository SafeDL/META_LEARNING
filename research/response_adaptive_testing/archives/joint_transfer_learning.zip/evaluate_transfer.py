"""Evaluate joint mean and transfer learning on the older development pools used for fitting."""
import time

import numpy as np
import torch

from methods.history_guided_testing.config import ROOT as BASELINE
from methods.history_guided_testing.io import read_json, write_json
from research.history_response_testing.history_model import predict

from .cohort_development import select
from .config import BUDGET, OUTPUT, SEEDS
from .develop import metrics
from .learn_transfer import RESULTS
from .static_controls import committed_ranking


def main():
    torch.set_num_threads(1)
    state = read_json(RESULTS / "model.json")
    assert state["prospective_cohort_used"] is False
    options = state["options"]
    configurations = {
        "full": options,
        "local": {
            **options, "source_scale": 0
        },
        "static": options
    }
    pools = [("original", BASELINE / "target/responses.npz")]
    pools += [(path.parent.name, path)
              for path in sorted((OUTPUT /
                                  "development_pools").glob("*/responses.npz"))
              ]
    records = []
    for name, bank_path in pools:
        with np.load(bank_path) as bank:
            for seed in SEEDS:
                prediction = predict(bank["x"], seed)
                for configuration, session_options in configurations.items():
                    path = RESULTS / "development" / f"{name}_{configuration}_{seed}.json"
                    if path.exists():
                        result = read_json(path)
                    else:
                        started = time.perf_counter()
                        if configuration == "static":
                            selected, _ = committed_ranking(
                                bank["x"], prediction, session_options, state)
                            observations = [{
                                "index":
                                index,
                                "continuous_risk":
                                float(bank["risk"][index])
                            } for index in selected]
                        else:
                            selected, observations = select(
                                bank["x"], prediction, session_options, state,
                                lambda index: bank["risk"][index])
                        result = {
                            **metrics(bank["collision"], selected), "selected_indices":
                            selected,
                            "observations":
                            observations,
                            "options":
                            session_options,
                            "mean_logits":
                            state["mean_logits"],
                            "elapsed_s":
                            time.perf_counter() - started,
                            "role":
                            "Older development pools used in this model's training"
                        }
                        write_json(path, result)
                    selected = result["selected_indices"]
                    assert len(selected) == len(set(selected)) == BUDGET
                    assert result["observations"] == [{
                        "index":
                        index,
                        "continuous_risk":
                        float(bank["risk"][index])
                    } for index in selected]
                    measured = metrics(bank["collision"], selected)
                    for key, value in measured.items():
                        assert result[key] == value
                    records.append({
                        "pool": name,
                        "seed": seed,
                        "configuration": configuration,
                        **measured
                    })
                    print("JOINT LEARNING DEVELOPMENT",
                          name,
                          seed,
                          configuration,
                          round(measured["mean_cumulative_collisions"], 3),
                          measured["F200"],
                          flush=True)
                    write_json(
                        RESULTS / "development_summary.json", {
                            "role":
                            "Training-pool checks; no independent advantage claim",
                            "records":
                            records,
                            "complete":
                            len(records)
                            == len(pools) * len(SEEDS) * len(configurations)
                        })


if __name__ == "__main__":
    main()
