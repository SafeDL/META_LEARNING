"""Joint response hypotheses: risk evidence updates source credibility and failures."""
import math

import numpy as np
from scipy.special import ndtri
import torch

from .config import BUDGET, QUADRATURE, RISK_EPSILON, SHORTLIST
from .model import joint_prior, risk_coordinate


def hypothesis_prior(x, risks, collisions, options, device="cuda"):
    _, _, covariance, cross, _, _ = joint_prior(x, risks, collisions, {
        **options, "source_scale": 0
    }, device)
    loading = cross.diag() / covariance.diag()
    mean_r = torch.as_tensor(risk_coordinate(risks, options["transform"]),
                             dtype=torch.float64,
                             device=device).clone()
    mean_c = mean_r.new_tensor(
        ndtri(np.clip(collisions, RISK_EPSILON, 1 - RISK_EPSILON)))
    variance = loading.square() * covariance.diag(
    ) + options["collision_scale"]**2
    if options.get("predictive_mean") == "empirical_probability":
        mean_c = mean_c * (1 + variance).sqrt()[:, None]
    if options["residual_mode"] == "learned_sensitivity":
        family = np.asarray(x)[:, 4].astype(int)
        offsets = torch.as_tensor(options["collision_offset"],
                                  dtype=mean_r.dtype,
                                  device=device)
        mean_c = mean_c + offsets[family, None]
    return mean_r, mean_c, covariance, loading, variance


class ResponseHypotheses:

    def __init__(self,
                 x,
                 risks,
                 collisions,
                 options,
                 budget=BUDGET,
                 device="cuda"):
        self.options, self.budget = options, budget
        self.mean_r, self.prior_c, self.covariance, self.loading, _ = hypothesis_prior(
            x, risks, collisions, options, device)
        self.prior_r = self.mean_r.clone()
        self.family = self.mean_r.new_tensor(np.asarray(x)[:, 4],
                                             dtype=torch.long)
        weight_count = 2 if options.get("weight_scope") == "family" else 1
        self.log_weights = self.mean_r.new_full((weight_count, risks.shape[1]),
                                                -math.log(risks.shape[1]))
        self.remaining = torch.ones(len(x), dtype=torch.bool, device=device)
        self.count, self.pending = 0, None
        self.records = []
        nodes, masses = np.polynomial.hermite.hermgauss(QUADRATURE)
        self.nodes = self.mean_r.new_tensor(nodes * math.sqrt(2))
        self.masses = self.mean_r.new_tensor(masses / math.sqrt(math.pi))

    def component_probabilities(self):
        mean = self.prior_c + self.loading[:,
                                           None] * (self.mean_r - self.prior_r)
        variance = self.loading.square() * self.covariance.diag(
        ) + self.options["collision_scale"]**2
        return torch.special.ndtr(mean / (1 + variance).sqrt()[:, None])

    def probabilities(self):
        component = self.component_probabilities()
        weights = self.log_weights.softmax(-1)
        if len(weights) == 1:
            return component @ weights[0]
        return (component * weights[self.family]).sum(1)

    def risk_failure_covariance(self, indices):
        component = self.component_probabilities()
        q = self.probabilities()
        weights = self.log_weights.softmax(-1)
        point_weights = weights[0].expand_as(component) if len(
            weights) == 1 else weights[self.family]
        mean = self.prior_c + self.loading[:,
                                           None] * (self.mean_r - self.prior_r)
        variance = self.loading.square() * self.covariance.diag(
        ) + self.options["collision_scale"]**2
        slope = (torch.exp(-0.5 * mean.square() / (1 + variance)[:, None]) /
                 (math.sqrt(2 * math.pi) * (1 + variance).sqrt()[:, None]))
        within = (slope * point_weights).sum(1) * self.loading
        between = ((component[indices] - q[indices, None]) *
                   point_weights[indices]) @ self.mean_r.T
        if len(weights) == 2:
            between *= self.family[indices, None] == self.family[None, :]
        return within[indices, None] * self.covariance[indices] + between

    def ranking_information(self, q):
        count = min(self.budget - self.count, int(self.remaining.sum()) - 1)
        order = q.masked_fill(~self.remaining,
                              -torch.inf).topk(count + 1).indices
        cross = self.risk_failure_covariance(order)
        weights = self.log_weights.softmax(-1)
        point_weights = weights[0].expand_as(
            self.mean_r) if len(weights) == 1 else weights[self.family]
        mean_r = (self.mean_r * point_weights).sum(1)
        variance_r = self.covariance.diag() + self.options["noise"] + (
            (self.mean_r - mean_r[:, None]).square() * point_weights).sum(1)
        reward_weights = q.new_full((count, ), 0.5 / self.budget)
        reward_weights[-1] = 0.5 + 0.5 * (self.budget - self.count -
                                          count) / self.budget
        return ((cross[:-1] - cross[1:]).square() *
                reward_weights[:, None]).sum(0) / variance_r

    def risk_fantasies(self, index):
        denominator = self.covariance[index, index] + self.options["noise"]
        row = int(self.family[index]) if len(self.log_weights) == 2 else 0
        weights = self.log_weights.softmax(-1)
        values = (self.mean_r[index, :, None] +
                  denominator.sqrt() * self.nodes).flatten()
        masses = (weights[row, :, None] * self.masses).flatten()
        residual = values[:, None] - self.mean_r[index]
        posterior_weights = (self.log_weights[row] -
                             0.5 * residual.square() / denominator).softmax(1)
        cross = self.covariance[:, index]
        mean = self.prior_c + self.loading[:,
                                           None] * (self.mean_r - self.prior_r)
        future_mean = mean[None, :, :] + (self.loading * cross / denominator)[
            None, :, None] * residual[:, None, :]
        future_variance = self.loading.square() * (self.covariance.diag(
        ) - cross.square() / denominator) + self.options["collision_scale"]**2
        component = torch.special.ndtr(
            future_mean / (1 + future_variance).sqrt()[None, :, None])
        if len(weights) == 1:
            future_q = torch.einsum("fnm,fm->fn", component, posterior_weights)
        else:
            future_q = (component * weights[self.family][None, :, :]).sum(2)
            affected = self.family == row
            future_q[:, affected] = torch.einsum("fnm,fm->fn",
                                                 component[:, affected],
                                                 posterior_weights)
        return values, future_q, masses

    def future_values(self, proposals, q):
        remaining_budget = self.budget - self.count
        horizon = min(remaining_budget - 1,
                      self.options.get("horizon", remaining_budget - 1))
        order = torch.arange(1, horizon + 1, dtype=q.dtype, device=q.device)
        future_weights = 0.5 + 0.5 * (remaining_budget - order) / self.budget
        immediate_weight = 0.5 + 0.5 * remaining_budget / self.budget
        values, bonuses = [], []
        for index in proposals:
            _, future_q, masses = self.risk_fantasies(index)
            future_q[:, ~self.remaining] = -torch.inf
            future_q[:, index] = -torch.inf
            future = (future_q.topk(horizon, dim=1).values *
                      future_weights).sum(1) @ masses
            committed = q.masked_fill(~self.remaining, -torch.inf).clone()
            committed[index] = -torch.inf
            committed = (committed.topk(horizon).values * future_weights).sum()
            values.append(immediate_weight * q[index] + future)
            bonuses.append(future - committed)
        return torch.stack(values), torch.stack(bonuses)

    def next_index(self):
        if self.pending is not None:
            raise RuntimeError("Observe the pending query first")
        if self.count == self.budget:
            return None
        q = self.probabilities()
        scores = q.masked_fill(~self.remaining, -torch.inf)
        index, bonus = int(scores.argmax()), 0.0
        if self.options.get("lookahead",
                            False) and self.count < self.budget - 1:
            size = min(SHORTLIST // 2, int(self.remaining.sum()))
            information = self.ranking_information(q).masked_fill(
                ~self.remaining, -torch.inf)
            proposals = torch.unique(
                torch.cat((scores.topk(size).indices,
                           information.topk(size).indices)))
            values, bonuses = self.future_values(proposals, q)
            best = int(values.argmax())
            index, bonus = int(proposals[best]), float(bonuses[best])
        self.pending = index
        self.records.append({
            "index":
            self.pending,
            "query_number":
            self.count + 1,
            "collision_score":
            float(q[self.pending]),
            "decision_value":
            bonus,
            "source_weights_before":
            self.log_weights.softmax(-1).tolist()
        })
        return self.pending

    def observe(self, risk):
        if self.pending is None:
            raise RuntimeError("Request a query before feedback")
        if not np.isfinite(risk) or not 0 <= risk <= 1:
            raise ValueError("Invalid continuous risk")
        index = self.pending
        value = float(risk_coordinate(risk, self.options["transform"]))
        denominator = self.covariance[index, index] + self.options["noise"]
        residual = value - self.mean_r[index].clone()
        row = int(self.family[index]) if len(self.log_weights) == 2 else 0
        self.log_weights[row] += -0.5 * residual.square() / denominator
        self.log_weights[row] -= torch.logsumexp(self.log_weights[row], 0)
        cross = self.covariance[:, index].clone()
        self.mean_r += cross[:, None] / denominator * residual
        self.covariance -= cross[:, None] * cross[None, :] / denominator
        self.records[-1].update({
            "continuous_risk":
            float(risk),
            "source_weights_after":
            self.log_weights.softmax(-1).tolist()
        })
        self.remaining[index] = False
        self.count += 1
        self.pending = None
