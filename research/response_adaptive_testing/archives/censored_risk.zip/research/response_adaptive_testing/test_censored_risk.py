"""Validate interval-observation moments and the unchanged interior update."""
import math

import numpy as np
import pytest
from scipy.integrate import quad
from scipy.special import log_ndtr
import torch

from .censored_risk import CensoredRiskSession, truncation_moments
from .session import AdaptiveTestingSession
from .test_method import example


@pytest.mark.parametrize("alpha", [-2.0, 0.0, 2.0, 8.0])
def test_interval_moments_match_numerical_integration(alpha):
    log_probability = log_ndtr(-alpha)

    def density(value):
        return math.exp(-0.5 * value * value - 0.5 * math.log(2 * math.pi) -
                        log_probability)

    mean = quad(lambda value: value * density(value),
                alpha,
                np.inf,
                epsabs=1e-12,
                epsrel=1e-12)[0]
    second = quad(lambda value: value * value * density(value),
                  alpha,
                  np.inf,
                  epsabs=1e-12,
                  epsrel=1e-12)[0]
    mills, contraction = truncation_moments(
        torch.tensor(alpha, dtype=torch.float64))
    assert abs(float(mills) - mean) < 1e-10
    assert abs(float(contraction) - (1 - second + mean * mean)) < 1e-9


def test_censored_session_preserves_interior_gaussian_update():
    x, risks, collisions, options = example()
    options.update(transform="logit", collision_transform="probit")
    exact = AdaptiveTestingSession(x, risks, collisions, options, device="cpu")
    censored = CensoredRiskSession(x, risks, collisions, options, device="cpu")
    for session in (exact, censored):
        session.pending = 0
        session.records.append({})
        session.observe(0.6)
    for name in ("mean_r", "mean_c", "rr", "cr", "cc", "coefficients",
                 "coefficient_r"):
        torch.testing.assert_close(getattr(exact, name),
                                   getattr(censored, name),
                                   atol=0,
                                   rtol=0)


@pytest.mark.parametrize("risk", [0.0, 1.0])
def test_interval_update_contracts_less_than_an_exact_boundary_point(risk):
    x, risks, collisions, options = example()
    options.update(transform="logit",
                   collision_transform="probit",
                   ranking_information=True)
    session = CensoredRiskSession(x, risks, collisions, options, device="cpu")
    prior = session.cc.clone()
    denominator = session.rr[0, 0] + options["noise"]
    point_variance = prior - session.cr[:, 0].square() / denominator
    session.pending = 0
    session.records.append({})
    session.observe(risk)
    assert 0 < session.records[-1]["covariance_contraction"] < 1
    assert torch.all(session.cc <= prior + 1e-12)
    assert torch.all(session.cc >= point_variance - 1e-12)
    joint = torch.cat(
        (torch.cat((session.rr, session.cr.T),
                   1), torch.cat((session.cr, session.cc_matrix), 1)), 0)
    assert torch.linalg.eigvalsh(joint).min() > -1e-10
