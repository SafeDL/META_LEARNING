"""Development test of interval risk feedback at the logit clipping boundaries."""
import math
import time

import numpy as np
import torch

from methods.history_guided_testing.config import ROOT as BASELINE
from methods.history_guided_testing.io import read_json, write_json
from research.history_response_testing.history_model import SOURCE_NAMES, predict

from .config import BUDGET, OUTPUT, RISK_EPSILON, SEEDS
from .develop import metrics
from .initial_prior import coordinates, reference_means
from .session import AdaptiveTestingSession

RESULTS = OUTPUT / "censored_risk"
UPPER_BOUND = math.log((1 - RISK_EPSILON) / RISK_EPSILON)


def truncation_moments(alpha):
    log_density = -0.5 * alpha.square() - 0.5 * math.log(2 * math.pi)
    mills = (log_density - torch.special.log_ndtr(-alpha)).exp()
    contraction = (mills * (mills - alpha)).clamp(0, 1)
    return mills, contraction


class CensoredRiskSession(AdaptiveTestingSession):

    def observe(self, risk):
        if self.pending is None:
            raise RuntimeError("Request a query before feedback")
        if not np.isfinite(risk) or not 0 <= risk <= 1:
            raise ValueError("Invalid continuous risk")
        if RISK_EPSILON < risk < 1 - RISK_EPSILON:
            super().observe(risk)
            self.records[-1]["risk_observation_type"] = "interior point"
            return
        assert self.options["transform"] == "logit"
        assert not self.options["lookahead"]
        index = self.pending
        direction = 1 if risk >= 1 - RISK_EPSILON else -1
        denominator = self.rr[index, index] + self.options["noise"]
        deviation = denominator.sqrt()
        alpha = (UPPER_BOUND - direction * self.mean_r[index]) / deviation
        mills, contraction = truncation_moments(alpha)
        shift = direction * mills / deviation
        reduction = contraction / denominator
        cross_r = self.rr[:, index].clone()
        cross_c = self.cr[:, index].clone()
        cross_coefficient = self.coefficient_r[:, index].clone()
        self.mean_r += cross_r * shift
        self.mean_c += cross_c * shift
        self.coefficients += cross_coefficient * shift
        self.rr -= cross_r[:, None] * cross_r[None, :] * reduction
        self.cr -= cross_c[:, None] * cross_r[None, :] * reduction
        self.cc -= cross_c.square() * reduction
        if self.cc_matrix is not None:
            self.cc_matrix -= cross_c[:, None] * cross_c[None, :] * reduction
        self.coefficient_r -= cross_coefficient[:, None] * cross_r[
            None, :] * reduction
        self.records[-1].update({
            "continuous_risk":
            float(risk),
            "response_coefficients":
            self.coefficients.tolist(),
            "risk_observation_type":
            "right censored" if direction == 1 else "left censored",
            "covariance_contraction":
            float(contraction),
            "posterior_approximation":
            "Gaussian assumed-density moments"
        })
        self.remaining[index] = False
        self.count += 1
        self.pending = None


def main():
    torch.set_num_threads(1)
    options = read_json(OUTPUT /
                        "confirmation/protocol.json")["candidate_options"]
    learned = read_json(OUTPUT /
                        "initial_prior/models/collision_mean_600.json")
    assert learned["base_options"] == options
    pools = [("original", BASELINE / "target/responses.npz")]
    pools += [(path.parent.name, path)
              for path in sorted((OUTPUT /
                                  "development_pools").glob("*/responses.npz"))
              ]
    records = []
    for name, path in pools:
        with np.load(path) as bank:
            for seed in SEEDS:
                prediction = predict(bank["x"], seed)
                for mean in ("empirical_mean", "learned_collision_mean"):
                    output = RESULTS / "development" / f"{name}_{mean}_{seed}.json"
                    if output.exists():
                        result = read_json(output)
                    else:
                        started = time.perf_counter()
                        session = CensoredRiskSession(bank["x"], *prediction,
                                                      options)
                        if mean == "learned_collision_mean":
                            family, risk, collision = coordinates(
                                bank["x"], *prediction)
                            session.mean_r, session.mean_c = reference_means(
                                family, risk, collision,
                                list(range(len(SOURCE_NAMES))),
                                risk.new_tensor(learned["mean_logits"]),
                                risk.new_tensor(options["collision_offset"]))
                        selected = []
                        while (index := session.next_index()) is not None:
                            session.observe(float(bank["risk"][index]))
                            selected.append(index)
                        assert len(selected) == len(set(selected)) == BUDGET
                        result = {
                            **metrics(bank["collision"], selected), "selected_indices":
                            selected,
                            "queries":
                            session.records,
                            "options":
                            options,
                            "mean_model":
                            learned
                            if mean == "learned_collision_mean" else None,
                            "censored_observations":
                            sum(row["risk_observation_type"] !=
                                "interior point" for row in session.records),
                            "elapsed_s":
                            time.perf_counter() - started,
                            "stage":
                            "development likelihood control; kernel parameters not retrained; primary confirmation unchanged"
                        }
                        write_json(output, result)
                    records.append({
                        "pool": name,
                        "seed": seed,
                        "mean": mean,
                        **{
                            key: result[key]
                            for key in ("mean_cumulative_collisions", "F200", "recall", "pool_collisions", "censored_observations")
                        }
                    })
                    print("CENSORED RISK DEVELOPMENT",
                          name,
                          seed,
                          mean,
                          round(result["mean_cumulative_collisions"], 3),
                          result["F200"],
                          flush=True)
                write_json(RESULTS / "summary.json", records)


if __name__ == "__main__":
    main()
