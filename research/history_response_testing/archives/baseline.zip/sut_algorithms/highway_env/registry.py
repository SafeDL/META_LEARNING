"""Registry for retained Highway-env systems under test."""

from __future__ import annotations

import hashlib
from functools import lru_cache
from pathlib import Path

from .base import Policy
from .idm_mobil import IDMMobilPolicy
from .mcts_cv import MCTSCVPolicy
from .ppo_ece import PPO_CHECKPOINT, PPOPolicy
from .value_iteration import ValueIterationPolicy

RETAINED_SUTS = ("idm_mobil", "vi_ttc", "mcts_cv", "ppo_ece")


@lru_cache(maxsize=8)
def _checkpoint_fingerprint(path: Path, modified_ns: int, size: int) -> str:
    """The modification time and size invalidate cached checkpoint identities."""
    return hashlib.sha256(path.read_bytes()).hexdigest()


def policy_factory(sut: str, assets_root: Path) -> Policy:
    if sut == "idm_mobil":
        return IDMMobilPolicy()
    if sut == "vi_ttc":
        return ValueIterationPolicy()
    if sut == "mcts_cv":
        return MCTSCVPolicy()
    if sut == "ppo_ece":
        checkpoint = assets_root / "ppo_ece" / "vd_1_5_trial_1.zip"
        return PPOPolicy(checkpoint)
    raise KeyError(f"Unsupported SUT: {sut}")


def build_spec_factory(build_id: str):
    """Resolve a controller build for the shared physical runner."""
    from highway_sim_env.build_spec import BuildSpec
    if build_id == "idm_ref":
        from sut_algorithms.highway_env.reference_profiles import IDM_REFERENCE_PROFILE
        reference = IDM_REFERENCE_PROFILE
        profile = reference.__dict__.copy()
        return BuildSpec(build_id, "profiled_idm", None, "legacy_profile",
                         "Profiled-IDM", 20.0, profile=profile)
    if build_id in {"mobil_ref_v2", "mobil_rear_guard_off_v2",
                    "mobil_rear_state_age"}:
        if build_id == "mobil_ref_v2":
            mutation = None
        elif build_id == "mobil_rear_guard_off_v2":
            mutation = {
                "rear_guard": "off",
                "guard_condition": "new_following_pred_a < -LANE_CHANGE_MAX_BRAKING_IMPOSED",
            }
        else:
            mutation = {
                "rear_state_age_s": 0.30,
                "scope": "candidate_lane_rear_predicted_braking_only",
            }
        return BuildSpec(build_id, "native_idm_mobil", None if not mutation else "mobil_ref_v2",
                         "native_vehicle", "highway-env IDM+MOBIL", 20.0,
                         mutation=mutation)
    if build_id in {"ppo_ref_v2", "ppo_obs_age020_v2"}:
        checkpoint = PPO_CHECKPOINT
        metadata = checkpoint.stat()
        digest = _checkpoint_fingerprint(checkpoint, metadata.st_mtime_ns, metadata.st_size)
        mutation = None if build_id == "ppo_ref_v2" else {"observation_delay_s": 0.20}
        return BuildSpec(build_id, "ppo_ece", None if not mutation else "ppo_ref_v2",
                         "external_meta_policy", "PPO-ECE", 5.0,
                         profile={"checkpoint_path": str(checkpoint)},
                         checkpoint_sha256=digest, mutation=mutation)
    if build_id == "vi_ttc_ref_audit_v4":
        return BuildSpec(build_id, "vi_ttc", None, "external_meta_policy",
                         "VI-TTC", 5.0)
    if build_id == "mcts_cv_ref_audit_v4":
        return BuildSpec(build_id, "mcts_cv", None, "external_meta_policy",
                         "MCTS-CV", 5.0)
    raise KeyError(f"Unsupported controller build: {build_id}")
