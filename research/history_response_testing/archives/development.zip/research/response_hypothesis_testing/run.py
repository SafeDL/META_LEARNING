"""Reproduce the final method while preserving the frozen default experiment."""
import json

import torch

from . import analyze, emulator, experiment, final_development, group_validation
from . import prediction_diagnostics, verify, write_report
from .config import OUTPUT, SEEDS
from .freeze import freeze


def main():
    freeze()
    torch.set_num_threads(1)
    for seed in SEEDS:
        emulator.train(seed)
    experiment.main()
    analyze.main()
    summary=json.loads((OUTPUT / "fresh_confirmation/summary.json").read_text(encoding="utf-8"))
    if not summary["success"]:
        raise RuntimeError("The locked confirmation criteria were not met")
    final_development.main()
    prediction_diagnostics.main()
    if not (OUTPUT / "group_validation.json").exists():
        group_validation.main()
    verify.main()
    write_report.main()
    freeze()
    print("Final method and evidence reproduced", flush=True)


if __name__ == "__main__":
    main()
