"""Source-conditioned continuous-feedback active search."""
