"""Exclude whole mechanism groups from network gradients, priors and calibration."""
import numpy as np
from scipy.special import expit
from sklearn.linear_model import LogisticRegression
import torch
from torch import nn
from torch.nn import functional as F

from methods.history_guided_testing.config import GROUPS, ROOT as BASELINE, group_of
from methods.history_guided_testing.history import split_indices
from .config import OUTPUT
from .dual import ResponseTestingSession
from .response_kernel import covariance
from .io import write_json


def main():
    torch.set_num_threads(1)
    bank = np.load(BASELINE / "history/responses.npz")
    train, validation = split_indices(bank["x"])
    records = []
    curves = {}
    for excluded in GROUPS:
        names = [n for g, members in GROUPS.items() if g != excluded for n in members]
        assert all(group_of(n) != excluded for n in names)
        weights = np.asarray([1 / 3 / len(GROUPS[group_of(n)]) for n in names])
        predicted_risk = np.zeros((len(validation), len(names)))
        predicted_collision = np.zeros_like(predicted_risk)
        calibration = {}
        torch.manual_seed(20261005)
        for family in (0, 1):
            ti = train[bank["x"][train, 4] == family]
            vi = validation[bank["x"][validation, 4] == family]
            positions = np.flatnonzero(bank["x"][validation, 4] == family)
            x = torch.as_tensor(bank["x"][:, :4], device="cuda", dtype=torch.float32)
            risks = torch.as_tensor(np.asarray([bank[n] for n in names]).T, device="cuda", dtype=torch.float32)
            collisions = torch.as_tensor(np.asarray([bank[n + "_collision"] for n in names]).T, device="cuda", dtype=torch.float32)
            model = nn.Sequential(nn.Linear(4, 64), nn.SiLU(), nn.Linear(64, 128), nn.SiLU(),
                                  nn.Linear(128, 64), nn.SiLU(), nn.Linear(64, 2 * len(names))).cuda()
            optimizer = torch.optim.AdamW(model.parameters(), lr=.001, weight_decay=.0001)
            rng = np.random.default_rng(20261005)
            best = float("inf")
            curve = []
            for epoch in range(1, 401):
                order = rng.permutation(ti)
                for start in range(0, len(order), 128):
                    indices = order[start:start + 128]
                    output = model(x[indices])
                    loss = ((output[:, :len(names)].sigmoid() - risks[indices]).square() *
                            (1 + 4 * risks[indices])).mean() + .1 * F.binary_cross_entropy_with_logits(
                                output[:, len(names):], collisions[indices])
                    optimizer.zero_grad(set_to_none=True)
                    loss.backward()
                    optimizer.step()
                if epoch % 10 == 0:
                    with torch.no_grad():
                        output = model(x[vi])
                        error = float(((output[:, :len(names)].sigmoid() - risks[vi]).square() *
                                      (1 + 4 * risks[vi])).mean() + .1 * F.binary_cross_entropy_with_logits(
                                          output[:, len(names):], collisions[vi]))
                    curve.append({"epoch": epoch, "validation_loss": error})
                    if error < best:
                        best = error
                        state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
            model.load_state_dict(state)
            with torch.no_grad():
                output = model(x[vi]).sigmoid().cpu().numpy()
            predicted_risk[positions] = output[:, :len(names)]
            predicted_collision[positions] = output[:, len(names):]
            flat_risk = np.concatenate([bank[n][ti] for n in names])[:, None]
            flat_collision = np.concatenate([bank[n + "_collision"][ti] for n in names])
            fitted = LogisticRegression(C=100).fit(flat_risk, flat_collision)
            calibration[family] = {"slope": float(fitted.coef_[0, 0]), "intercept": float(fitted.intercept_[0])}
            curves[f"{excluded}:{family}"] = curve
        x = bank["x"][validation]
        kernel = covariance(x, predicted_risk, .05, physical_weight=.1)
        for target in GROUPS[excluded]:
            session = ResponseTestingSession(x, kernel, predicted_risk, predicted_collision, weights, calibration)
            selected = []
            while (index := session.next_index()) is not None:
                session.observe(float(bank[target][validation[index]]))
                selected.append(index)
            collision = bank[target + "_collision"][validation]
            curve = np.cumsum(collision[selected])
            ranking = np.argsort(-(predicted_collision @ weights), kind="stable")[:200]
            ranking_curve = np.cumsum(collision[ranking])
            records.append({"excluded_group": excluded, "target": target, "available_sources": names,
                "target_excluded_from_gradients": True, "target_excluded_from_checkpoint_selection": True,
                "target_excluded_from_calibration": True, "pool_collision_count": int(collision.sum()),
                "candidate_F50": int(curve[49]), "candidate_F100": int(curve[99]), "candidate_F200": int(curve[-1]),
                "candidate_auc": float(curve.mean()), "ranking_auc": float(ranking_curve.mean()),
                "ranking_F200": int(ranking_curve[-1]), "selected_indices": selected})
            print("Excluded-group", excluded, target, records[-1]["candidate_F200"], "/", int(collision.sum()), flush=True)
    write_json(OUTPUT / "group_validation.json", {"records": records, "training_curves": curves,
        "independent_group_count": 4, "validation_coordinates": 410, "budget": 200,
        "scope": "diagnostic with fixed developed hyperparameters, not a new blind confirmation or six independent tasks"})


if __name__ == "__main__":
    main()
