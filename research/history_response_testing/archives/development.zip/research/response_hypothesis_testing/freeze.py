"""Snapshot the authorized baseline and verify it without changing its files."""
import hashlib
import json
import subprocess
import zipfile
from pathlib import Path

from .config import ROOT

REPO = ROOT.parents[1]
FOLDERS = ("methods/history_guided_testing", "methods/ras_frt_uq",
           "results/history_guided_testing", "tests/history_guided_testing",
           "highway_sim_env", "sut_algorithms/highway_env")


def baseline_files():
    files = [REPO / name for name in ("README.md", "environment.yml", "docs/style.md",
             "docs/Attachment_Paper_Review_and_Research_Directions.md")]
    files += [path for name in FOLDERS for path in (REPO / name).rglob("*")
              if path.is_file() and "__pycache__" not in path.parts]
    return sorted(files)


def freeze():
    folder = ROOT / "frozen_baseline"
    folder.mkdir(exist_ok=True)
    manifest = folder / "manifest.json"
    if manifest.exists():
        expected = json.loads(manifest.read_text(encoding="utf-8"))
        changed = [name for name, digest in expected["sha256"].items()
                   if hashlib.sha256((REPO / name).read_bytes()).hexdigest() != digest]
        if changed:
            raise RuntimeError(f"Frozen baseline changed: {changed}")
        return expected
    files = baseline_files()
    hashes = {path.relative_to(REPO).as_posix(): hashlib.sha256(path.read_bytes()).hexdigest()
              for path in files}
    with zipfile.ZipFile(folder / "baseline.zip", "w", zipfile.ZIP_DEFLATED) as archive:
        for path in files:
            archive.write(path, path.relative_to(REPO).as_posix())
    with zipfile.ZipFile(folder / "baseline.zip") as archive:
        assert all(hashlib.sha256(archive.read(name)).hexdigest() == digest
                   for name, digest in hashes.items())
    value = {"commit": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=REPO,
             text=True).strip(), "sha256": hashes, "archive_verified": True,
             "baseline_paths_unchanged": True, "original_target_is_development": True}
    manifest.write_text(json.dumps(value, indent=2), encoding="utf-8")
    return value


if __name__ == "__main__":
    print("Frozen files:", len(freeze()["sha256"]), flush=True)
