"""Record every development trial; select no settings on confirmation data."""
import numpy as np
import torch
from sklearn.metrics import roc_curve

from methods.history_guided_testing.config import ROOT as BASELINE
from methods.history_guided_testing.evaluate import discovery_metrics
from methods.history_guided_testing.history import load_history, split_indices, subset
from methods.history_guided_testing.train import load_kernel
from .config import OUTPUT, SEEDS
from .core import HypothesisSession, source_predictions
from .run import write_json


def historical_collision_threshold(history, indices):
    bank = np.load(BASELINE / "history/responses.npz")
    risk = np.concatenate([bank[name][indices] for name in history])
    collision = np.concatenate([bank[name + "_collision"][indices] for name in history])
    false_positive, true_positive, thresholds = roc_curve(collision, risk)
    return float(thresholds[np.argmax(true_positive - false_positive)])


def main():
    torch.set_num_threads(1)
    history = load_history()
    train, _ = split_indices(next(iter(history.values()))["x"])
    bank = np.load(BASELINE / "target/responses.npz")
    names, means, weights = source_predictions(subset(history, train), bank["x"])
    threshold = historical_collision_threshold(history, train)
    print("Historical-only collision utility threshold", threshold, flush=True)
    for seed in SEEDS:
        with torch.no_grad():
            covariance = load_kernel(seed, "global_feedback").cuda().covariance(bank["x"])
        for mixture in (False, True):
            for utility in ("risk", "excess", "collision"):
                for lookahead in (False, True):
                    name = ("sources" if mixture else "average") + "_" + utility + ("_ens" if lookahead else "_greedy")
                    path = OUTPUT / "trials" / f"{name}_{seed}.json"
                    if path.exists():
                        continue
                    session = HypothesisSession(covariance, means, weights, mixture=mixture, lookahead=lookahead,
                        utility="event" if utility == "collision" else utility,
                        threshold=threshold if utility == "collision" else .5)
                    import time
                    started = time.perf_counter()
                    selected = []
                    while (index := session.next_index()) is not None:
                        session.observe(float(bank["risk"][index]))
                        selected.append(index)
                    result = discovery_metrics(bank, selected)
                    write_json(path, {**result, "selected_indices": selected, "queries": session.records,
                                      "seed": seed, "elapsed_s": time.perf_counter() - started,
                                      "threshold": session.threshold, "utility": utility})
                    print(name, seed, [result["checkpoints"][str(k)]["collisions"] for k in (50, 100, 200)],
                          round(result["discovery_auc"], 3), flush=True)


if __name__ == "__main__":
    main()
