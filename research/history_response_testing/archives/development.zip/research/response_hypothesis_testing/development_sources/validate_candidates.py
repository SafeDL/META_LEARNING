"""Five-seed development replication of promising, fully specified candidates."""
import numpy as np
import torch
from sklearn.linear_model import LogisticRegression

from methods.history_guided_testing.config import ROOT as BASELINE
from methods.history_guided_testing.evaluate import discovery_metrics
from methods.history_guided_testing.history import load_history, split_indices, subset
from .config import OUTPUT, SEEDS
from .core import HypothesisSession, source_predictions
from .emulator import predict
from .response_kernel import covariance
from .run import write_json

CANDIDATES={
    "risk_average":{"feedback":"risk","mixture":False,"length":.05,"noise":.05,"horizon":None},
    "risk_sources":{"feedback":"risk","mixture":True,"length":.05,"noise":.05,"horizon":None},
    "risk_sources_short":{"feedback":"risk","mixture":True,"length":.025,"noise":.01,"horizon":1},
    "calibrated_average":{"feedback":"calibrated","mixture":False,"length":.05,"noise":.05,"horizon":None},
}


def calibrators():
    bank=np.load(BASELINE/"history/responses.npz")
    history=load_history()
    train,_=split_indices(bank["x"])
    result={}
    for family in (0,1):
        indices=train[bank["x"][train,4]==family]
        risk=np.concatenate([bank[n][indices] for n in history])[:,None]
        collision=np.concatenate([bank[n+"_collision"][indices] for n in history])
        model=LogisticRegression(C=100).fit(risk,collision)
        result[family]={"slope":float(model.coef_[0,0]),"intercept":float(model.intercept_[0])}
    return result


def main():
    torch.set_num_threads(1)
    history=load_history()
    train,_=split_indices(next(iter(history.values()))["x"])
    bank=np.load(BASELINE/"target/responses.npz")
    _,_,weights=source_predictions(subset(history,train),bank["x"])
    calibration=calibrators()
    for seed in SEEDS:
        risk_means,collision_means=predict(bank["x"],seed)
        for name,config in CANDIDATES.items():
            path=OUTPUT/"candidates"/f"{name}_{seed}.json"
            if path.exists():
                continue
            means=risk_means if config["feedback"]=="risk" else collision_means
            kernel=covariance(bank["x"],risk_means,config["length"],physical_weight=.1)
            session=HypothesisSession(kernel,means,weights,mixture=config["mixture"],utility="risk",noise=config["noise"],
                lookahead=config["horizon"] is not None,horizon=config["horizon"])
            selected=[]
            while (index:=session.next_index()) is not None:
                observed=float(bank["risk"][index])
                if config["feedback"]=="risk":
                    value=observed
                else:
                    calibration_family=calibration[int(bank["x"][index,4])]
                    value=1/(1+np.exp(-(calibration_family["slope"]*observed+calibration_family["intercept"])))
                session.observe(value)
                session.records[-1]["continuous_risk"]=observed
                selected.append(index)
            result=discovery_metrics(bank,selected)
            write_json(path,{**result,"selected_indices":selected,"queries":session.records,"seed":seed,"config":config})
            print(name,seed,[result["checkpoints"][str(k)]["collisions"] for k in (50,100,200)],round(result["discovery_auc"],3),flush=True)


if __name__=="__main__":
    main()
