"""Short decision horizons limit extrapolation under uncertain task models."""
import numpy as np
import torch

from methods.history_guided_testing.config import ROOT as BASELINE
from methods.history_guided_testing.evaluate import discovery_metrics
from methods.history_guided_testing.history import load_history, split_indices, subset
from .config import OUTPUT
from .core import HypothesisSession, source_predictions
from .emulator import predict
from .response_kernel import covariance
from .run import write_json


def main():
    torch.set_num_threads(1)
    history=load_history()
    train,_=split_indices(next(iter(history.values()))["x"])
    bank=np.load(BASELINE/"target/responses.npz")
    _,_,weights=source_predictions(subset(history,train),bank["x"])
    means,_=predict(bank["x"],11)
    for length in (.025,.05,.1):
        kernel=covariance(bank["x"],means,length,physical_weight=.1)
        for noise in (.01,.05):
            for mixture in (False,True):
                for horizon in (1,3,5,10,25):
                    name=f"horizon_{length}_{noise}_{horizon}_"+("sources" if mixture else "average")
                    path=OUTPUT/"horizon_trials"/(name+".json")
                    if path.exists():
                        continue
                    session=HypothesisSession(kernel,means,weights,mixture=mixture,utility="risk",
                                              noise=noise,lookahead=True,horizon=horizon)
                    selected=[]
                    while (index:=session.next_index()) is not None:
                        session.observe(float(bank["risk"][index]))
                        selected.append(index)
                    result=discovery_metrics(bank,selected)
                    write_json(path,{**result,"selected_indices":selected,"queries":session.records,
                        "response_length":length,"noise":noise,"mixture":mixture,"horizon":horizon})
                    print(name,[result["checkpoints"][str(k)]["collisions"] for k in (50,100,200)],
                          round(result["discovery_auc"],3),flush=True)


if __name__=="__main__":
    main()
