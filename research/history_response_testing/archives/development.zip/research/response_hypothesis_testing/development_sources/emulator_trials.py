"""Develop explicit source emulators and historical-calibrated feedback."""
import time

import numpy as np
import torch
from sklearn.linear_model import LogisticRegression

from methods.history_guided_testing.config import ROOT as BASELINE
from methods.history_guided_testing.evaluate import discovery_metrics
from methods.history_guided_testing.history import load_history, split_indices, subset
from methods.history_guided_testing.train import load_kernel
from .config import OUTPUT
from .core import HypothesisSession, source_predictions
from .emulator import predict
from .response_kernel import covariance
from .run import write_json


def main():
    torch.set_num_threads(1)
    history=load_history()
    train,_=split_indices(next(iter(history.values()))["x"])
    bank=np.load(BASELINE/"target/responses.npz")
    histbank=np.load(BASELINE/"history/responses.npz")
    calibrators={}
    for family in (0,1):
        indices=train[histbank["x"][train,4]==family]
        risk=np.concatenate([histbank[n][indices] for n in history])[:,None]
        collision=np.concatenate([histbank[n+"_collision"][indices] for n in history])
        calibrators[family]=LogisticRegression(C=100).fit(risk,collision)
    _,_,weights=source_predictions(subset(history,train),bank["x"])
    risk_means,collision_means=predict(bank["x"],11)
    with torch.no_grad():
        physical=load_kernel(11,"global_feedback").cuda().covariance(bank["x"])
    for feedback in ("risk","calibrated"):
        means=risk_means if feedback=="risk" else collision_means
        for kernel_name in ("physical","response"):
            kernel=physical if kernel_name=="physical" else covariance(bank["x"],risk_means,.05,physical_weight=.1)
            for noise in (.0025,.01,.05):
                for mixture in (False,True):
                    for lookahead in (False,True):
                        name=f"emulator_{feedback}_{kernel_name}_{noise}_"+("sources" if mixture else "average")+("_ens" if lookahead else "_greedy")
                        path=OUTPUT/"emulator_trials"/(name+".json")
                        if path.exists():
                            continue
                        session=HypothesisSession(kernel,means,weights,mixture=mixture,utility="risk",noise=noise,lookahead=lookahead)
                        selected=[]
                        started=time.perf_counter()
                        while (index:=session.next_index()) is not None:
                            observed=float(bank["risk"][index])
                            value=observed if feedback=="risk" else float(calibrators[int(bank["x"][index,4])].predict_proba([[observed]])[0,1])
                            session.observe(value)
                            session.records[-1]["continuous_risk"]=observed
                            selected.append(index)
                        result=discovery_metrics(bank,selected)
                        write_json(path,{**result,"selected_indices":selected,"queries":session.records,
                            "feedback":feedback,"kernel":kernel_name,"noise":noise,"mixture":mixture,
                            "lookahead":lookahead,"elapsed_s":time.perf_counter()-started})
                        print(name,[result["checkpoints"][str(k)]["collisions"] for k in (50,100,200)],
                              round(result["discovery_auc"],3),flush=True)


if __name__=="__main__":
    main()
