"""Historical risk-to-collision calibration, with continuous target feedback."""
import time

import numpy as np
import torch
from sklearn.linear_model import LogisticRegression

from methods.history_guided_testing.config import ROOT as BASELINE
from methods.history_guided_testing.evaluate import discovery_metrics
from methods.history_guided_testing.history import load_history, split_indices, subset
from methods.history_guided_testing.train import load_kernel
from .config import OUTPUT
from .core import HypothesisSession, source_predictions
from .response_kernel import covariance
from .run import write_json


def main():
    torch.set_num_threads(1)
    history = load_history()
    train, _ = split_indices(next(iter(history.values()))["x"])
    bank = np.load(BASELINE / "target/responses.npz")
    histbank = np.load(BASELINE / "history/responses.npz")
    calibrated = {}
    for family in (0, 1):
        indices = train[histbank["x"][train,4] == family]
        risk = np.concatenate([histbank[name][indices] for name in history])[:,None]
        collision = np.concatenate([histbank[name+"_collision"][indices] for name in history])
        model = LogisticRegression(C=100, solver="lbfgs").fit(risk, collision)
        calibrated[family] = model
        print("historical calibration", family, model.coef_.tolist(), model.intercept_.tolist(), flush=True)
    sources = {name:{"x": row["x"], "risk": histbank[name+"_collision"].astype(float)} for name,row in history.items()}
    _, means, weights = source_predictions(subset(sources,train), bank["x"])
    _, rawmeans, _ = source_predictions(subset(history,train), bank["x"])
    with torch.no_grad():
        physical = load_kernel(11,"global_feedback").cuda().covariance(bank["x"])
    for kernel_name in ("physical", "response", "collision_response"):
        kernel = physical if kernel_name == "physical" else covariance(bank["x"],
            means if kernel_name == "collision_response" else rawmeans, .05, physical_weight=.1)
        for noise in (.0001,.0025,.01,.05):
            for mixture in (False,True):
                for lookahead in (False,True):
                    name=f"calibrated_{kernel_name}_{noise}_"+("sources" if mixture else "average")+("_ens" if lookahead else "_greedy")
                    path=OUTPUT/"calibrated_trials"/(name+".json")
                    if path.exists():
                        continue
                    session=HypothesisSession(kernel,means,weights,mixture=mixture,utility="risk",noise=noise,lookahead=lookahead)
                    started=time.perf_counter()
                    selected=[]
                    while (index:=session.next_index()) is not None:
                        observed=float(bank["risk"][index])
                        proxy=float(calibrated[int(bank["x"][index,4])].predict_proba([[observed]])[0,1])
                        session.observe(proxy)
                        session.records[-1]["continuous_risk"]=observed
                        selected.append(index)
                    result=discovery_metrics(bank,selected)
                    write_json(path,{**result,"selected_indices":selected,"queries":session.records,
                        "kernel":kernel_name,"noise":noise,"mixture":mixture,"lookahead":lookahead,
                        "elapsed_s":time.perf_counter()-started,"target_binary_feedback":False})
                    print(name,[result["checkpoints"][str(k)]["collisions"] for k in (50,100,200)],
                          round(result["discovery_auc"],3),flush=True)


if __name__=="__main__":
    main()
