"""Continuous response hypotheses via a Bayesian source basis and residual GP."""
import time

import numpy as np
import torch

from methods.history_guided_testing.config import ROOT as BASELINE
from methods.history_guided_testing.evaluate import discovery_metrics
from methods.history_guided_testing.history import load_history, split_indices, subset
from methods.history_guided_testing.train import load_kernel
from .config import OUTPUT
from .core import HypothesisSession, source_predictions
from .run import write_json


def main():
    torch.set_num_threads(1)
    history = load_history()
    train, _ = split_indices(next(iter(history.values()))["x"])
    bank = np.load(BASELINE / "target/responses.npz")
    _, means, weights = source_predictions(subset(history, train), bank["x"])
    with torch.no_grad():
        physical = load_kernel(11, "global_feedback").cuda().covariance(bank["x"])
    features = torch.as_tensor((means - means @ weights[:, None]) * np.sqrt(weights), device="cuda")
    family = torch.as_tensor(bank["x"][:,4], device="cuda")
    basis = features @ features.T * (family[:,None] == family[None,:])
    for strength in (.1, 1., 10.):
        for residual in (.01, .1, 1.):
            kernel = strength * basis + residual * physical
            for utility in ("risk", "event", "excess"):
                for lookahead in (False, True):
                    name = f"basis_{strength}_{residual}_{utility}_" + ("ens" if lookahead else "greedy")
                    path = OUTPUT / "basis_trials" / (name + ".json")
                    if path.exists():
                        continue
                    session = HypothesisSession(kernel, means, weights, mixture=False,
                                                utility=utility, lookahead=lookahead)
                    started = time.perf_counter()
                    selected = []
                    while (index := session.next_index()) is not None:
                        session.observe(float(bank["risk"][index]))
                        selected.append(index)
                    result = discovery_metrics(bank, selected)
                    write_json(path, {**result, "selected_indices": selected, "queries": session.records,
                        "source_strength": strength, "residual_strength": residual,
                        "utility": utility, "lookahead": lookahead, "elapsed_s": time.perf_counter()-started})
                    print(name, [result["checkpoints"][str(k)]["collisions"] for k in (50,100,200)],
                          round(result["discovery_auc"],3), flush=True)


if __name__ == "__main__":
    main()
