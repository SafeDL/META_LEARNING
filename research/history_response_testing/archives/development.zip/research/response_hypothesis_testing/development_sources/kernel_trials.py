"""Development trials of response similarity; all settings and outcomes retained."""
import time

import numpy as np
import torch

from methods.history_guided_testing.config import ROOT as BASELINE
from methods.history_guided_testing.evaluate import discovery_metrics
from methods.history_guided_testing.history import load_history, split_indices, subset
from .config import OUTPUT
from .core import HypothesisSession, source_predictions
from .response_kernel import covariance
from .run import write_json


def main():
    torch.set_num_threads(1)
    history = load_history()
    train, _ = split_indices(next(iter(history.values()))["x"])
    bank = np.load(BASELINE / "target/responses.npz")
    names, means, weights = source_predictions(subset(history, train), bank["x"])
    for length in (.025, .05, .1, .2, .4):
        for physics in (0., .1, .5):
            kernel = covariance(bank["x"], means, length, physical_weight=physics)
            for mixture in (False, True):
                for utility in ("risk", "event"):
                    name = f"response_{length}_{physics}_" + ("sources" if mixture else "average") + "_" + utility
                    path = OUTPUT / "kernel_trials" / (name + ".json")
                    if path.exists():
                        continue
                    session = HypothesisSession(kernel, means, weights, mixture=mixture, utility=utility)
                    started = time.perf_counter()
                    selected = []
                    while (index := session.next_index()) is not None:
                        session.observe(float(bank["risk"][index]))
                        selected.append(index)
                    result = discovery_metrics(bank, selected)
                    write_json(path, {**result, "selected_indices": selected, "queries": session.records,
                                      "response_length": length, "physical_weight": physics,
                                      "mixture": mixture, "utility": utility, "elapsed_s": time.perf_counter()-started})
                    print(name, [result["checkpoints"][str(k)]["collisions"] for k in (50, 100, 200)],
                          round(result["discovery_auc"], 3), flush=True)


if __name__ == "__main__":
    main()
