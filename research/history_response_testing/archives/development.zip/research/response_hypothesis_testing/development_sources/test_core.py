import numpy as np
import pytest
import torch
from scipy.special import logsumexp
from scipy.stats import multivariate_normal

from methods.history_guided_testing.gp import RiskGP
from .core import HypothesisSession


def fixture():
    rng=np.random.default_rng(7)
    features=rng.normal(size=(12,4))
    covariance=.02*features@features.T+.01*np.eye(12)
    means=rng.uniform(.1,.9,size=(12,3))
    weights=np.array([.25,.25,.5])
    return covariance,means,weights


def test_batch_posterior_and_likelihood_and_order():
    covariance,means,weights=fixture()
    indices=[3,8,2]
    observations=np.array([.2,.8,.5])
    sessions=[]
    for order in (range(3),reversed(range(3))):
        session=HypothesisSession(covariance,means,weights,device="cpu")
        for position in order:
            session.pending=indices[position]
            session.records.append({})
            session.observe(float(observations[position]))
        sessions.append(session)
    block=covariance[np.ix_(indices,indices)]+.0025*np.eye(3)
    cross=covariance[:,indices]
    expected=means+cross@np.linalg.solve(block,observations[:,None]-means[indices])
    expected_covariance=covariance-cross@np.linalg.solve(block,cross.T)
    scores=np.log(weights)+np.array([multivariate_normal.logpdf(observations,mean=means[indices,j],cov=block) for j in range(3)])
    for session in sessions:
        np.testing.assert_allclose(session.mean.numpy(),expected,atol=1e-12)
        np.testing.assert_allclose(session.covariance.numpy(),expected_covariance,atol=1e-12)
        np.testing.assert_allclose(session.weights.numpy(),np.exp(scores-logsumexp(scores)),atol=1e-12)


def test_fantasies_do_not_change_observations_and_final_budget_is_greedy():
    covariance,means,weights=fixture()
    session=HypothesisSession(covariance,means,weights,device="cpu",lookahead=True,budget=1)
    probability,_=session.probabilities()
    assert session.next_index()==int(probability.argmax())
    with pytest.raises(RuntimeError):
        session.next_index()
    session.observe(.5)
    assert session.next_index() is None
    session=HypothesisSession(covariance,means,weights,device="cpu",lookahead=True,budget=4)
    before=[session.mean.clone(),session.covariance.clone(),session.log_weights.clone()]
    probabilities,_=session.probabilities()
    scores=session.fantasy_values(torch.tensor([1,2]),probabilities)
    assert torch.isfinite(scores).all()
    for original,current in zip(before,[session.mean,session.covariance,session.log_weights]):
        assert torch.equal(original,current)
    assert session.count==0 and not session.records


def test_source_mean_matches_frozen_group_average():
    from methods.history_guided_testing.history import historical_risk
    from .core import source_predictions
    rng=np.random.default_rng(3)
    x=rng.uniform(size=(20,5))
    history={name:{"x":x,"risk":rng.uniform(size=20)} for name in
             ("idm_reactive","fvdm_reactive","idm_delayed","fvdm_delayed","idm_limited","idm_predictive")}
    _,means,weights=source_predictions(history,x[:4])
    np.testing.assert_allclose(means@weights,historical_risk(history,x[:4]),atol=1e-14)


def test_dual_readouts_match_separate_conditioning():
    from .dual import ResponseTestingSession
    covariance, means, weights = fixture()
    x = np.zeros((len(means), 5))
    x[:, 4] = np.arange(len(x)) % 2
    collision_means = means ** 2
    calibration = {0: {"slope": 3., "intercept": -1.},
                   1: {"slope": 4., "intercept": -2.}}
    dual = ResponseTestingSession(x, covariance, means, collision_means, weights,
                                  calibration, budget=4, noise=.05, device="cpu")
    risk = HypothesisSession(covariance, means, weights, mixture=False, utility="risk",
                             noise=.05, budget=4, device="cpu")
    calibrated = HypothesisSession(covariance, collision_means, weights, mixture=False,
                                   utility="risk", noise=.05, budget=4, device="cpu")
    from scipy.special import expit
    for count in range(4):
        alpha = 1 - count / 4
        risk_scores, _ = risk.probabilities()
        class_scores, _ = calibrated.probabilities()
        scores = (alpha * class_scores + (1 - alpha) * risk_scores).masked_fill(~risk.remaining, -torch.inf)
        index = int(scores.argmax())
        assert dual.next_index() == index
        observed = .2 + .1 * count
        dual.observe(observed)
        options = calibration[int(x[index, 4])]
        transformed = float(expit(options["slope"] * observed + options["intercept"]))
        for session, feedback in ((risk, observed), (calibrated, transformed)):
            session.pending = index
            session.records.append({})
            session.observe(feedback)
        np.testing.assert_allclose(dual.mean[:, 0].numpy(), risk.mean[:, 0].numpy(), atol=1e-13)
        np.testing.assert_allclose(dual.mean[:, 1].numpy(), calibrated.mean[:, 0].numpy(), atol=1e-13)
        assert dual.count == risk.count == calibrated.count == count + 1
    assert dual.next_index() is None
