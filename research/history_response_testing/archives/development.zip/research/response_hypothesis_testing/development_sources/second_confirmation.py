"""Fresh confirmation of budget-dependent risk and calibrated-score readouts."""
from concurrent.futures import ProcessPoolExecutor, ThreadPoolExecutor
import hashlib
import json
import multiprocessing as mp
from pathlib import Path
import threading

import numpy as np
import torch

from methods.history_guided_testing.config import ROOT as BASELINE, TARGET
from methods.history_guided_testing.history import historical_risk, load_history, split_indices, subset
from methods.history_guided_testing.prepare import measure_scene
from methods.history_guided_testing.scenarios import parameter_cells
from . import confirmation as first
from .config import BUDGET, OUTPUT, SEEDS
from .core import source_predictions
from .dual import ResponseTestingSession
from .emulator import predict
from .freeze import freeze
from .response_kernel import covariance
from .run import write_json
from .validate_candidates import calibrators

FOLDER = OUTPUT / "fresh_confirmation"
POOL_SEEDS = tuple((1098001 + 191 * i, 1098002 + 191 * i) for i in range(20))
METHODS = ("candidate", "main", "ras_frt_uq", "class_rank", "risk_only", "calibrated_only")


def lock_protocol():
    path = FOLDER / "protocol.json"
    if path.exists():
        return json.loads(path.read_text(encoding="utf-8"))
    calibration = calibrators()
    value = {
        "locked_on": "2026-10-05 Asia/Shanghai", "confirmation_round": 2,
        "pool_sampling_seeds": POOL_SEEDS, "pool_count": 20, "methods": METHODS,
        "training_seeds": SEEDS, "training_seed_per_pool": [SEEDS[i % 5] for i in range(20)],
        "candidate": {"prior": "explicit historical risk and collision-response heads",
                      "response_length": .05, "physical_length": .2, "physical_weight": .1,
                      "sigma": .25, "noise": .05, "calibrated_weight": "1 - queries_used / 200",
                      "utility": "weighted expected clipped risk and calibrated score",
                      "source_posterior": False, "lookahead": False},
        "calibration": calibration, "budget": 200, "scenes_per_family": 1024,
        "target_profile": "same frozen FVDM",
        "primary_metric": "mean cumulative collision count over all 200 queries",
        "independent_unit": "new Sobol candidate pool",
        "primary_comparisons": ["main", "ras_frt_uq"],
        "significance": "two-sided exact paired sign-flip; Holm within two comparisons",
        "round_alpha": .05 / (2 * 3),
        "multi_round_rule": "conservative alpha spending 0.05 / [round * (round+1)]",
        "success": "positive AUC difference with Holm p<round_alpha against both, mean AUC gain >=1 against RAS, paired F200 bootstrap 95% CI lower bound >=-1",
        "secondary_metrics": ["F10", "F50", "F100", "F200", "collision parameter cells", "risk QD score"],
        "development": "first original target and completed first confirmation; all fresh seeds still unmeasured",
        "feedback": {"ras_frt_uq": "queried binary collision", "other_methods": "queried continuous risk only"},
        "physical_execution": "only requested scenes; shared physical cache; no full-pool recall claim",
        "model_sha256": {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
                         for p in (OUTPUT / "models").glob("emulator_*.pt")},
        "source_sha256": {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in
                          [Path(__file__).parent / name for name in
                           ("dual.py", "emulator.py", "response_kernel.py", "second_confirmation.py",
                            "validate_candidates.py")]},
    }
    write_json(path, value)
    return value


def fresh_scenes(pool):
    from scipy.stats import qmc
    from methods.history_guided_testing.config import BOUNDS
    scenes = first.new_scenes(pool % 10)
    for family, seed in enumerate(POOL_SEEDS[pool]):
        points = qmc.Sobol(4, scramble=True, seed=seed).random_base2(10)
        bounds = np.asarray(BOUNDS[family])
        for index, point in enumerate(points):
            scene = scenes[family * 1024 + index]
            scene["numeric_input"] = [*point.tolist(), family]
            scene["active_parameters"] = dict(zip(scene["active_parameters"],
                (bounds[:, 0] + point * (bounds[:, 1] - bounds[:, 0])).tolist()))
            scene["scenario_id"] = f"fresh_confirmation:{pool}:{family}:{index:04d}"
            scene["sampling_seed"] = seed
    return scenes


def selector(connection, method, seed, x, prior, risk_means, collision_means, weights, ras, calibration):
    from methods.history_guided_testing.experiment import RemoteOracle
    from methods.history_guided_testing.search import TestingSession, select_session
    from methods.ras_frt_uq.unified import select_from_responses
    from threadpoolctl import threadpool_limits
    torch.set_num_threads(1)
    threadpool_limits(limits=1)
    oracle = RemoteOracle(connection)
    try:
        if method == "main":
            result = select_session(TestingSession(x, seed, mode="global_feedback", prior=prior), oracle)
        elif method == "ras_frt_uq":
            result = select_from_responses(x, parameter_cells(x), ras, oracle, seed)
        elif method == "class_rank":
            selected = np.argsort(-(collision_means @ weights), kind="stable")[:200].tolist()
            rows = []
            for index in selected:
                observed = oracle.query(index)
                rows.append({"index": index, "query_number": observed.query_number, "continuous_risk": observed.risk})
            result = {"selected_indices": selected, "queries": rows}
        else:
            kernel = covariance(x, risk_means, .05, physical_weight=.1, device="cpu")
            mode = {"candidate": "dual", "risk_only": "risk", "calibrated_only": "calibrated"}[method]
            session = ResponseTestingSession(x, kernel, risk_means, collision_means, weights, calibration,
                                             mode=mode, device="cpu")
            selected = []
            while (index := session.next_index()) is not None:
                observation = oracle.query(index)
                session.observe(observation.risk)
                selected.append(index)
            result = {"selected_indices": selected, "queries": session.records}
        connection.send(("result", result))
    except Exception as error:
        connection.send(("error", repr(error)))
        raise
    finally:
        connection.close()


def main():
    freeze()
    protocol = lock_protocol()
    for name, digest in protocol["model_sha256"].items():
        assert hashlib.sha256((OUTPUT / "models" / name).read_bytes()).hexdigest() == digest
    torch.set_num_threads(1)
    history = load_history()
    train, _ = split_indices(next(iter(history.values()))["x"])
    history = subset(history, train)
    calibration = {int(key): value for key, value in protocol["calibration"].items()}
    pools = []
    previous_x = np.vstack([np.load(BASELINE / "target/responses.npz")["x"],
                           next(iter(history.values()))["x"],
                           *[np.asarray([s["numeric_input"] for s in json.loads(
                               (first.FOLDER / f"pool_{i}" / "scenarios.json").read_text(encoding="utf-8"))])
                             for i in range(10)]])
    previous_points = set(map(tuple, previous_x))
    for pool in range(20):
        seed = SEEDS[pool % 5]
        scenes = fresh_scenes(pool)
        x = np.asarray([s["numeric_input"] for s in scenes])
        assert not set(map(tuple, x)) & previous_points
        previous_points.update(map(tuple, x))
        write_json(FOLDER / f"pool_{pool}" / "scenarios.json", scenes)
        risks, collisions = predict(x, seed)
        _, _, weights = source_predictions(history, x)
        prior = historical_risk(history, x)
        ras = first.ras_predictions(x, seed)
        pools.append((scenes, x, prior, risks, collisions, weights, ras))
    context = mp.get_context("spawn")
    lock = threading.Lock()
    cache, pending = {}, {}
    for pool in range(20):
        path = FOLDER / f"pool_{pool}" / "measurements.jsonl"
        if path.exists():
            for line in path.read_text(encoding="utf-8").splitlines():
                row = json.loads(line)
                cache[(pool, row["index"])] = row
    print("Fresh locked confirmation; cached physical calls:", len(cache), flush=True)
    with ProcessPoolExecutor(max_workers=12, mp_context=context) as simulator:
        def query(pool, index):
            key = (pool, index)
            with lock:
                if key in cache:
                    return cache[key]
                if key not in pending:
                    pending[key] = simulator.submit(measure_scene, (pools[pool][0][index], TARGET))
                future = pending[key]
            row = {**future.result(), "index": index}
            with lock:
                if key not in cache:
                    cache[key] = row
                    with (FOLDER / f"pool_{pool}" / "measurements.jsonl").open("a", encoding="utf-8") as handle:
                        handle.write(json.dumps(row) + "\n")
                    if len(cache) % 200 == 0:
                        print("Fresh physical calls:", len(cache), flush=True)
            return row

        def run_one(arguments):
            pool, method = arguments
            path = FOLDER / f"pool_{pool}" / f"{method}.json"
            if path.exists():
                return
            scenes, x, prior, risks, collisions, weights, ras = pools[pool]
            seed = SEEDS[pool % 5]
            parent, child = context.Pipe()
            process = context.Process(target=selector, args=(child, method, seed, x, prior, risks, collisions, weights, ras, calibration))
            process.start()
            child.close()
            disclosed = set()
            try:
                while True:
                    message, value = parent.recv()
                    if message == "query":
                        if value in disclosed or len(disclosed) >= 200 or not 0 <= value < len(x):
                            raise ValueError("Duplicate, over-budget or invalid query")
                        disclosed.add(value)
                        row = query(pool, value)
                        parent.send((None, bool(row["collision"])) if method == "ras_frt_uq" else (float(row["risk"]), None))
                    elif message == "result":
                        assert len(value["selected_indices"]) == 200
                        assert set(value["selected_indices"]) == disclosed
                        write_json(path, {**value, "pool": pool, "seed": seed, "method": method,
                                   "feedback": protocol["feedback"]["ras_frt_uq" if method == "ras_frt_uq" else "other_methods"]})
                        print("Fresh sequence locked:", pool, method, flush=True)
                        break
                    else:
                        raise RuntimeError(value)
            finally:
                parent.close()
                process.join(timeout=10)
                if process.is_alive():
                    process.terminate()
                    process.join()
        with ThreadPoolExecutor(max_workers=12) as workers:
            list(workers.map(run_one, [(pool, method) for pool in range(20) for method in METHODS]))
    write_json(FOLDER / "physical_cost.json", {"unique_new_simulator_calls": len(cache),
        "simulator_seconds": sum(r["elapsed_s"] for r in cache.values()),
        "selector_queries": 20 * len(METHODS) * 200, "all_sequences_locked": True})
    freeze()
    print("Fresh physical confirmation complete", flush=True)


if __name__ == "__main__":
    main()
