"""Use the completed first confirmation as development for a fresh second round."""
from concurrent.futures import ProcessPoolExecutor,ThreadPoolExecutor
import json
import multiprocessing as mp

import numpy as np
from scipy.special import expit
import torch

from methods.history_guided_testing.config import TARGET
from methods.history_guided_testing.prepare import measure_scene
from methods.history_guided_testing.scenarios import parameter_cells
from .config import OUTPUT,SEEDS
from .core import HypothesisSession
from .emulator import predict
from .response_kernel import covariance
from .run import write_json
from .validate_candidates import calibrators


def main():
    torch.set_num_threads(1)
    calibration=calibrators()
    weights=np.array([.125,.125,.125,.125,.25,.25])
    with ProcessPoolExecutor(max_workers=10,mp_context=mp.get_context("spawn")) as simulator:
        def one_pool(pool):
            folder=OUTPUT/"confirmation"/f"pool_{pool}"
            scenes=json.loads((folder/"scenarios.json").read_text(encoding="utf-8"))
            x=np.asarray([s["numeric_input"] for s in scenes])
            cache={r["index"]:r for r in map(json.loads,(folder/"measurements.jsonl").read_text(encoding="utf-8").splitlines())}
            extra=OUTPUT/"followup_development"/f"pool_{pool}_measurements.jsonl"
            if extra.exists():
                cache.update({r["index"]:r for r in map(json.loads,extra.read_text(encoding="utf-8").splitlines())})
            def query(index):
                if index not in cache:
                    row={**simulator.submit(measure_scene,(scenes[index],TARGET)).result(),"index":index}
                    cache[index]=row
                    extra.parent.mkdir(parents=True,exist_ok=True)
                    with extra.open("a",encoding="utf-8") as handle:
                        handle.write(json.dumps(row)+"\n")
                return float(cache[index]["risk"])
            risks,collisions=predict(x,SEEDS[pool%5])
            for kind in ("class_gp","class_rank","hybrid_step","hybrid_linear"):
                path=OUTPUT/"followup_development"/f"{kind}_{pool}.json"
                if path.exists():
                    continue
                kernel=covariance(x,risks,.05,physical_weight=.1)
                class_session=HypothesisSession(kernel,collisions,weights,mixture=False,utility="risk",noise=.05)
                risk_session=HypothesisSession(kernel,risks,weights,mixture=False,utility="risk",noise=.05)
                selected=[]
                rows=[]
                for count in range(200):
                    if kind=="class_rank":
                        scores=collisions@weights
                        scores[np.asarray(selected,dtype=int)]=-np.inf
                        index=int(scores.argmax())
                    elif kind=="class_gp":
                        index=class_session.next_index()
                    else:
                        alpha=float(count<50) if kind=="hybrid_step" else 1-count/200
                        c,_=class_session.probabilities()
                        r,_=risk_session.probabilities()
                        scores=(alpha*c+(1-alpha)*r).masked_fill(~class_session.remaining,-torch.inf)
                        index=int(scores.argmax())
                    observed=query(index)
                    options=calibration[int(x[index,4])]
                    proxy=float(expit(options["slope"]*observed+options["intercept"]))
                    if kind!="class_rank":
                        if kind!="class_gp":
                            class_session.pending=index
                            class_session.records.append({})
                        class_session.observe(proxy)
                        risk_session.pending=index
                        risk_session.records.append({})
                        risk_session.observe(observed)
                    selected.append(index)
                    rows.append({"query_number":count+1,"index":index,"continuous_risk":observed,"proxy_feedback":proxy})
                truth=np.array([cache[i]["collision"] for i in selected])
                curve=np.cumsum(truth)
                value={"selected_indices":selected,"queries":rows,"pool":pool,"method":kind,
                       "discovery_auc":float(curve.mean()),**{f"F{k}":int(curve[k-1]) for k in (10,50,100,200)},
                       "stage":"first confirmation pool now reused for development; not new confirmation"}
                write_json(path,value)
                print("Followup",pool,kind,[value[f"F{k}"] for k in (50,100,200)],round(value["discovery_auc"],3),flush=True)
        with ThreadPoolExecutor(max_workers=10) as workers:
            list(workers.map(one_pool,range(10)))


if __name__=="__main__":
    main()
