"""Write an evidence-led research report from saved development and confirmation."""
import json

import numpy as np

from methods.history_guided_testing.config import ROOT as BASELINE
from .config import OUTPUT, ROOT, SEEDS
from .run import write_json


def load(path):
    return json.loads(path.read_text(encoding="utf-8"))


def main():
    summary=load(OUTPUT/"confirmation/summary.json")
    diagnostics=load(OUTPUT/"prediction_diagnostics.json")
    original=load(BASELINE/"comparison_summary.json")
    names={"candidate":"完整来源响应 GP","main":"冻结历史引导 GP","ras_frt_uq":"RAS-FRT-UQ",
           "knn_history":"固定历史 kNN 排序","emulator_rank":"神经历史风险固定排序",
           "emulator_physical":"同一神经先验＋原物理核"}
    def row(name):
        values=summary["aggregate"][name]
        return "|"+names[name]+"|"+"|".join(f"{values[k]['mean']:.2f} ± {values[k]['std']:.2f}" for k in ("F50","F100","F200","discovery_auc"))+"|"
    primary=summary["comparisons"]
    gains={m:primary[m]["discovery_auc"]["mean_difference"]/summary["aggregate"][m]["discovery_auc"]["mean"] for m in primary}
    development=[]
    for path in OUTPUT.rglob("*.json"):
        if "confirmation" in path.parts:
            continue
        value=load(path)
        if "discovery_auc" in value and "checkpoints" in value:
            development.append({"path":str(path.relative_to(ROOT)),"auc":value["discovery_auc"],
                                "F50":value["checkpoints"]["50"]["collisions"],
                                "F100":value["checkpoints"]["100"]["collisions"],
                                "F200":value["checkpoints"]["200"]["collisions"]})
    write_json(OUTPUT/"development_inventory.json",{"run_count":len(development),"runs":development,
        "interpretation":"development trials are not independent confirmatory evidence"})
    lines=["# 完整历史响应向量引导的风险测试","",
           "**状态：** "+("达到预先登记的显著优势标准。" if summary["success"] else "确认实验完成；预先登记的优势标准尚未全部达到。"),"",
           f"在 10 个重新生成的 Sobol 场景池上，每方法均执行 200 次查询，新方法的碰撞发现曲线面积相对冻结方法提高 {gains['main']:.2%}，相对 RAS 提高 {gains['ras_frt_uq']:.2%}。统计单位为候选池，使用成对符号翻转检验，并对两个主比较作 Holm 校正。目标仍是原 FVDM，仿真、场景范围、风险公式和碰撞判定均保持原设置。","",
           "## 确认结果","",
           "每个场景池包含切入 1024 个、前车急刹 1024 个。十个池轮流使用五个训练种子；一个池中的六种方法共享同一物理结果缓存。曲线面积为第 1–200 次查询累计碰撞数的均值，越高表示发现越早。表中标准差描述十个池之间的变化。","",
           "|方法|F50|F100|F200|发现曲线面积|","|---|---:|---:|---:|---:|"]
    lines.extend(row(name) for name in names)
    lines += ["","|主比较：新方法减对照|曲线面积差|成对 bootstrap 95% CI|Holm 校正 p|","|---|---:|---:|---:|"]
    for method in primary:
        result=primary[method]["discovery_auc"]
        lower,upper=result["bootstrap_95_ci"]
        lines.append(f"|{names[method]}|{result['mean_difference']:.3f}|[{lower:.3f}, {upper:.3f}]|{result['holm_adjusted_p']:.5f}|")
    lines += ["","预先固定的成功标准同时要求两个主比较 p<0.05、相对 RAS 的曲线面积增益至少为 1，以及 F200 成对差的 95% CI 下界不低于 −1。F50、F100、参数单元和风险 QDScore 是次级结果；不以多次挑选指标替代主检验。符号翻转检验使用零假设下成对差符号可交换的假设。","",
              "![新坐标确认的碰撞发现曲线](results/confirmation/discovery.png)","",
              "## 方法与工程实现","",
              "离线对两类场景分别学习六个历史 SUT 的连续风险响应。网络为 4→64→128→64→12，SiLU 激活；前六个输出预测连续风险，后六个为仅在历史训练中使用的碰撞辅助头。风险平方误差按 1+4R 加权，并加入 0.1 倍历史碰撞 BCE。每个种子训练 400 轮，批量 128，AdamW 学习率 0.001、权重衰减 0.0001；每 10 轮按历史空间验证集选择检查点。目标结果不进入这项训练。","",
              "初始均值沿用机制组均衡的平均规则，同时完整保留六维来源响应向量。目标差异 GP 的相关性由该响应向量和物理场景参数共同确定：90% 为完整来源响应的 Matérn-5/2，10% 为物理参数的 Matérn-5/2。来源距离除以 √6；长度尺度分别为 0.05、0.2，核幅度为 0.25。不同场景类型间相关性为零。在线冻结网络和核，逐次更新目标实测风险，按截断于 [0,1] 的预期风险选择下一个候选。","",
              "0.05 是 GP 工作似然的正则方差，用于约束对历史预测误差的修正幅度，不是对确定性模拟器噪声的实测估计。高风险评价阈值仍为 R>0.5。新方法和原主方法在目标端只收到查询点的连续风险；RAS 收到查询点的二值碰撞。新方法离线辅助头使用的是已有历史碰撞标签，其信息与计算成本在这里明确报告。","",
              "## 哪些机制值得保留","",
              "同一神经先验的固定排序检验目标反馈是否带来额外收益；同一神经先验＋原物理核检验完整来源响应相似度的作用。比较均使用相同候选池和查询预算。来源条件化的离散后验、完整预算 ENS、缩短前瞻、来源低秩基、尾部变换和历史风险—碰撞校准均已实际回放。最终确认使用更简洁的完整响应核与风险反馈配置，未把离散来源身份或 ENS 强行保留为贡献。","",
              f"开发记录共 {len(development)} 次回放，逐次选择、反馈和指标保存在 results 各开发目录，索引见 [development_inventory.json](results/development_inventory.json)。这些试验使用已分析过的原目标库；确认结论来自独立的新坐标池，不能把开发回放的多次比较当成多份独立证据。","",
              "## 对照相同反馈点的风险诊断","",
              "在原开发目标库中，五个种子共享各自的随机反馈顺序，分别在 10、20、50、100 次反馈后预测未查询候选。该实验解释机制，不参与确认统计。","",
              "|预测模型|总体风险 RMSE|高风险 RMSE|高风险 AP|","|---|---:|---:|---:|"]
    for method,label in (("knn_prior","原历史 kNN 先验"),("frozen","冻结反馈模型"),("emulator_prior","神经历史先验"),("candidate","完整来源响应 GP")):
        value=diagnostics["aggregate"][method]
        lines.append(f"|{label}|{value['rmse']:.4f}|{value['tail_rmse']:.4f}|{value['tail_ap']:.4f}|")
    lines += ["","新方法针对危险候选排序和高风险预测组织设计，整体 RMSE 不作为碰撞发现的替代验收指标。完整诊断见 [prediction_diagnostics.json](results/prediction_diagnostics.json)。","",
              "## 冻结与可复现性","",
              "原方法、原九个基线及组件结果均保持原路径和内容；冻结快照包含 176 个文件，逐文件 SHA-256 校验并核对 ZIP 解压内容。原始提交为 357cab201e150e940a73a91a05c29d32440e8699，用户新增的研究方向文档也进入快照。冻结校验见 [manifest.json](frozen_baseline/manifest.json)。原目标库中的完整原九基线比较仍在 [原报告](../../results/history_guided_testing/README.md)。","",
              "确认选择器运行在独立进程中。父进程逐次执行并披露请求场景的风险，检查重复查询、预算和最终索引的一致性；二值碰撞只传给 RAS，其他方法的碰撞计数在所有序列锁定后由评估器生成。只物理执行实际请求场景，结果缓存跨方法复用；没有测完新池的全部候选，因此新确认报告发现数和已发现参数单元，不声称完整池召回率。","",
              "新实验复用 12,288 条历史实测响应。新物理调用和选择器调用分别见 [physical_cost.json](results/confirmation/physical_cost.json)。GPU 训练与离线特征计算使用 metadrive 环境中的 RTX 4090 D；并发在线选择采用 CPU float64。软件版本见 [provenance.json](results/provenance.json)。","",
              "```powershell","conda activate metadrive","python -B -m research.response_hypothesis_testing.emulator","python -B -m research.response_hypothesis_testing.confirmation","python -B -m research.response_hypothesis_testing.analyze_confirmation","python -B -m research.response_hypothesis_testing.prediction_diagnostics","python -B -m research.response_hypothesis_testing.report","python -B -m pytest -q -p no:cacheprovider research/response_hypothesis_testing/test_core.py tests/history_guided_testing","```","",
              "已有训练检查点和确认测量会复用。当前结论范围为固定 FVDM、两种功能场景和同一参数范围内的新坐标，不将十个场景池表述成十种独立的新驾驶算法。","",
              "## 文献与研究判断","",
              "用户提供的 [逐篇研究借鉴文档](../../docs/Attachment_Paper_Review_and_Research_Directions.md) 已用于对齐任务、组件和验收口径。开发中落实了多来源解释及预算前瞻的 2×2 对照。预算前瞻采用 [ENS 原始工作](https://proceedings.mlr.press/v70/jiang17d.html) 的当前收益＋未来重新选批结构；[PEARL](https://arxiv.org/abs/1903.08254) 和 [DREAM](https://arxiv.org/abs/2008.02790) 分别提供来源假设更新和任务相关信息的设计依据。数学上的模型平均、Matérn 核及 ENS 均按已有方法使用，不以重新命名声称首创。","",
              "[Coverage-Aware Active Evaluation](https://arxiv.org/abs/2608.13719) 是相关的直接竞争方向。这里获得的证据支持完整历史响应相似度对连续目标反馈传播的工程收益；是否构成可发表的新方法，需要围绕这个具体机制继续定位，而不是将历史＋残差＋主动测试的组合本身作为新颖性。",""
              ]
    (ROOT/"README.md").write_text("\n".join(lines),encoding="utf-8")
    print("Research report written",flush=True)


if __name__=="__main__":
    main()
