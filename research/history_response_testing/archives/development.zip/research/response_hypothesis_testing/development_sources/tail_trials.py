"""Tail-emphasized continuous response trials; no binary target feedback."""
import time

import numpy as np
import torch

from methods.history_guided_testing.config import ROOT as BASELINE
from methods.history_guided_testing.evaluate import discovery_metrics
from methods.history_guided_testing.history import load_history, split_indices, subset
from methods.history_guided_testing.train import load_kernel
from .config import OUTPUT
from .core import HypothesisSession, source_predictions
from .response_kernel import covariance
from .run import write_json


def main():
    torch.set_num_threads(1)
    history = load_history()
    train, _ = split_indices(next(iter(history.values()))["x"])
    bank = np.load(BASELINE / "target/responses.npz")
    with torch.no_grad():
        physical = load_kernel(11, "global_feedback").cuda().covariance(bank["x"])
    _, original_means, _ = source_predictions(subset(history, train), bank["x"])
    for power in (2, 4, 8):
        transformed = {name: {"x": row["x"], "risk": row["risk"] ** power}
                       for name, row in subset(history, train).items()}
        _, means, weights = source_predictions(transformed, bank["x"])
        for kernel_name in ("physical", "response"):
            kernel = physical if kernel_name == "physical" else covariance(bank["x"], original_means, .05, physical_weight=.1)
            for noise in (.0001, .0025, .01):
                for mixture in (False, True):
                    name = f"tail_{power}_{kernel_name}_{noise}_" + ("sources" if mixture else "average")
                    path = OUTPUT / "tail_trials" / (name + ".json")
                    if path.exists():
                        continue
                    session = HypothesisSession(kernel, means, weights, mixture=mixture,
                                                utility="risk", noise=noise)
                    started = time.perf_counter()
                    selected = []
                    while (index := session.next_index()) is not None:
                        session.observe(float(bank["risk"][index]) ** power)
                        selected.append(index)
                    result = discovery_metrics(bank, selected)
                    write_json(path, {**result, "selected_indices": selected, "queries": session.records,
                        "power": power, "kernel": kernel_name, "noise": noise,
                        "mixture": mixture, "elapsed_s": time.perf_counter()-started})
                    print(name, [result["checkpoints"][str(k)]["collisions"] for k in (50,100,200)],
                          round(result["discovery_auc"],3), flush=True)


if __name__ == "__main__":
    main()
