"""Evaluate only locked sequences, preserving the pool as the statistical unit."""
from itertools import product
import json

import numpy as np

from methods.history_guided_testing.scenarios import parameter_cells
from .confirmation import FOLDER, METHODS
from .run import write_json


def paired_statistics(differences):
    differences=np.asarray(differences,dtype=float)
    signs=np.asarray(list(product((-1,1),repeat=len(differences))))
    observed=abs(differences.mean())
    p=float(np.mean(np.abs(signs@differences/len(differences))>=observed-1e-12))
    rng=np.random.default_rng(20261005)
    bootstrap=differences[rng.integers(0,len(differences),size=(20000,len(differences)))].mean(axis=1)
    return {"mean_difference":float(differences.mean()),"per_pool_differences":differences.tolist(),
            "bootstrap_95_ci":np.quantile(bootstrap,[.025,.975]).tolist(),"exact_two_sided_sign_flip_p":p}


def main():
    protocol=json.loads((FOLDER/"protocol.json").read_text(encoding="utf-8"))
    results={method:[] for method in METHODS}
    for pool in range(10):
        folder=FOLDER/f"pool_{pool}"
        bank={row["index"]:row for row in map(json.loads,(folder/"measurements.jsonl").read_text(encoding="utf-8").splitlines())}
        scenes=json.loads((folder/"scenarios.json").read_text(encoding="utf-8"))
        x=np.asarray([scene["numeric_input"] for scene in scenes])
        cells=parameter_cells(x)
        for method in METHODS:
            sequence=json.loads((folder/f"{method}.json").read_text(encoding="utf-8"))["selected_indices"]
            assert len(sequence)==len(set(sequence))==200
            collision=np.asarray([bank[i]["collision"] for i in sequence])
            risk=np.asarray([bank[i]["risk"] for i in sequence])
            curve=np.cumsum(collision)
            record={"pool":pool,"discovery_auc":float(curve.mean()),"curve":curve.tolist()}
            for count in (10,50,100,200):
                selected=sequence[:count]
                elite=np.zeros(512)
                np.maximum.at(elite,cells[selected],np.maximum(risk[:count]-.5,0))
                record[f"F{count}"]=int(curve[count-1])
                record[f"collision_cells_{count}"]=len(set(cells[selected][collision[:count]]))
                record[f"risk_qd_{count}"]=float(elite.sum())
            results[method].append(record)
    summary={method:{key:{"mean":float(np.mean([r[key] for r in rows])),
                         "std":float(np.std([r[key] for r in rows],ddof=1))}
                       for key in ("F10","F50","F100","F200","discovery_auc","collision_cells_200","risk_qd_200")}
             for method,rows in results.items()}
    comparisons={}
    for method in ("main","ras_frt_uq"):
        comparisons[method]={metric:paired_statistics([a[metric]-b[metric] for a,b in zip(results["candidate"],results[method])])
                             for metric in ("discovery_auc","F50","F100","F200")}
    ordered=sorted(comparisons,key=lambda name:comparisons[name]["discovery_auc"]["exact_two_sided_sign_flip_p"])
    corrected=0.
    for rank,method in enumerate(ordered):
        corrected=max(corrected,min(1.,(2-rank)*comparisons[method]["discovery_auc"]["exact_two_sided_sign_flip_p"]))
        comparisons[method]["discovery_auc"]["holm_adjusted_p"]=corrected
    success=all(comparisons[m]["discovery_auc"]["holm_adjusted_p"]<.05 and
                comparisons[m]["discovery_auc"]["mean_difference"]>0 for m in comparisons)
    success=success and comparisons["ras_frt_uq"]["discovery_auc"]["mean_difference"]>=1
    success=success and all(comparisons[m]["F200"]["bootstrap_95_ci"][0]>=-1 for m in comparisons)
    value={"protocol":protocol,"aggregate":summary,"comparisons":comparisons,"success":success,
           "records":results,"statistical_unit":"10 independent Sobol pools",
           "scope":"same fixed FVDM and simulator; coordinate generalization, not independent new controller families",
           "p_test_assumption":"paired differences are sign exchangeable under the null",
           "full_pool_recall_evaluated":False,"secondary_p_values_are_exploratory":True}
    write_json(FOLDER/"summary.json",value)
    for method in METHODS:
        print(method,{k:round(v["mean"],3) for k,v in summary[method].items()},flush=True)
    print("PRIMARY",{m:comparisons[m]["discovery_auc"] for m in comparisons},flush=True)
    print("PREDECLARED SUCCESS",success,flush=True)
    draw(value)


def draw(value):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    fig,ax=plt.subplots(figsize=(9,5))
    labels={"candidate":"Response-vector GP","main":"Frozen history GP","ras_frt_uq":"RAS-FRT-UQ",
            "knn_history":"Historical kNN ranking","emulator_rank":"Neural history ranking","emulator_physical":"Neural prior + physical GP"}
    for method,rows in value["records"].items():
        curves=np.asarray([row["curve"] for row in rows])
        mean=curves.mean(axis=0)
        line,=ax.plot(np.arange(1,201),mean,label=labels[method],linewidth=2)
        error=curves.std(axis=0,ddof=1)/np.sqrt(len(rows))
        ax.fill_between(np.arange(1,201),mean-1.96*error,mean+1.96*error,color=line.get_color(),alpha=.1)
    ax.set(xlabel="Target scenario calls",ylabel="Discovered collisions")
    ax.legend(fontsize=8)
    ax.grid(alpha=.2)
    fig.tight_layout()
    fig.savefig(FOLDER/"discovery.png",dpi=200)
    fig.savefig(FOLDER/"discovery.pdf")
    plt.close(fig)


if __name__=="__main__":
    main()
