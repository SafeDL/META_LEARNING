"""Exact shared-covariance mixture GP and bounded-budget ENS approximation."""
import math

import numpy as np
import torch
from scipy.spatial.distance import cdist

from methods.history_guided_testing.config import GROUPS
from .config import BUDGET, NOISE, QUADRATURE, SHORTLIST, THRESHOLD


def source_predictions(history, x):
    names, estimates, weights = [], [], []
    groups = [tuple(name for name in members if name in history) for members in GROUPS.values()]
    groups = [members for members in groups if members]
    for members in groups:
        for name in members:
            source = history[name]
            distances = cdist(x, source["x"])
            nearest = np.argsort(distances, axis=1, kind="stable")[:, :8]
            distances = np.take_along_axis(distances, nearest, axis=1)
            local = np.exp(-.5 * (distances / .15) ** 2)
            local /= local.sum(axis=1, keepdims=True)
            estimates.append((local * source["risk"][nearest]).sum(axis=1))
            weights.append(1 / len(groups) / len(members))
            names.append(name)
    return names, np.asarray(estimates).T, np.asarray(weights)


def exceedance(mean, variance):
    return torch.special.ndtr((mean - THRESHOLD) / variance.clamp(min=1e-14).sqrt())


class HypothesisSession:
    def __init__(self, covariance, source_means, weights, *, mixture=True,
                 lookahead=False, budget=BUDGET, noise=NOISE, device="cuda",
                 utility="event", threshold=THRESHOLD, horizon=None):
        self.covariance = torch.as_tensor(covariance, dtype=torch.float64, device=device).clone()
        means = torch.as_tensor(source_means, dtype=torch.float64, device=device)
        weights = torch.as_tensor(weights, dtype=torch.float64, device=device)
        self.mean = means.clone() if mixture else (means @ weights)[:, None]
        self.log_weights = weights.log() if mixture else weights.new_zeros(1)
        self.remaining = torch.ones(len(means), dtype=torch.bool, device=device)
        self.lookahead = lookahead
        self.noise, self.budget = noise, budget
        self.utility, self.threshold = utility, threshold
        self.horizon = horizon
        self.pending, self.count = None, 0
        self.records = []
        nodes, masses = np.polynomial.hermite.hermgauss(QUADRATURE)
        self.nodes = torch.as_tensor(nodes * math.sqrt(2), dtype=means.dtype, device=device)
        self.masses = torch.as_tensor(masses / math.sqrt(math.pi), dtype=means.dtype, device=device)

    @property
    def weights(self):
        return self.log_weights.softmax(0)

    def probabilities(self):
        per_source = self.reward(self.mean, self.covariance.diag()[:, None])
        return per_source @ self.weights, per_source

    def reward(self, mean, variance):
        sd = variance.clamp(min=1e-14).sqrt()
        if self.utility == "event":
            return torch.special.ndtr((mean - self.threshold) / sd)
        threshold = .5 if self.utility == "excess" else 0.
        def positive_part(bound):
            z = (mean - bound) / sd
            return (mean - bound) * torch.special.ndtr(z) + sd * torch.exp(-.5 * z.square()) / math.sqrt(2 * math.pi)
        return positive_part(threshold) - positive_part(1.)

    def next_index(self):
        if self.pending is not None:
            raise RuntimeError("Observe pending query first")
        if self.count >= self.budget or not self.remaining.any():
            return None
        probability, per_source = self.probabilities()
        scores = probability.masked_fill(~self.remaining, -torch.inf)
        index = int(scores.argmax())
        extra_value = 0.
        if self.lookahead and self.budget - self.count > 1:
            disagreement = ((per_source - probability[:, None]).square() @ self.weights)
            information = disagreement + probability * (1 - probability)
            information = information.masked_fill(~self.remaining, -torch.inf)
            size = min(SHORTLIST // 2, int(self.remaining.sum()))
            proposals = torch.unique(torch.cat((scores.topk(size).indices,
                                                information.topk(size).indices)))
            values = self.fantasy_values(proposals, probability)
            best = int(values.argmax())
            index = int(proposals[best])
            extra_value = float(values[best] - probability[index])
        self.pending = index
        self.records.append({"query_number": self.count + 1, "index": index,
                             "probability": float(probability[index]),
                             "future_utility": extra_value,
                             "weights_before": self.weights.cpu().tolist()})
        return index

    def fantasy_values(self, proposals, probability):
        # Fantasies are integrations under the Gaussian working likelihood.
        # They never become observations and are never clipped to physical risk.
        future_count = min(self.budget - self.count - 1, int(self.remaining.sum()) - 1)
        if self.horizon is not None:
            future_count = min(future_count, self.horizon)
        weights = self.weights
        values = []
        variance = self.covariance.diag()
        for index in proposals:
            denominator = variance[index] + self.noise
            outcomes = (self.mean[index, :, None] + denominator.sqrt() * self.nodes).flatten()
            masses = (weights[:, None] * self.masses).flatten()
            likelihood = -.5 * (outcomes[:, None] - self.mean[index]).square() / denominator
            posterior_weights = (self.log_weights + likelihood).softmax(-1)
            cross = self.covariance[:, index]
            future_variance = (variance - cross.square() / denominator).clamp(min=0)
            future_mean = self.mean[None, :, :] + cross[None, :, None] / denominator * (
                outcomes[:, None, None] - self.mean[index][None, None, :])
            future_probability = (self.reward(future_mean, future_variance[None, :, None]) *
                                  posterior_weights[:, None, :]).sum(-1)
            future_probability[:, ~self.remaining] = -torch.inf
            future_probability[:, index] = -torch.inf
            utility = future_probability.topk(future_count, dim=1).values.sum(1)
            values.append(probability[index] + utility @ masses)
        return torch.stack(values)

    def observe(self, risk):
        if self.pending is None:
            raise RuntimeError("Request query before feedback")
        index = self.pending
        if risk is not None:
            if not np.isfinite(risk) or not 0 <= risk <= 1:
                raise ValueError("Invalid measured risk")
            cross = self.covariance[:, index].clone()
            denominator = self.covariance[index, index] + self.noise
            residual = risk - self.mean[index].clone()
            self.log_weights += -.5 * residual.square() / denominator
            self.log_weights -= torch.logsumexp(self.log_weights, 0)
            self.mean += cross[:, None] / denominator * residual
            self.covariance -= cross[:, None] * cross[None, :] / denominator
        self.records[-1]["risk"] = risk
        self.records[-1]["weights_after"] = self.weights.cpu().tolist()
        self.remaining[index] = False
        self.pending = None
        self.count += 1
