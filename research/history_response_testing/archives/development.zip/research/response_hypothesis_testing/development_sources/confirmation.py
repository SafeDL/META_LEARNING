"""Locked, paired physical confirmation with process-isolated selectors."""
from concurrent.futures import ProcessPoolExecutor, ThreadPoolExecutor
import hashlib
import json
import multiprocessing as mp
from pathlib import Path
import threading

import numpy as np
from scipy.stats import qmc
import torch

from methods.history_guided_testing.config import BOUNDS, ROOT as BASELINE, TARGET
from methods.history_guided_testing.history import load_history, historical_risk, split_indices, subset
from methods.history_guided_testing.prepare import measure_scene
from methods.history_guided_testing.scenarios import scene_library, parameter_cells
from .config import BUDGET, OUTPUT, SEEDS
from .core import HypothesisSession, source_predictions
from .emulator import predict
from .freeze import freeze
from .response_kernel import covariance
from .run import write_json

FOLDER=OUTPUT/"confirmation"
METHODS=("candidate","main","ras_frt_uq","knn_history","emulator_rank","emulator_physical")
POOL_SEEDS=tuple((990001+137*i,990002+137*i) for i in range(10))


def protocol():
    path=FOLDER/"protocol.json"
    if path.exists():
        return json.loads(path.read_text(encoding="utf-8"))
    value={"locked_on":"2026-10-05 Asia/Shanghai","pool_sampling_seeds":POOL_SEEDS,
           "methods":METHODS,"training_seeds":SEEDS,"training_seed_per_pool":[SEEDS[i%5] for i in range(10)],
           "candidate":{"prior":"group-balanced explicit neural source risk means",
                        "kernel":"Matern52 on all six source risks plus physical Matern52",
                        "response_length":.05,"physical_length":.2,"physical_weight":.1,
                        "sigma":.25,"noise":.05,"utility":"expected clipped continuous risk",
                        "source_posterior":False,"lookahead":False},
           "budget":BUDGET,"scenes_per_family":1024,"target_profile":"unchanged frozen FVDM",
           "primary_metric":"mean cumulative collision count across all 200 queries (discovery_auc)",
           "independent_unit":"new Sobol candidate pool, not individual scenarios or training seeds",
           "primary_comparisons":["main","ras_frt_uq"],
           "significance":"two-sided exact paired sign-flip, Holm correction of two primary comparisons",
           "success":"positive AUC improvement with Holm p<0.05 against both; mean AUC gain >=1 against RAS; paired F200 95% CI lower bound >=-1",
           "secondary_metrics":["F10","F50","F100","F200","collision parameter cells","risk QD score"],
           "selection":"locked after all original-target development trials; new physical responses not read",
           "physical_execution":"only selected scenarios and shared cached measurements; no pool recall claim",
           "feedback":{"ras_frt_uq":"queried binary collision","other_methods":"queried continuous risk"},
           "model_sha256":{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (OUTPUT/"models").glob("emulator_*.pt")},
           "source_sha256":{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in
              [Path(__file__).parent/n for n in ("core.py","emulator.py","response_kernel.py","confirmation.py")]}}
    write_json(path,value)
    return value


def new_scenes(pool_index):
    scenes=scene_library("target")
    for family,seed in enumerate(POOL_SEEDS[pool_index]):
        points=qmc.Sobol(4,scramble=True,seed=seed).random_base2(10)
        bounds=np.asarray(BOUNDS[family])
        for index,point in enumerate(points):
            scene=scenes[family*1024+index]
            scene["numeric_input"]=[*point.tolist(),family]
            scene["active_parameters"]=dict(zip(scene["active_parameters"],
                (bounds[:,0]+point*(bounds[:,1]-bounds[:,0])).tolist()))
            scene["scenario_id"]=f"confirmation:{pool_index}:{family}:{index:04d}"
            scene["sampling_seed"]=seed
    return scenes


def ras_predictions(x,seed):
    from methods.ras_frt_uq.unified import MODEL_ROOT,ResponseEncoder,predict_response
    state=torch.load(MODEL_ROOT/f"seed_{seed}.pt",map_location="cpu",weights_only=True)
    result=np.zeros((len(x),6))
    for family in (0,1):
        indices=np.flatnonzero(x[:,4]==family)
        model=ResponseEncoder(6).cuda().eval().requires_grad_(False)
        model.load_state_dict(state["encoders"][str(family)])
        result[indices]=predict_response(model,x[indices,:4])
    return result


def selector(connection,method,seed,x,prior,means,weights,ras_response):
    from methods.history_guided_testing.experiment import RemoteOracle
    from methods.history_guided_testing.search import TestingSession,select_session
    from methods.history_guided_testing.train import load_kernel
    from methods.ras_frt_uq.unified import select_from_responses
    torch.set_num_threads(1)
    oracle=RemoteOracle(connection)
    try:
        if method=="ras_frt_uq":
            value=select_from_responses(x,parameter_cells(x),ras_response,oracle,seed)
        elif method=="main":
            value=select_session(TestingSession(x,seed,mode="global_feedback",prior=prior),oracle)
        elif method in ("knn_history","emulator_rank"):
            scores=prior if method=="knn_history" else means@weights
            selected=np.argsort(-scores,kind="stable")[:BUDGET].tolist()
            rows=[]
            for index in selected:
                observation=oracle.query(index)
                rows.append({"index":index,"risk":observation.risk,"query_number":observation.query_number})
            value={"selected_indices":selected,"queries":rows}
        else:
            if method=="candidate":
                # CUDA is used for offline training and parent-side feature inference.
                # Independent selector processes use the same exact CPU float64 updates.
                response=torch.as_tensor(means,dtype=torch.float64)
                inputs=torch.as_tensor(x,dtype=torch.float64)
                from methods.history_guided_testing.kernel import matern52
                distance=torch.cdist(response,response)/np.sqrt(means.shape[1])
                physical_distance=torch.cdist(inputs[:,:4],inputs[:,:4])
                kernel=.25**2*(.9*matern52(distance,.05)+.1*matern52(physical_distance,.2))*(inputs[:,4:5]==inputs[:,4:5].T)
            else:
                with torch.no_grad():
                    kernel=load_kernel(seed,"global_feedback").covariance(x)
            session=HypothesisSession(kernel,means,weights,mixture=False,utility="risk",noise=.05,device="cpu")
            selected=[]
            while (index:=session.next_index()) is not None:
                observation=oracle.query(index)
                session.observe(observation.risk)
                selected.append(index)
            value={"selected_indices":selected,"queries":session.records}
        connection.send(("result",value))
    except Exception as error:
        connection.send(("error",repr(error)))
        raise
    finally:
        connection.close()


def main():
    freeze()
    locked=protocol()
    for name,digest in locked["model_sha256"].items():
        assert hashlib.sha256((OUTPUT/"models"/name).read_bytes()).hexdigest()==digest
    torch.set_num_threads(1)
    history=load_history()
    train,_=split_indices(next(iter(history.values()))["x"])
    history=subset(history,train)
    pools=[]
    for i in range(10):
        seed=SEEDS[i%5]
        scenes=new_scenes(i)
        x=np.asarray([scene["numeric_input"] for scene in scenes])
        original=np.load(BASELINE/"target/responses.npz")["x"]
        assert not set(map(tuple,x))&set(map(tuple,original))
        assert not set(map(tuple,x))&set(map(tuple,next(iter(history.values()))["x"]))
        folder=FOLDER/f"pool_{i}"
        write_json(folder/"scenarios.json",scenes)
        means,_=predict(x,seed)
        _,_,weights=source_predictions(history,x)
        prior=historical_risk(history,x)
        ras=ras_predictions(x,seed)
        pools.append((scenes,x,prior,means,weights,ras))
    context=mp.get_context("spawn")
    lock=threading.Lock()
    cache={}
    pending={}
    for i in range(10):
        path=FOLDER/f"pool_{i}"/"measurements.jsonl"
        if path.exists():
            for line in path.read_text(encoding="utf-8").splitlines():
                row=json.loads(line)
                cache[(i,row["index"])]=row
    print("Locked confirmation starts; cached physical measurements:",len(cache),flush=True)
    with ProcessPoolExecutor(max_workers=12,mp_context=context) as simulator:
        def measurement(pool,index):
            key=(pool,index)
            with lock:
                if key in cache:
                    return cache[key]
                if key not in pending:
                    pending[key]=simulator.submit(measure_scene,(pools[pool][0][index],TARGET))
                future=pending[key]
            row={**future.result(),"index":index}
            with lock:
                if key not in cache:
                    cache[key]=row
                    path=FOLDER/f"pool_{pool}"/"measurements.jsonl"
                    with path.open("a",encoding="utf-8") as handle:
                        handle.write(json.dumps(row)+"\n")
                    if len(cache)%100==0:
                        print("Confirmation physical calls:",len(cache),flush=True)
            return row

        def run_one(arguments):
            pool,method=arguments
            destination=FOLDER/f"pool_{pool}"/f"{method}.json"
            if destination.exists():
                return
            seed=SEEDS[pool%5]
            scenes,x,prior,means,weights,ras=pools[pool]
            parent,child=context.Pipe()
            process=context.Process(target=selector,args=(child,method,seed,x,prior,means,weights,ras))
            process.start()
            child.close()
            disclosed=set()
            try:
                while True:
                    message,value=parent.recv()
                    if message=="query":
                        if value in disclosed or len(disclosed)>=BUDGET or not 0<=value<len(x):
                            raise ValueError("Duplicate, invalid or over-budget query")
                        disclosed.add(value)
                        row=measurement(pool,value)
                        parent.send((None,bool(row["collision"])) if method=="ras_frt_uq" else (float(row["risk"]),None))
                        if len(disclosed)%50==0:
                            print("Queries",pool,method,len(disclosed),flush=True)
                    elif message=="result":
                        assert len(value["selected_indices"])==BUDGET
                        assert set(value["selected_indices"])==disclosed
                        write_json(destination,{**value,"pool":pool,"seed":seed,"method":method,
                                   "budget":BUDGET,"feedback":locked["feedback"]["ras_frt_uq" if method=="ras_frt_uq" else "other_methods"]})
                        print("Confirmation sequence locked:",pool,method,flush=True)
                        break
                    else:
                        raise RuntimeError(value)
            finally:
                parent.close()
                process.join(timeout=10)
                if process.is_alive():
                    process.terminate()
                    process.join()
        with ThreadPoolExecutor(max_workers=12) as executor:
            for _ in executor.map(run_one,[(pool,method) for pool in range(10) for method in METHODS]):
                pass
    write_json(FOLDER/"physical_cost.json",{"unique_new_simulator_calls":len(cache),
        "simulator_seconds":sum(row["elapsed_s"] for row in cache.values()),
        "queried_scenarios_only":True,"selector_queries":10*len(METHODS)*BUDGET,
        "all_sequences_locked":True})
    freeze()
    print("Physical confirmation complete",flush=True)


if __name__=="__main__":
    main()
