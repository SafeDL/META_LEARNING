from pathlib import Path

ROOT = Path(__file__).resolve().parent
OUTPUT = ROOT / "results"
BUDGET = 200
SEEDS = (11, 23, 37, 53, 71)
SOURCE_WEIGHTS = (1/8, 1/8, 1/8, 1/8, 1/4, 1/4)
