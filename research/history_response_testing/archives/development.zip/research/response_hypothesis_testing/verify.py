"""Replay every final sequence and verify physical and source provenance."""
import hashlib
import json
import zipfile

import numpy as np
import torch

from methods.history_guided_testing.config import TARGET
from methods.history_guided_testing.prepare import measure_scene
from .config import OUTPUT, ROOT, SEEDS, SOURCE_WEIGHTS
from .dual import ResponseTestingSession
from .emulator import predict
from .freeze import freeze
from .io import write_json
from .prepare import fresh_scenes
from .response_kernel import covariance


def main():
    torch.set_num_threads(1)
    frozen = freeze()
    folder = OUTPUT / "fresh_confirmation"
    protocol = json.loads((folder / "protocol.json").read_text(encoding="utf-8"))
    calibration = {int(key): value for key, value in protocol["calibration"].items()}
    with zipfile.ZipFile(ROOT / "research_source.zip") as archive:
        for name, digest in protocol["source_sha256"].items():
            original = archive.read(f"research/response_hypothesis_testing/{name}")
            assert hashlib.sha256(original).hexdigest() == digest
    with zipfile.ZipFile(ROOT / "development_source.zip") as archive:
        first = json.loads((OUTPUT / "confirmation/protocol.json").read_text(encoding="utf-8"))
        for name, digest in first["source_sha256"].items():
            assert hashlib.sha256(archive.read(f"research/response_hypothesis_testing/{name}")).hexdigest() == digest
    for name, digest in protocol["model_sha256"].items():
        assert hashlib.sha256((OUTPUT / "models" / name).read_bytes()).hexdigest() == digest
    replayed, physical = [], []
    for pool in range(20):
        current = folder / f"pool_{pool}"
        scenes = json.loads((current / "scenarios.json").read_text(encoding="utf-8"))
        assert fresh_scenes(pool) == scenes
        x = np.asarray([scene["numeric_input"] for scene in scenes])
        rows = {row["index"]: row for row in map(json.loads,
                (current / "measurements.jsonl").read_text(encoding="utf-8").splitlines())}
        risk, collision = predict(x, SEEDS[pool % 5])
        kernel = covariance(x, risk, .05, physical_weight=.1, device="cpu")
        for method, mode in (("candidate", "dual"), ("risk_only", "risk"), ("calibrated_only", "calibrated")):
            expected = json.loads((current / f"{method}.json").read_text(encoding="utf-8"))["selected_indices"]
            session = ResponseTestingSession(x, kernel, risk, collision, np.asarray(SOURCE_WEIGHTS),
                                             calibration, mode=mode, device="cpu")
            selected = []
            while (index := session.next_index()) is not None:
                assert index == expected[len(selected)], (pool, method, len(selected), index)
                session.observe(float(rows[index]["risk"]))
                selected.append(index)
            assert selected == expected
            replayed.append({"pool": pool, "method": method, "queries": len(selected)})
        if pool in (0, 10, 19):
            for family in (0, 1):
                index = next(i for i in expected if x[i, 4] == family)
                measured = measure_scene((scenes[index], TARGET))
                assert abs(measured["risk"] - rows[index]["risk"]) < 1e-12
                assert measured["collision"] == rows[index]["collision"]
                physical.append({"pool": pool, "index": index, "risk_matches": True, "collision_matches": True})
        print("Verified final sequences:", pool, flush=True)
    write_json(OUTPUT / "verification.json", {
        "frozen_files_unchanged": len(frozen["sha256"]), "archived_locked_sources_match": True,
        "model_hashes_match": True, "saved_sequences_replayed": replayed,
        "identical_selected_queries": sum(r["queries"] for r in replayed), "physical_replays": physical,
        "final_active_source_sha256": {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in ROOT.glob("*.py")},
    })
    freeze()
    print("Verification complete", flush=True)


if __name__ == "__main__":
    main()
