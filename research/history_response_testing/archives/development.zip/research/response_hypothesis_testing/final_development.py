"""Final candidate on the original, fully inspected target for nine-baseline comparison."""
import numpy as np
import torch

from methods.history_guided_testing.config import ROOT as BASELINE
from methods.history_guided_testing.evaluate import discovery_metrics
from .config import OUTPUT, SEEDS
from .dual import ResponseTestingSession
from .emulator import predict
from .response_kernel import covariance
from .io import write_json
from .calibration import calibrators


def main():
    torch.set_num_threads(1)
    bank = np.load(BASELINE / "target/responses.npz")
    calibration = calibrators()
    weights = np.array([.125, .125, .125, .125, .25, .25])
    for seed in SEEDS:
        path = OUTPUT / "final_development" / f"candidate_{seed}.json"
        if path.exists():
            continue
        risks, collisions = predict(bank["x"], seed)
        kernel = covariance(bank["x"], risks, .05, physical_weight=.1)
        session = ResponseTestingSession(bank["x"], kernel, risks, collisions, weights, calibration)
        selected = []
        while (index := session.next_index()) is not None:
            session.observe(float(bank["risk"][index]))
            selected.append(index)
        result = discovery_metrics(bank, selected)
        write_json(path, {**result, "selected_indices": selected, "queries": session.records,
                         "seed": seed, "stage": "original-target development only"})
        print("Final development", seed, [result["checkpoints"][str(k)]["collisions"] for k in (50,100,200)],
              round(result["discovery_auc"],3), flush=True)


if __name__ == "__main__":
    main()
