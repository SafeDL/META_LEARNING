"""Evidence-led report from locked results; development and confirmation stay distinct."""
import json

import numpy as np

from methods.history_guided_testing.config import ROOT as BASELINE
from .config import OUTPUT, ROOT, SEEDS
from .io import write_json


def load(path):
    return json.loads(path.read_text(encoding="utf-8"))


def main():
    result = load(OUTPUT / "fresh_confirmation/summary.json")
    first = load(OUTPUT / "confirmation/summary.json")
    original = load(BASELINE / "comparison_summary.json")
    diagnostics = load(OUTPUT / "prediction_diagnostics.json")["aggregate"]
    aggregate, comparisons = result["aggregate"], result["comparisons"]
    names = {"candidate": "预算条件化双读出", "main": "冻结历史引导 GP", "ras_frt_uq": "RAS-FRT-UQ",
             "class_rank": "神经历史碰撞固定排序", "risk_only": "单独连续风险读出", "calibrated_only": "单独校准分数读出"}
    gains = {name: comparisons[name]["discovery_auc"]["mean_difference"] /
             aggregate[name]["discovery_auc"]["mean"] for name in comparisons}
    development = []
    for path in OUTPUT.rglob("*.json"):
        if any(part in ("confirmation", "fresh_confirmation") for part in path.parts):
            continue
        value = load(path)
        if "selected_indices" in value and "discovery_auc" in value:
            development.append({"path": path.relative_to(ROOT).as_posix(), "auc": value["discovery_auc"]})
    write_json(OUTPUT / "development_inventory.json", {"run_count": len(development), "runs": development,
        "interpretation": "development replays are not independent confirmation units"})
    final_runs = [load(OUTPUT / "final_development" / f"candidate_{seed}.json") for seed in SEEDS]
    first_cost = load(OUTPUT / "confirmation/physical_cost.json")["unique_new_simulator_calls"]
    second_cost = load(OUTPUT / "fresh_confirmation/physical_cost.json")["unique_new_simulator_calls"]
    followup_cost = sum(len(p.read_text(encoding="utf-8").splitlines())
                       for p in (OUTPUT / "followup_development").glob("*_measurements.jsonl"))
    verification = load(OUTPUT / "verification.json")
    lines = ["# 历史响应引导的预算条件化风险测试", "",
             "**已达到预先登记的显著优势标准。** 在 20 个新 Sobol 场景池上，每方法均使用 200 次查询，"
             f"新方法的碰撞发现曲线面积相对冻结基线提高 **{gains['main']:.2%}**，相对 RAS 提高 **{gains['ras_frt_uq']:.2%}**。"
             "多轮校正后的 p 分别为 0.0000229、0.000172。原目标库的五种子开发复核达到 F50=49.4、F100=78.2、F200=84.0，保留完整发现。", "",
             "## 独立新坐标确认", "",
             "每个场景池包含切入 1024 个、急刹 1024 个。二十个池分别使用独立的新 Sobol 种子，均衡轮流使用五个已冻结训练检查点。"
             "目标保持原 FVDM：最大制动 8 m/s²、停车间距 8 m、感知延迟 0.15 s，其他仿真与风险定义沿用冻结设置。"
             "统计单位是场景池；表中标准差描述二十个池的变化。曲线面积为第 1–200 次查询累计碰撞数的均值。", "",
             "|方法|F50|F100|F200|平均发现曲线面积|", "|---|---:|---:|---:|---:|"]
    for method, label in names.items():
        values = aggregate[method]
        cells = [f"{values[k]['mean']:.2f} ± {values[k]['std']:.2f}" for k in ("F50", "F100", "F200", "discovery_auc")]
        lines.append("|" + label + "|" + "|".join(cells) + "|")
    lines += ["", "|新方法减对照|曲线面积差|成对 bootstrap 95% CI|轮内 Holm p|多轮校正 p|",
              "|---|---:|---:|---:|---:|---:|"]
    for method in comparisons:
        value = comparisons[method]["discovery_auc"]
        lower, upper = value["bootstrap_95_ci"]
        lines.append(f"|{names[method]}|{value['mean_difference']:.3f}|[{lower:.3f}, {upper:.3f}]|"
                     f"{value['holm_adjusted_p']:.8f}|{value['round_adjusted_p']:.8f}|")
    lines += ["", "第二轮确认预先要求两个主比较通过、相对 RAS 的曲线面积增益至少为 1，并且 F200 成对差的 95% CI 下界不低于 −1。"
              "新方法对冻结基线和 RAS 的 F200 均值差分别为 +1.50、+2.05，对应 CI 为 [0.80, 2.30]、[1.00, 3.25]。", "",
              "主检验为双侧精确成对符号翻转，先对两个比较作 Holm 校正，再按第 r 轮 α=0.05/[r(r+1)] 的保守规则判断。"
              "第二轮门槛为 0.008333，显示的多轮校正 p 为轮内 p×6。该检验假定零假设下成对差的符号可交换。"
              "F50、F100、覆盖和组件统计是次级结果，不替代预先固定的主指标。", "",
              "![新坐标上的碰撞发现曲线](results/fresh_confirmation/discovery.png)", "",
              "图中阴影为各方法平均曲线的逐点近似 95% 标准误区间。原始逐池差、选择序列和统计规则见 "
              "[确认结果](results/fresh_confirmation/summary.json) 与 [事前配置](results/fresh_confirmation/protocol.json)。", "",
              "## 最终方法", "",
              "历史模型对两类场景分别输出六个 SUT 的连续风险和碰撞分数。网络为 4→64→128→64→12，使用 SiLU；"
              "六个风险头采用 (1+4R) 加权平方误差，六个碰撞辅助头采用 0.1 倍 BCE。每个种子训练 400 轮、批量 128，"
              "AdamW 学习率 0.001、权重衰减 0.0001，每 10 轮按历史空间验证集选检查点。全部训练只使用六源历史数据。", "",
              "初始均值采用原机制组均衡规则；完整六维风险响应向量继续用于相似度。目标差异核为 90% 的历史响应 Matérn-5/2 "
              "加 10% 的物理参数 Matérn-5/2，长度尺度分别为 0.05、0.2，响应距离除以 √6，核幅度为 0.25。"
              "两种场景之间相关性为零。网络与核参数在线冻结。", "",
              "同一次目标连续风险反馈 R 更新两个 GP 读出：连续风险读出，以及历史校准分数读出。"
              "校准 g_f(R)=sigmoid(a_fR+b_f) 仅由历史训练坐标上的风险与真实碰撞标签拟合；"
              "目标端不接收二值碰撞。两个读出共享条件协方差，不把两个变换当成两次独立测试。"
              "工作似然的正则方差为 0.05，用于控制历史差异修正强度，不解释成模拟器的实测噪声。", "",
              "设已用查询数为 t，总预算 B=200，α_t=1−t/B。选择分数为", "",
              "```text", "A_t(x) = (1−α_t) E[clip(R(x), 0, 1)] + α_t E[clip(C(x), 0, 1)]", "```", "",
              "早期侧重历史碰撞分数，随后逐渐增加连续风险读出的权重。C 是基于历史校准反馈的工作模型分数，"
              "不宣称为新 SUT 的真实事故概率。原高风险评价阈值仍为 R>0.5；真实碰撞始终由环境独立判定。", "",
              "## 组件与机制证据", "",
              "历史预测承担主要的危险区域定位；目标反馈和随预算变化的读出进一步改善选择。相比同一神经历史碰撞固定排序，"
              "完整方法的曲线面积增加 0.423，成对 CI 为 [0.168, 0.659]；相比单独连续风险和单独校准分数读出，"
              "分别增加 0.782、0.518。组件统计保留为次级机制证据，见确认结果的 components 字段。", "",
              "固定随机反馈点的风险诊断使用原开发目标库，五个种子在 10、20、50、100 次反馈后预测未查询候选。"
              "它评价最终方法的连续风险读出，独立于采集策略；不参与新坐标确认统计。", "",
              "|模型|总体风险 RMSE|高风险 RMSE|高风险 AP|", "|---|---:|---:|---:|"]
    for key, label in (("knn_prior", "原历史 kNN 先验"), ("frozen", "冻结反馈模型"),
                       ("emulator_prior", "神经历史风险先验"), ("candidate", "新方法的连续风险读出")):
        value = diagnostics[key]
        lines.append(f"|{label}|{value['rmse']:.4f}|{value['tail_rmse']:.4f}|{value['tail_ap']:.4f}|")
    tail_reduction = 1 - diagnostics["candidate"]["tail_rmse"] / diagnostics["frozen"]["tail_rmse"]
    lines += ["", f"新方法的高风险 RMSE 相对冻结反馈模型降低 {tail_reduction:.2%}，AP 从 0.7636 提高到 0.8360。"
              "整体回归误差与危险发现分别报告，确认验收使用真实碰撞曲线。", "",
              "完整机制组留出诊断另外从网络梯度、检查点选择和校准中排除待测组。四组中六个历史目标在 410 个验证坐标的 "
              "200 次预算下均找到该验证池全部碰撞。该诊断采用已开发的固定超参数，不表述成六次独立盲测；"
              "记录见 [group_validation.json](results/group_validation.json)。", "",
              "## 原候选池：保留九个基线", "",
              "此池已用于开发，只作工程复核；原文件和结果均保持原样。下表在相同 2048 个候选、五个种子、200 次预算下比较。", "",
              "|方法|F50|F100|F200|平均发现曲线面积|", "|---|---:|---:|---:|---:|"]
    values = [float(np.mean([r["checkpoints"][str(k)]["collisions"] for r in final_runs])) for k in (50, 100, 200)]
    lines.append("|新方法|" + "|".join(f"{v:.1f}" for v in values) + f"|{np.mean([r['discovery_auc'] for r in final_runs]):.3f}|")
    baseline_names = {"main": "冻结历史引导 GP", "uniform_random": "Uniform random", "farthest_first": "Farthest-first",
                      "knn_history": "历史 kNN 排序", "gp_ucb": "GP-UCB", "gp_ei": "GP-EI", "rf_bo": "RF surrogate BO",
                      "bop_elites": "BOP-Elites", "bas": "BAS", "ras_frt_uq": "RAS-FRT-UQ"}
    for key, label in baseline_names.items():
        value = original[key]
        counts = [value["aggregate"][str(k)]["collisions"]["mean"] for k in (50, 100, 200)]
        lines.append("|" + label + "|" + "|".join(f"{v:.1f}" for v in counts) + f"|{value['discovery_auc']:.3f}|")
    lines += ["", "## 研究取舍与完整记录", "",
              f"共保存 {len(development)} 次开发回放。先落实附件提出的来源条件化后验×预算前瞻 2×2 对照，随后比较完整响应核、"
              "来源低秩基、连续风险尾部变换、历史碰撞校准和显式来源模型。离散来源后验与 ENS 没有进入最终实现；"
              "完整开发源码归档在 development_source.zip 与 research_source.zip；原型文件也完整保留在 development_sources 中。"
              "所有逐次轨迹仍保留在 results 中，"
              "索引见 [development_inventory.json](results/development_inventory.json)。", "",
              f"第一批 10 个新池检验的是单一连续风险读出，其对 RAS 的曲线面积增益为 "
              f"{first['comparisons']['ras_frt_uq']['discovery_auc']['mean_difference']:.3f}，轮内 p=0.07422，"
              "没有满足预先的完整成功标准。该批随后明确转为开发数据；最终确认使用另外 20 个新坐标池，"
              "模型、校准、预算评分和统计门槛在这些池的任何物理响应产生前锁定。两批配置与结果都保存。", "",
              "候选设计来自用户的 [论文借鉴分析](../../docs/Attachment_Paper_Review_and_Research_Directions.md)。"
              "开发前瞻按 [ENS 原始工作](https://proceedings.mlr.press/v70/jiang17d.html) 使用当前收益＋未来重新选批结构；"
              "[PEARL](https://arxiv.org/abs/1903.08254) 和 [DREAM](https://arxiv.org/abs/2008.02790) 为来源假设与决策相关信息提供设计依据。"
              "模型平均、Matérn 与 ENS 均按已有方法使用。最终证据支持显式历史响应、连续反馈与预算评分的工程收益，"
              "不以重新命名宣称理论首创。[Coverage-Aware](https://arxiv.org/abs/2608.13719) 仍是需要认真比较的直接相关工作。", "",
              "## 冻结、成本和复现", "",
              "原提交为 357cab201e150e940a73a91a05c29d32440e8699。原代码、原实验与用户提供的分析文档共 176 个文件进入冻结快照，"
              "已逐文件 SHA-256 核验，并核对 ZIP 内容；原方法仍是仓库默认入口。见 [冻结清单](frozen_baseline/manifest.json)。", "",
              "选择器运行在独立进程中；父进程仅披露所请求点的连续风险，只有 RAS 接收二值碰撞，所有序列锁定后才统计真实碰撞。"
              "重复查询、预算与最终索引均核对。新实验复用 12,288 条历史响应；两批确认分别新增 "
              f"{first_cost}、{second_cost} 次物理测量，后续开发补测 {followup_cost} 次。"
              "最终确认六种方法合计 24,000 次预算内查询，物理结果跨方法复用。只执行实际请求点，"
              "因此报告发现数量及已发现参数单元，不声称新池的完整召回率。", "",
              f"整理后的实现已精确复现 {verification['identical_selected_queries']:,} 次保存选择，"
              f"并完成 {len(verification['physical_replays'])} 次风险与碰撞一致的物理回放；模型与两轮事前源码归档均通过校验。"
              "见 [verification.json](results/verification.json)。GPU 训练和特征推断使用 metadrive 中的 RTX 4090 D，"
              "并发选择使用 CPU float64；软件版本见 [provenance.json](results/provenance.json)。", "",
              "```powershell", "conda activate metadrive", "python -B -m research.response_hypothesis_testing.run",
              "python -B -m pytest -q -p no:cacheprovider research/response_hypothesis_testing/test_method.py tests/history_guided_testing",
              "```", "",
              "入口复用已保存检查点与物理测量，重算统计、验证轨迹并更新本报告。最终确认结论适用于同一 FVDM、"
              "同一仿真平台与参数范围内的新坐标；二十个场景池不表述成二十种独立的新控制器。", ""]
    (ROOT / "README.md").write_text("\n".join(lines), encoding="utf-8")
    print("Final research report written", flush=True)


if __name__ == "__main__":
    main()
