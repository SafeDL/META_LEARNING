"""Similarity of full historical responses, with a physical residual channel."""
import numpy as np
import torch

from methods.history_guided_testing.kernel import matern52


def covariance(x, means, response_length=.2, physical_length=.2,
               physical_weight=.1, sigma=.25, device="cuda"):
    x = torch.as_tensor(x, dtype=torch.float64, device=device)
    means = torch.as_tensor(means, dtype=torch.float64, device=device)
    # RMS distances keep the response dimension comparable when a group is excluded.
    response_distance = torch.cdist(means, means) / np.sqrt(means.shape[1])
    physical_distance = torch.cdist(x[:, :4], x[:, :4])
    response = matern52(response_distance, response_length)
    physical = matern52(physical_distance, physical_length)
    return sigma ** 2 * ((1 - physical_weight) * response + physical_weight * physical) * (
        x[:, 4:5] == x[:, 4:5].T)
