"""History-only per-source response emulators; source outputs remain explicit."""
import numpy as np
import torch
from torch import nn
from torch.nn import functional as F
from methods.history_guided_testing.config import ROOT as BASELINE, PROFILES
from methods.history_guided_testing.history import split_indices
from .config import OUTPUT, SEEDS
from .io import write_json
NAMES = tuple((profile.name for profile in PROFILES))

class Emulator(nn.Module):

    def __init__(self):
        super().__init__()
        self.layers = nn.Sequential(nn.Linear(4, 64), nn.SiLU(), nn.Linear(64, 128), nn.SiLU(), nn.Linear(128, 64), nn.SiLU(), nn.Linear(64, 12))

    def forward(self, x):
        values = self.layers(x)
        return (values[:, :6].sigmoid(), values[:, 6:])

def train(seed):
    path = OUTPUT / 'models' / f'emulator_{seed}.pt'
    if path.exists():
        return
    bank = np.load(BASELINE / 'history/responses.npz')
    (train_indices, validation) = split_indices(bank['x'])
    torch.manual_seed(seed)
    rng = np.random.default_rng(seed)
    states = {}
    curves = {}
    for family in (0, 1):
        ti = train_indices[bank['x'][train_indices, 4] == family]
        vi = validation[bank['x'][validation, 4] == family]
        x = torch.as_tensor(bank['x'][:, :4], dtype=torch.float32, device='cuda')
        risk = torch.as_tensor(np.asarray([bank[n] for n in NAMES]).T, dtype=torch.float32, device='cuda')
        collision = torch.as_tensor(np.asarray([bank[n + '_collision'] for n in NAMES]).T, dtype=torch.float32, device='cuda')
        model = Emulator().cuda()
        optimizer = torch.optim.AdamW(model.parameters(), lr=0.001, weight_decay=0.0001)
        best = float('inf')
        curve = []
        for epoch in range(1, 401):
            model.train()
            order = rng.permutation(ti)
            for start in range(0, len(order), 128):
                indices = order[start:start + 128]
                (prediction, logits) = model(x[indices])
                loss = ((prediction - risk[indices]).square() * (1 + 4 * risk[indices])).mean() + 0.1 * F.binary_cross_entropy_with_logits(logits, collision[indices])
                optimizer.zero_grad(set_to_none=True)
                loss.backward()
                optimizer.step()
            if epoch % 10 == 0:
                model.eval()
                with torch.no_grad():
                    (prediction, logits) = model(x[vi])
                    error = ((prediction - risk[vi]).square() * (1 + 4 * risk[vi])).mean() + 0.1 * F.binary_cross_entropy_with_logits(logits, collision[vi])
                error = float(error)
                curve.append({'epoch': epoch, 'validation_loss': error})
                if error < best:
                    best = error
                    states[str(family)] = {k: v.detach().cpu().clone() for (k, v) in model.state_dict().items()}
        curves[str(family)] = curve
        print('History emulator', seed, family, 'validation', best, flush=True)
    path.parent.mkdir(parents=True, exist_ok=True)
    torch.save({'states': states, 'source_names': NAMES, 'seed': seed}, path)
    write_json(OUTPUT / 'models' / f'emulator_{seed}.json', {'curves': curves, 'epochs': 400, 'target_data_used': False, 'historical_collision_heads': True, 'risk_tail_weight': 4})

def predict(x, seed):
    state = torch.load(OUTPUT / 'models' / f'emulator_{seed}.pt', weights_only=True)
    risks = np.zeros((len(x), 6))
    probabilities = np.zeros((len(x), 6))
    for family in (0, 1):
        indices = np.flatnonzero(x[:, 4] == family)
        model = Emulator().cuda().eval().requires_grad_(False)
        model.load_state_dict(state['states'][str(family)])
        with torch.no_grad():
            (risk, logits) = model(torch.as_tensor(x[indices, :4], dtype=torch.float32, device='cuda'))
        risks[indices] = risk.cpu().numpy()
        probabilities[indices] = logits.sigmoid().cpu().numpy()
    return (risks, probabilities)
if __name__ == '__main__':
    torch.set_num_threads(1)
    for seed in SEEDS:
        train(seed)
