"""Expected discovery fractions under an unknown finite failure count."""
import numpy as np
import torch

from .session import BehaviorTestingSession

QUADRATURE = 128
NODE_BATCH = 8


def fractional_discovery_scores(probabilities, quadrature=QUADRATURE):
    nodes, weights = np.polynomial.legendre.leggauss(quadrature)
    nodes = probabilities.new_tensor((nodes + 1) / 2)
    weights = probabilities.new_tensor(weights / 2)
    score = torch.zeros_like(probabilities)
    for start in range(0, quadrature, NODE_BATCH):
        t = nodes[start:start + NODE_BATCH]
        factor = 1 - probabilities[..., None] + probabilities[..., None] * t
        log_factor = factor.log()
        log_product = log_factor.sum(1, keepdim=True)
        without_current = (log_product - log_factor).exp()
        score += probabilities * (without_current *
                                  weights[start:start + NODE_BATCH]).sum(2)
    return score


class CoverageTestingSession(BehaviorTestingSession):

    def __init__(self,
                 x,
                 risk_predictions,
                 collision_predictions,
                 discrepancy,
                 budget=200,
                 device="cuda"):
        super().__init__(x, risk_predictions, collision_predictions,
                         discrepancy, budget, device)
        self.fractional_scores = fractional_discovery_scores(self.collision)

    def next_index(self):
        if self.pending is not None:
            raise RuntimeError("Observe the pending query first")
        if self.count == self.budget:
            return None
        gain = self.log_weights.softmax(0) @ self.fractional_scores
        self.pending = int(
            gain.masked_fill(~self.remaining, -torch.inf).argmax())
        self.records.append({
            "index":
            self.pending,
            "query_number":
            self.count + 1,
            "collision_probability":
            float(self.probabilities()[self.pending]),
            "expected_discovery_fraction":
            float(gain[self.pending])
        })
        return self.pending
