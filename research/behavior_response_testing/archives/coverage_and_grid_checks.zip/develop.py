"""Compare fixed, discrete-source and continuous-behavior priors fairly."""
import time

import numpy as np
import torch

from methods.history_guided_testing.io import read_json, write_json
from research.history_response_testing.kernel import covariance
from research.history_response_testing.session import RiskTestingSession
from research.response_adaptive_testing.confirmation import CONFIRMATION, verify_lock
from research.response_adaptive_testing.develop import metrics

from .coverage import CoverageTestingSession
from .model import BehaviorResponseModel
from .prediction import behavior_grid, historical_risk_calibrators, response_tables
from .session import BUDGET, BehaviorTestingSession, rmse_discrepancy
from .train import OUTPUT

SCREENING_SEEDS = (11, 23, 37, 53, 71)
METHODS = ("fixed_behavior", "discrete_history", "continuous_behavior",
           "matched_history_gp", "coverage_behavior", "matched_collision_gp",
           "calibrated_behavior", "calibrated_discrete")


def main():
    torch.set_num_threads(1)
    first = read_json(CONFIRMATION / "summary.json")
    assert first["success"] is False
    verify_lock(first["protocol"])
    training = read_json(OUTPUT / "protocol.json")
    grid = behavior_grid()
    historical = np.array(list(
        training["historical_behavior_descriptors"].values()),
                          dtype=np.float32)
    calibrators = historical_risk_calibrators(training["training_profiles"])
    protocol = {
        "role":
        "Development after failed confirmation; not independent validation",
        "methods":
        METHODS,
        "seeds":
        SCREENING_SEEDS,
        "profiles":
        [profile["name"] for profile in first["protocol"]["profiles"]],
        "training_profiles":
        training["training_profiles"],
        "validation_profiles":
        training["validation_profiles"],
        "replicates_per_profile":
        2,
        "continuous_particle_count":
        len(grid),
        "continuous_prior":
        "Uniform three normalized physical parameters; balanced controller kind",
        "discrete_particle_count":
        len(historical),
        "discrete_prior":
        "Uniform over sixteen actual historical behavioral profiles",
        "likelihood":
        "Raw-risk Gaussian discrepancy GP with shared covariance; per-family total variance from known-profile development predictor RMSE; half GP variance and half work observation variance",
        "discrepancy_length":
        0.2,
        "budget":
        BUDGET,
        "online_feedback":
        "Queried continuous risk only",
        "target_parameters":
        "Never given to selector; historical descriptors and prior grid only",
        "matched_information":
        "All methods use the same newly fitted forward response model and historicalized training data",
        "matched_history_gp":
        "Previous best algorithm and kernel settings, sixteen conditional-model source responses, uniform source weights, risk-to-collision calibration refit on the same sixteen training profiles",
        "matched_collision_gp":
        "Same information-matched history GP, selecting collision score only instead of a budget-dependent risk/collision mixture",
        "calibrated_behavior":
        "Continuous behavior posterior with historical known-profile risk likelihood fitted GP discrepancy and work variance",
        "calibrated_discrete":
        "Discrete history posterior with the same fitted risk discrepancy",
        "historical_risk_calibration":
        calibrators,
        "scope":
        "Two controller kinds and three declared behavioral parameters",
        "coverage_behavior":
        "Same continuous behavior posterior; select expected C_i/N with zero gain when N=0, using 128-point Gauss-Legendre integration under conditional independent Bernoulli collision predictions"
    }
    write_json(OUTPUT / "development_protocol.json", protocol)
    predictors = {}
    for seed in SCREENING_SEEDS:
        states = torch.load(OUTPUT / "models" / f"predictor_{seed}.pt",
                            map_location="cuda",
                            weights_only=True)
        models = []
        for family in (0, 1):
            model = BehaviorResponseModel().cuda().eval()
            model.load_state_dict(states[str(family)])
            models.append(model)
        validation = read_json(
            OUTPUT / "models" /
            f"predictor_{seed}.json")["known_profile_validation"]
        variance = [
            validation[str(family)]["risk_rmse"]**2 for family in (0, 1)
        ]
        predictors[seed] = models, variance
    records = []
    for name in protocol["profiles"]:
        for replicate in range(2):
            pool = CONFIRMATION / name / f"pool_{replicate}"
            with np.load(pool / "responses.npz") as bank:
                for seed, (models, variance) in predictors.items():
                    risk_grid, collision_grid = response_tables(
                        bank["x"], grid, models)
                    risk_history, collision_history = response_tables(
                        bank["x"], historical, models)
                    baseline = read_json(pool / "selection" /
                                         f"previous_best_{seed}.json")
                    for method in METHODS:
                        path = OUTPUT / "development" / name / f"pool_{replicate}" / f"{method}_{seed}.json"
                        if path.exists():
                            result = read_json(path)
                        else:
                            started = time.perf_counter()
                            selected, observations = [], []
                            if method == "fixed_behavior":
                                selected = torch.argsort(
                                    collision_grid.mean(0),
                                    descending=True,
                                    stable=True)[:BUDGET].tolist()
                                observations = [{
                                    "index":
                                    index,
                                    "continuous_risk":
                                    float(bank["risk"][index])
                                } for index in selected]
                            elif method in ("matched_history_gp",
                                            "matched_collision_gp"):
                                risks = risk_history.cpu().numpy().T
                                collisions = collision_history.cpu().numpy().T
                                session = RiskTestingSession(
                                    bank["x"],
                                    covariance(bank["x"], risks),
                                    risks,
                                    collisions,
                                    np.full(len(historical),
                                            1 / len(historical)),
                                    calibrators,
                                    mode="calibrated" if method
                                    == "matched_collision_gp" else "dual")
                                while (index :=
                                       session.next_index()) is not None:
                                    value = float(bank["risk"][index])
                                    session.observe(value)
                                    selected.append(index)
                                    observations.append({
                                        "index":
                                        index,
                                        "continuous_risk":
                                        value
                                    })
                            else:
                                risk, collision = (
                                    (risk_history, collision_history)
                                    if method in ("discrete_history",
                                                  "calibrated_discrete") else
                                    (risk_grid, collision_grid))
                                session_class = (CoverageTestingSession if
                                                 method == "coverage_behavior"
                                                 else BehaviorTestingSession)
                                discrepancy = (read_json(
                                    OUTPUT / "calibration" /
                                    f"discrepancy_{seed}.json")["parameters"]
                                               if
                                               method.startswith("calibrated_")
                                               else rmse_discrepancy(variance))
                                session = session_class(
                                    bank["x"], risk, collision, discrepancy)
                                while (index :=
                                       session.next_index()) is not None:
                                    value = float(bank["risk"][index])
                                    session.observe(value)
                                    selected.append(index)
                                    observations.append({
                                        "index":
                                        index,
                                        "continuous_risk":
                                        value
                                    })
                            result = {
                                **metrics(bank["collision"], selected), "selected_indices":
                                selected,
                                "observations":
                                observations,
                                "method":
                                method,
                                "elapsed_s":
                                time.perf_counter() - started,
                                "role":
                                "Development; parameter-oracle information excluded"
                            }
                            write_json(path, result)
                        selected = result["selected_indices"]
                        assert len(selected) == len(set(selected)) == BUDGET
                        assert result["observations"] == [{
                            "index":
                            index,
                            "continuous_risk":
                            float(bank["risk"][index])
                        } for index in selected]
                        measured = metrics(bank["collision"], selected)
                        for key, value in measured.items():
                            assert result[key] == value
                        total = measured["pool_collisions"]
                        area = measured[
                            "mean_cumulative_collisions"] / total if total else 0
                        base_area = baseline[
                            "mean_cumulative_collisions"] / total if total else 0
                        records.append({
                            "profile":
                            name,
                            "replicate":
                            replicate,
                            "seed":
                            seed,
                            "method":
                            method,
                            "split":
                            "forward_training"
                            if name in training["training_profiles"] else
                            "forward_validation",
                            **measured, "normalized_area":
                            area,
                            "difference_normalized_area":
                            area - base_area,
                            "difference_recall":
                            measured["recall"] - baseline["recall"],
                            "difference_F200":
                            measured["F200"] - baseline["F200"]
                        })
                        print("BEHAVIOR DEVELOPMENT",
                              name,
                              replicate,
                              seed,
                              method,
                              round(measured["mean_cumulative_collisions"], 3),
                              measured["F200"],
                              flush=True)
                    write_json(
                        OUTPUT / "development_summary.json", {
                            "role":
                            "Disclosed development, not independent superiority",
                            "records":
                            records,
                            "complete":
                            len(records) == len(protocol["profiles"]) * 2 *
                            len(SCREENING_SEEDS) * len(METHODS)
                        })
    comparison = {
        method: {
            key:
            float(
                np.mean([
                    row[f"difference_{key}"] for row in records
                    if row["method"] == method
                ]))
            for key in ("normalized_area", "recall", "F200")
        }
        for method in METHODS
    }
    write_json(
        OUTPUT / "development_comparison.json", {
            "role":
            "Development differences against frozen previous best; new information requires matched controls",
            "mean_differences": comparison
        })
    print("BEHAVIOR DIFFERENCES", comparison, flush=True)


if __name__ == "__main__":
    main()
