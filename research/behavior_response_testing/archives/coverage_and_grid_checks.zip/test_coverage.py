"""Compare normalized discovery moments with full binary enumeration."""
import itertools
import math

import numpy as np
import torch

from .coverage import CoverageTestingSession, fractional_discovery_scores
from .session import rmse_discrepancy


def test_fractional_discovery_equals_binary_enumeration_including_empty_pool():
    probabilities = torch.tensor(
        [[0.2, 0.4, 0.7], [0., 1., 1.], [0., 0., 0.], [0.7, 0., 0.]],
        dtype=torch.float64)
    expected = torch.zeros_like(probabilities)
    for labels in itertools.product((0, 1), repeat=3):
        if not sum(labels):
            continue
        labels = torch.tensor(labels, dtype=probabilities.dtype)
        probability = torch.where(labels.bool(), probabilities,
                                  1 - probabilities).prod(1)
        expected += probability[:, None] * labels[None, :] / labels.sum()
    actual = fractional_discovery_scores(probabilities, quadrature=8)
    torch.testing.assert_close(actual, expected, atol=1e-14, rtol=0)
    positive_pool = 1 - (1 - probabilities).prod(1)
    torch.testing.assert_close(actual.sum(1),
                               positive_pool,
                               atol=1e-14,
                               rtol=0)


def test_expected_recall_and_collision_probability_can_choose_different_queries(
):
    x = np.array([[0., 0., 0., 0., 0.], [0.1, 0.2, 0., 0., 0.],
                  [0., 0., 0., 0., 1.]])
    risk = np.full((2, 3), 0.4)
    collision = np.array([[1., 0., 0.], [0., 1., 1.]])
    session = CoverageTestingSession(x,
                                     risk,
                                     collision,
                                     rmse_discrepancy([0.01, 0.02]),
                                     budget=1,
                                     device="cpu")
    session.log_weights = torch.tensor(
        [math.log(0.4), math.log(0.6)], dtype=torch.float64)
    assert int(session.probabilities().argmax()) == 1
    assert session.next_index() == 0


def test_quadrature_resolves_a_large_deterministic_failure_set():
    p = torch.ones((1, 2048), dtype=torch.float64)
    actual = fractional_discovery_scores(p)
    torch.testing.assert_close(actual, p / 2048, atol=1e-12, rtol=0)
