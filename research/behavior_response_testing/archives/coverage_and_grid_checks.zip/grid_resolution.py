"""Check a fourfold denser behavioral prior on disclosed development pools."""
import time

import numpy as np
import torch

from methods.history_guided_testing.io import read_json, write_json
from research.response_adaptive_testing.confirmation import CONFIRMATION
from research.response_adaptive_testing.develop import metrics

from .coverage import CoverageTestingSession
from .prediction import behavior_grid, response_tables
from .model import BehaviorResponseModel
from .session import BUDGET, BehaviorTestingSession, rmse_discrepancy
from .train import OUTPUT

GRID_LOG2 = 10
SEEDS = (11, 37)
METHODS = {
    "continuous_behavior": BehaviorTestingSession,
    "coverage_behavior": CoverageTestingSession
}


def main():
    torch.set_num_threads(1)
    training = read_json(OUTPUT / "protocol.json")
    grid = behavior_grid(GRID_LOG2)
    write_json(
        OUTPUT / "grid_resolution" / "protocol.json", {
            "role":
            "Development numerical resolution check, no independent claim",
            "profiles": training["validation_profiles"],
            "seeds": SEEDS,
            "particle_count": len(grid),
            "prior": "Same scrambled Sobol prior extended fourfold",
            "budget": BUDGET,
            "online_feedback": "Queried continuous risk only"
        })
    records = []
    for seed in SEEDS:
        states = torch.load(OUTPUT / "models" / f"predictor_{seed}.pt",
                            map_location="cuda",
                            weights_only=True)
        models = []
        for family in (0, 1):
            model = BehaviorResponseModel().cuda().eval()
            model.load_state_dict(states[str(family)])
            models.append(model)
        validation = read_json(
            OUTPUT / "models" /
            f"predictor_{seed}.json")["known_profile_validation"]
        variance = [validation[str(f)]["risk_rmse"]**2 for f in (0, 1)]
        for name in training["validation_profiles"]:
            for replicate in range(2):
                pool = CONFIRMATION / name / f"pool_{replicate}"
                with np.load(pool / "responses.npz") as bank:
                    risks, collisions = response_tables(
                        bank["x"], grid, models)
                    for method, session_class in METHODS.items():
                        path = OUTPUT / "grid_resolution" / name / f"pool_{replicate}" / f"{method}_{seed}.json"
                        if path.exists():
                            result = read_json(path)
                        else:
                            started = time.perf_counter()
                            session = session_class(bank["x"], risks,
                                                    collisions,
                                                    rmse_discrepancy(variance))
                            selected, observations = [], []
                            while (index := session.next_index()) is not None:
                                value = float(bank["risk"][index])
                                session.observe(value)
                                selected.append(index)
                                observations.append({
                                    "index": index,
                                    "continuous_risk": value
                                })
                            result = {
                                **metrics(bank["collision"], selected), "selected_indices":
                                selected,
                                "observations":
                                observations,
                                "elapsed_s":
                                time.perf_counter() - started
                            }
                            write_json(path, result)
                        coarse = read_json(OUTPUT / "development" / name /
                                           f"pool_{replicate}" /
                                           f"{method}_{seed}.json")
                        previous = read_json(pool / "selection" /
                                             f"previous_best_{seed}.json")
                        count = result["pool_collisions"]
                        records.append({
                            "profile": name,
                            "replicate": replicate,
                            "seed": seed,
                            "method": method,
                            **{
                                f"difference_{label}_{key}": (result[key] - other[key]) / (count if key == "mean_cumulative_collisions" and count else 1)
                                for label, other in (("coarse", coarse), ("previous", previous))
                                for key in ("mean_cumulative_collisions", "recall", "F200")
                            }
                        })
                        print("GRID RESOLUTION",
                              name,
                              replicate,
                              seed,
                              method,
                              result["F200"],
                              flush=True)
                        write_json(OUTPUT / "grid_resolution" / "summary.json",
                                   {
                                       "records": records,
                                       "complete": len(records) == 64
                                   })
    comparison = {
        method: {
            key:
            float(
                np.mean(
                    [row[key] for row in records if row["method"] == method]))
            for key in records[0] if key.startswith("difference_")
        }
        for method in METHODS
    }
    write_json(OUTPUT / "grid_resolution" / "comparison.json", comparison)
    print("GRID DIFFERENCES", comparison, flush=True)


if __name__ == "__main__":
    main()
