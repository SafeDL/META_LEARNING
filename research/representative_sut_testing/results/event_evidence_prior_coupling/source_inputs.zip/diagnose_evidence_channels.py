"""Audit competing evidence channels on the same already-paid EP trajectories."""
import numpy as np
from scipy.special import logsumexp

from methods.history_guided_testing.io import read_json, write_json
from .adaptive_margin_prior import event_log_likelihood
from .config import OUTPUT


SOURCE = OUTPUT / "ep_discovery_supported_prior_coupling"
RESULTS = OUTPUT / "margin_evidence_channel_diagnostic"


def main():
    rows = []
    for path in sorted(SOURCE.glob("pool_*/*/ep_discovery_supported_prior_11.json")):
        run = read_json(path)
        weights = np.full(2, -np.log(2))
        losses, mix_loss, original_loss = np.zeros(2), 0., 0.
        contributions = {"safe_value": 0., "safe_event": 0., "collision_event": 0.}
        records = []
        for t, evidence in enumerate(run["prior_evidence_records"]):
            component = [c[t] for c in run["component_margin_records"]]
            likelihood = event_log_likelihood(np.asarray([r["predictive_mean_before"] for r in component]),
                                              np.asarray([r["predictive_variance_before"] for r in component]),
                                              evidence["collision"])
            if evidence["collision"]:
                contributions["collision_event"] += likelihood[0] - likelihood[1]
            else:
                mixed = evidence["log_predictive_likelihoods"]
                contributions["safe_value"] += mixed[0] - mixed[1]
                contributions["safe_event"] += likelihood[0] - likelihood[1]
            mix_loss -= logsumexp(weights + likelihood)
            original_loss -= logsumexp(np.log(evidence["weights_before"]) + likelihood)
            losses -= likelihood
            weights += likelihood
            weights -= logsumexp(weights)
            if abs(mix_loss + logsumexp(-losses) - np.log(2)) > 1e-8:
                raise ValueError("Event-score mixture identity failed")
            records.append({"query": t + 1, "event_log_likelihoods": likelihood.tolist(),
                            "shadow_weights_after": np.exp(weights).tolist()})
        rows.append({"pool": path.parent.parent.name, "sut": path.parent.name,
                     "log_odds_contributions": contributions, "component_event_log_losses": losses.tolist(),
                     "event_mixture_log_loss": mix_loss, "original_mixture_event_log_loss": original_loss,
                     "shadow_final_weights": np.exp(weights).tolist(), "records": records})
    write_json(RESULTS / "summary.json", {"rows": rows, "paid_records": 200 * len(rows),
               "scope": "same paid trajectories and before-query component predictions; shadow event weights do not simulate changed actions",
               "prefix_log_loss_identity_verified": True, "new_physical_calls": 0})
    for row in rows:
        print({k: v for k, v in row.items() if k != "records"}, flush=True)


if __name__ == "__main__":
    main()
