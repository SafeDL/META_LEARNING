"""Bounded event-score credibility comparison with unchanged mixed EP updates."""
from .config import OUTPUT
from .evaluate_ep_discovery_support import evaluate_stage


def main():
    evaluate_stage(OUTPUT / "event_evidence_prior_coupling", "event_evidence_prior", "event",
                   "ep_discovery_supported_prior_coupling", "ep_discovery_supported_prior")


if __name__ == "__main__":
    main()
