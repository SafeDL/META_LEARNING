"""Joint decision uncertainty differs from independent point uncertainty."""
from types import SimpleNamespace
import json

import numpy as np
from scipy.special import ndtr
import torch

from .decision_support import bivariate_normal_probability, discovery_loss_support, ordering_support


def build(correlation):
    model = SimpleNamespace(mean=torch.tensor([-.5, .5], dtype=torch.float64),
                            covariance=torch.tensor([[1., correlation], [correlation, 1.]], dtype=torch.float64),
                            noise=torch.ones(2, dtype=torch.float64))
    return SimpleNamespace(models=[model], selection_weights=lambda: np.asarray([1.]))


def test_shared_uncertainty_can_cancel_in_the_decision_contrast():
    correlated, independent = ordering_support(build(.9), 0, 1), ordering_support(build(0), 0, 1)
    np.testing.assert_allclose(correlated['ordering_support'], ndtr(1 / np.sqrt(.2)), atol=1e-12)
    np.testing.assert_allclose(independent['ordering_support'], ndtr(1 / np.sqrt(2)), atol=1e-12)
    assert correlated['supported'] and not independent['supported']
    json.dumps(correlated, allow_nan=False)


def test_heteroscedastic_noise_defines_conditional_event_propensity():
    candidate = build(.4)
    candidate.models[0].noise = torch.tensor([.25, 1.], dtype=torch.float64)
    result = ordering_support(candidate, 0, 1)
    draws = np.random.default_rng(11).multivariate_normal([-.5, .5], [[1., .4], [.4, 1.]], size=100000)
    empirical = np.mean(draws[:, 0] / .5 < draws[:, 1])
    assert abs(result['ordering_support'] - empirical) < .005
    same = ordering_support(candidate, 0, 0)
    assert same['ordering_support'] == .5 and not same['supported']


def test_model_ambiguity_is_retained_in_the_mixture_support():
    first, second = build(.9).models[0], build(.9).models[0]
    second.mean = -second.mean
    candidate = SimpleNamespace(models=[first, second], selection_weights=lambda: np.asarray([.3, .7]))
    result = ordering_support(candidate, 0, 1)
    expected = .3 * ndtr(1 / np.sqrt(.2)) + .7 * ndtr(-1 / np.sqrt(.2))
    np.testing.assert_allclose(result['ordering_support'], expected, atol=1e-12)
    assert not result['supported']


def test_bivariate_probability_matches_independence_and_zero_mean_quadrant():
    np.testing.assert_allclose(bivariate_normal_probability(.3, -.5, 0), ndtr(.3) * ndtr(-.5), atol=1e-12)
    for correlation in (-.95, -.4, .4, .95):
        exact = .25 + np.arcsin(correlation) / (2 * np.pi)
        np.testing.assert_allclose(bivariate_normal_probability(0, 0, correlation), exact, atol=1e-10)


def test_almost_equivalent_high_success_actions_need_no_strict_order_identification():
    candidate = build(0)
    candidate.models[0].mean = torch.tensor([-4.1, -4.], dtype=torch.float64)
    strict = ordering_support(candidate, 0, 1)
    loss = discovery_loss_support(candidate, 0, 1)
    assert not strict['supported'] and loss['supported']
    assert loss['loss_probability'] < .003
    np.testing.assert_allclose(loss['gain_probability'] - loss['loss_probability'],
                               ndtr(4.1 / np.sqrt(2)) - ndtr(4 / np.sqrt(2)), atol=1e-10)
    json.dumps(loss, allow_nan=False)
