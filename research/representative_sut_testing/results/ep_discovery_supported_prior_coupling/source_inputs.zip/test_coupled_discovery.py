"""Exhaustive finite-bank checks against a feedback-adaptive reference."""
import itertools
from types import SimpleNamespace

import numpy as np

from .coupled_discovery import ReferenceReplay, run_policy


class AdaptiveReference:
    def __init__(self):
        self.last_positive = False

    def rank(self, remaining, *, tie_break):
        order = [0, 2, 4, 1, 3] if self.last_positive else [0, 1, 3, 2, 4]
        return np.asarray([i for i in order if remaining[i]])

    def observe(self, index, risk, collision):
        self.last_positive = collision


class Alternative:
    def rank(self, remaining, *, tie_break):
        return np.flatnonzero(remaining)[::-1]

    def observe_event(self, index, collision):
        return None


class Oracle:
    def __init__(self, labels):
        self.labels = labels
        self.queried = []

    def query(self, index):
        assert index not in self.queried
        self.queried.append(index)
        return SimpleNamespace(risk=float(self.labels[index]), collision=self.labels[index])


def independent_reference(labels, budget):
    model = AdaptiveReference()
    available = np.ones(len(labels), dtype=bool)
    order = []
    for _ in range(budget):
        index = int(model.rank(available, tie_break=np.arange(len(labels)))[0])
        order.append(index)
        available[index] = False
        model.observe(index, float(labels[index]), labels[index])
    return order


def test_all_binary_banks_respect_full_adaptive_reference_bounds():
    for labels in itertools.product((False, True), repeat=5):
        baseline = independent_reference(labels, 4)
        for method in ("greedy_reference", "event_only_search", "coupled_discovery"):
            reference = ReferenceReplay(AdaptiveReference(), 5, np.arange(5))
            oracle = Oracle(labels)
            run = run_policy(method, reference, Alternative(), oracle, 4, 1)
            assert oracle.queried == run["selected_indices"] and len(oracle.queried) == 4
            assert run["reference_prefix_indices"] == baseline[:len(run["reference_prefix_indices"])]
            actual = np.cumsum([labels[i] for i in run["selected_indices"]])
            base = np.cumsum([labels[i] for i in baseline])
            bound = np.asarray([c["discovery_gain_lower"] for c in run["coupling_checks"]])
            assert np.all(actual - base >= bound)
            assert actual[-1] - base[-1] >= run["terminal_gain_lower"]
            assert (actual - base).sum() >= run["area_gain_lower"]
            if method == "coupled_discovery":
                assert np.all(actual >= base - 1) and run["max_negative_extra_count"] <= 1
            if method == "greedy_reference":
                assert run["selected_indices"] == baseline


def test_replay_of_known_alternative_costs_no_additional_oracle_query():
    labels = [False, True, False, True, False]
    oracle = Oracle(labels)
    reference = ReferenceReplay(AdaptiveReference(), 5, np.arange(5))
    run = run_policy("coupled_discovery", reference, Alternative(), oracle, 5, 1)
    assert len(oracle.queried) == 5
    assert len(run["reference_prefix_indices"]) == 5
    assert run["terminal_gain_lower"] == 0


def test_failure_forces_reference_until_negative_extra_is_replayed():
    labels = [False, True, True, True, False]
    reference = ReferenceReplay(AdaptiveReference(), 5, np.arange(5))
    run = run_policy("coupled_discovery", reference, Alternative(), Oracle(labels), 4, 1)
    assert run["queries"][1]["role"] == "alternative"
    assert run["queries"][2]["role"] == "reference"
    assert run["coupling_checks"][1]["negative_extra_count"] == 1


def test_all_positive_banks_have_pointwise_nonnegative_discovery_gain():
    labels = [True] * 5
    reference = ReferenceReplay(AdaptiveReference(), 5, np.arange(5))
    run = run_policy("coupled_discovery", reference, Alternative(), Oracle(labels), 4, 1)
    assert all(check["discovery_gain_lower"] == 0 for check in run["coupling_checks"])
