"""Meaningful budget, shared initialization and event-metric checks."""
from types import SimpleNamespace

import numpy as np

from .develop import metrics
from .response import ResponseModel
from .selector import METHODS, select


class QueryOracle:
    def __init__(self):
        self.indices = []

    def query(self, index):
        assert index not in self.indices
        assert len(self.indices) < 200
        self.indices.append(index)
        collision = index % 3 == 0
        return SimpleNamespace(risk=0.9 if collision else 0.2, collision=collision)


class IdentityPayoff:
    def predict(self, features):
        return features[:, :2]


class NoHarm:
    classes_ = np.asarray([0])


class PositivePart:
    def predict(self, features):
        return np.maximum(features[:, :2], 0)


class NegativePart:
    def predict(self, features):
        return np.maximum(-features[:, :2], 0)


PAYOFF = {"returns": [IdentityPayoff()] * 3, "harm": [NoHarm()] * 3,
          "benefit": [PositivePart()] * 3, "loss": [NegativePart()] * 3}


def test_all_controls_spend_same_budget_and_share_initialization():
    rng = np.random.default_rng(41)
    x = np.column_stack((rng.random((240, 4)), np.repeat([0, 1], 120)))
    predictions = (rng.random((240, 3)), rng.random((240, 3)),
                   {"risk_local_variance": [0.01, 0.01], "event_local_variance": [0.04, 0.04],
                    "risk_event_local_covariance": [0., 0.]})
    results = []
    for method in METHODS:
        oracle = QueryOracle()
        result = select(method, x, predictions, PAYOFF, oracle, 11)
        assert result["selected_indices"] == oracle.indices
        assert len(oracle.indices) == len(set(oracle.indices)) == 200
        assert sum(record["role"] == "planned_query" for record in result["queries"]) == result["audit_query_count"] <= 190
        for check in result["planning_checks"]:
            assert result["selected_indices"][check["start_query"] - 1] == check["chosen_index"]
            if check["screen_applied"]:
                assert min(check["predicted_gain"]) >= -1e-10
        covariance = np.asarray(result["task_posterior"]["latent_response_covariance"])
        assert np.linalg.eigvalsh(covariance).min() >= -1e-10
        results.append(result)
    assert all(result["selected_indices"][:10] == results[0]["selected_indices"][:10]
               for result in results)


def test_every_local_certificate_matches_executed_block_and_true_gain():
    rng = np.random.default_rng(47)
    x = np.column_stack((rng.random((240, 4)), np.repeat([0, 1], 120)))
    predictions = (rng.random((240, 3)), rng.random((240, 3)),
                   {"risk_local_variance": [0.01, 0.01], "event_local_variance": [0.04, 0.04],
                    "risk_event_local_covariance": [0., 0.]})
    result = select("loss_budget_payoff", x, predictions, PAYOFF, QueryOracle(), 23)
    labels = np.asarray([index % 3 == 0 for index in range(len(x))])
    for certificate in result["audits"]:
        start = certificate["start_query"] - 1
        end = start + certificate["comparison_budget"]
        assert result["selected_indices"][start:end] == certificate["executed_order"]
        if certificate["accepted"]:
            reference = np.cumsum(labels[certificate["reference"]])
            actual = np.cumsum(labels[certificate["executed_order"]])
            gains = [int(actual[-1] - reference[-1]), int(actual.sum() - reference.sum())]
            assert np.all(np.asarray(gains) >= certificate["executable_gain_lower"])
            assert min(gains) >= 0


def test_only_target_feedback_changes_latent_response_state():
    x = np.asarray([[0., 0., 0., 0., 0.], [1., 1., 1., 1., 0.]])
    risk = np.asarray([[0.1, 0.9], [0.2, 0.8]])
    collision = np.asarray([[0.1, 0.9], [0.1, 0.9]])
    model = ResponseModel(x, risk, collision,
                          {"risk_local_variance": [0.01, 0.01], "event_local_variance": [0.04, 0.04],
                           "risk_event_local_covariance": [0., 0.]})
    np.testing.assert_array_equal(model.mean[:2].cpu(), np.zeros(2))
    model.observe(0, 0.9, True)
    assert model.mean[1] > model.mean[0]


def test_co_primary_metrics_and_budget_ceiling_are_distinct():
    collision = np.ones(300, dtype=bool)
    value = metrics(collision, list(range(200)))
    assert value["F200"] == 200
    assert np.isclose(value["recall_200"], 2 / 3)
    assert np.isclose(value["area_200"], 201 / 600)
    assert value["terminal_ceiling_attainment"] == 1
    empty = metrics(np.zeros(300, dtype=bool), list(range(200)))
    assert empty["recall_200"] is None and empty["area_200"] is None
