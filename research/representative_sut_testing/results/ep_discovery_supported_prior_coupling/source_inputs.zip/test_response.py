"""Shared task observability, independent channels and posterior invariants."""
import math

import numpy as np
import torch

from .response import ResponseModel, historical_predictions, preserve_branch_mean


CALIBRATION = {"risk_local_variance": [0.01, 0.01], "event_local_variance": [0.04, 0.04],
               "risk_event_local_covariance": [0., 0.]}


def toy_model(risk_informative=True):
    x = np.asarray([[0., 0., 0., 0., 0.], [0., 0., 0., 0., 1.], [1., 1., 1., 1., 1.]])
    risk = np.asarray([[0.1, 0.5, 0.9], [0.5, 0.5, 0.5], [0.5, 0.5, 0.5]])
    if not risk_informative:
        risk[:] = 0.5
    event = np.asarray([[0.01, 0.01, 0.01], [0.99, 0.01, 0.01], [0.01, 0.99, 0.99]])
    return ResponseModel(x, risk, event, CALIBRATION)


def test_low_event_risk_feedback_can_reverse_unqueried_failure_ranking_across_families():
    model = toy_model()
    before = model.event_probabilities().cpu().numpy()
    assert np.isclose(before[0], 0.01) and before[1] < before[2]
    model.observe_risk(0, 0.1)
    after = model.event_probabilities().cpu().numpy()
    assert after[1] > after[2]
    assert after[1] > 0.7
    assert np.linalg.norm(model.task_state()["latent_response_mean"]) > 0


def test_risk_blind_mode_requires_event_feedback_instead():
    model = toy_model(False)
    before = model.event_probabilities().clone()
    model.observe_risk(0, 0.1)
    torch.testing.assert_close(model.event_probabilities(), before)
    assert model.mean[:model.sources].abs().max().item() == 0
    model.observe_event(1, True)
    assert model.event_probabilities()[1] > before[1]
    assert model.event_probabilities()[2] < before[2]


def test_joint_covariance_is_psd_and_initial_event_marginals_match_pooled_history():
    model = toy_model()
    assert torch.linalg.eigvalsh(model.covariance).min().item() >= -1e-10
    np.testing.assert_allclose(model.event_probabilities().cpu().numpy(),
                               [0.01, (0.99 + 0.02) / 3, (0.01 + 1.98) / 3], atol=1e-12)


def test_event_moments_and_risk_pin_are_independent_when_history_has_no_cross_channel_mode():
    x = np.asarray([[0., 0., 0., 0., 0.], [1., 1., 1., 1., 0.]])
    model = ResponseModel(x, np.full((2, 2), 0.5), np.full((2, 2), 0.5), CALIBRATION)
    model.observe(0, 0.2, True)
    coordinate = model.event_indices[0]
    assert np.isclose(model.mean[coordinate].item(), math.sqrt(2 / math.pi))
    assert np.isclose(model.covariance[coordinate, coordinate].item(), 1 - 2 / math.pi)
    assert model.mean[model.risk_indices[0]].item() == 0.2
    assert model.covariance[model.risk_indices[0]].abs().max().item() == 0


def test_risk_and_event_branches_preserve_marginals_and_do_not_mutate_real_state():
    model = toy_model()
    before = [model.mean.clone(), model.covariance.clone()]
    indices = torch.arange(3, device="cuda")
    weights, predictions = model.planning_branches(indices)
    torch.testing.assert_close(weights.sum(dim=1), torch.ones(3, dtype=torch.float64, device="cuda"))
    expected = (weights[:, :, None] * predictions).sum(dim=1)
    prior = model.event_probabilities()[None, :].expand(3, -1)
    torch.testing.assert_close(expected, prior, rtol=0, atol=1e-12)
    assert predictions.min().item() >= -1e-12
    assert predictions.max().item() <= 1 + 1e-12
    torch.testing.assert_close(model.mean, before[0])
    torch.testing.assert_close(model.covariance, before[1])


def test_source_permutation_changes_coordinates_but_not_predicted_event_response():
    first = toy_model()
    x = np.asarray([[0., 0., 0., 0., 0.], [0., 0., 0., 0., 1.], [1., 1., 1., 1., 1.]])
    risk = np.asarray([[0.1, 0.5, 0.9], [0.5, 0.5, 0.5], [0.5, 0.5, 0.5]])
    event = np.asarray([[0.01, 0.01, 0.01], [0.99, 0.01, 0.01], [0.01, 0.99, 0.99]])
    second = ResponseModel(x, risk[:, ::-1].copy(), event[:, ::-1].copy(), CALIBRATION)
    first.observe(0, 0.1, False)
    second.observe(0, 0.1, False)
    torch.testing.assert_close(first.event_probabilities(), second.event_probabilities())


def test_general_branch_mean_correction_keeps_range_even_for_badly_biased_forecasts():
    forecasts = torch.tensor([[[0., 1.], [0.9, 0.5], [1., 0.]]], dtype=torch.float64, device="cuda")
    weights = torch.tensor([[0.1, 0.2, 0.7]], dtype=torch.float64, device="cuda")
    marginal = torch.tensor([[0.01, 0.99]], dtype=torch.float64, device="cuda")
    repaired = preserve_branch_mean(forecasts, weights, marginal)
    torch.testing.assert_close((repaired * weights[:, :, None]).sum(dim=1), marginal, atol=1e-12, rtol=0)
    assert repaired.min().item() >= -1e-12 and repaired.max().item() <= 1 + 1e-12


def test_known_historical_coordinates_retain_exact_allowed_source_outcomes():
    rng = np.random.default_rng(73)
    x = np.column_stack((rng.random((24, 4)), np.repeat([0, 1], 12)))
    risk = rng.random(24)
    event = np.arange(24) % 2
    bank = {"x": x, "allowed": risk, "allowed_collision": event}
    predicted_risk, predicted_event = historical_predictions(x, bank, ["allowed"])
    np.testing.assert_array_equal(predicted_risk[:, 0], risk)
    np.testing.assert_array_equal(predicted_event[:, 0], event)


def test_correlated_residuals_still_allow_different_events_at_identical_observed_risk():
    x = np.asarray([[0., 0., 0., 0., 0.], [1., 1., 1., 1., 0.]])
    calibration = {"risk_local_variance": [0.01, 0.01],
                   "event_local_variance": [0.04, 0.04],
                   "risk_event_local_covariance": [0.02, 0.02]}
    probabilities = []
    for event in (False, True):
        model = ResponseModel(x, np.full((2, 2), 0.5), np.full((2, 2), 0.5), calibration)
        assert torch.linalg.eigvalsh(model.covariance).min().item() >= -1e-10
        model.observe_risk(0, 0.5)
        coordinate = model.event_indices[0]
        assert model.covariance[coordinate, coordinate] > 0
        model.observe_event(0, event)
        probabilities.append(float(model.event_probabilities()[0]))
        assert model.mean[model.risk_indices[0]].item() == 0.5
    assert probabilities[0] < 0.2 and probabilities[1] > 0.8
