"""Sharp partial-label bounds for an actual paid-query continuation.

No response-model coverage or random-sampling assumption is required. The event
map and the reference list must be fixed for the comparison. Bounds describe the
committed local continuation, not a different adaptive reference's whole run.
"""
import numpy as np


def list_weights(order, pool_size):
    weights = np.zeros((pool_size, 2), dtype=int)
    weights[np.asarray(order, dtype=int), 0] = 1
    weights[np.asarray(order, dtype=int), 1] = np.arange(len(order), 0, -1)
    return weights


class ExecutionCertificate:
    def __init__(self, reference, proposal, pool_size):
        self.reference = list(map(int, reference))
        self.proposal = list(map(int, proposal))
        if len(reference) != len(proposal) or len(set(reference)) != len(reference) or len(
                set(proposal)) != len(proposal):
            raise ValueError("Comparison requires equal-length unique lists")
        self.pool_size = pool_size
        self.budget = len(reference)
        self.indices = []
        self.labels = []

    def observe(self, index, collision):
        if index in self.indices or len(self.indices) >= self.budget:
            raise ValueError("Duplicate query or exhausted continuation budget")
        self.indices.append(int(index))
        self.labels.append(bool(collision))

    def continuation(self, order):
        fill = [index for index in order if index not in self.indices]
        return [*self.indices, *fill[:self.budget - len(self.indices)]]

    def bounds(self, order):
        actual = self.continuation(order)
        difference = (list_weights(actual, self.pool_size)
                      - list_weights(self.reference, self.pool_size))
        unknown = np.ones(self.pool_size, dtype=bool)
        unknown[self.indices] = False
        known = (difference[self.indices] * np.asarray(self.labels)[:, None]).sum(axis=0)
        lower = known + np.minimum(difference[unknown], 0).sum(axis=0)
        upper = known + np.maximum(difference[unknown], 0).sum(axis=0)
        return lower, upper

    def joint_lower_bound(self):
        actual = self.continuation(self.proposal)
        difference = (list_weights(actual, self.pool_size)
                      - list_weights(self.reference, self.pool_size)).sum(axis=1)
        unknown = np.ones(self.pool_size, dtype=bool)
        unknown[self.indices] = False
        known = (difference[self.indices] * np.asarray(self.labels)).sum()
        return int(known + np.minimum(difference[unknown], 0).sum())

    def decision(self):
        lower, upper = self.bounds(self.proposal)
        joint_lower = self.joint_lower_bound()
        return {
            "audit_queries": len(self.indices), "comparison_budget": self.budget,
            "reference": self.reference, "proposal": self.proposal,
            "audit_indices": self.indices.copy(), "audit_labels": self.labels.copy(),
            "actual_continuation": self.continuation(self.proposal),
            "executable_gain_lower": lower.tolist(), "executable_gain_upper": upper.tolist(),
            "non_decreasing": bool(np.all(lower >= 0)),
            "strict_gain_lower": joint_lower,
            "supported": bool(np.all(lower >= 0) and joint_lower > 0),
            "scope": "this fixed local continuation, including all paid queries",
        }


def head_correction(reference, candidate):
    proposal = list(map(int, reference))
    candidate = int(candidate)
    if candidate in proposal:
        position = proposal.index(candidate)
        proposal[0], proposal[position] = proposal[position], proposal[0]
    else:
        proposal[0] = candidate
    return proposal
