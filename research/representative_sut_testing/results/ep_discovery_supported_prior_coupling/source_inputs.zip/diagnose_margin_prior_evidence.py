"""History/neutral model evidence on identical already-paid neutral prefixes."""
from zipfile import ZipFile

import numpy as np
from scipy.special import log_ndtr, logsumexp, ndtr
from threadpoolctl import threadpool_limits
import torch

from methods.history_guided_testing.history import historical_risk, load_history, split_indices, subset
from methods.history_guided_testing.io import read_json, write_json
from methods.history_guided_testing.search import TestingSession

from .censored_margin_response import CensoredMarginResponse, historical_margin_prior, neutral_margin_prior
from .config import OUTPUT, POOL_SEEDS, SUT_IDS
from .frozen_coupling import FrozenReplay


SOURCE = OUTPUT / "neutral_margin_prior_coupling"
RESULTS = OUTPUT / "margin_prior_evidence_diagnostic"


def main():
    with ZipFile(SOURCE / "source_inputs.zip") as archive:
        for name in ("censored_margin_response.py", "frozen_coupling.py"):
            if archive.read(name) != (OUTPUT.parent / name).read_bytes():
                raise ValueError("Prior evidence diagnosis requires the frozen policy model")
    RESULTS.mkdir(parents=True, exist_ok=True)
    with ZipFile(RESULTS / "source_inputs.zip", "w") as archive:
        for path in sorted(OUTPUT.parent.glob("*.py")):
            archive.write(path, path.name)
    history = load_history()
    train, _ = split_indices(next(iter(history.values()))["x"])
    allowed = subset(history, train)
    rows = []
    torch.set_num_threads(1)
    with threadpool_limits(limits=1):
        for pool in range(len(POOL_SEEDS)):
            with np.load(OUTPUT / f"pool_{pool}" / SUT_IDS[0] / "responses.npz") as bank:
                x = bank["x"].copy()
            risk_prior, prior = historical_risk(allowed, x), historical_margin_prior(x)
            for sut in SUT_IDS:
                run = read_json(SOURCE / f"pool_{pool}" / sut / "neutral_margin_response_11.json")
                reference = FrozenReplay(TestingSession(x, 11, mode="global_feedback", prior=risk_prior))
                models = [CensoredMarginResponse(reference, x[:, 4], p, continuous_safe=True)
                          for p in (prior, neutral_margin_prior(prior))]
                logweights = np.full(2, -np.log(2))
                known, records = {}, []
                for query, observation in enumerate(run["queries"], 1):
                    index, risk, event = observation["index"], observation["risk"], observation["collision"]
                    means = np.array([float(m.mean[index]) for m in models])
                    variances = np.array([float(m.covariance[index, index] + m.noise[index]) for m in models])
                    saved = run["margin_records"][query - 1]
                    if not np.allclose([means[1], variances[1]], [saved["predictive_mean_before"], saved["predictive_variance_before"]], rtol=0, atol=1e-10):
                        raise ValueError("Neutral shadow differs from the actual paid predictions")
                    probability = ndtr(-means / np.sqrt(variances))
                    weights_before = np.exp(logweights)
                    if event:
                        likelihood = log_ndtr(-means / np.sqrt(variances))
                    else:
                        likelihood = -.5 * (np.log(2 * np.pi * variances) + (1 - risk - means) ** 2 / variances)
                    logweights += likelihood
                    logweights -= logsumexp(logweights)
                    records.append({"query": query, "index": index, "risk": risk, "collision": event,
                                    "log_predictive_likelihoods": likelihood.tolist(),
                                    "weights_before": weights_before.tolist(), "weights_after": np.exp(logweights).tolist(),
                                    "component_event_probabilities": probability.tolist(),
                                    "mixture_event_probability_before": float(weights_before @ probability)})
                    for model in models:
                        model.observe(index, risk, event)
                    known[index] = risk, event
                    reference.advance(known)
                if reference.order != run["reference_prefix_indices"]:
                    raise ValueError("Evidence diagnostic changed the original reference prefix")
                events = np.array([r["collision"] for r in records])
                probability = np.array([r["component_event_probabilities"] for r in records])
                mixture = np.array([r["mixture_event_probability_before"] for r in records])
                row = {"pool": pool, "sut_id": sut,
                       "history_weight_at_nodes": {str(t): records[t - 1]["weights_after"][0] for t in (10, 30, 50, 100, 150, 200)},
                       "event_brier_history": float(np.mean((events - probability[:, 0]) ** 2)),
                       "event_brier_neutral": float(np.mean((events - probability[:, 1]) ** 2)),
                       "event_brier_mixture": float(np.mean((events - mixture) ** 2))}
                rows.append(row)
                write_json(RESULTS / f"pool_{pool}" / f"{sut}.json", {"summary": row, "records": records})
                print("PRIOR EVIDENCE", pool, sut, row, flush=True)
    write_json(RESULTS / "summary.json", {"rows": rows, "paths": 12, "paid_records_replayed": 2400,
               "scope": "same paid neutral-policy prefixes; predictive likelihood uses event mass or positive-proxy density under a common mixed measure",
               "inference_scope": "ADF working posterior evidence, not exact model evidence or frequentist confidence",
               "new_physical_calls": 0, "significant_advantage_established": False})
    write_json(RESULTS / "progress.json", {"status": "complete", "paths": 12, "paid_records_replayed": 2400,
                                           "new_physical_calls": 0})


if __name__ == "__main__":
    main()
