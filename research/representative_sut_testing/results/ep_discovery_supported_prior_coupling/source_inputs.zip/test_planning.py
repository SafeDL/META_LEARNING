"""Budget values and dual-objective decisions, independently enumerated."""
import numpy as np
import torch

from .planning import action_values, choose_action


def test_budget_values_equal_explicit_branch_enumeration_without_reusing_the_query():
    probability = torch.tensor([0.3, 0.5, 0.8], dtype=torch.float64, device="cuda")
    weights = torch.tensor([[0.2, 0.8], [0.6, 0.4], [0.5, 0.5]],
                           dtype=torch.float64, device="cuda")
    forecasts = torch.tensor([[[0.3, 0.1, 0.9], [0.3, 0.6, 0.5]],
                              [[0.7, 0.5, 0.6], [0.1, 0.5, 0.95]],
                              [[0.1, 0.4, 0.8], [0.7, 0.2, 0.8]]],
                             dtype=torch.float64, device="cuda")
    before = forecasts.clone()
    actual = action_values(probability, weights, forecasts, 2).cpu().numpy()
    expected = []
    for query in range(3):
        value = [probability[query].item(), 2 * probability[query].item()]
        for branch in range(2):
            best = max(forecasts[query, branch, other].item() for other in range(3) if other != query)
            value[0] += weights[query, branch].item() * best
            value[1] += weights[query, branch].item() * best
        expected.append(value)
    np.testing.assert_allclose(actual, expected, atol=1e-12)
    torch.testing.assert_close(forecasts, before)


def test_last_query_has_no_future_information_reward():
    probability = torch.tensor([0.9, 0.5], dtype=torch.float64, device="cuda")
    actual = action_values(probability, None, None, 1).cpu().numpy()
    np.testing.assert_allclose(actual, [[0.9, 0.9], [0.5, 0.5]])


def test_dual_screen_and_no_gain_tie_rule_are_distinct():
    values = np.asarray([[10., 100.], [11., 99.], [10.5, 105.]])
    assert choose_action(values, 0, np.arange(3), checked=False) == 1
    assert choose_action(values, 0, np.arange(3), checked=True) == 2
    equal = np.ones((3, 2))
    assert choose_action(equal, 2, np.arange(3), checked=False) == 2
    assert choose_action(equal, 2, np.arange(3), checked=True) == 2
