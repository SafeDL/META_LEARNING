"""Support means all compatible thresholds agree; contradictions reject the model."""
from types import SimpleNamespace

import numpy as np
from scipy.special import ndtr

from .threshold_response import ThresholdResponse


def model():
    reference = SimpleNamespace(session=SimpleNamespace(gp=SimpleNamespace(
        covariance=np.diag([.09, .0001, .01]), mean=np.asarray([.9, .85, .6]), noise=.0025)), head=lambda: 0)
    candidate = ThresholdResponse(reference, [0, 0, 1])
    return candidate


def test_no_positive_event_cannot_identify_a_strict_discovery_improvement():
    candidate = model()
    assert candidate.rank(np.ones(3, dtype=bool), tie_break=np.arange(3))[0] == 0


def test_all_compatible_thresholds_support_a_lower_uncertainty_candidate():
    candidate = model()
    candidate.positive[0] = 1
    candidate.upper[0] = .8
    assert candidate.rank(np.ones(3, dtype=bool), tie_break=np.arange(3))[0] == 1
    deviation = np.sqrt(candidate.gp.variance + candidate.gp.noise)
    thresholds = np.linspace(0, .8, 1000)
    gains = ndtr((.85 - thresholds) / deviation[1]) - ndtr((.9 - thresholds) / deviation[0])
    assert np.min(gains) >= candidate.checks[-1]["worst_model_probability_gain"] - 1e-12


def test_ranking_disagreement_defers_to_reference():
    candidate = model()
    candidate.positive[0] = 1
    candidate.upper[0] = .99
    assert candidate.rank(np.ones(3, dtype=bool), tie_break=np.arange(3))[0] == 0


def test_contradictory_risk_event_pairs_invalidate_the_threshold_explanation():
    candidate = model()
    candidate.family[2] = 0
    candidate.observe(1, .7, True)
    candidate.observe(2, .8, False)
    assert not candidate.consistent(0)
    assert candidate.rank(np.ones(3, dtype=bool), tie_break=np.arange(3))[0] == 0


def test_negative_risk_one_is_a_consistent_all_safe_hypothesis():
    candidate = model()
    candidate.lower[1] = 1
    assert candidate.consistent(1) and candidate.positive[1] == 0
