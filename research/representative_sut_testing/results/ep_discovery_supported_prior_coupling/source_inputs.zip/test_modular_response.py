"""Evidence is measured before risk arrives; score regret is pathwise."""
import math

import numpy as np
import torch

from .modular_response import ModularResponse


class Forecast:
    def __init__(self, probability):
        self.probability = probability
        self.risk_seen = False

    def clone(self):
        return Forecast(.2)

    def event_probabilities(self):
        return torch.tensor([self.probability], dtype=torch.float64)

    def observe(self, index, risk, collision):
        self.risk_seen = True
        self.probability = .99 if collision else .01

    def observe_event(self, index, collision):
        self.probability = .8 if collision else .2


def test_current_risk_cannot_leak_into_module_evidence():
    model = ModularResponse(Forecast(.9))
    model.observe(0, .99, False)
    np.testing.assert_allclose(model.records[0]["event_probabilities_before_risk"], [.9, .2])
    np.testing.assert_allclose(model.weights(), [.1 / .9, .8 / .9])
    assert model.with_risk.risk_seen


def test_mixture_regret_bound_on_an_adaptively_updated_sequence():
    model = ModularResponse(Forecast(.9))
    for collision in ([True] * 8 + [False, True, False, False] * 10):
        model.observe(0, float(collision), collision)
        report = model.diagnostics()
        assert report["mixture_log_loss"] <= min(report["expert_log_losses"]) + math.log(2) + 1e-12
        assert np.isclose(sum(report["module_weights"]), 1)
