"""Test binary-loss-supported reference observation against fixed pairing."""
import multiprocessing as mp
import time
from zipfile import ZipFile

import numpy as np
from threadpoolctl import threadpool_limits
import torch

from methods.history_guided_testing.experiment import RemoteOracle
from methods.history_guided_testing.history import historical_risk, load_history, split_indices, subset
from methods.history_guided_testing.io import read_json, write_json
from methods.history_guided_testing.search import TestingSession
from research.risk_conditioned_response_testing.confirmation import CONFIRMATION

from .adaptive_margin_prior import AdaptiveMarginPrior
from .baselines import verify_baseline_inputs
from .censored_margin_response import historical_margin_prior
from .config import BUDGET, INITIAL_QUERIES, OUTPUT, POOL_SEEDS, SUT_IDS
from .decision_support import SUPPORT_THRESHOLD, bivariate_normal_probability
from .develop import disclose
from .discovery_supported_coupling import run_supported_policy
from .evaluate_adaptive_margin_prior import audit_adaptive
from .frozen_coupling import FrozenReplay
from .ep_margin_response import ExpectationPropagatedMargin
from .evaluate_discovery_support import audit_support


RESULTS = OUTPUT / "ep_discovery_supported_prior_coupling"
SEED = 11
METHOD = "ep_discovery_supported_prior"


def selector_worker(connection):
    try:
        torch.set_num_threads(1)
        with threadpool_limits(limits=1):
            while True:
                message, task = connection.recv()
                if message == "stop":
                    return
                reference = FrozenReplay(TestingSession(task["x"], SEED, mode="global_feedback", prior=task["risk_prior"]))
                candidate = AdaptiveMarginPrior(reference, task["x"][:, 4], task["margin_prior"], freeze_after_initialization=False, model_class=ExpectationPropagatedMargin)
                tie = np.random.default_rng(SEED).random(len(task["x"]))
                run = run_supported_policy(reference, candidate, RemoteOracle(connection), tie, BUDGET, INITIAL_QUERIES)
                run.update(candidate.diagnostics())
                connection.send(("result", run))
    except Exception as error:
        connection.send(("error", repr(error)))
        raise
    finally:
        connection.close()


def main():
    verify_baseline_inputs(read_json(CONFIRMATION / "protocol.json"))
    RESULTS.mkdir(parents=True, exist_ok=True)
    write_json(RESULTS / "protocol.json", {
        "stage": "joint EP versus ADF inference; same observation and decision-equivalence rules",
        "sut_ids": SUT_IDS, "pools": [0, 1], "seed": SEED, "budget": BUDGET,
        "new_curves": 12, "reused_controls": 24,
        "model": "same history/neutral models, likelihood, priors and decision rule; only ADF replaced by joint EP refitting",
        "decision": "candidate mean collision probability must improve; current reference slot can be replaced only if joint candidate-miss/reference-hit probability <=1/sqrt(200)",
        "joint_probability": "Gaussian report covariance includes independent observation noise; deterministic bivariate normal quadrature, then prior-model averaging",
        "scope": "working immediate binary loss, not strict propensity ranking or a true-world confidence statement",
        "threshold": float(1 - SUPPORT_THRESHOLD), "threshold_design": "locked budget-only 1/sqrt(B), no target-dependent threshold search",
        "protection": "unchanged actual discovery credit and independent paid-reference replay",
        "coverage": "fixed 105-position prefix guarantee removed when supported reference slots are skipped; actual count bound retained",
        "controls": "existing frozen_reference and ADF discovery_supported_prior trajectories",
        "ep_inference": "parallel damped site refitting; exact safe Gaussian sites, inequality moment matching; tolerance 1e-7, maximum 200 iterations",
        "new_physical_calls": 0})
    snapshot = RESULTS / "source_inputs.zip"
    if not snapshot.exists():
        with ZipFile(snapshot, "w") as archive:
            for path in sorted(OUTPUT.parent.glob("*.py")):
                archive.write(path, path.name)
    with ZipFile(snapshot) as archive:
        if any(archive.read(n) != (OUTPUT.parent / n).read_bytes() for n in archive.namelist()):
            raise ValueError("Discovery support code changed after freezing")
    history = load_history()
    train, _ = split_indices(next(iter(history.values()))["x"])
    allowed = subset(history, train)
    context = mp.get_context("spawn")
    parent, child = context.Pipe()
    process = context.Process(target=selector_worker, args=(child,))
    process.start()
    child.close()
    rows = []
    try:
        for pool in range(len(POOL_SEEDS)):
            with np.load(OUTPUT / f"pool_{pool}" / SUT_IDS[0] / "responses.npz") as bank:
                x = bank["x"].copy()
            risk_prior, margin = historical_risk(allowed, x), historical_margin_prior(x)
            for sut in SUT_IDS:
                with np.load(OUTPUT / f"pool_{pool}" / sut / "responses.npz") as bank:
                    baseline = read_json(OUTPUT / f"pool_{pool}" / sut / "baselines" / f"frozen_original_{SEED}.json")
                    controls = OUTPUT / "neutral_margin_prior_coupling" / f"pool_{pool}" / sut
                    for method in ("frozen_reference", "discovery_supported_prior", METHOD):
                        if method == METHOD:
                            path = RESULTS / f"pool_{pool}" / sut / f"{METHOD}_{SEED}.json"
                            if path.exists():
                                run = read_json(path)
                            else:
                                started = time.perf_counter()
                                run = disclose(parent, {"x": x, "risk_prior": risk_prior, "margin_prior": margin}, bank["risk"], bank["collision"])
                                run.update(method=METHOD, seed=SEED, selector_elapsed_s=time.perf_counter() - started)
                                write_json(path, run)
                            audit_adaptive(run, METHOD, bank, baseline, controls, paired_reference=False)
                            audit_support(run)
                            if any(len(updates) != BUDGET or any(u["relative_site_change"] >= 1e-7 for u in updates) for updates in run["component_inference_updates"]):
                                raise ValueError("EP inference records are missing or unconverged")
                            print("DISCOVERY SUPPORT", pool, sut, run["F200"], run["reference_observations_skipped"], flush=True)
                            write_json(RESULTS / "progress.json", {"status": "running", "latest": str(path.relative_to(RESULTS)), "expected_new_curves": 12})
                        else:
                            source = controls if method == "frozen_reference" else OUTPUT / "discovery_supported_prior_coupling" / f"pool_{pool}" / sut
                            run = read_json(source / f"{method}_{SEED}.json")
                        rows.append({"pool": pool, "sut_id": sut, "method": method,
                                     "area_pct": 100 * run["area_200"], "recall_pct": 100 * run["recall_200"], "F200": run["F200"]})
    finally:
        if process.is_alive():
            parent.send(("stop", None))
        parent.close()
        process.join(timeout=10)
        if process.is_alive():
            process.terminate()
            process.join()
        if process.exitcode != 0:
            raise RuntimeError(f"Discovery support selector exited {process.exitcode}")
    aggregate = {m: {k: float(np.mean([r[k] for r in rows if r["method"] == m])) for k in ("area_pct", "recall_pct", "F200")}
                 for m in ("frozen_reference", "discovery_supported_prior", METHOD)}
    changes = {m: {"area_pp": aggregate[METHOD]["area_pct"] - aggregate[m]["area_pct"],
                   "recall_pp": aggregate[METHOD]["recall_pct"] - aggregate[m]["recall_pct"]} for m in ("frozen_reference", "discovery_supported_prior")}
    summary = {"rows": rows, "aggregate": aggregate, "candidate_changes": changes, "new_curves": 12,
               "reused_controls": 24, "joint_binary_support_verified": True, "full_reference_bounds_verified": True,
               "significant_advantage_established": False}
    write_json(RESULTS / "summary.json", summary)
    lines = ["# 发现损失支持下的参照观测", "", "新执行 12 条策略曲线，复用 24 条既有控制；同 SUT、场景、模型与 200 次预算。",
             "只修改参照时段：当联合工作后验中的候选无碰撞／参照碰撞概率不超过 1/sqrt(200)，且实际损失额度允许时，继续候选。",
             "不要求严格辨明潜在倾向排序。固定前缀至少 105 项的保证已移除，实际全程计数界保持不变。", "",
             "| 方法 | Area % | Recall % | 平均 F200 |", "|---|---:|---:|---:|"]
    for method, value in aggregate.items():
        lines.append(f"| {method} | {value['area_pct']:.3f} | {value['recall_pct']:.3f} | {value['F200']:.2f} |")
    lines += ["", "| 池 | SUT | 方法 | Area % | Recall % | F200 |", "|---|---|---|---:|---:|---:|"]
    for row in rows:
        lines.append(f"| {row['pool']} | {row['sut_id']} | {row['method']} | {row['area_pct']:.3f} | {row['recall_pct']:.3f} | {row['F200']} |")
    lines += ["", "查询前证据、联合概率、条件参照观测、实际反馈及原参照全程界核对通过。",
              "支持量来自 ADF 工作后验，不是未知目标的频率保证；本轮不自动补种子或宣称显著优势。"]
    (RESULTS / "report.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    write_json(RESULTS / "progress.json", {"status": "complete", "new_curves": 12, "reused_controls": 24,
                                         "new_disclosures": 12 * BUDGET, "new_physical_calls": 0})
    print({"aggregate": aggregate, "candidate_changes": changes}, flush=True)


if __name__ == "__main__":
    main()
