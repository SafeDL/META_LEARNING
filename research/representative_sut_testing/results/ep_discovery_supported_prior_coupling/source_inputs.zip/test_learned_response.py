"""Changing local spatial correlation preserves task modes and prior marginals."""
import numpy as np
import torch

from .learned_response import learned_local_covariance
from .response import ResponseModel


def test_learned_residual_correlation_preserves_marginals_and_task_modes():
    x = np.asarray([[0., 0., 0., 0., 0.], [.1, .1, .1, .1, 0.], [0., 0., 0., 0., 1.]])
    risk = np.asarray([[.1, .9], [.2, .8], [.1, .9]])
    event = np.asarray([[.1, .9], [.2, .8], [.1, .9]])
    calibration = {"risk_local_variance": [.01, .01], "event_local_variance": [.04, .04],
                   "risk_event_local_covariance": [.015, .015]}
    model = ResponseModel(x, risk, event, calibration)
    initial_mean = model.mean.clone()
    diagonal = model.covariance.diagonal().clone()
    probabilities = model.event_probabilities().clone()
    loading = model.covariance[:, :model.sources].clone()
    learned_local_covariance(model, np.asarray([[2., .3, .2], [.3, 3., .4], [.2, .4, 4.]]))
    torch.testing.assert_close(model.mean, initial_mean)
    torch.testing.assert_close(model.covariance.diagonal(), diagonal)
    torch.testing.assert_close(model.event_probabilities(), probabilities)
    torch.testing.assert_close(model.covariance[:, :model.sources], loading)
    torch.testing.assert_close(model.covariance, model.covariance.T)
    assert torch.linalg.eigvalsh(model.covariance).min() >= -1e-10
    task = loading @ loading.T
    i, j = model.event_indices[0], model.event_indices[2]
    assert abs(float(model.covariance[i, j] - task[i, j])) < 1e-12
