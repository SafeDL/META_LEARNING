"""Measure how paid feedback changes a fixed remaining-budget forecast."""
import copy
from zipfile import ZipFile

import numpy as np
from threadpoolctl import threadpool_limits

from methods.history_guided_testing.history import historical_risk, load_history, split_indices, subset
from methods.history_guided_testing.io import read_json, write_json
from methods.history_guided_testing.search import TestingSession

from .config import BUDGET, INITIAL_QUERIES, OUTPUT, POOL_SEEDS, SUT_IDS
from .frozen_coupling import FrozenReplay
from .risk_event_response import RiskEventResponse, fit_event_readout
from .risk_task_prior import risk_templates
from .student_risk_prior import add_student_risk_variation


SOURCE = OUTPUT / "student_risk_coupling"
RESULTS = OUTPUT / "feedback_decision_value_diagnostic"
SEED = 11
QUERY_NODES = (10, 30, 50, 100, 150, 190)


def forecast(model, available, tie, budget):
    indices = np.flatnonzero(available)
    probability = model.probabilities()
    order = np.lexsort((tie[indices], -model.gp.mean[indices], -np.round(probability[indices], 12)))
    chosen = indices[order[:budget]]
    return {"indices": chosen.tolist(), "expected_found": float(probability[chosen].sum()),
            "expected_area": float(probability[chosen] @ np.arange(budget, 0, -1))}


def evaluate_forecast(forecast, labels):
    events = labels[forecast["indices"]]
    return {**forecast, "actual_found": int(events.sum()), "actual_area": int(np.cumsum(events).sum())}


def main():
    with ZipFile(SOURCE / "source_inputs.zip") as archive:
        for name in ("frozen_coupling.py", "risk_event_response.py", "risk_task_prior.py", "student_risk_prior.py"):
            if archive.read(name) != (OUTPUT.parent / name).read_bytes():
                raise ValueError("Feedback diagnostic requires the frozen Student risk implementation")
    RESULTS.mkdir(parents=True, exist_ok=True)
    with ZipFile(RESULTS / "source_inputs.zip", "w") as archive:
        for path in sorted(OUTPUT.parent.glob("*.py")):
            archive.write(path, path.name)
    history = load_history()
    train, _ = split_indices(next(iter(history.values()))["x"])
    allowed = subset(history, train)
    readout = fit_event_readout(RESULTS)
    rows = []
    with threadpool_limits(limits=1):
        for pool in range(len(POOL_SEEDS)):
            with np.load(OUTPUT / f"pool_{pool}" / SUT_IDS[0] / "responses.npz") as bank:
                x = bank["x"].copy()
            prior, templates = historical_risk(allowed, x), risk_templates(allowed, x)
            for sut in SUT_IDS:
                run = read_json(SOURCE / f"pool_{pool}" / sut / "coupled_response_11.json")
                reference = FrozenReplay(TestingSession(x, SEED, mode="global_feedback", prior=prior))
                candidate = add_student_risk_variation(RiskEventResponse(reference, x[:, 4], readout), templates)
                tie = np.random.default_rng(SEED).random(len(x))
                available = np.ones(len(x), dtype=bool)
                known, found = {}, 0
                predictions = []
                for query, observation in enumerate(run["queries"], 1):
                    reference.advance(known)
                    head = reference.head()
                    debt = reference.certificate(known)["negative_extra_count"]
                    permitted = debt + 1 <= 1 + found / np.sqrt(BUDGET) + 1e-12
                    proposed = head if query <= INITIAL_QUERIES or not permitted else int(candidate.rank(available, tie_break=tie)[0])
                    index, risk, event = observation["index"], observation["risk"], observation["collision"]
                    if proposed != index:
                        raise ValueError("Feedback diagnostic differs from the paid selection")
                    future = available.copy()
                    future[index] = False
                    if query in QUERY_NODES:
                        budget = BUDGET - query
                        before = forecast(candidate, future, tie, budget)
                        risk_only = copy.copy(candidate)
                        risk_only.gp = copy.deepcopy(candidate.gp)
                        risk_only.gp.observe(index, risk)
                        after_risk = forecast(risk_only, future, tie, budget)
                    candidate.observe(index, risk, event)
                    known[index] = risk, event
                    available[index] = False
                    found += int(event)
                    reference.advance(known)
                    if query in QUERY_NODES:
                        after_full = forecast(candidate, future, tie, budget)
                        predictions.append({"query": query, "index": index, "role": observation["role"],
                                            "risk": risk, "collision": event, "remaining_budget": budget,
                                            "before": before, "after_risk": after_risk, "after_full": after_full})
                if reference.order != run["reference_prefix_indices"]:
                    raise ValueError("Feedback diagnostic changed the reference trajectory")
                # Only the evaluator below reads future collision labels.
                with np.load(OUTPUT / f"pool_{pool}" / sut / "responses.npz") as bank:
                    for prediction in predictions:
                        prediction.update(pool=pool, sut_id=sut)
                        for key in ("before", "after_risk", "after_full"):
                            prediction[key] = evaluate_forecast(prediction[key], bank["collision"])
                        baseline = prediction["before"]
                        for key in ("after_risk", "after_full"):
                            updated = prediction[key]
                            updated["changed_members"] = len(set(updated["indices"]) - set(baseline["indices"]))
                            updated["actual_found_gain"] = updated["actual_found"] - baseline["actual_found"]
                            updated["actual_area_gain"] = updated["actual_area"] - baseline["actual_area"]
                        rows.append(prediction)
                write_json(RESULTS / f"pool_{pool}" / f"{sut}.json", {"records": predictions})
                write_json(RESULTS / "progress.json", {"status": "running", "states": len(rows), "expected": 72})
                print("FEEDBACK VALUE", pool, sut, [(p["query"], p["after_full"]["changed_members"],
                      p["after_full"]["actual_found_gain"]) for p in predictions], flush=True)
    aggregates = {key: {"mean_changed_members": float(np.mean([r[key]["changed_members"] for r in rows])),
                        "states_found_improved": sum(r[key]["actual_found_gain"] > 0 for r in rows),
                        "states_found_worsened": sum(r[key]["actual_found_gain"] < 0 for r in rows),
                        "mean_actual_found_gain": float(np.mean([r[key]["actual_found_gain"] for r in rows])),
                        "mean_actual_area_gain": float(np.mean([r[key]["actual_area_gain"] for r in rows]))}
                  for key in ("after_risk", "after_full")}
    write_json(RESULTS / "summary.json", {"rows": rows, "aggregate": aggregates,
               "scope": "development-only fixed-batch forecast; equal future set and budget before/after actual paid feedback, not an adaptive policy comparison",
               "replayed_paths": 12, "states": 72, "query_nodes": QUERY_NODES,
               "no_future_labels_in_predictions": True, "new_physical_calls": 0,
               "significant_advantage_established": False})
    write_json(RESULTS / "progress.json", {"status": "complete", "paths": 12, "states": 72, "new_physical_calls": 0})
    print(aggregates, flush=True)


if __name__ == "__main__":
    main()
