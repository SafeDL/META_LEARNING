"""Historical versus neutral event priors under one mixed observation model."""
import multiprocessing as mp
import time
from zipfile import ZipFile

import numpy as np
from scipy.special import log_ndtr
from threadpoolctl import threadpool_limits
import torch

from methods.history_guided_testing.experiment import RemoteOracle
from methods.history_guided_testing.history import historical_risk, load_history, split_indices, subset
from methods.history_guided_testing.io import read_json, write_json
from methods.history_guided_testing.search import TestingSession
from research.risk_conditioned_response_testing.confirmation import CONFIRMATION

from .baselines import verify_baseline_inputs
from .censored_margin_response import CensoredMarginResponse, historical_margin_prior, neutral_margin_prior
from .config import BUDGET, INITIAL_QUERIES, OUTPUT, POOL_SEEDS, SEEDS, SUT_IDS
from .develop import disclose, metrics
from .frozen_coupling import FrozenReplay, run_policy


RESULTS = OUTPUT / "neutral_margin_prior_coupling"
METHODS = ("frozen_reference", "history_margin_response", "neutral_margin_response")


def selector_worker(connection):
    try:
        torch.set_num_threads(1)
        with threadpool_limits(limits=1):
            while True:
                message, task = connection.recv()
                if message == "stop":
                    return
                if message != "task" or task["method"] not in METHODS:
                    raise ValueError("Invalid censored-margin task")
                session = TestingSession(task["x"], task["seed"], mode="global_feedback", prior=task["risk_prior"])
                reference = FrozenReplay(session)
                margin_prior = neutral_margin_prior(task["margin_prior"]) if task["method"] == "neutral_margin_response" else task["margin_prior"]
                model = CensoredMarginResponse(reference, task["x"][:, 4], margin_prior, continuous_safe=True)
                error = float(np.max(np.abs(model.probabilities() - margin_prior["probability"])))
                if error > 1e-10:
                    raise ValueError("Margin prior does not preserve historical collision probability")
                tie = np.random.default_rng(task["seed"]).random(len(task["x"]))
                result = run_policy(task["method"], reference, model, RemoteOracle(connection),
                                    tie, BUDGET, INITIAL_QUERIES)
                result.update(model.diagnostics(), prior_probability_max_error=error)
                connection.send(("result", result))
    except Exception as error:
        connection.send(("error", repr(error)))
        raise
    finally:
        connection.close()


def audit_run(run, method, bank, baseline, *, paired_reference=True):
    order = run["selected_indices"]
    if len(order) != BUDGET or len(set(order)) != BUDGET:
        raise ValueError("Invalid mixed-feedback paid budget")
    actual = metrics(bank["collision"], order)
    if any(run[k] != actual[k] for k in ("area_200", "recall_200", "curve", "F200")):
        raise ValueError("Margin metrics differ from measured events")
    expected = [{"index": i, "risk": float(bank["risk"][i]), "collision": bool(bank["collision"][i])} for i in order]
    if run["disclosures"] != expected or len(run["margin_records"]) != BUDGET or run["margin_observations"] != BUDGET:
        raise ValueError("Margin feedback differs from actual paid disclosures")
    for observation, record in zip(expected, run["margin_records"]):
        if any(record[k] != observation[k] for k in observation):
            raise ValueError("Margin inference uses unrequested feedback")
        continuous = not record["collision"]
        likelihood = "positive_value" if continuous else "negative_censor" if record["collision"] else "positive_censor"
        proxy = 1 - record["risk"] if continuous else None
        if record["likelihood"] != likelihood or record["observed_proxy"] != proxy:
            raise ValueError("Mixed likelihood does not match the declared observation type")
        mean, variance = record["predictive_mean_before"], record["predictive_variance_before"]
        if variance <= 0:
            raise ValueError("Invalid margin predictive variance")
        if continuous:
            innovation, strength = (proxy - mean) / np.sqrt(variance), 1.
        else:
            sign = -1 if record["collision"] else 1
            z = sign * mean / np.sqrt(variance)
            ratio = np.exp(-.5 * z ** 2 - .5 * np.log(2 * np.pi) - log_ndtr(z))
            innovation, strength = sign * ratio, np.clip(ratio * (ratio + z), 0, 1)
        if not np.allclose([innovation, strength], [record["standardized_mean_innovation"],
                            record["conditional_variance_factor"]], rtol=1e-8, atol=1e-8):
            raise ValueError("Margin moment update differs from its observation likelihood")
    if method == "frozen_reference" and order != baseline["selected_indices"]:
        raise ValueError("Frozen reference no longer matches retained baseline")
    if order[:10] != baseline["selected_indices"][:10]:
        raise ValueError("Margin controls have different initialization")
    prefix = run["reference_prefix_indices"]
    if prefix != baseline["selected_indices"][:len(prefix)] or len(run["coupling_checks"]) != BUDGET:
        raise ValueError("Margin coupling changed the independent reference")
    gains = np.asarray(run["curve"]) - baseline["curve"]
    bounds = []
    for t, check in enumerate(run["coupling_checks"], 1):
        k = check["reference_prefix_length"]
        coverage = t if t <= 10 else 10 + (t - 9) // 2 if paired_reference else INITIAL_QUERIES
        scheduled = t > 10 and (t - 11) % 2 == 0
        if not coverage <= k <= t or check["scheduled_reference"] != scheduled:
            raise ValueError("Margin policy violates reference coverage")
        if paired_reference and scheduled and check["chosen_index"] != check["reference_index"]:
            raise ValueError("Scheduled reference observation was skipped")
        extra = [i for i in order[:t] if i not in prefix[:k]]
        negative = [i for i in extra if not bank["collision"][i]]
        if (extra != check["extra_indices"] or negative != check["negative_extra_indices"]
                or check["negative_extra_count"] != len(negative) or check["discovery_gain_lower"] != -len(negative)):
            raise ValueError("Margin reference ledger differs from the paid prefix")
        if gains[t - 1] < -len(negative):
            raise ValueError("Margin discovery curve violates the reference count bound")
        if method != "frozen_reference":
            found = run["curve"][t - 1]
            if len(negative) > 1 + found / np.sqrt(BUDGET) + 1e-12:
                raise ValueError("Margin policy exceeds discovery credit")
            if found < (baseline["curve"][t - 1] - 1) / (1 + 1 / np.sqrt(BUDGET)) - 1e-12:
                raise ValueError("Margin policy violates the full relative discovery bound")
        bounds.append(-len(negative))
    if sum(bounds) != run["area_gain_lower"] or bounds[-1] != run["terminal_gain_lower"] or gains.sum() < sum(bounds):
        raise ValueError("Margin area or terminal accounting is inconsistent")
    for check in run["regime_selection_checks"]:
        i, j = check["chosen_index"], check["reference_index"]
        if order[check["query"] - 1] != i or bank["x"][i, 4] != bank["x"][j, 4]:
            raise ValueError("Margin candidate changed the declared functional regime")
        if i != j and check["chosen_probability"] <= check["reference_probability"] + 1e-12:
            raise ValueError("Margin correction lacks its declared probability advantage")


def summarize(seeds):
    rows = []
    for pool in range(len(POOL_SEEDS)):
        for sut in SUT_IDS:
            folder = OUTPUT / f"pool_{pool}" / sut
            with np.load(folder / "responses.npz") as bank:
                for method in METHODS:
                    runs = []
                    for seed in seeds:
                        run = read_json(RESULTS / f"pool_{pool}" / sut / f"{method}_{seed}.json")
                        audit_run(run, method, bank, read_json(folder / "baselines" / f"frozen_original_{seed}.json"))
                        runs.append(run)
                    rows.append({"pool": pool, "sut_id": sut, "method": method,
                                 "area_pct": float(100 * np.mean([r["area_200"] for r in runs])),
                                 "recall_pct": float(100 * np.mean([r["recall_200"] for r in runs])),
                                 "F200": float(np.mean([r["F200"] for r in runs])),
                                 "distinct_sequences": len({tuple(r["selected_indices"]) for r in runs})})
    aggregate = {m: {k: float(np.mean([r[k] for r in rows if r["method"] == m]))
                     for k in ("area_pct", "recall_pct", "F200")} for m in METHODS}
    candidate = aggregate["neutral_margin_response"]
    changes = {m: {"area_pp": candidate["area_pct"] - aggregate[m]["area_pct"],
                   "recall_pp": candidate["recall_pct"] - aggregate[m]["recall_pct"]} for m in METHODS[:-1]}
    return {"rows": rows, "aggregate": aggregate, "candidate_changes": changes,
            "gate_passed": all(c["area_pp"] > 0 and c["recall_pp"] > 0 for c in changes.values()),
            "seeds": list(seeds), "audited_runs": len(rows) * len(seeds),
            "mixed_likelihood_feedback_verified": True, "full_reference_bounds_verified": True,
            "significant_advantage_established": False}


def evaluate(connection, seeds, allowed):
    for pool in range(len(POOL_SEEDS)):
        with np.load(OUTPUT / f"pool_{pool}" / SUT_IDS[0] / "responses.npz") as bank:
            x = bank["x"].copy()
        margin = historical_margin_prior(x)
        risk_prior = historical_risk(allowed, x)
        np.savez(RESULTS / f"margin_prior_pool_{pool}.npz", **{k: v for k, v in margin.items() if isinstance(v, np.ndarray)})
        neutral = neutral_margin_prior(margin)
        np.savez(RESULTS / f"neutral_prior_pool_{pool}.npz", **{k: v for k, v in neutral.items() if isinstance(v, np.ndarray)})
        write_json(RESULTS / f"margin_prior_pool_{pool}.json", {"safe_source_counts": margin["safe_source_counts"], "scope": margin["scope"]})
        for sut in SUT_IDS:
            with np.load(OUTPUT / f"pool_{pool}" / sut / "responses.npz") as bank:
                if not np.array_equal(x, bank["x"]):
                    raise ValueError("Margin SUTs do not share the same pool")
                for seed in seeds:
                    for method in METHODS:
                        path = RESULTS / f"pool_{pool}" / sut / f"{method}_{seed}.json"
                        if path.exists():
                            continue
                        started = time.perf_counter()
                        task = {"method": method, "seed": seed, "x": x, "risk_prior": risk_prior, "margin_prior": margin}
                        run = disclose(connection, task, bank["risk"], bank["collision"])
                        run.update(method=method, seed=seed, selector_elapsed_s=time.perf_counter() - started)
                        write_json(path, run)
                        write_json(RESULTS / "progress.json", {"status": "running", "latest": str(path.relative_to(RESULTS)),
                                                              "screening_runs": 36, "conditional_full_runs": 180})
                        print("CENSORED MARGIN", pool, sut, seed, method, run["F200"], flush=True)


def main():
    verify_baseline_inputs(read_json(CONFIRMATION / "protocol.json"))
    RESULTS.mkdir(parents=True, exist_ok=True)
    write_json(RESULTS / "protocol.json", {
        "stage": "existing six-SUT development, no blind significance claim", "sut_ids": SUT_IDS,
        "pools": list(range(len(POOL_SEEDS))), "methods": METHODS, "budget": BUDGET,
        "initialization": "same first ten frozen_original queries",
        "prior": "historical event probability versus fixed neutral p=0.5; same six-source conditional safe proxy means",
        "covariance": "same normalized learned correlation and source response modes; marginal mean/variance uniquely calibrated to selected event prior and unchanged positive-report mean",
        "noise": "original locked noise-to-total-variance ratio, scaled by the margin report variance",
        "observation": "latent reported margin Z+noise; safe case reports 1-R, collision constrains it <=0 without a numeric negative value",
        "semantic_scope": "constructed latent observation model; raw Risk is not a censored collision threshold and proxy is not a physical distance",
        "history_control": "exact previous censored_margin_response model; same feedback, pairing and protection",
        "neutral_choice": "p=0.5 fixed a priori, no target-dependent threshold or prior search; historical safe-proxy scale and correlation retained",
        "inference": "GPU float64 Gaussian assumed-density filtering; numerical values and Gaussian inequality moments",
        "selection": "same functional regime, strict predictive collision-probability advantage, paired reference schedule",
        "protection": "same actual paid-reference replay and L_t<=1+F_actual(t)/sqrt(200)",
        "selector_payload": "coordinates, history-only priors and seed; no SUT identity/parameters/future labels",
        "screening_seeds": SEEDS[:1], "conditional_seeds": SEEDS,
        "promotion": "both Area and Recall improve against frozen reference and historical-prior mixed model",
        "new_physical_calls": 0})
    snapshot = RESULTS / "source_inputs.zip"
    if not snapshot.exists():
        with ZipFile(snapshot, "w") as archive:
            for path in sorted(OUTPUT.parent.glob("*.py")):
                archive.write(path, path.name)
    with ZipFile(snapshot) as archive:
        if any(archive.read(n) != (OUTPUT.parent / n).read_bytes() for n in archive.namelist()):
            raise ValueError("Margin source changed after freezing")
    history = load_history()
    train, _ = split_indices(next(iter(history.values()))["x"])
    allowed = subset(history, train)
    context = mp.get_context("spawn")
    parent, child = context.Pipe()
    process = context.Process(target=selector_worker, args=(child,))
    process.start()
    child.close()
    try:
        evaluate(parent, SEEDS[:1], allowed)
        screening = summarize(SEEDS[:1])
        write_json(RESULTS / "screening.json", screening)
        if screening["gate_passed"]:
            evaluate(parent, SEEDS[1:], allowed)
            final = summarize(SEEDS)
        else:
            final = screening
    finally:
        if process.is_alive():
            parent.send(("stop", None))
        parent.close()
        process.join(timeout=10)
        if process.is_alive():
            process.terminate()
            process.join()
        if process.exitcode != 0:
            raise RuntimeError(f"Margin selector exited {process.exitcode}")
    write_json(RESULTS / "summary.json", final)
    lines = ["# 历史与中性事件先验的有限筛查", "",
             "六固定 SUT、两共享池、200 次唯一查询及共同十次初始化；两步排程和发现额度不变。",
             "两个余量模型共享混合似然、历史安全代理均值及相关性结构；历史事件先验与固定 p=0.5 中性先验分别匹配边缘均值和方差。",
             "为保持正报告条件均值，事件先验改变时边缘尺度也随唯一矩匹配解改变；绝对协方差并非完全相同。",
             "无碰撞代理值为 1−Risk，碰撞只提供非正潜在余量约束；潜变量是工作模型，不是实际车距或原 Risk 的物理截断。",
             "Gaussian ADF 为近似推断，不自动提供未知 SUT 上的校准保证。", "",
             "| 方法 | Area % | Recall % | 平均 F200 |", "|---|---:|---:|---:|"]
    for method, value in final["aggregate"].items():
        lines.append(f"| {method} | {value['area_pct']:.3f} | {value['recall_pct']:.3f} | {value['F200']:.2f} |")
    lines += ["", "| 池 | SUT | 方法 | Area % | Recall % | F200 |", "|---|---|---|---:|---:|---:|"]
    for row in final["rows"]:
        lines.append(f"| {row['pool']} | {row['sut_id']} | {row['method']} | {row['area_pct']:.3f} | {row['recall_pct']:.3f} | {row['F200']:.2f} |")
    lines += ["", f"{final['audited_runs']} 条曲线、{final['audited_runs'] * BUDGET} 次披露与混合似然、原参照及全程计数界核对通过。",
              "未通过筛查，不补种子。" if not screening["gate_passed"] else "通过初筛后补齐五种子；开发池仍不能证明显著优势。"]
    (RESULTS / "report.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    write_json(RESULTS / "progress.json", {"status": "complete", "runs": final["audited_runs"],
                                         "disclosures": final["audited_runs"] * BUDGET,
                                         "gate_passed": final["gate_passed"], "new_physical_calls": 0})
    print({"aggregate": final["aggregate"], "candidate_changes": final["candidate_changes"], "gate_passed": final["gate_passed"]}, flush=True)


if __name__ == "__main__":
    main()
