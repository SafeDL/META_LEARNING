"""Past response templates permit nonmonotone labels without task identity inputs."""
import numpy as np
import torch

from .response import ResponseModel, historical_predictions


def test_history_template_keeps_nonmonotone_risk_event_pairs():
    x = np.asarray([[0., 0., 0., 0., 0.], [1., 1., 1., 1., 0.]])
    bank = {"x": x, "past": np.asarray([.7, .8]), "past_collision": np.asarray([True, False])}
    risk, event = historical_predictions(x, bank, ["past"])
    np.testing.assert_array_equal(risk[:, 0], [.7, .8])
    np.testing.assert_array_equal(event[:, 0], [1, 0])


def test_expanded_response_covariance_is_valid_and_event_feedback_updates_task_state():
    rng = np.random.default_rng(31)
    x = np.asarray([[0., 0., 0., 0., 0.], [.5, .5, .5, .5, 0.], [0., 0., 0., 0., 1.]])
    risk = rng.uniform(.1, .9, (3, 30))
    event = rng.uniform(.01, .99, (3, 30))
    calibration = {"risk_local_variance": [.01, .01], "event_local_variance": [.1, .1],
                   "risk_event_local_covariance": [0., 0.]}
    model = ResponseModel(x, risk, event, calibration)
    assert model.sources == 30
    assert torch.linalg.eigvalsh(model.covariance).min() >= -1e-10
    before = model.mean[:model.sources].clone()
    model.observe(0, .5, True)
    assert not torch.equal(before, model.mean[:model.sources])
    assert torch.isfinite(model.mean).all() and torch.isfinite(model.covariance).all()
