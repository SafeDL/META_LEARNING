"""Replay paid prefixes to separate risk errors from event-response errors."""
from zipfile import ZipFile
from types import ModuleType

import numpy as np
from scipy.linalg import solve_triangular
from scipy.special import ndtr, ndtri
from threadpoolctl import threadpool_limits

from methods.history_guided_testing.history import historical_risk, load_history, split_indices, subset
from methods.history_guided_testing.io import read_json, write_json
from methods.history_guided_testing.search import TestingSession

from .config import INITIAL_QUERIES, OUTPUT, POOL_SEEDS, SUT_IDS


SOURCE = OUTPUT / "earned_discovery_credit_coupling"
RESULTS = OUTPUT / "correction_reliability_diagnostic"
SEED = 11


def summarize_records(records):
    if not records:
        return {"count": 0}
    errors = np.array([r["risk_error"] for r in records])
    standardized = np.array([r["standardized_risk_error"] for r in records])
    probability = np.array([r["event_probability_before_query"] for r in records])
    conditional = np.array([r["event_probability_given_actual_risk"] for r in records])
    event = np.array([r["collision"] for r in records])
    return {"count": len(records), "risk_mean_error": float(errors.mean()),
            "risk_rmse": float(np.sqrt(np.mean(errors ** 2))),
            "risk_standardized_error_quantiles": np.quantile(standardized, [.05, .5, .95]).tolist(),
            "risk_nominal_95_interval_hit_rate": float(np.mean(np.abs(standardized) <= 1.96)),
            "event_probability_mean": float(probability.mean()), "actual_event_rate": float(event.mean()),
            "event_brier_before": float(np.mean((event - probability) ** 2)),
            "event_brier_given_actual_risk": float(np.mean((event - conditional) ** 2)),
            "median_event_probability_change_given_risk": float(np.median(conditional - probability))}


def main():
    frozen = {}
    with ZipFile(SOURCE / "source_inputs.zip") as archive:
        for name in ("frozen_coupling.py", "risk_event_response.py", "risk_task_prior.py"):
            module = ModuleType(f"{__package__}.diagnostic_{name[:-3]}")
            module.__package__ = __package__
            exec(compile(archive.read(name).decode("utf-8"), str(SOURCE / "source_inputs.zip" / name), "exec"), module.__dict__)
            frozen[name[:-3]] = module
    history = load_history()
    train, _ = split_indices(next(iter(history.values()))["x"])
    allowed = subset(history, train)
    readout = frozen["risk_event_response"].fit_event_readout(RESULTS)
    rows = []
    with threadpool_limits(limits=1):
        for pool in range(len(POOL_SEEDS)):
            with np.load(OUTPUT / f"pool_{pool}" / SUT_IDS[0] / "responses.npz") as bank:
                x = bank["x"].copy()
            prior = historical_risk(allowed, x)
            templates = frozen["risk_task_prior"].risk_templates(allowed, x)
            for sut in SUT_IDS:
                run = read_json(SOURCE / f"pool_{pool}" / sut / "coupled_response_11.json")
                reference = frozen["frozen_coupling"].FrozenReplay(TestingSession(x, SEED, mode="global_feedback", prior=prior))
                candidate = frozen["risk_task_prior"].add_risk_task_variation(
                    frozen["risk_event_response"].RiskEventResponse(reference, x[:, 4], readout), templates)
                available = np.ones(len(x), dtype=bool)
                tie = np.random.default_rng(SEED).random(len(x))
                known, found, records = {}, 0, []
                planned_checks = {c["query"]: c for c in run["regime_selection_checks"]}
                for t, observation in enumerate(run["queries"]):
                    reference.advance(known)
                    head = reference.head()
                    debt = reference.certificate(known)["negative_extra_count"]
                    allowed_probe = debt + 1 <= 1 + found / np.sqrt(200) + 1e-12
                    proposed = head if t < INITIAL_QUERIES or not allowed_probe else int(candidate.rank(available, tie_break=tie)[0])
                    index = observation["index"]
                    if proposed != index:
                        raise ValueError("Diagnostic replay differs from the paid policy")
                    probability = candidate.probabilities()
                    if t + 1 in planned_checks:
                        saved = planned_checks[t + 1]
                        if not np.allclose([probability[index], probability[head]],
                                           [saved["chosen_probability"], saved["reference_probability"]], rtol=0, atol=1e-10):
                            raise ValueError("Diagnostic prediction differs from the frozen decision")
                    cross = candidate.kernel[index, candidate.indices]
                    residual_mean = float(cross @ candidate.alpha)
                    residual_variance = 1.
                    if candidate.indices:
                        solved = solve_triangular(candidate.factor, candidate.root_precision * cross, lower=True)
                        residual_variance = max(1 - float(solved @ solved), 0)
                    group = int(x[index, 4])
                    risk, collision = observation["risk"], observation["collision"]
                    mapped = float(readout[group].predict([risk])[0])
                    conditional = float(ndtr((np.sqrt(2) * ndtri(mapped) + residual_mean) / np.sqrt(1 + residual_variance)))
                    mean = float(candidate.gp.mean[index])
                    sd = float(np.sqrt(candidate.gp.variance[index] + candidate.gp.noise))
                    records.append({"query": t + 1, "index": index, "family": group,
                                    "role": observation["role"], "risk": risk, "collision": collision,
                                    "risk_mean_before_query": mean, "risk_sd_before_query": sd,
                                    "risk_error": risk - mean, "standardized_risk_error": (risk - mean) / sd,
                                    "event_probability_before_query": float(probability[index]),
                                    "event_probability_given_actual_risk": conditional,
                                    "reference_probability_before_query": float(probability[head])})
                    known[index] = risk, collision
                    found += int(collision)
                    available[index] = False
                    candidate.observe(index, risk, collision)
                    reference.advance(known)
                if reference.order != run["reference_prefix_indices"]:
                    raise ValueError("Reliability replay changed the frozen reference prefix")
                alternatives = [r for r in records if r["role"] == "alternative"]
                row = {"pool": pool, "sut_id": sut, "all_queries": summarize_records(records),
                       "alternatives": summarize_records(alternatives),
                       "negative_alternatives": summarize_records([r for r in alternatives if not r["collision"]]),
                       "positive_alternatives": summarize_records([r for r in alternatives if r["collision"]])}
                write_json(RESULTS / f"pool_{pool}" / f"{sut}.json", {"summary": row, "records": records})
                rows.append(row)
                write_json(RESULTS / "progress.json", {"status": "running", "paths": len(rows), "expected": 12})
                print("RELIABILITY", pool, sut, row["alternatives"], flush=True)
    write_json(RESULTS / "summary.json", {"rows": rows, "replayed_paths": 12,
               "paid_records_replayed": 2400, "new_physical_calls": 0,
               "scope": "selected-query development diagnostic; actual risk used only after the paid prediction is saved",
               "no_population_calibration_claim": True, "source_policy_and_reference_replay_matched": True})
    write_json(RESULTS / "progress.json", {"status": "complete", "paths": 12, "paid_records_replayed": 2400,
                                           "new_physical_calls": 0})


if __name__ == "__main__":
    main()
