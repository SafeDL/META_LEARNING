"""Evaluate discovery-loss predictions without completing unqueried labels."""
import numpy as np

from methods.history_guided_testing.io import read_json, write_json
from .config import OUTPUT


SOURCE = OUTPUT / "discovery_supported_prior_coupling"
RESULTS = OUTPUT / "discovery_loss_calibration_diagnostic"


def main():
    rows = []
    all_records = []
    for path in sorted(SOURCE.glob("pool_*/*/discovery_supported_prior_11.json")):
        run = read_json(path)
        paid = {q["index"]: q["collision"] for q in run["queries"]}
        records = []
        for check in run["discovery_support_checks"]:
            if not check["reference_observation_skipped"]:
                continue
            index, reference = check["chosen_index"], check["reference_index"]
            failure = not paid[index]
            lower = int(failure and paid.get(reference, False))
            upper = lower + int(failure and reference not in paid)
            records.append({"query": check["query"], "candidate_index": index, "reference_index": reference,
                            "predicted_loss": check["binary_support"]["loss_probability"],
                            "candidate_collision": paid[index], "reference_collision": paid.get(reference),
                            "actual_loss_lower": lower, "actual_loss_upper": upper})
        row = {"pool": path.parent.parent.name, "sut_id": path.parent.name, "skips": len(records),
               "predicted_loss_sum": float(sum(r["predicted_loss"] for r in records)),
               "actual_loss_lower": sum(r["actual_loss_lower"] for r in records),
               "actual_loss_upper": sum(r["actual_loss_upper"] for r in records),
               "unrevealed_comparators": sum(r["reference_collision"] is None for r in records)}
        rows.append(row)
        all_records.extend(records)
        write_json(RESULTS / path.parent.parent.name / f"{path.parent.name}.json", {"summary": row, "records": records})
    summary = {"rows": rows, "supported_skips": len(all_records),
               "predicted_loss_sum": float(sum(r["predicted_loss"] for r in all_records)),
               "actual_loss_lower": sum(r["actual_loss_lower"] for r in all_records),
               "actual_loss_upper": sum(r["actual_loss_upper"] for r in all_records),
               "unrevealed_comparators": sum(r["reference_collision"] is None for r in all_records),
               "scope": "paid labels only; future comparator outcomes not filled from measured full bank; local pair loss is not full-policy regret",
               "calibration_scope": "adaptive selected pairs, not independent calibration samples or a significance test",
               "new_physical_calls": 0}
    write_json(RESULTS / "summary.json", summary)
    print({key: summary[key] for key in summary if key != "rows"}, flush=True)


if __name__ == "__main__":
    main()
