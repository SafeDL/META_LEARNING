"""Learn correction returns against adaptive greedy continuations on public histories."""
import pickle
import time

import numpy as np
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
import torch

from methods.history_guided_testing.io import read_json, write_json

from .calibration import historical_calibration
from .config import BUDGET, PAYOFF_CONTEXTS
from .planning import action_values, choose_action
from .response import ResponseModel, historical_predictions


def proposals(model, remaining, tie_break, budget):
    rank = model.rank(remaining, tie_break=tie_break)
    indices = np.flatnonzero(remaining)
    tensor = torch.as_tensor(indices, device=model.device)
    weights, predictions = model.planning_branches(tensor)
    values = action_values(model.event_probabilities()[tensor], weights, predictions, budget).cpu().numpy()
    reference = int(np.flatnonzero(indices == rank[0])[0])
    candidates = list(map(int, rank[:3]))
    for checked in (False, True):
        position = choose_action(values, reference, tie_break[indices], checked=checked)
        if int(indices[position]) not in candidates:
            candidates.append(int(indices[position]))
    positions = [int(np.flatnonzero(indices == index)[0]) for index in candidates]
    features = proposal_features(model, candidates, values[positions] - values[reference],
                                 int(rank[0]), remaining, budget)
    return candidates, features


def proposal_features(model, candidates, gains, reference, remaining, budget):
    probability = model.event_probabilities().cpu().numpy()
    risk = model.mean[model.risk_indices].cpu().numpy()
    diagonal = model.covariance.diagonal()
    risk_variance = diagonal[model.risk_indices].cpu().numpy()
    event_variance = diagonal[model.event_indices].cpu().numpy()
    task_variance = float(model.covariance[:model.sources, :model.sources].trace())
    state = model.task_state()
    queried = BUDGET - budget
    normalizer = np.asarray([budget, budget * (budget + 1) / 2])
    selected = np.asarray(candidates, dtype=int)
    return np.column_stack((
        gains / normalizer,
        probability[selected], probability[selected] - probability[reference],
        risk[selected], risk[selected] - risk[reference],
        np.maximum(risk_variance[selected], 0), np.maximum(event_variance[selected], 0),
        np.full(len(selected), budget / BUDGET),
        np.full(len(selected), max(task_variance - 1, 0) / max(model.sources - 1, 1)),
        np.full(len(selected), state["event_log_loss_before_query"] / max(queried, 1)),
        np.full(len(selected), state["event_log_loss_after_risk"] / max(queried, 1)),
        np.full(len(selected), probability[remaining].sum() / max(budget, 1)),
    ))


def continuation_return(model, remaining, risk, collision, tie_break, budget, first):
    learner = model.clone()
    available = remaining.copy()
    events, selected = [], []
    for step in range(budget):
        index = int(first if step == 0 else learner.rank(available, tie_break=tie_break)[0])
        if not available[index]:
            raise ValueError("Duplicate counterfactual historical query")
        learner.observe(index, float(risk[index]), bool(collision[index]))
        available[index] = False
        selected.append(index)
        events.append(int(collision[index]))
    curve = np.cumsum(events)
    return np.asarray([curve[-1], curve.sum()], dtype=float), selected


def fit_models(rows):
    tasks = sorted({row["training_task"] for row in rows})
    models = {"returns": [], "harm": [], "benefit": [], "loss": []}
    for excluded in (None, *tasks):
        included = [row for row in rows if row["training_task"] != excluded]
        x = np.asarray([row["features"] for row in included])
        y = np.asarray([row["normalized_gain"] for row in included])
        # Each historical system has equal total training weight.
        count = {task: sum(row["training_task"] == task for row in included) for task in tasks}
        weight = np.asarray([1 / count[row["training_task"]] for row in included])
        model = RandomForestRegressor(n_estimators=128, max_depth=5, min_samples_leaf=4,
                                      random_state=11, n_jobs=1)
        model.fit(x, y, sample_weight=weight)
        models["returns"].append(model)
        harm = np.asarray([min(row["actual_gain"]) < 0 for row in included], dtype=int)
        classifier = RandomForestClassifier(n_estimators=128, max_depth=5, min_samples_leaf=4,
                                             random_state=11, n_jobs=1)
        classifier.fit(x, harm, sample_weight=weight)
        models["harm"].append(classifier)
        for name, target in (("benefit", np.maximum(y, 0)), ("loss", np.maximum(-y, 0))):
            component = RandomForestRegressor(n_estimators=128, max_depth=5, min_samples_leaf=4,
                                               random_state=11, n_jobs=1)
            component.fit(x, target, sample_weight=weight)
            models[name].append(component)
    return models


def learned_values(models, features):
    predictions = np.stack([model.predict(features) for model in models["returns"]])
    harms = []
    for model in models["harm"]:
        if 1 in model.classes_:
            harms.append(model.predict_proba(features)[:, list(model.classes_).index(1)])
        else:
            harms.append(np.zeros(len(features)))
    benefit = np.stack([model.predict(features) for model in models["benefit"]]).min(axis=0)
    loss = np.stack([model.predict(features) for model in models["loss"]]).max(axis=0)
    return predictions.mean(axis=0), predictions[1:].min(axis=0), np.stack(harms).max(axis=0), benefit - loss


def payoff_choice(candidates, features, models, tie_break, *, checked):
    values, lower, harm, margin = learned_values(models, features)
    values[0] = lower[0] = margin[0] = 0
    harm[0] = 0
    screened = values.copy()
    if checked:
        eligible = (np.all(lower >= -1e-12, axis=1) & np.all(values >= -1e-12, axis=1)
                    & np.all(margin >= -1e-12, axis=1))
        screened[~eligible] = -np.inf
    chosen = choose_action(screened, 0, tie_break[candidates], checked=False)
    return chosen, values, lower, harm, margin


def policy_state_rows(history, allowed, base_rows, folder):
    """One fixed aggregation pass; sampler excludes its task's payoff rows."""
    rows, trajectories, rollouts = [], [], 0
    tie_break = np.random.default_rng(11).random(len(history["x"]))
    for target in allowed:
        sampler_rows = [row for row in base_rows if row["training_task"] != target]
        sampler = fit_models(sampler_rows)
        sources = [name for name in allowed if name != target]
        calibration = historical_calibration(history, sources)
        risk_predictions, event_predictions = historical_predictions(history["x"], history, sources)
        learner = ResponseModel(history["x"], risk_predictions, event_predictions, calibration)
        risk, collision = history[target], history[target + "_collision"]
        remaining = np.ones(len(history["x"]), dtype=bool)
        prefix, corrections = [], 0
        for queried in range(max(PAYOFF_CONTEXTS) + 1):
            candidates = features = None
            if queried >= 10:
                candidates, features = proposals(learner, remaining, tie_break, BUDGET - queried)
            if queried in PAYOFF_CONTEXTS:
                budget = BUDGET - queried
                reference, reference_order = continuation_return(
                    learner, remaining, risk, collision, tie_break, budget, candidates[0])
                rollouts += 1
                for index, feature in zip(candidates[1:], features[1:]):
                    actual, order = continuation_return(learner, remaining, risk, collision,
                                                        tie_break, budget, index)
                    rollouts += 1
                    gain = actual - reference
                    rows.append({"training_task": target, "prior_sources": sources,
                                 "state_policy": "loss-budget correction with its task rows excluded",
                                 "sampler_training_tasks": sorted({row["training_task"] for row in sampler_rows}),
                                 "prefix_indices": prefix.copy(), "queried_prefix": queried,
                                 "remaining_budget": budget, "candidate": index,
                                 "reference": candidates[0], "features": feature.tolist(),
                                 "actual_gain": gain.tolist(),
                                 "normalized_gain": (gain / [budget, budget * (budget + 1) / 2]).tolist(),
                                 "reference_order": reference_order, "candidate_order": order})
                write_json(folder / "state_aggregation_progress.json", {
                    "status": "running", "latest_task": target, "context": queried,
                    "added_rows": len(rows), "new_adaptive_rollouts": rollouts})
            if queried < max(PAYOFF_CONTEXTS):
                if candidates is None:
                    index = int(learner.rank(remaining, tie_break=tie_break)[0])
                else:
                    choice, *_ = payoff_choice(candidates, features, sampler, tie_break, checked=True)
                    index = candidates[choice]
                    corrections += int(choice != 0)
                learner.observe(index, float(risk[index]), bool(collision[index]))
                remaining[index] = False
                prefix.append(index)
        trajectories.append({"training_task": target, "prefix_indices": prefix,
                             "corrections": corrections})
    return rows, trajectories, rollouts


def aggregate_payoff_data(history, allowed, data, folder):
    if data.get("state_aggregation_complete", False):
        return data
    base_rows = data["rows"]
    added, trajectories, rollouts = policy_state_rows(history, allowed, base_rows, folder)
    data.update(rows=base_rows + added, base_rows=len(base_rows), added_rows=len(added),
                policy_trajectories=trajectories, new_adaptive_rollouts=rollouts,
                state_aggregation_complete=True,
                aggregation_scope="one pass; only allowed histories; sampler removes task's own payoff labels")
    write_json(folder / "payoff_training.json", data)
    write_json(folder / "state_aggregation_progress.json", {
        "status": "complete", "added_rows": len(added), "new_adaptive_rollouts": rollouts})
    return data


def train_payoff(history, allowed, folder):
    path = folder / "payoff_models.pkl"
    if path.exists():
        with path.open("rb") as stream:
            return pickle.load(stream)
    labels = folder / "payoff_training.json"
    if labels.exists():
        data = read_json(labels)
        if data["allowed_historical_tasks"] != allowed:
            raise ValueError("Reused payoff labels have different allowed historical systems")
        data = aggregate_payoff_data(history, allowed, data, folder)
        models = fit_models(data["rows"])
        with path.open("wb") as stream:
            pickle.dump(models, stream)
        return models
    started = time.perf_counter()
    rows, rollouts = [], 0
    tie_break = np.random.default_rng(11).random(len(history["x"]))
    for target in allowed:
        sources = [name for name in allowed if name != target]
        calibration = historical_calibration(history, sources)
        predictions = historical_predictions(history["x"], history, sources)
        learner = ResponseModel(history["x"], *predictions, calibration)
        remaining = np.ones(len(history["x"]), dtype=bool)
        # Only public training tasks enter these counterfactual continuations.
        risk, collision = history[target], history[target + "_collision"]
        for queried in range(max(PAYOFF_CONTEXTS) + 1):
            if queried in PAYOFF_CONTEXTS:
                budget = BUDGET - queried
                candidates, features = proposals(learner, remaining, tie_break, budget)
                reference, reference_order = continuation_return(
                    learner, remaining, risk, collision, tie_break, budget, candidates[0])
                rollouts += 1
                for index, feature in zip(candidates[1:], features[1:]):
                    actual, order = continuation_return(learner, remaining, risk, collision,
                                                        tie_break, budget, index)
                    rollouts += 1
                    gain = actual - reference
                    rows.append({"training_task": target, "prior_sources": sources,
                                 "queried_prefix": queried, "remaining_budget": budget,
                                 "candidate": index, "reference": candidates[0],
                                 "features": feature.tolist(),
                                 "actual_gain": gain.tolist(),
                                 "normalized_gain": (gain / [budget, budget * (budget + 1) / 2]).tolist(),
                                 "reference_order": reference_order, "candidate_order": order})
                write_json(folder / "payoff_training_progress.json", {
                    "status": "running", "latest_task": target, "latest_context": queried,
                    "rows": len(rows), "adaptive_rollouts": rollouts})
            if queried < max(PAYOFF_CONTEXTS):
                index = int(learner.rank(remaining, tie_break=tie_break)[0])
                learner.observe(index, float(risk[index]), bool(collision[index]))
                remaining[index] = False
    data = {
        "allowed_historical_tasks": allowed, "contexts": PAYOFF_CONTEXTS,
        "rows": rows, "adaptive_rollouts": rollouts, "new_physical_calls": 0,
        "elapsed_s": time.perf_counter() - started,
        "scope": "actual allowed-source responses; outer target excluded; no true target parameters",
        "uncertainty_scope": "leave-task model disagreement, not a calibrated confidence interval"}
    data = aggregate_payoff_data(history, allowed, data, folder)
    models = fit_models(data["rows"])
    folder.mkdir(parents=True, exist_ok=True)
    with path.open("wb") as stream:
        pickle.dump(models, stream)
    write_json(folder / "payoff_training_progress.json", {
        "status": "complete", "rows": len(rows), "adaptive_rollouts": rollouts})
    return models
