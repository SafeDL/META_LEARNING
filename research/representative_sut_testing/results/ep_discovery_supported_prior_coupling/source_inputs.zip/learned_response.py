"""Reuse the frozen history-trained correlation for local response residuals."""
import numpy as np
import torch


@torch.no_grad()
def learned_local_covariance(model, covariance):
    correlation = torch.as_tensor(covariance, dtype=torch.float64, device=model.device).clone()
    deviation = correlation.diagonal().clamp_min(1e-12).sqrt()
    correlation /= deviation[:, None] * deviation[None, :]
    family = torch.as_tensor(model.family, device=model.device)
    correlation *= family[:, None] == family[None, :]
    loading = model.covariance[:, :model.sources]
    task = loading @ loading.T
    risk, event = model.risk_indices, model.event_indices
    risk_variance = (model.covariance.diagonal()[risk] - task.diagonal()[risk]).clamp_min(1e-12)
    event_variance = (model.covariance.diagonal()[event] - task.diagonal()[event]).clamp_min(1e-12)
    own_cross = model.covariance[risk, event] - task[risk, event]
    risk_sd, event_sd = risk_variance.sqrt(), event_variance.sqrt()
    channel_correlation = own_cross / (risk_sd * event_sd)
    if torch.any(channel_correlation.abs() > 1 + 1e-8):
        raise ValueError("Historical local channel covariance is not positive semidefinite")
    risk_covariance = correlation * risk_sd[:, None] * risk_sd[None, :]
    event_covariance = correlation * event_sd[:, None] * event_sd[None, :]
    cross = correlation * channel_correlation[:, None] * risk_sd[:, None] * event_sd[None, :]
    replacement = task.clone()
    replacement[risk[:, None], risk] += risk_covariance
    replacement[event[:, None], event] += event_covariance
    replacement[risk[:, None], event] += cross
    replacement[event[:, None], risk] += cross.T
    if not torch.allclose(replacement.diagonal(), model.covariance.diagonal(), rtol=0, atol=1e-9):
        raise ValueError("Learned correlation changed the initial response variance")
    model.covariance = replacement
    if not np.isfinite(model.covariance.cpu().numpy()).all():
        raise ValueError("Nonfinite learned response covariance")
    return model
