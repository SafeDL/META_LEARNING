"""Execute prior selection and averaging, with frozen matched controls."""
import multiprocessing as mp
import time
from zipfile import ZipFile

import numpy as np
from scipy.special import logsumexp
from threadpoolctl import threadpool_limits
import torch

from methods.history_guided_testing.experiment import RemoteOracle
from methods.history_guided_testing.history import historical_risk, load_history, split_indices, subset
from methods.history_guided_testing.io import read_json, write_json
from methods.history_guided_testing.search import TestingSession
from research.risk_conditioned_response_testing.confirmation import CONFIRMATION

from .adaptive_margin_prior import AdaptiveMarginPrior, mixed_log_likelihood
from .baselines import verify_baseline_inputs
from .censored_margin_response import historical_margin_prior
from .config import BUDGET, INITIAL_QUERIES, OUTPUT, POOL_SEEDS, SUT_IDS
from .develop import disclose
from .evaluate_censored_margin import audit_run
from .frozen_coupling import FrozenReplay, run_policy


RESULTS = OUTPUT / "adaptive_margin_prior_coupling"
CONTROLS = OUTPUT / "neutral_margin_prior_coupling"
METHODS = ("initial_prior_selection", "online_prior_average")
CONTROL_METHODS = ("frozen_reference", "history_margin_response", "neutral_margin_response")
SEED = 11


def selector_worker(connection):
    try:
        torch.set_num_threads(1)
        with threadpool_limits(limits=1):
            while True:
                message, task = connection.recv()
                if message == "stop":
                    return
                if message != "task" or task["method"] not in METHODS:
                    raise ValueError("Invalid adaptive-prior task")
                reference = FrozenReplay(TestingSession(task["x"], task["seed"], mode="global_feedback", prior=task["risk_prior"]))
                model = AdaptiveMarginPrior(reference, task["x"][:, 4], task["margin_prior"],
                                             freeze_after_initialization=task["method"] == "initial_prior_selection")
                tie = np.random.default_rng(task["seed"]).random(len(task["x"]))
                result = run_policy(task["method"], reference, model, RemoteOracle(connection), tie, BUDGET, INITIAL_QUERIES)
                result.update(model.diagnostics())
                connection.send(("result", result))
    except Exception as error:
        connection.send(("error", repr(error)))
        raise
    finally:
        connection.close()


def audit_adaptive(run, method, bank, baseline, folder, *, paired_reference=True):
    audit_run(run, method, bank, baseline, paired_reference=paired_reference)
    if len(run["component_margin_records"]) != 2 or len(run["prior_evidence_records"]) != BUDGET:
        raise ValueError("Missing adaptive prior component or evidence records")
    for component in run["component_margin_records"]:
        audit_run({**run, "margin_records": component}, method, bank, baseline, paired_reference=paired_reference)
    logweights = np.full(2, -np.log(2))
    chosen = None
    for t, evidence in enumerate(run["prior_evidence_records"], 1):
        records = [c[t - 1] for c in run["component_margin_records"]]
        if any(evidence[k] != records[0][k] for k in ("index", "risk", "collision")):
            raise ValueError("Adaptive prior evidence differs from real observations")
        means = np.asarray([r["predictive_mean_before"] for r in records])
        variances = np.asarray([r["predictive_variance_before"] for r in records])
        likelihood = mixed_log_likelihood(means, variances, evidence["risk"], evidence["collision"])
        weights = np.exp(logweights)
        used = np.eye(2)[chosen] if method == "initial_prior_selection" and chosen is not None else weights
        if (not np.allclose(evidence["weights_before"], weights, rtol=0, atol=1e-10)
                or not np.allclose(evidence["selection_weights_before"], used, rtol=0, atol=1e-10)
                or not np.allclose(evidence["log_predictive_likelihoods"], likelihood, rtol=0, atol=1e-8)):
            raise ValueError("Adaptive prior uses post-query or inconsistent evidence")
        logweights += likelihood
        logweights -= logsumexp(logweights)
        if not np.allclose(evidence["weights_after"], np.exp(logweights), rtol=0, atol=1e-10):
            raise ValueError("Adaptive prior weights differ from mixed-likelihood update")
        if t == INITIAL_QUERIES and method == "initial_prior_selection":
            chosen = int(np.argmax(logweights))
    if run["selected_model_after_initialization"] != chosen:
        raise ValueError("Initial prior choice did not use exactly ten feedbacks")
    for check in run["regime_selection_checks"]:
        used = run["prior_evidence_records"][check["query"] - 1]["selection_weights_before"]
        if not np.allclose(check["selection_weights"], used, atol=1e-10, rtol=0):
            raise ValueError("Prior selection weights changed before the recorded action")
        predictions = np.asarray([used @ np.asarray(check["component_chosen_probabilities"]),
                                  used @ np.asarray(check["component_reference_probabilities"])])
        if not np.allclose(predictions, [check["chosen_probability"], check["reference_probability"]], atol=1e-10, rtol=0):
            raise ValueError("Action probabilities do not match adaptive prior weights")
    if method == "initial_prior_selection":
        pure_method = CONTROL_METHODS[chosen + 1]
        pure = read_json(folder / f"{pure_method}_{SEED}.json")
        if run["selected_indices"] != pure["selected_indices"] or run["disclosures"] != pure["disclosures"]:
            raise ValueError("Executed initial prior selection differs from the exact pure-policy replay")


def main():
    verify_baseline_inputs(read_json(CONFIRMATION / "protocol.json"))
    RESULTS.mkdir(parents=True, exist_ok=True)
    write_json(RESULTS / "protocol.json", {
        "stage": "bounded prior-selection validation on existing development pools",
        "sut_ids": SUT_IDS, "pools": [0, 1], "seed": SEED, "budget": BUDGET,
        "new_methods": METHODS, "frozen_controls": str(CONTROLS),
        "new_curves": 24, "reused_control_curves": 36,
        "initial_weights": [.5, .5], "initial_choice": "MAP after exactly the common ten paid observations; choice then frozen",
        "online_choice": "posterior model average using query-before mixed likelihood; all real feedback updates both ADF models",
        "observation": "same safe positive value 1-R and failure censoring constraint under a common mixed measure",
        "unchanged": "six sources, kernel, prior definitions, two-step schedule, independent reference and discovery credit",
        "selector_payload": "x, history-only priors and seed; no SUT identity/parameters/future outcomes",
        "interpretation": "working-posterior evidence; adaptation of standard Bayesian model comparison, not a new general theory",
        "expansion": "none in this bounded validation; first verify real selection and compare all fixed controls",
        "new_physical_calls": 0})
    snapshot = RESULTS / "source_inputs.zip"
    if not snapshot.exists():
        with ZipFile(snapshot, "w") as archive:
            for path in sorted(OUTPUT.parent.glob("*.py")):
                archive.write(path, path.name)
    with ZipFile(snapshot) as archive:
        if any(archive.read(n) != (OUTPUT.parent / n).read_bytes() for n in archive.namelist()):
            raise ValueError("Adaptive prior code changed after freeze")
    history = load_history()
    train, _ = split_indices(next(iter(history.values()))["x"])
    allowed = subset(history, train)
    context = mp.get_context("spawn")
    parent, child = context.Pipe()
    process = context.Process(target=selector_worker, args=(child,))
    process.start()
    child.close()
    rows = []
    try:
        for pool in range(len(POOL_SEEDS)):
            with np.load(OUTPUT / f"pool_{pool}" / SUT_IDS[0] / "responses.npz") as bank:
                x = bank["x"].copy()
            prior, margin = historical_risk(allowed, x), historical_margin_prior(x)
            for sut in SUT_IDS:
                control_folder = CONTROLS / f"pool_{pool}" / sut
                with np.load(OUTPUT / f"pool_{pool}" / sut / "responses.npz") as bank:
                    if not np.array_equal(x, bank["x"]):
                        raise ValueError("Adaptive-prior SUT coordinates differ")
                    baseline = read_json(OUTPUT / f"pool_{pool}" / sut / "baselines" / f"frozen_original_{SEED}.json")
                    for method in (*CONTROL_METHODS, *METHODS):
                        if method in CONTROL_METHODS:
                            run = read_json(control_folder / f"{method}_{SEED}.json")
                            audit_run(run, method, bank, baseline)
                        else:
                            path = RESULTS / f"pool_{pool}" / sut / f"{method}_{SEED}.json"
                            if path.exists():
                                run = read_json(path)
                            else:
                                started = time.perf_counter()
                                task = {"method": method, "seed": SEED, "x": x, "risk_prior": prior, "margin_prior": margin}
                                run = disclose(parent, task, bank["risk"], bank["collision"])
                                run.update(method=method, seed=SEED, selector_elapsed_s=time.perf_counter() - started)
                                write_json(path, run)
                                print("ADAPTIVE PRIOR", pool, sut, method, run["F200"], flush=True)
                            audit_adaptive(run, method, bank, baseline, control_folder)
                            write_json(RESULTS / "progress.json", {"status": "running", "latest": str(path.relative_to(RESULTS)), "expected_new_curves": 24})
                        rows.append({"pool": pool, "sut_id": sut, "method": method,
                                     "area_pct": 100 * run["area_200"], "recall_pct": 100 * run["recall_200"], "F200": run["F200"]})
    finally:
        if process.is_alive():
            parent.send(("stop", None))
        parent.close()
        process.join(timeout=10)
        if process.is_alive():
            process.terminate()
            process.join()
        if process.exitcode != 0:
            raise RuntimeError(f"Adaptive-prior selector exited {process.exitcode}")
    aggregate = {m: {k: float(np.mean([r[k] for r in rows if r["method"] == m]))
                     for k in ("area_pct", "recall_pct", "F200")} for m in (*CONTROL_METHODS, *METHODS)}
    comparison = {m: {c: {"area_pp": aggregate[m]["area_pct"] - aggregate[c]["area_pct"],
                          "recall_pp": aggregate[m]["recall_pct"] - aggregate[c]["recall_pct"]}
                      for c in CONTROL_METHODS} for m in METHODS}
    summary = {"rows": rows, "aggregate": aggregate, "candidate_changes": comparison,
               "new_curves": 24, "reused_control_curves": 36, "seed": SEED,
               "initial_policy_matches_pure_replay": True, "before_query_evidence_and_action_weights_verified": True,
               "full_reference_bounds_verified": True, "significant_advantage_established": False}
    write_json(RESULTS / "summary.json", summary)
    lines = ["# 初始反馈先验选择与持续先验平均", "",
             "六固定 SUT、两共享池、200 次唯一查询、共同十次初始化、相同两步排程及发现额度。",
             "新增 24 条真实选择器曲线，36 条固定控制从已执行阶段复用，不增加独立证据。",
             "权重使用查询前的事件质量或正代理值密度，实际反馈后更新；初始 MAP 在第十次反馈后锁定，持续平均则逐次更新。",
             "ADF 为工作近似，模型平均与先验选择本身不是新的通用理论。", "",
             "| 方法 | Area % | Recall % | 平均 F200 |", "|---|---:|---:|---:|"]
    for method, value in aggregate.items():
        lines.append(f"| {method} | {value['area_pct']:.3f} | {value['recall_pct']:.3f} | {value['F200']:.2f} |")
    lines += ["", "| 池 | SUT | 方法 | Area % | Recall % | F200 |", "|---|---|---|---:|---:|---:|"]
    for row in rows:
        lines.append(f"| {row['pool']} | {row['sut_id']} | {row['method']} | {row['area_pct']:.3f} | {row['recall_pct']:.3f} | {row['F200']} |")
    lines += ["", "初始选择的真实轨迹与对应纯策略逐项一致，持续平均的预测权重、反馈更新、独立参照与计数界均核对通过。",
              "本轮为有限机制验证，不自动追加种子，未进行独立显著性确认。"]
    (RESULTS / "report.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    write_json(RESULTS / "progress.json", {"status": "complete", "new_curves": 24, "reused_controls": 36,
                                         "new_disclosures": 24 * BUDGET, "new_physical_calls": 0})
    print({"aggregate": aggregate, "candidate_changes": comparison}, flush=True)


if __name__ == "__main__":
    main()
