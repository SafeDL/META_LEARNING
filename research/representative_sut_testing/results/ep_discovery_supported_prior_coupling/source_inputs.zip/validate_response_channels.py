"""Check the stronger event-only comparator on the preassigned validation split."""
import multiprocessing as mp
from zipfile import ZipFile

import numpy as np

from methods.history_guided_testing.config import ROOT as HISTORY_ROOT
from methods.history_guided_testing.io import read_json, write_json

from .calibration import historical_calibration
from .cohort_payoff import SEED, VALIDATION, load_bank
from .config import OUTPUT, PROFILES
from .coupled_discovery import selector_worker
from .develop import disclose, metrics
from .response import historical_predictions


RESULTS = OUTPUT / "response_channel_validation"
METHODS = ("greedy_reference", "event_only_search")


def main():
    write_json(RESULTS / "protocol.json", {
        "stage": "strong-comparator public validation, not promotion of coupled discovery",
        "validation_configurations": VALIDATION, "methods": METHODS,
        "budget": 200, "pool": 0, "seed": SEED, "initial_queries": 10,
        "response_prior": "same original six sources and covariance calibration",
        "changed": "global response updates use both risk/event or event only; queried feedback is the same",
        "no_gain_model_training": True, "new_physical_calls": 0,
        "scope": "IDM/FVDM configurations; not a six-SUT main experiment or blind confirmation",
    })
    with ZipFile(RESULTS / "source_inputs.zip", "w") as archive:
        for path in sorted(OUTPUT.parent.glob("*.py")):
            archive.write(path, path.name)
    context = mp.get_context("spawn")
    parent, child = context.Pipe()
    process = context.Process(target=selector_worker, args=(child,))
    process.start()
    child.close()
    rows = []
    try:
        with np.load(HISTORY_ROOT / "history/responses.npz") as history:
            names = [p.name for p in PROFILES]
            calibration = historical_calibration(history, names)
            for name in VALIDATION:
                bank = load_bank(name)
                predictions = (*historical_predictions(bank["x"], history, names), calibration)
                initial = None
                for method in METHODS:
                    path = RESULTS / name / f"{method}_{SEED}.json"
                    if path.exists():
                        run = read_json(path)
                    else:
                        task = {"method": method, "x": bank["x"], "predictions": predictions, "seed": SEED}
                        run = disclose(parent, task, bank["risk"], bank["collision"])
                        run.update(method=method, seed=SEED, historical_sources=names)
                        write_json(path, run)
                    if initial is None:
                        initial = run["selected_indices"][:10]
                    if initial != run["selected_indices"][:10]:
                        raise ValueError("Response-channel controls differ in initialization")
                    actual = metrics(bank["collision"], run["selected_indices"])
                    if actual["curve"] != run["curve"]:
                        raise ValueError("Response-channel discovery curve differs from paid queries")
                    rows.append({"target": name, "method": method,
                                 "area_pct": 100 * actual["area_200"],
                                 "recall_pct": 100 * actual["recall_200"], "F200": actual["F200"]})
                    write_json(RESULTS / "progress.json", {"status": "running", "runs": len(rows), "expected_runs": 24})
                    print("RESPONSE CHANNEL", name, method, run["F200"], flush=True)
    finally:
        if process.is_alive():
            parent.send(("stop", None))
        parent.close()
        process.join(timeout=10)
        if process.is_alive():
            process.terminate()
            process.join()
        if process.exitcode != 0:
            raise RuntimeError(f"Response-channel selector exited {process.exitcode}")
    aggregate = {method: {key: float(np.mean([r[key] for r in rows if r["method"] == method]))
                          for key in ("area_pct", "recall_pct", "F200")} for method in METHODS}
    changes = {key: aggregate["event_only_search"][key] - aggregate["greedy_reference"][key]
               for key in ("area_pct", "recall_pct", "F200")}
    write_json(RESULTS / "summary.json", {"rows": rows, "aggregate": aggregate, "event_only_changes": changes,
                                        "runs": 24, "disclosures": 4800, "new_physical_calls": 0,
                                        "significant_advantage_established": False})
    lines = ["# 风险与碰撞反馈通道的固定配置验证", "",
             "既定 12 个验证配置、同六来源先验、pool_0、种子 11、200 次预算与共同 10 次初始化。",
             "两方法都获取同次风险与碰撞；区别是风险反馈是否更新全局响应模型。不训练新的收益模型，不晋升此前失败的耦合候选。", "",
             "| 方法 | Area % | Recall % | 平均 F200 |", "|---|---:|---:|---:|"]
    for method, value in aggregate.items():
        lines.append(f"| {method} | {value['area_pct']:.3f} | {value['recall_pct']:.3f} | {value['F200']:.2f} |")
    lines += ["", "| 配置 | 方法 | Area % | Recall % | F200 |", "|---|---|---:|---:|---:|"]
    for row in rows:
        lines.append(f"| {row['target']} | {row['method']} | {row['area_pct']:.3f} | {row['recall_pct']:.3f} | {row['F200']} |")
    lines += ["", f"仅事件更新相对联合更新：Area {changes['area_pct']:+.3f}、Recall {changes['recall_pct']:+.3f} 个百分点。",
              "24 条曲线、4800 次唯一反馈披露核对；新增物理执行为 0。",
              "结果只适用于当前公开 IDM/FVDM 配置验证，不能推广到六代表 SUT 或宣称显著优势。",
              "收益与损失需分别评价；加入更多反馈不保证错误指定的跨通道模型获得更好的危险排序。"]
    (RESULTS / "report.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    write_json(RESULTS / "progress.json", {"status": "complete", "runs": 24, "disclosures": 4800})
    print({"aggregate": aggregate, "changes": changes}, flush=True)


if __name__ == "__main__":
    main()
