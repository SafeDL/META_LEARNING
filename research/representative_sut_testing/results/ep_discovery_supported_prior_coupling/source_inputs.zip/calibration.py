"""Response covariance and local interpolation error from allowed sources only."""
import numpy as np
from scipy.spatial.distance import cdist
from scipy.special import ndtri


def historical_calibration(bank, names):
    x = bank["x"]
    family = x[:, 4].astype(int)
    distance = cdist(x[:, :4], x[:, :4])
    distance[family[:, None] != family[None, :]] = np.inf
    np.fill_diagonal(distance, np.inf)
    nearest = np.argsort(distance, axis=1, kind="stable")[:, :8]
    local = np.take_along_axis(distance, nearest, axis=1)
    weights = np.exp(-0.5 * (local / 0.15) ** 2)
    weights /= weights.sum(axis=1, keepdims=True)
    risk = np.column_stack([bank[name] for name in names])
    event = np.column_stack([bank[name + "_collision"] for name in names])
    predicted_risk = (risk[nearest] * weights[:, :, None]).sum(axis=1)
    predicted_event = (event[nearest] * weights[:, :, None]).sum(axis=1)
    risk_residual = risk - predicted_risk
    event_residual = (ndtri(np.clip(event, 0.01, 0.99))
                      - ndtri(np.clip(predicted_event, 0.01, 0.99)))
    return {
        "risk_local_variance": [float((risk_residual[family == g] ** 2).mean()) for g in (0, 1)],
        "event_local_variance": [float((event_residual[family == g] ** 2).mean()) for g in (0, 1)],
        "risk_event_local_covariance": [float((risk_residual[family == g]
                                                * event_residual[family == g]).mean()) for g in (0, 1)],
    }
