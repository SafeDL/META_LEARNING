"""Print complete source-held-out development, including unsuccessful gates."""
import numpy as np

from methods.history_guided_testing.io import read_json, write_json

from .config import CHECKPOINTS, DEVELOPMENT, DEVELOPMENT_SEEDS, PROFILES
from .selector import METHODS


def main():
    folder = DEVELOPMENT
    progress = read_json(folder / "progress.json")
    if progress["status"] != "complete":
        raise ValueError("Development is still running; a complete table is not available")
    rows, details = [], {}
    for profile in PROFILES:
        details[profile.name] = {}
        for method in METHODS:
            runs = [read_json(folder / profile.name / f"{method}_{seed}.json") for seed in DEVELOPMENT_SEEDS]
            if any(len(set(run["selected_indices"])) != 200 for run in runs):
                raise ValueError("Invalid development selection budget")
            values = {
                "target": profile.name, "method": method,
                "total_collisions": runs[0]["total_collisions"],
                "area_pct": 100 * np.mean([run["area_200"] for run in runs]),
                "recall_pct": 100 * np.mean([run["recall_200"] for run in runs]),
                "F200": np.mean([run["F200"] for run in runs]),
                "terminal_ceiling_attainment_pct": 100 * np.mean([
                    run["terminal_ceiling_attainment"] for run in runs]),
                "audit_queries": np.mean([run["audit_query_count"] for run in runs]),
                "supported_runs": sum(run["correction_supported"] for run in runs),
                "accepted_runs": sum(run["correction_non_decreasing"] for run in runs),
                "selector_elapsed_s": np.mean([run["selector_elapsed_s"] for run in runs]),
                **{f"F{t}": np.mean([run["checkpoints"][str(t)] for run in runs])
                   for t in CHECKPOINTS},
            }
            rows.append(values)
            details[profile.name][method] = values
    aggregate = {
        method: {key: float(np.mean([row[key] for row in rows if row["method"] == method]))
                 for key in ("area_pct", "recall_pct", "F200", "audit_queries", "selector_elapsed_s")}
        for method in METHODS
    }
    candidate_method = METHODS[-1]
    candidate = aggregate[candidate_method]
    changes = {
        method: {
            "area_pp": candidate["area_pct"] - aggregate[method]["area_pct"],
            "recall_pp": candidate["recall_pct"] - aggregate[method]["recall_pct"],
        }
        for method in METHODS if method != candidate_method
    }
    supported = sum(row["supported_runs"] for row in rows if row["method"] == candidate_method)
    write_json(folder / "summary.json", {
        "stage": "source-held-out development, not confirmation",
        "rows": rows, "aggregate": aggregate, "candidate_changes": changes,
        "supported_runs": supported, "candidate_runs": len(PROFILES) * len(DEVELOPMENT_SEEDS),
        "development_seeds": DEVELOPMENT_SEEDS,
        "empirical_joint_mean_improvement": all(
            value["area_pp"] > 0 and value["recall_pp"] > 0 for value in changes.values()),
        "significant_advantage_established": False,
    })
    lines = [
        "# 历史系统留出开发阶段", "",
        f"六个已有历史系统逐一留出，每折使用其余五个来源；每方法 {len(DEVELOPMENT_SEEDS)} 个共同种子、200 次唯一查询。",
        f"选择器只接收历史预测、坐标和已查询反馈。{len(PROFILES) * len(METHODS) * len(DEVELOPMENT_SEEDS)} 条曲线共 {len(PROFILES) * len(METHODS) * len(DEVELOPMENT_SEEDS) * 200} 次披露，新增物理调用为 0。",
        "这些来源已经公开，相关模型族也不能视为六个独立算法样本；本阶段不作显著优势确认。", "",
        f"| 留出系统 | 方法 | 全池碰撞 | Area % | Recall % | F10 | F30 | F50 | F100 | F150 | F200 | 偏离参照次数 | 即时不下降/{len(DEVELOPMENT_SEEDS)} | 即时严格证书/{len(DEVELOPMENT_SEEDS)} | 选择秒 |",
        "|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for row in rows:
        fields = [row["target"], row["method"], str(row["total_collisions"]),
                  f"{row['area_pct']:.3f}", f"{row['recall_pct']:.3f}"]
        fields += [f"{row[f'F{t}']:.1f}" for t in CHECKPOINTS]
        fields += [f"{row['audit_queries']:.1f}", str(row["accepted_runs"]), str(row["supported_runs"]),
                   f"{row['selector_elapsed_s']:.3f}"]
        lines.append("| " + " | ".join(fields) + " |")
    lines += ["", "| 方法 | 等权系统 Area % | Recall % | F200 | 平均偏离参照次数 |",
              "|---|---:|---:|---:|---:|"]
    for method, value in aggregate.items():
        lines.append(f"| {method} | {value['area_pct']:.3f} | {value['recall_pct']:.3f} | "
                     f"{value['F200']:.2f} | {value['audit_queries']:.1f} |")
    accepted = sum(row["accepted_runs"] for row in rows if row["method"] == candidate_method)
    lines += ["", f"即时不下降观测 {accepted}/{len(PROFILES) * len(DEVELOPMENT_SEEDS)} 条候选曲线；"
              f"严格增量证书 {supported}/{len(PROFILES) * len(DEVELOPMENT_SEEDS)}。两者不等于全程优势。"]
    for method, value in changes.items():
        lines.append(f"相对 {method}：Area {value['area_pp']:+.3f} 个百分点，"
                     f"Recall {value['recall_pp']:+.3f} 个百分点。")
    lines += ["", "性能和证书分别评价：证书对象只有一条已执行查询；规划的未来值不是证书。"
              "后续重新学习的全程性能另作实测。失败探测已经消耗的预算不能恢复。"]
    report = "\n".join(lines) + "\n"
    (folder / "report.md").write_text(report, encoding="utf-8")
    print(report, flush=True)


if __name__ == "__main__":
    main()
