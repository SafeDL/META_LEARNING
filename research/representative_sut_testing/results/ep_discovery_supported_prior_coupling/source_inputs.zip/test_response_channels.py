"""The local control preserves prior marginals and removes shared task transfer."""
import numpy as np
import torch

from .response import ResponseModel
from .response_channels import local_event_prior


def test_local_event_control_matches_marginals_and_isolates_scenario_families():
    x = np.asarray([[0., 0., 0., 0., 0.], [0., 0., 0., 0., 1.]])
    risk = np.asarray([[.1, .9], [.1, .9]])
    events = np.asarray([[.1, .9], [.1, .9]])
    calibration = {"risk_local_variance": [.01, .01], "event_local_variance": [.04, .04],
                   "risk_event_local_covariance": [0., 0.]}
    prior = ResponseModel(x, risk, events, calibration)
    covariance = prior.covariance.clone()
    local = local_event_prior(prior)
    torch.testing.assert_close(prior.covariance, covariance)
    torch.testing.assert_close(prior.event_probabilities(), local.event_probabilities())
    assert prior.covariance[prior.event_indices[0], prior.event_indices[1]] > 0
    assert local.covariance[local.event_indices[0], local.event_indices[1]] == 0
    assert torch.count_nonzero(local.covariance[:local.sources]) == 0
    assert torch.linalg.eigvalsh(local.covariance).min() >= -1e-10
    unchanged = local.mean[local.event_indices[1]].clone()
    local.observe_event(0, True)
    assert local.mean[local.event_indices[1]] == unchanged
