"""A shared historical response state with distinct risk and event observations."""
import copy
import math

import numpy as np
from scipy.spatial.distance import cdist
from scipy.special import ndtri
import torch


def historical_predictions(x, bank, names):
    distance = cdist(x[:, :4], bank["x"][:, :4])
    distance[x[:, 4, None] != bank["x"][None, :, 4]] = np.inf
    nearest = np.argsort(distance, axis=1, kind="stable")[:, :8]
    local = np.take_along_axis(distance, nearest, axis=1)
    weights = np.exp(-0.5 * (local / 0.15) ** 2)
    weights /= weights.sum(axis=1, keepdims=True)
    exact = local[:, 0] == 0
    weights[exact] = 0
    weights[exact, 0] = 1
    risk = np.column_stack([(bank[name][nearest] * weights).sum(axis=1) for name in names])
    collision = np.column_stack([
        (bank[name + "_collision"][nearest] * weights).sum(axis=1) for name in names
    ])
    return risk, collision


def preserve_branch_mean(predictions, weights, marginal):
    """Largest affine contrast retention with fixed mean and binary range."""
    average = (predictions * weights[:, :, None]).sum(dim=1)
    contrast = predictions - average[:, None, :]
    positive = contrast.max(dim=1).values.clamp_min(1e-12)
    negative = (-contrast.min(dim=1).values).clamp_min(1e-12)
    scale = torch.minimum((1 - marginal) / positive, marginal / negative).clamp_max(1)
    return marginal[:, None, :] + scale[:, None, :] * contrast


class ResponseModel:
    def __init__(self, x, risk, collision, calibration):
        if not torch.cuda.is_available():
            raise RuntimeError("Use the metadrive Conda environment with CUDA")
        self.device = "cuda"
        self.size, self.sources = risk.shape
        self.family = np.asarray(x[:, 4], dtype=int)
        distance = cdist(x[:, :4], x[:, :4], "sqeuclidean")
        physical = np.exp(-distance / (2 * 0.2 ** 2))
        physical *= self.family[:, None] == self.family[None, :]

        event_values = ndtri(np.clip(collision, 0.01, 0.99))
        divisor = math.sqrt(max(self.sources - 1, 1))
        risk_modes = (risk - risk.mean(axis=1, keepdims=True)) / divisor
        event_modes = (event_values - event_values.mean(axis=1, keepdims=True)) / divisor
        risk_local = np.asarray(calibration["risk_local_variance"]) + 1e-6
        event_local = np.asarray(calibration["event_local_variance"]) + 1e-6
        local_cross = np.asarray(calibration["risk_event_local_covariance"])
        deviation = np.sqrt((event_modes ** 2).sum(axis=1) + event_local[self.family])
        event_modes /= deviation[:, None]

        # Task variation is shared across functional scenarios. Physical
        # residuals are local to a scenario family. Their empirical joint
        # covariance retains an unexplained event component after seeing risk.
        risk_covariance = risk_modes @ risk_modes.T + physical * risk_local[self.family, None]
        event_covariance = event_modes @ event_modes.T + physical * event_local[self.family, None] / (
                deviation[:, None] * deviation[None, :])
        cross = risk_modes @ event_modes.T + physical * local_cross[self.family, None] / deviation[None, :]
        covariance = np.block([
            [np.eye(self.sources), risk_modes.T, event_modes.T],
            [risk_modes, risk_covariance, cross],
            [event_modes, cross.T, event_covariance],
        ])
        mean = np.concatenate((np.zeros(self.sources), risk.mean(axis=1),
                               ndtri(np.clip(collision.mean(axis=1), 0.01, 0.99))))
        self.mean = torch.as_tensor(mean, dtype=torch.float64, device=self.device)
        self.covariance = torch.as_tensor(covariance, dtype=torch.float64, device=self.device)
        self.risk_indices = torch.arange(self.sources, self.sources + self.size, device=self.device)
        self.event_indices = self.risk_indices + self.size
        nodes, weights = np.polynomial.hermite.hermgauss(3)
        self.risk_nodes = torch.as_tensor(nodes * math.sqrt(2), dtype=torch.float64, device=self.device)
        self.risk_weights = torch.as_tensor(weights / math.sqrt(math.pi),
                                           dtype=torch.float64, device=self.device)
        self.event_log_loss = 0.
        self.event_log_loss_after_risk = 0.

    def clone(self):
        result = copy.copy(self)
        result.mean = self.mean.clone()
        result.covariance = self.covariance.clone()
        return result

    def event_probabilities(self):
        variance = self.covariance.diagonal()[self.event_indices].clamp_min(1e-12)
        return torch.special.ndtr(self.mean[self.event_indices] / variance.sqrt()).clamp(0.01, 0.99)

    @torch.no_grad()
    def observe_risk(self, index, risk):
        coordinate = int(self.risk_indices[index])
        variance = self.covariance[coordinate, coordinate].clamp_min(1e-12)
        cross = self.covariance[:, coordinate].clone()
        self.mean += cross / variance * (risk - self.mean[coordinate]).clone()
        self.covariance -= torch.outer(cross, cross) / variance
        # The fixed execution bank defines a deterministic queried risk.
        self.mean[coordinate] = risk
        self.covariance[coordinate, :] = 0
        self.covariance[:, coordinate] = 0

    @torch.no_grad()
    def observe_event(self, index, collision):
        coordinate = int(self.event_indices[index])
        variance = self.covariance[coordinate, coordinate].clamp_min(1e-12)
        deviation = variance.sqrt()
        sign = 1 if collision else -1
        z = sign * self.mean[coordinate] / deviation
        ratio = torch.exp(-0.5 * z.square() - 0.5 * math.log(2 * math.pi)
                          - torch.special.log_ndtr(z))
        shrink = (ratio * (ratio + z)).clamp(0, 1)
        cross = self.covariance[:, coordinate].clone()
        self.mean += cross * sign * ratio / deviation
        self.covariance -= torch.outer(cross, cross) * shrink / variance

    def observe(self, index, risk, collision):
        probability = float(self.event_probabilities()[index])
        self.event_log_loss -= math.log(probability if collision else 1 - probability)
        self.observe_risk(index, risk)
        conditional = float(self.event_probabilities()[index])
        self.event_log_loss_after_risk -= math.log(conditional if collision else 1 - conditional)
        self.observe_event(index, collision)

    @torch.no_grad()
    def rank(self, remaining, *, tie_break):
        probability = self.event_probabilities().cpu().numpy()
        risk = self.mean[self.risk_indices].cpu().numpy()
        indices = np.flatnonzero(remaining)
        order = np.lexsort((tie_break[indices], -risk[indices], -np.round(probability[indices], 12)))
        return indices[order]

    @torch.no_grad()
    def planning_branches(self, indices):
        risk_indices, event_indices = self.risk_indices[indices], self.event_indices[indices]
        probability = self.event_probabilities()[indices]
        risk_variance = self.covariance.diagonal()[risk_indices].clamp_min(1e-12)
        event_variance = self.covariance.diagonal()[event_indices].clamp_min(1e-12)
        cross = self.covariance[risk_indices[:, None], event_indices[None, :]]
        own_cross = self.covariance[risk_indices, event_indices]
        risk_gain = cross / risk_variance[:, None]
        conditional_variance = (event_variance[None, :] - cross.square()
                                / risk_variance[:, None]).clamp_min(1e-12)
        conditional_cross = (self.covariance[event_indices[:, None], event_indices[None, :]]
                             - cross * own_cross[:, None] / risk_variance[:, None])
        own_variance = (event_variance - own_cross.square() / risk_variance).clamp_min(1e-12)
        own_deviation = own_variance.sqrt()
        risk_mean, event_mean = self.mean[risk_indices], self.mean[event_indices]
        nodes = (risk_mean[:, None] + risk_variance.sqrt()[:, None] * self.risk_nodes).clamp(0, 1)
        change = nodes - risk_mean[:, None]
        conditional_own_mean = event_mean[:, None] + own_cross[:, None] / risk_variance[:, None] * change
        node_events = torch.special.ndtr(conditional_own_mean / own_deviation[:, None])
        node_weights = self.risk_weights[None, :].expand(len(indices), -1)
        # Keep the parent event marginal despite finite quadrature and clipping.
        node_events = preserve_branch_mean(node_events[:, :, None], node_weights,
                                           probability[:, None]).squeeze(2)
        weights, predictions = [], []
        for node in range(3):
            conditional_mean = event_mean[None, :] + risk_gain * change[:, node, None]
            for outcome in (0, 1):
                sign = 1 if outcome else -1
                z = sign * conditional_own_mean[:, node] / own_deviation
                ratio = torch.exp(-0.5 * z.square() - 0.5 * math.log(2 * math.pi)
                                  - torch.special.log_ndtr(z))
                shrink = (ratio * (ratio + z)).clamp(0, 1)
                mean = conditional_mean + conditional_cross * (sign * ratio / own_deviation)[:, None]
                variance = (conditional_variance - conditional_cross.square()
                            * (shrink / own_variance)[:, None]).clamp_min(1e-12)
                predictions.append(torch.special.ndtr(mean / variance.sqrt()))
                chance = node_events[:, node] if outcome else 1 - node_events[:, node]
                weights.append(self.risk_weights[node] * chance)
        weights = torch.stack(weights, dim=1)
        predictions = preserve_branch_mean(torch.stack(predictions, dim=1), weights,
                                             probability[None, :])
        return weights, predictions

    def task_state(self):
        return {
            "latent_response_mean": self.mean[:self.sources].cpu().tolist(),
            "latent_response_covariance": self.covariance[:self.sources, :self.sources].cpu().tolist(),
            "event_log_loss_before_query": self.event_log_loss,
            "event_log_loss_after_risk": self.event_log_loss_after_risk,
            "scope": "response-mode coefficients, not controller identity or physical parameters",
        }
