"""Exhaustive checks of sharp bounds, paid continuations and prefix corrections."""
from itertools import permutations, product

import numpy as np

from .certificate import ExecutionCertificate, head_correction, list_weights
from .pools import scene_pool


def test_shared_pool_bounds_and_separation():
    first, second = scene_pool(0), scene_pool(1)
    x = np.asarray([scene["numeric_input"] for scene in first])
    assert x.shape == (2048, 5)
    assert np.all((x[:, :4] >= 0) & (x[:, :4] <= 1))
    assert np.bincount(x[:, 4].astype(int)).tolist() == [1024, 1024]
    assert not set(map(tuple, x)) & {tuple(scene["numeric_input"]) for scene in second}
    assert first == scene_pool(0)


def test_sharp_bounds_equal_extrema_of_all_label_completions():
    reference, proposal, size = [0, 1, 2], [2, 1, 3], 4
    for count in range(4):
        for audited in permutations(range(size), count):
            for observed in product((0, 1), repeat=count):
                certificate = ExecutionCertificate(reference, proposal, size)
                for index, label in zip(audited, observed):
                    certificate.observe(index, label)
                actual = certificate.continuation(proposal)
                assert len(actual) == len(set(actual)) == len(reference)
                difference = list_weights(actual, size) - list_weights(reference, size)
                values = [difference.T @ np.asarray(labels) for labels in product((0, 1), repeat=size)
                          if all(labels[index] == label for index, label in zip(audited, observed))]
                low, high = certificate.bounds(proposal)
                np.testing.assert_array_equal(low, np.min(values, axis=0))
                np.testing.assert_array_equal(high, np.max(values, axis=0))
                assert certificate.joint_lower_bound() == np.min(np.asarray(values).sum(axis=1))


def test_two_labels_support_internal_head_swap_for_every_completion():
    reference = list(range(8))
    certificate = ExecutionCertificate(reference, head_correction(reference, 7), 8)
    certificate.observe(7, True)
    certificate.observe(0, False)
    assert certificate.decision()["supported"]
    assert certificate.decision()["executable_gain_lower"] == [0, 1]
    for unknown in product((0, 1), repeat=6):
        labels = np.asarray([0, *unknown, 1])
        actual = certificate.continuation(certificate.proposal)
        gain = (list_weights(actual, 8) - list_weights(reference, 8)).T @ labels
        assert gain[0] == 0 and gain[1] >= 1


def test_external_head_replacement_counts_displaced_tail():
    reference = list(range(8))
    certificate = ExecutionCertificate(reference, head_correction(reference, 8), 9)
    certificate.observe(8, True)
    certificate.observe(0, False)
    assert certificate.decision()["executable_gain_lower"] == [0, 1]
    assert certificate.continuation(certificate.proposal) == [8, 0, 1, 2, 3, 4, 5, 6]


def test_failed_probe_has_real_cost_even_when_falling_back():
    reference = list(range(8))
    certificate = ExecutionCertificate(reference, head_correction(reference, 8), 9)
    certificate.observe(8, False)
    low, _ = certificate.bounds(reference)
    assert low.tolist() == [-1, -8]
    assert len(certificate.continuation(reference)) == 8


def test_one_observed_failure_supports_no_loss_but_not_strict_gain():
    reference = list(range(8))
    certificate = ExecutionCertificate(reference, head_correction(reference, 7), 8)
    certificate.observe(7, True)
    assert certificate.decision()["non_decreasing"]
    assert not certificate.decision()["supported"]


def test_paid_audit_order_matters_for_early_gain():
    reference = list(range(8))
    certificate = ExecutionCertificate(reference, head_correction(reference, 7), 8)
    certificate.observe(0, False)
    certificate.observe(7, True)
    assert certificate.decision()["executable_gain_lower"] == [0, 0]
    assert not certificate.decision()["supported"]
