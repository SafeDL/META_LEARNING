"""Check ADF order dependence using identical already-paid observations."""
from zipfile import ZipFile

import numpy as np
from threadpoolctl import threadpool_limits
import torch

from methods.history_guided_testing.history import historical_risk, load_history, split_indices, subset
from methods.history_guided_testing.io import read_json, write_json
from methods.history_guided_testing.search import TestingSession

from .censored_margin_response import CensoredMarginResponse, historical_margin_prior, neutral_margin_prior
from .config import OUTPUT, POOL_SEEDS, SUT_IDS
from .frozen_coupling import FrozenReplay


SOURCE = OUTPUT / "discovery_supported_prior_coupling"
RESULTS = OUTPUT / "margin_inference_order_diagnostic"


def top_indices(probability, available):
    indices = np.flatnonzero(available)
    return indices[np.lexsort((indices, -probability[indices]))[:200]]


def main():
    with ZipFile(SOURCE / "source_inputs.zip") as archive:
        if archive.read("censored_margin_response.py") != (OUTPUT.parent / "censored_margin_response.py").read_bytes():
            raise ValueError("Order diagnosis requires the original ADF model")
    RESULTS.mkdir(parents=True, exist_ok=True)
    with ZipFile(RESULTS / "source_inputs.zip", "w") as archive:
        for path in sorted(OUTPUT.parent.glob("*.py")):
            archive.write(path, path.name)
    history = load_history()
    train, _ = split_indices(next(iter(history.values()))["x"])
    allowed = subset(history, train)
    rows = []
    torch.set_num_threads(1)
    with threadpool_limits(limits=1):
        for pool in range(len(POOL_SEEDS)):
            with np.load(OUTPUT / f"pool_{pool}" / SUT_IDS[0] / "responses.npz") as bank:
                x = bank["x"].copy()
            risk_prior, margin = historical_risk(allowed, x), historical_margin_prior(x)
            for sut in SUT_IDS:
                run = read_json(SOURCE / f"pool_{pool}" / sut / "discovery_supported_prior_11.json")
                available = np.ones(len(x), dtype=bool)
                available[run["selected_indices"]] = False
                for component, prior in enumerate((margin, neutral_margin_prior(margin))):
                    probability = []
                    permutations = [np.arange(200), np.arange(199, -1, -1), np.random.default_rng(11).permutation(200)]
                    for order in permutations:
                        reference = FrozenReplay(TestingSession(x, 11, mode="global_feedback", prior=risk_prior))
                        model = CensoredMarginResponse(reference, x[:, 4], prior, continuous_safe=True)
                        for offset in order:
                            q = run["queries"][offset]
                            model.observe(q["index"], q["risk"], q["collision"])
                        probability.append(model.probabilities())
                    old_top = set(top_indices(probability[0], available))
                    comparisons = []
                    for name, changed in zip(("reversed", "permuted"), probability[1:]):
                        comparisons.append({"order": name,
                                            "maximum_probability_change": float(np.max(np.abs(changed[available] - probability[0][available]))),
                                            "mean_probability_change": float(np.mean(np.abs(changed[available] - probability[0][available]))),
                                            "top_200_changed_members": len(set(top_indices(changed, available)) - old_top)})
                    row = {"pool": pool, "sut_id": sut, "component": "history" if component == 0 else "neutral", "comparisons": comparisons}
                    rows.append(row)
                    write_json(RESULTS / "progress.json", {"status": "running", "components_done": len(rows), "expected": 24})
                    print("MARGIN ORDER", pool, sut, component, comparisons, flush=True)
    write_json(RESULTS / "summary.json", {"rows": rows, "components": 24,
               "scope": "same 200 paid observations and fixed unqueried set, inference only; no future labels read or new strategy curves",
               "new_physical_calls": 0})
    write_json(RESULTS / "progress.json", {"status": "complete", "components": 24, "new_physical_calls": 0})


if __name__ == "__main__":
    main()
