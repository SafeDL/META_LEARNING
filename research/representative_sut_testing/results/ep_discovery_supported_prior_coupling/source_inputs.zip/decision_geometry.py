"""Directional response information for current and budget-boundary decisions."""
import math

import numpy as np
import torch


GEOMETRY_FEATURES = (
    "candidate_reference_standardized_contrast", "candidate_reference_contrast_variance",
    "head_standardized_contrast", "head_contrast_variance",
    "head_risk_information_difference", "head_joint_information_difference",
    "head_risk_error_amplification_difference",
    "boundary_standardized_contrast", "boundary_contrast_variance",
    "boundary_risk_information_difference", "boundary_joint_information_difference",
    "boundary_risk_error_amplification_difference",
)


@torch.no_grad()
def contrast_information(model, pairs, queries):
    """Gaussian risk information plus quadrature-averaged sign information.

    Columns concern possible queries; rows concern event-latent contrasts,
    scaled by current marginal deviations to agree with probit ranking.
    Risk is integrated under the working Gaussian before clipping or ADF.
    These are model sensitivities, not target confidence or utility bounds.
    """
    pairs = torch.as_tensor(pairs, device=model.device)
    queries = torch.as_tensor(queries, device=model.device)
    left, right = model.event_indices[pairs[:, 0]], model.event_indices[pairs[:, 1]]
    risk, event = model.risk_indices[queries], model.event_indices[queries]
    covariance = model.covariance
    diagonal = covariance.diagonal()
    left_scale = diagonal[left].clamp_min(1e-12).rsqrt()
    right_scale = diagonal[right].clamp_min(1e-12).rsqrt()
    variance = (diagonal[left] * left_scale.square() + diagonal[right] * right_scale.square()
                - 2 * covariance[left, right] * left_scale * right_scale).clamp_min(0)
    deviation = variance.clamp_min(1e-12).sqrt()
    risk_variance = diagonal[risk].clamp_min(1e-12)
    event_variance = diagonal[event].clamp_min(1e-12)
    own_cross = covariance[risk, event]
    risk_cross = (covariance[left[:, None], risk] * left_scale[:, None]
                  - covariance[right[:, None], risk] * right_scale[:, None])
    event_cross = (covariance[left[:, None], event] * left_scale[:, None]
                   - covariance[right[:, None], event] * right_scale[:, None])
    risk_information = risk_cross.square() / risk_variance
    conditional_cross = event_cross - risk_cross * own_cross / risk_variance
    conditional_variance = (event_variance - own_cross.square() / risk_variance).clamp_min(1e-12)
    conditional_means = (model.mean[event, None]
                         + own_cross[:, None] / risk_variance.sqrt()[:, None] * model.risk_nodes)
    standardized = conditional_means / conditional_variance.sqrt()[:, None]
    sign_factor = torch.exp(-standardized.square() - math.log(2 * math.pi)
                            - torch.special.log_ndtr(standardized)
                            - torch.special.log_ndtr(-standardized))
    expected_factor = (sign_factor * model.risk_weights).sum(dim=1)
    event_information = conditional_cross.square() / conditional_variance * expected_factor
    normalizer = variance.clamp_min(1e-12)[:, None]
    return {
        "standardized_contrast": (model.mean[left] * left_scale - model.mean[right] * right_scale) / deviation,
        "contrast_variance": variance,
        "risk_information_fraction": (risk_information / normalizer).clamp(0, 1),
        "joint_information_fraction": ((risk_information + event_information) / normalizer).clamp(0, 1),
        "risk_error_amplification": risk_cross.abs() / risk_variance / deviation[:, None],
    }


def geometry_features(model, candidates, reference, remaining, tie_break, budget):
    rank = model.rank(remaining, tie_break=tie_break)
    if budget >= len(rank):
        raise ValueError("Budget boundary requires an unselected candidate outside the budget")
    queries = [*map(int, candidates), int(reference)]
    immediate_pairs = [(int(index), int(reference)) for index in candidates]
    immediate = contrast_information(model, immediate_pairs, queries)
    critical = contrast_information(model, [(int(rank[0]), int(rank[1])),
                                           (int(rank[budget - 1]), int(rank[budget]))], queries)
    columns = [immediate["standardized_contrast"], immediate["contrast_variance"]]
    for position in (0, 1):
        columns.extend([
            critical["standardized_contrast"][position].expand(len(candidates)),
            critical["contrast_variance"][position].expand(len(candidates)),
        ])
        for name in ("risk_information_fraction", "joint_information_fraction", "risk_error_amplification"):
            values = critical[name][position]
            columns.append(values[:-1] - values[-1])
    features = torch.stack(columns, dim=1).cpu().numpy()
    if not np.isfinite(features).all():
        raise ValueError("Nonfinite directional response features")
    return features
