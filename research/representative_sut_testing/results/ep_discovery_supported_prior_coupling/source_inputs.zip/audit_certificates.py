"""Rebuild local certificates from disclosures and the independent evaluator bank."""
import numpy as np

from methods.history_guided_testing.config import ROOT as HISTORY_ROOT
from methods.history_guided_testing.io import read_json, write_json

from .certificate import ExecutionCertificate
from .config import DEVELOPMENT, MECHANISM_FOLDER, OUTPUT
from .selector import METHODS


def verify_run(path, collision):
    run = read_json(path)
    accepted = 0
    for stored in run["audits"]:
        certificate = ExecutionCertificate(stored["reference"], stored["proposal"], len(collision))
        for index, label in zip(stored["audit_indices"], stored["audit_labels"]):
            if bool(collision[index]) != label:
                raise ValueError("Certificate event differs from evaluator")
            certificate.observe(index, label)
        rebuilt = certificate.decision()
        for key in ("supported", "executable_gain_lower", "executable_gain_upper"):
            if rebuilt[key] != stored[key]:
                raise ValueError(f"Recomputed certificate differs: {path}, {key}")
        start = stored["start_query"] - 1
        actual = run["selected_indices"][start:start + certificate.budget]
        if actual != stored["executed_order"]:
            raise ValueError("Actual query continuation differs from certificate record")
        if stored.get("accepted", stored["supported"]):
            if actual != rebuilt["actual_continuation"]:
                raise ValueError("Supported correction was not executed")
            reference_curve = np.cumsum(collision[stored["reference"]])
            actual_curve = np.cumsum(collision[actual])
            gain = np.asarray([actual_curve[-1] - reference_curve[-1],
                               actual_curve.sum() - reference_curve.sum()])
            if np.any(gain < rebuilt["executable_gain_lower"]) or gain.sum() < rebuilt["strict_gain_lower"]:
                raise ValueError("Supported local certificate fails actual event comparison")
            accepted += 1
    return {"file": str(path.relative_to(OUTPUT)), "comparisons": len(run["audits"]),
            "accepted_local_comparisons": accepted,
            "audit_queries": run["audit_query_count"]}


def main():
    rows = []
    with np.load(HISTORY_ROOT / "history/responses.npz") as history:
        for path in DEVELOPMENT.glob(f"*/{METHODS[-1]}_*.json"):
            rows.append(verify_run(path, history[path.parent.name + "_collision"]))
    for path in OUTPUT.glob(f"pool_*/*/{MECHANISM_FOLDER}/{METHODS[-1]}_*.json"):
        with np.load(path.parents[1] / "responses.npz") as bank:
            rows.append(verify_run(path, bank["collision"]))
    write_json(OUTPUT / "local_certificate_audit.json", {
        "passed_available_runs": rows,
        "accepted_local_comparisons": sum(row["accepted_local_comparisons"] for row in rows),
        "scope": "all available local-correction decisions and their executed blocks; no global adaptive-policy guarantee",
    })
    print("CERTIFICATE AUDIT", len(rows), "runs", sum(row["accepted_local_comparisons"] for row in rows),
          "accepted local comparisons", flush=True)


if __name__ == "__main__":
    main()
