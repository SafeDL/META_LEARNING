"""Prior evidence timing, censoring mass, positive density and fixed decisions."""
from types import SimpleNamespace

import numpy as np
from scipy.special import logsumexp
from scipy.stats import norm

from .adaptive_margin_prior import AdaptiveMarginPrior, mixed_log_likelihood
from .censored_margin_response import calibrated_margin_moments


def build(freeze):
    reference = SimpleNamespace(session=SimpleNamespace(gp=SimpleNamespace(covariance=np.eye(12), noise=.1)),
                                head=lambda: 10)
    probability, positive = np.full(12, .8), np.full(12, .4)
    mean, variance = calibrated_margin_moments(probability, positive)
    prior = {"probability": probability, "positive_mean": positive, "mean": mean,
             "report_variance": variance, "modes": np.zeros((12, 6))}
    return AdaptiveMarginPrior(reference, [0] * 12, prior, freeze_after_initialization=freeze, device="cpu")


def test_mixed_likelihood_uses_event_mass_and_positive_value_density():
    means, variances = np.asarray([-.3, .2]), np.asarray([.5, .1])
    np.testing.assert_allclose(mixed_log_likelihood(means, variances, .5, True), norm.logcdf(0, means, np.sqrt(variances)))
    np.testing.assert_allclose(mixed_log_likelihood(means, variances, .5, False), norm.logpdf(.5, means, np.sqrt(variances)))
    np.testing.assert_array_equal(mixed_log_likelihood(means, variances, .51, True), mixed_log_likelihood(means, variances, 1., True))


def test_initial_selection_uses_ten_feedbacks_and_does_not_change_later():
    model = build(True)
    for index in range(9):
        model.observe(index, 1., True)
    assert model.selected_model is None
    model.observe(9, 1., True)
    assert model.selected_model == 0
    np.testing.assert_array_equal(model.selection_weights(), [1, 0])
    choice = model.selected_model
    model.observe(10, .1, False)
    assert model.selected_model == choice
    assert len(model.evidence_records) == 11 and all(len(m.records) == 11 for m in model.models)


def test_online_weights_are_updated_after_observation_not_before():
    model = build(False)
    prior = model.probabilities().copy()
    model.observe(0, .4, False)
    record = model.evidence_records[-1]
    np.testing.assert_array_equal(record['weights_before'], [.5, .5])
    expected = np.log([.5, .5]) + record['log_predictive_likelihoods']
    np.testing.assert_allclose(record['weights_after'], np.exp(expected - logsumexp(expected)))
    assert record['weights_after'][1] > .5
    assert model.selected_model is None and not np.array_equal(model.probabilities(), prior)
