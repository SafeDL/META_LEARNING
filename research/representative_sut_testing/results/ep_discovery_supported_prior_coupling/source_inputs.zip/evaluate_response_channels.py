"""Six-SUT main development with matched event-feedback response controls."""
import multiprocessing as mp
import time
from zipfile import ZipFile

import numpy as np

from methods.history_guided_testing.config import ROOT as HISTORY_ROOT
from methods.history_guided_testing.io import read_json, write_json

from .calibration import historical_calibration
from .config import OUTPUT, POOL_SEEDS, PROFILES, SEEDS, SUT_IDS
from .develop import disclose, metrics
from .response import historical_predictions
from .response_channels import METHODS, selector_worker


RESULTS = OUTPUT / "response_channel_main"


def summarize():
    rows = []
    for pool in range(len(POOL_SEEDS)):
        for sut in SUT_IDS:
            with np.load(OUTPUT / f"pool_{pool}" / sut / "responses.npz") as bank:
                initial = {}
                for method in METHODS:
                    runs = [read_json(RESULTS / f"pool_{pool}" / sut / f"{method}_{seed}.json") for seed in SEEDS]
                    for seed, run in zip(SEEDS, runs):
                        order = run["selected_indices"]
                        if len(order) != 200 or len(set(order)) != 200:
                            raise ValueError("Invalid main response-channel query budget")
                        rebuilt = metrics(bank["collision"], order)
                        if any(run[key] != rebuilt[key] for key in ("area_200", "recall_200", "curve", "F200", "checkpoints")):
                            raise ValueError("Main metrics differ from executed target events")
                        expected = [{"index": index, "risk": float(bank["risk"][index]),
                                     "collision": bool(bank["collision"][index])} for index in order]
                        if run["disclosures"] != expected:
                            raise ValueError("Main feedback differs from fixed measured responses")
                        if seed in initial and initial[seed] != order[:10]:
                            raise ValueError("Main response-channel controls differ in initialization")
                        initial[seed] = order[:10]
                    rows.append({"pool": pool, "sut_id": sut, "method": method, "runs": len(runs),
                                 "area_pct": 100 * np.mean([r["area_200"] for r in runs]),
                                 "recall_pct": 100 * np.mean([r["recall_200"] for r in runs]),
                                 "F200": np.mean([r["F200"] for r in runs]),
                                 "distinct_sequences": len({tuple(r["selected_indices"]) for r in runs})})
    aggregate = {method: {key: float(np.mean([r[key] for r in rows if r["method"] == method]))
                          for key in ("area_pct", "recall_pct", "F200")} for method in METHODS}
    frozen = read_json(OUTPUT / "baseline_comparison.json")["aggregate"]
    full = aggregate["shared_event_response"]
    changes = {method: {"area_pp": full["area_pct"] - value["area_pct"],
                        "recall_pp": full["recall_pct"] - value["recall_pct"]}
               for method, value in aggregate.items() if method != "shared_event_response"}
    frozen_changes = {r["method"]: {"area_pp": full["area_pct"] - r["area_pct"],
                                    "recall_pp": full["recall_pct"] - r["recall_pct"]} for r in frozen}
    write_json(RESULTS / "summary.json", {"rows": rows, "aggregate": aggregate,
                                        "matched_changes": changes, "frozen_baseline_changes": frozen_changes,
                                        "significant_advantage_established": False,
                                        "scope": "six-SUT development; existing pools have been used in method design"})
    lines = ["# 六 SUT 的响应通道与共享任务结构比较", "",
             "原定六 SUT、两个共享池、五个选择种子、200 次预算及共同 10 次初始化。三方法获得同一已查询风险／碰撞反馈。",
             "目标参数、身份和未查询标签不进入独立选择进程；只使用原六来源历史，不使用额外配置监督。",
             "局部事件 GP 保持相同历史事件均值、初始边缘概率和物理长度尺度，去除跨场景的共享响应模式。", "",
             "| 方法 | Area % | Recall % | 平均 F200 |", "|---|---:|---:|---:|"]
    for method, value in aggregate.items():
        lines.append(f"| {method} | {value['area_pct']:.3f} | {value['recall_pct']:.3f} | {value['F200']:.2f} |")
    lines += ["", "| 池 | SUT | 方法 | Area % | Recall % | F200 | 不同选择序列/5 |",
              "|---|---|---|---:|---:|---:|---:|"]
    for row in rows:
        lines.append(f"| {row['pool']} | {row['sut_id']} | {row['method']} | {row['area_pct']:.3f} | "
                     f"{row['recall_pct']:.3f} | {row['F200']:.2f} | {row['distinct_sequences']} |")
    lines += ["", "## 冻结基线的同池比较", "",
              "冻结方法保持原反馈权限；行为模型使用额外历史配置。机制归因依靠上面的同反馈对照。", "",
              "| 冻结基线 | Area % | Recall % | 共享事件响应 ΔArea | ΔRecall |",
              "|---|---:|---:|---:|---:|"]
    for row in frozen:
        change = frozen_changes[row["method"]]
        lines.append(f"| {row['method']} | {row['area_pct']:.3f} | {row['recall_pct']:.3f} | "
                     f"{change['area_pp']:+.3f} | {change['recall_pp']:+.3f} |")
    lines += ["", "180 条曲线、36000 次披露重算完成；新增物理执行为 0。",
              "重复种子不构成独立 SUT 或确认样本，已有池属于开发；不据此宣布显著优势。"]
    (RESULTS / "report.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print({"aggregate": aggregate, "matched_changes": changes}, flush=True)


def main():
    write_json(RESULTS / "protocol.json", {
        "stage": "six representative SUT main development, not confirmation",
        "sut_ids": SUT_IDS, "pool_ids": list(range(len(POOL_SEEDS))), "seeds": SEEDS,
        "methods": METHODS, "budget": 200, "initial_queries": 10,
        "historical_sources": [p.name for p in PROFILES], "extra_historical_configurations_used": False,
        "feedback": "same requested risk and same-execution collision",
        "target_identity_or_parameters_in_selector": False,
        "new_physical_calls": 0, "expected_runs": 180,
    })
    snapshot = RESULTS / "source_inputs.zip"
    if not snapshot.exists():
        with ZipFile(snapshot, "w") as archive:
            for path in sorted(OUTPUT.parent.glob("*.py")):
                archive.write(path, path.name)
    with ZipFile(snapshot) as archive:
        for name in archive.namelist():
            if archive.read(name) != (OUTPUT.parent / name).read_bytes():
                raise ValueError("Response-channel main source changed after freezing")
    context = mp.get_context("spawn")
    parent, child = context.Pipe()
    process = context.Process(target=selector_worker, args=(child,))
    process.start()
    child.close()
    try:
        with np.load(HISTORY_ROOT / "history/responses.npz") as history:
            names = [p.name for p in PROFILES]
            calibration = historical_calibration(history, names)
            for pool in range(len(POOL_SEEDS)):
                for sut in SUT_IDS:
                    with np.load(OUTPUT / f"pool_{pool}" / sut / "responses.npz") as bank:
                        predictions = (*historical_predictions(bank["x"], history, names), calibration)
                        for seed in SEEDS:
                            for method in METHODS:
                                path = RESULTS / f"pool_{pool}" / sut / f"{method}_{seed}.json"
                                if path.exists():
                                    continue
                                started = time.perf_counter()
                                task = {"method": method, "seed": seed, "x": bank["x"], "predictions": predictions}
                                run = disclose(parent, task, bank["risk"], bank["collision"])
                                run.update(method=method, seed=seed, selector_elapsed_s=time.perf_counter() - started)
                                write_json(path, run)
                                write_json(RESULTS / "progress.json", {"status": "running", "latest": str(path.relative_to(RESULTS)),
                                                                      "expected_runs": 180})
                                print("RESPONSE MAIN", pool, sut, seed, method, run["F200"], flush=True)
    finally:
        if process.is_alive():
            parent.send(("stop", None))
        parent.close()
        process.join(timeout=10)
        if process.is_alive():
            process.terminate()
            process.join()
        if process.exitcode != 0:
            raise RuntimeError(f"Response-channel main selector exited {process.exitcode}")
    summarize()
    write_json(RESULTS / "progress.json", {"status": "complete", "runs": 180, "disclosures": 36000,
                                         "new_physical_calls": 0, "significant_advantage_established": False})


if __name__ == "__main__":
    main()
