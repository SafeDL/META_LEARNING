"""Matched response controls: shared risk/event, shared event, local event GP."""
import numpy as np
import torch
from threadpoolctl import threadpool_limits

from methods.history_guided_testing.experiment import RemoteOracle

from .config import BUDGET, INITIAL_QUERIES
from .response import ResponseModel


METHODS = ("joint_risk_response", "shared_event_response", "local_event_gp")


@torch.no_grad()
def local_event_prior(prior):
    model = prior.clone()
    loading = prior.covariance[:, :prior.sources]
    model.covariance -= loading @ loading.T
    scale = torch.ones(len(model.mean), dtype=torch.float64, device=model.device)
    scale[model.event_indices] = model.covariance.diagonal()[model.event_indices].clamp_min(1e-12).rsqrt()
    model.covariance *= scale[:, None] * scale[None, :]
    return model


def select(method, x, predictions, oracle, seed):
    if method not in METHODS:
        raise ValueError("Unknown response-channel control")
    initialization = ResponseModel(x, *predictions)
    if method == "joint_risk_response":
        model = initialization
    elif method == "shared_event_response":
        model = initialization.clone()
    else:
        model = local_event_prior(initialization)
    available = np.ones(len(x), dtype=bool)
    tie = np.random.default_rng(seed).random(len(x))
    selected, observations = [], []
    for t in range(BUDGET):
        chooser = initialization if t < INITIAL_QUERIES else model
        index = int(chooser.rank(available, tie_break=tie)[0])
        observation = oracle.query(index)
        if observation.risk is None or observation.collision is None:
            raise ValueError("Response controls require the same queried risk/event feedback")
        selected.append(index)
        available[index] = False
        observations.append({"index": index, "risk": float(observation.risk),
                             "collision": bool(observation.collision),
                             "role": "initialization" if t < INITIAL_QUERIES else "discovery"})
        if method == "joint_risk_response":
            model.observe(index, observation.risk, observation.collision)
        else:
            if t < INITIAL_QUERIES:
                initialization.observe(index, observation.risk, observation.collision)
            model.observe_event(index, observation.collision)
    return {"selected_indices": selected, "queries": observations, "planning_checks": [], "audits": [],
            "task_posterior": model.task_state(),
            "feedback_use": "risk and event" if method == "joint_risk_response" else "event-only target updates"}


def selector_worker(connection):
    try:
        with threadpool_limits(limits=1):
            while True:
                message, task = connection.recv()
                if message == "stop":
                    return
                if message != "task":
                    raise ValueError("Invalid response-channel task")
                result = select(task["method"], task["x"], task["predictions"], RemoteOracle(connection), task["seed"])
                connection.send(("result", result))
    except Exception as error:
        connection.send(("error", repr(error)))
        raise
    finally:
        connection.close()
