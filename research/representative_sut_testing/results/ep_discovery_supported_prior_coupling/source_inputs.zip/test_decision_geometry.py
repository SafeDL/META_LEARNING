"""Directional information distinguishes blind, informative and amplified queries."""
import math
from types import SimpleNamespace

import numpy as np
import torch

from .decision_geometry import contrast_information


def gaussian_state(risk_loading, event_loading, mean=None):
    loading = torch.as_tensor(np.vstack((risk_loading, event_loading)), dtype=torch.float64)
    size = len(risk_loading)
    nodes, weights = np.polynomial.hermite.hermgauss(3)
    return SimpleNamespace(
        device="cpu", covariance=loading @ loading.T,
        mean=torch.zeros(size * 2, dtype=torch.float64) if mean is None else torch.tensor(mean),
        risk_indices=torch.arange(size), event_indices=torch.arange(size, size * 2),
        risk_nodes=torch.tensor(nodes * math.sqrt(2)),
        risk_weights=torch.tensor(weights / math.sqrt(math.pi)),
    )


def test_risk_blind_contrast_can_be_observed_by_event_feedback():
    model = gaussian_state([[1., 0.], [1., 0.]], [[0., 1.], [0., 0.]])
    result = contrast_information(model, [(0, 1)], [0])
    np.testing.assert_allclose(result["risk_information_fraction"], [[0.]])
    np.testing.assert_allclose(result["joint_information_fraction"], [[2 / math.pi]])


def test_aligned_risk_feedback_removes_the_contrast_variance():
    model = gaussian_state([[0., 1.], [1., 0.]], [[0., 1.], [0., 0.]])
    result = contrast_information(model, [(0, 1)], [0])
    np.testing.assert_allclose(result["risk_information_fraction"], [[1.]])
    np.testing.assert_allclose(result["joint_information_fraction"], [[1.]])


def test_equal_information_can_have_different_error_amplification():
    event = [[0., 1.], [0., 0.]]
    regular = gaussian_state([[0., 1.], [1., 0.]], event)
    amplified = gaussian_state([[0., .01], [1., 0.]], event)
    a = contrast_information(regular, [(0, 1)], [0])
    b = contrast_information(amplified, [(0, 1)], [0])
    np.testing.assert_allclose(a["risk_information_fraction"], b["risk_information_fraction"])
    np.testing.assert_allclose(b["risk_error_amplification"], 100 * a["risk_error_amplification"])


def test_same_response_contrast_has_zero_information():
    model = gaussian_state([[1., 0.], [0., 1.]], [[1., 1.], [1., 1.]])
    result = contrast_information(model, [(0, 1)], [0, 1])
    for value in result.values():
        assert torch.isfinite(value).all()
        assert not torch.count_nonzero(value)


def test_risk_variance_reduction_matches_explicit_gaussian_conditioning():
    rng = np.random.default_rng(17)
    model = gaussian_state(rng.normal(size=(3, 6)), rng.normal(size=(3, 6)))
    result = contrast_information(model, [(0, 1)], [2])
    covariance = model.covariance.numpy()
    contrast = np.zeros(6)
    contrast[3], contrast[4] = 1 / np.sqrt(covariance[3, 3]), -1 / np.sqrt(covariance[4, 4])
    old = contrast @ covariance @ contrast
    conditioned = covariance - np.outer(covariance[:, 2], covariance[:, 2]) / covariance[2, 2]
    new = contrast @ conditioned @ contrast
    np.testing.assert_allclose(result["risk_information_fraction"], [[(old - new) / old]])
    assert result["risk_information_fraction"][0, 0] <= result["joint_information_fraction"][0, 0] <= 1
