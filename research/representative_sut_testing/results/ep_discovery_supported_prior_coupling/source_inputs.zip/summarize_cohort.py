"""Audit reused payoff labels and report the complete fixed-cohort validation."""
from dataclasses import asdict
from zipfile import ZipFile

import numpy as np

from methods.history_guided_testing.config import TARGET
from methods.history_guided_testing.io import read_json, write_json

from .cohort_payoff import RESULTS, SEED, TRAINING, VALIDATION, load_bank
from .config import BUDGET, CHECKPOINTS, PAYOFF_CONTEXTS, PROFILES
from .develop import metrics
from .selector import METHODS


def audit_training(protocol):
    training = read_json(RESULTS / "payoff_training.json")
    with ZipFile(RESULTS / "source_inputs.zip") as archive:
        sources = [name for name in archive.namelist() if name.endswith(".py")]
        for name in sources:
            if archive.read(name) != (RESULTS.parents[1] / name).read_bytes():
                raise ValueError(f"Algorithm source changed after freezing: {name}")
    names = [profile.name for profile in PROFILES]
    if training["allowed_historical_tasks"] != TRAINING:
        raise ValueError("Payoff training differs from the declared split")
    profiles = protocol["training_profiles"] + protocol["validation_profiles"]
    signatures = [tuple(sorted((k, v) for k, v in p.items() if k != "name")) for p in profiles]
    if len(set(signatures)) != len(signatures):
        raise ValueError("Repeated training/validation controller configuration")
    original = [asdict(p) for p in (*PROFILES, TARGET)]
    original_signatures = {tuple(sorted((k, v) for k, v in p.items() if k != "name")) for p in original}
    if original_signatures.intersection(signatures):
        raise ValueError("Reused cohort duplicates an original source or target configuration")
    banks = {name: load_bank(name) for name in TRAINING}
    counts = {name: 0 for name in TRAINING}
    for row in training["rows"]:
        task = row["training_task"]
        if task not in TRAINING or row["prior_sources"] != names:
            raise ValueError("Training row uses an undeclared task or response source")
        prefix = row["prefix_indices"]
        q = row["queried_prefix"]
        budget = BUDGET - q
        if q not in PAYOFF_CONTEXTS or len(prefix) != q or len(set(prefix)) != q:
            raise ValueError("Invalid training support prefix")
        if row["remaining_budget"] != budget:
            raise ValueError("Counterfactual remaining budget differs from the support prefix")
        if len(row["features"]) != 13 or not np.isfinite(row["features"]).all():
            raise ValueError("Invalid payoff state/action features")
        returns = []
        for kind in ("reference", "candidate"):
            order = row[kind + "_order"]
            if len(order) != budget or len(set(order)) != budget or set(order).intersection(prefix):
                raise ValueError("Counterfactual continuation repeats or exceeds paid queries")
            if order[0] != row[kind]:
                raise ValueError("Counterfactual first action differs from its label")
            curve = np.cumsum(banks[task]["collision"][order])
            returns.append(np.asarray([curve[-1], curve.sum()]))
        gain = returns[1] - returns[0]
        if not np.array_equal(gain, row["actual_gain"]):
            raise ValueError("Historical counterfactual gain differs from measured events")
        normalized = gain / [budget, budget * (budget + 1) / 2]
        if not np.allclose(normalized, row["normalized_gain"], rtol=0, atol=1e-12):
            raise ValueError("Historical gain normalization differs from its budget")
        counts[task] += 1
    if any(count == 0 for count in counts.values()):
        raise ValueError("Declared historical configuration has no supervised payoff rows")
    return {"rows": len(training["rows"]), "rows_per_task": counts,
            "unchanged_source_snapshot_files": len(sources),
            "adaptive_rollouts": training["adaptive_rollouts"],
            "training_validation_disjoint": not set(TRAINING).intersection(VALIDATION),
            "no_original_source_or_target_duplicate": True,
            "counterfactual_gain_recomputed": True,
            "new_physical_calls": 0}


def audit_run(run, bank):
    selected = run["selected_indices"]
    if len(selected) != BUDGET or len(set(selected)) != BUDGET:
        raise ValueError("Invalid validation query budget")
    if run["payoff_training_systems"] != TRAINING:
        raise ValueError("Validation run uses different payoff supervision")
    if run["historical_sources"] != [p.name for p in PROFILES]:
        raise ValueError("Validation response prior differs from the common six sources")
    for key in ("queries", "disclosures"):
        if len(run[key]) != BUDGET:
            raise ValueError("Incomplete validation disclosure record")
        for index, observation in zip(selected, run[key]):
            if (observation["index"] != index or observation["risk"] != float(bank["risk"][index])
                    or observation["collision"] != bool(bank["collision"][index])):
                raise ValueError("Validation feedback differs from measured responses")
    actual = metrics(bank["collision"], selected)
    for key, value in actual.items():
        reported = run[key]
        if isinstance(value, float):
            if not np.isclose(value, reported, rtol=0, atol=1e-12):
                raise ValueError(f"Validation metric differs from executed events: {key}")
        elif value != reported:
            raise ValueError(f"Validation metric differs from executed events: {key}")
    changed = 0
    for check in run["planning_checks"]:
        if selected[check["start_query"] - 1] != check["chosen_index"]:
            raise ValueError("Saved planned action differs from its executed query")
        gain = np.asarray(check["chosen_values"]) - check["reference_values"]
        if not np.allclose(gain, check["predicted_gain"], rtol=0, atol=1e-12):
            raise ValueError("Saved model payoff differs from its decision inputs")
        if check["screen_applied"]:
            if (np.any(gain < -1e-10) or min(check["support_lower"]) < -1e-12
                    or min(check["loss_budget_margin"]) < -1e-12):
                raise ValueError("Selected action violates the declared model screen")
        changed += check["chosen_index"] != check["reference_index"]
    if changed != run["audit_query_count"]:
        raise ValueError("Correction count differs from actual decisions")
    return actual


def main():
    if read_json(RESULTS / "progress.json")["status"] != "complete":
        raise ValueError("Fixed-cohort validation is still running")
    protocol = read_json(RESULTS / "protocol.json")
    if protocol["training_systems"] != TRAINING or protocol["validation_systems"] != VALIDATION:
        raise ValueError("Fixed training/validation split changed")
    audit = audit_training(protocol)
    rows = []
    for name in VALIDATION:
        bank = load_bank(name)
        initial = None
        for method in METHODS:
            run = read_json(RESULTS / name / f"{method}_{SEED}.json")
            actual = audit_run(run, bank)
            if initial is None:
                initial = run["selected_indices"][:10]
            if run["selected_indices"][:10] != initial:
                raise ValueError("Mechanism controls differ in initialization")
            rows.append({"target": name, "family": name.split("_")[0], "method": method,
                         "total_collisions": actual["total_collisions"],
                         "area_pct": 100 * actual["area_200"],
                         "recall_pct": 100 * actual["recall_200"], "F200": actual["F200"],
                         "corrections": run["audit_query_count"],
                         "selector_elapsed_s": run["selector_elapsed_s"],
                         **{f"F{t}": actual["checkpoints"][str(t)] for t in CHECKPOINTS}})
    keys = ("area_pct", "recall_pct", "F200", "corrections", "selector_elapsed_s")
    aggregate = {method: {key: float(np.mean([r[key] for r in rows if r["method"] == method]))
                          for key in keys} for method in METHODS}
    candidate = aggregate[METHODS[-1]]
    changes = {method: {"area_pp": candidate["area_pct"] - aggregate[method]["area_pct"],
                        "recall_pp": candidate["recall_pct"] - aggregate[method]["recall_pct"]}
               for method in METHODS[:-1]}
    paired = []
    for name in VALIDATION:
        values = {r["method"]: r for r in rows if r["target"] == name}
        full, reference = values[METHODS[-1]], values[METHODS[0]]
        paired.append({"target": name, "area_pp": full["area_pct"] - reference["area_pct"],
                       "recall_pp": full["recall_pct"] - reference["recall_pct"],
                       "F200_gain": full["F200"] - reference["F200"]})
    joint = all(c["area_pp"] > 0 and c["recall_pp"] > 0 for c in changes.values())
    summary = {"stage": "fixed public configuration development validation, not confirmation",
               "rows": rows, "aggregate": aggregate, "candidate_changes": changes,
               "paired_changes_against_reference": paired,
               "family_aggregate": {
                   family: {method: {key: float(np.mean([
                       r[key] for r in rows if r["family"] == family and r["method"] == method]))
                                     for key in keys} for method in METHODS}
                   for family in ("idm", "fvdm")},
               "empirical_joint_mean_improvement": joint,
               "significant_advantage_established": False}
    write_json(RESULTS / "summary.json", summary)
    audit.update(status="passed", runs=len(rows), disclosures=len(rows) * BUDGET,
                 common_initialization=True, validation_metrics_recomputed=True)
    write_json(RESULTS / "audit.json", audit)
    lines = ["# 固定配置队列的纠正收益验证", "",
             "24 个既定训练配置监督收益，12 个既定验证配置比较三种选择规则；同六来源响应先验、pool_0、种子 11、预算 200。",
             "36 条曲线、7200 次反馈披露，新增物理执行为 0。完整历史标签只用于训练配置的反事实监督。",
             "配置属于 IDM/FVDM 两个相关模型族；本阶段是公开开发验证，不作显著性确认。", "",
             "| 方法 | 等权配置 Area % | Recall % | F200 | 平均纠正次数 | 平均选择秒 |",
             "|---|---:|---:|---:|---:|---:|"]
    for method, value in aggregate.items():
        lines.append(f"| {method} | {value['area_pct']:.3f} | {value['recall_pct']:.3f} | "
                     f"{value['F200']:.2f} | {value['corrections']:.2f} | {value['selector_elapsed_s']:.2f} |")
    lines += ["", "| 配置 | 方法 | 全池碰撞 | Area % | Recall % | F10 | F30 | F50 | F100 | F150 | F200 | 纠正次数 |",
              "|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|"]
    for row in rows:
        fields = [row["target"], row["method"], str(row["total_collisions"]),
                  f"{row['area_pct']:.3f}", f"{row['recall_pct']:.3f}"]
        fields += [str(row[f"F{t}"]) for t in CHECKPOINTS] + [str(row["corrections"])]
        lines.append("| " + " | ".join(fields) + " |")
    lines += [""]
    for method, change in changes.items():
        lines.append(f"完整方法相对 {method}：Area {change['area_pp']:+.3f}、Recall {change['recall_pp']:+.3f} 个百分点。")
    diagnostic_path = RESULTS / "payoff_generalization.json"
    if diagnostic_path.exists():
        diagnostic = read_json(diagnostic_path)
        screen = diagnostic["diagnostics"]["loo_screen"]
        lines += ["", "## 收益可预测性诊断", "",
                  "每个历史配置的收益预测来自完整移除该配置标签的模型，仅分析训练配置，不使用验证标签调参。",
                  f"两项归一化收益 R² 为 {diagnostic['normalized_gain_r2'][0]:.3f}、"
                  f"{diagnostic['normalized_gain_r2'][1]:.3f}；预测与实际相关性为 "
                  f"{diagnostic['prediction_actual_correlation'][0]:.3f}、"
                  f"{diagnostic['prediction_actual_correlation'][1]:.3f}。",
                  f"单个整配置留出模型的收益—损失筛查在 {screen['states']} 个状态中纠正 "
                  f"{screen['corrections']} 次，其中 {screen['harmful_corrections']} 次损害至少一项指标。",
                  "这个单留出模型诊断不是部署时全部模型包络的完整策略评价；它显示收益迁移误差，不能当作风险保证。",
                  "[逐项诊断](payoff_generalization.json)、[预测与实测图](payoff_generalization.png)。"]
    lines += ["", f"历史监督 {audit['rows']} 行、{audit['adaptive_rollouts']} 次自适应反事实延续已按实测事件重算；",
              "配置排除、共同初始化、200 次唯一披露、模型筛查条件及全部评价指标核对通过。",
              "满足开发双指标门槛。" if joint else "未满足开发双指标门槛，不推进主实验或确认。",
              "模型包络仍不是真实收益置信界。进一步实验的依据应是纠正收益是否可预测，不能通过增加相同曲线的重复次数宣布显著优势。"]
    (RESULTS / "report.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print({"aggregate": aggregate, "candidate_changes": changes,
           "empirical_joint_mean_improvement": joint, "audit": audit["status"]}, flush=True)


if __name__ == "__main__":
    main()
