"""Payoff supervision on the fixed public training/validation configuration split."""
import multiprocessing as mp
import pickle
import time

import numpy as np

from methods.history_guided_testing.config import ROOT as HISTORY_ROOT
from methods.history_guided_testing.io import read_json, write_json

from .calibration import historical_calibration
from .config import BOUNDS, BUDGET, OUTPUT, PAYOFF_CONTEXTS, PROFILES
from .develop import disclose
from .payoff import continuation_return, fit_models, proposals
from .response import ResponseModel, historical_predictions
from .selector import METHODS, selector_worker


COHORT = OUTPUT.parents[1] / "behavior_response_testing/results/confirmation"
RESULTS = OUTPUT / "cohort_payoff_development"
TRAINING = [f"{family}_{i:02d}" for family in ("idm", "fvdm") for i in range(12)]
VALIDATION = [f"{family}_{i:02d}" for family in ("idm", "fvdm") for i in range(12, 18)]
POOL = 0
SEED = 11


def load_bank(name):
    folder = COHORT / name / f"pool_{POOL}"
    with np.load(folder / "responses.npz") as data:
        return {key: data[key].copy() for key in ("x", "risk", "collision")}


def prepare_protocol():
    source = read_json(COHORT / "protocol.json")
    profiles = {p["name"]: p for p in source["profiles"]}
    if set(TRAINING).intersection(VALIDATION):
        raise ValueError("Training and validation systems overlap")
    seen = set()
    for name in (*TRAINING, *VALIDATION):
        profile = dict(profiles[name])
        profile.pop("name")
        signature = tuple(sorted(profile.items()))
        if signature in seen:
            raise ValueError("Duplicate controller configuration in reused cohort")
        seen.add(signature)
        bank = load_bank(name)
        scenarios = read_json(COHORT / name / f"pool_{POOL}" / "scenarios.json")
        if not np.array_equal(bank["x"], [s["numeric_input"] for s in scenarios]):
            raise ValueError("Reused coordinates differ from measured scenario records")
        expected_context = {"duration_s": 12, "ego_speed_mps": 25,
                            "desired_speed_mps": 23, "lane_count": 2}
        for scenario in scenarios:
            if scenario["fixed_context"] != expected_context or scenario["simulator_seed"] != 4179941:
                raise ValueError("Historical scenario context differs from main testing protocol")
            coordinate = scenario["numeric_input"]
            family = int(coordinate[4])
            bounds = np.asarray(BOUNDS[family])
            physical_values = bounds[:, 0] + np.asarray(coordinate[:4]) * (bounds[:, 1] - bounds[:, 0])
            if not np.allclose(physical_values, list(scenario["active_parameters"].values()), atol=1e-12):
                raise ValueError("Historical scene uses different parameter bounds")
        if bank["x"].shape != (2048, 5) or len(bank["risk"]) != 2048:
            raise ValueError("Cohort bank shape differs from main scenario contract")
        if bank["collision"].dtype != np.bool_ or not np.isfinite(bank["risk"]).all():
            raise ValueError("Invalid historical responses")
        if np.any((bank["risk"] < 0) | (bank["risk"] > 1)):
            raise ValueError("Historical risk out of range")
        if any(np.count_nonzero(bank["x"][:, 4] == g) != 1024 for g in (0, 1)):
            raise ValueError("Scenario families differ from main contract")
    protocol = {
        "stage": "public configuration validation; not blind confirmation",
        "training_systems": TRAINING, "validation_systems": VALIDATION,
        "excluded_development_systems": [f"{f}_{i:02d}" for f in ("idm", "fvdm") for i in range(18, 24)],
        "training_profiles": [profiles[n] for n in TRAINING],
        "validation_profiles": [profiles[n] for n in VALIDATION],
        "response_prior": "same original six measured sources; expanded records supervise payoff only",
        "predictor_input": "scenario coordinates, six historical response vectors, requested risk/event feedback",
        "payoff_input": "same 13 anonymous state/action features; no system parameters or unqueried target labels",
        "budget": BUDGET, "pool": POOL, "seed": SEED, "methods": METHODS,
        "payoff_contexts": PAYOFF_CONTEXTS, "new_physical_measurements": 0,
        "main_sut_protocol_changed": False,
        "algorithm_families": "IDM and FVDM; configurations are not independent algorithm families",
    }
    write_json(RESULTS / "protocol.json", protocol)
    return protocol


def train(history, calibration, source_names):
    path = RESULTS / "payoff_models.pkl"
    if path.exists():
        with path.open("rb") as stream:
            return pickle.load(stream)
    started = time.perf_counter()
    rows, rollouts = [], 0
    for name in TRAINING:
        bank = load_bank(name)
        prediction = historical_predictions(bank["x"], history, source_names)
        learner = ResponseModel(bank["x"], *prediction, calibration)
        remaining = np.ones(len(bank["x"]), dtype=bool)
        tie = np.random.default_rng(SEED).random(len(remaining))
        prefix = []
        for queried in range(max(PAYOFF_CONTEXTS) + 1):
            if queried in PAYOFF_CONTEXTS:
                budget = BUDGET - queried
                candidates, features = proposals(learner, remaining, tie, budget)
                reference, ref_order = continuation_return(
                    learner, remaining, bank["risk"], bank["collision"], tie, budget, candidates[0])
                rollouts += 1
                for candidate, feature in zip(candidates[1:], features[1:]):
                    actual, order = continuation_return(learner, remaining, bank["risk"], bank["collision"],
                                                        tie, budget, candidate)
                    rollouts += 1
                    gain = actual - reference
                    rows.append({"training_task": name, "prior_sources": source_names,
                                 "prefix_indices": prefix.copy(), "queried_prefix": queried,
                                 "remaining_budget": budget, "candidate": candidate,
                                 "reference": candidates[0], "features": feature.tolist(),
                                 "actual_gain": gain.tolist(),
                                 "normalized_gain": (gain / [budget, budget * (budget + 1) / 2]).tolist(),
                                 "reference_order": ref_order, "candidate_order": order})
                write_json(RESULTS / "training_progress.json", {
                    "status": "running", "task": name, "context": queried,
                    "rows": len(rows), "adaptive_rollouts": rollouts})
                print("PAYOFF TRAIN", name, queried, len(rows), flush=True)
            if queried < max(PAYOFF_CONTEXTS):
                index = int(learner.rank(remaining, tie_break=tie)[0])
                learner.observe(index, float(bank["risk"][index]), bool(bank["collision"][index]))
                remaining[index] = False
                prefix.append(index)
    models = fit_models(rows)
    with path.open("wb") as stream:
        pickle.dump(models, stream)
    write_json(RESULTS / "payoff_training.json", {
        "allowed_historical_tasks": TRAINING, "rows": rows,
        "adaptive_rollouts": rollouts, "new_physical_calls": 0,
        "elapsed_s": time.perf_counter() - started,
        "scope": "24 preassigned historical configurations; validation and main target outcomes excluded",
        "uncertainty_scope": "leave-configuration model envelope, not confidence bounds"})
    write_json(RESULTS / "training_progress.json", {
        "status": "complete", "rows": len(rows), "adaptive_rollouts": rollouts})
    return models


def main():
    prepare_protocol()
    source_names = [p.name for p in PROFILES]
    with np.load(HISTORY_ROOT / "history/responses.npz") as history:
        calibration = historical_calibration(history, source_names)
        models = train(history, calibration, source_names)
        context = mp.get_context("spawn")
        parent, child = context.Pipe()
        process = context.Process(target=selector_worker, args=(child,))
        process.start()
        child.close()
        try:
            for name in VALIDATION:
                bank = load_bank(name)
                predictions = (*historical_predictions(bank["x"], history, source_names), calibration)
                for method in METHODS:
                    path = RESULTS / name / f"{method}_{SEED}.json"
                    if path.exists():
                        continue
                    started = time.perf_counter()
                    task = {"method": method, "seed": SEED, "x": bank["x"],
                            "predictions": predictions, "payoff_models": models}
                    result = disclose(parent, task, bank["risk"], bank["collision"])
                    result.update(method=method, seed=SEED, historical_sources=source_names,
                                  payoff_training_systems=TRAINING,
                                  selector_elapsed_s=time.perf_counter() - started)
                    write_json(path, result)
                    write_json(RESULTS / "progress.json", {
                        "status": "running", "latest": str(path.relative_to(RESULTS)), "expected_runs": 36})
                    print("COHORT VALIDATE", name, method, result["F200"], flush=True)
        finally:
            if process.is_alive():
                parent.send(("stop", None))
            parent.close()
            process.join(timeout=10)
            if process.is_alive():
                process.terminate()
                process.join()
            if process.exitcode != 0:
                raise RuntimeError(f"Cohort selector exited {process.exitcode}")
    write_json(RESULTS / "progress.json", {
        "status": "complete", "runs": 36, "disclosures": 7200,
        "new_physical_calls": 0, "significant_advantage_established": False})


if __name__ == "__main__":
    main()
