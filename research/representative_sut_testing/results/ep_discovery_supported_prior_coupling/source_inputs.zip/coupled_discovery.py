"""Couple discovery to an independent adaptive reference using paid feedback."""
import numpy as np
from threadpoolctl import threadpool_limits

from methods.history_guided_testing.experiment import RemoteOracle

from .config import BUDGET, INITIAL_QUERIES
from .response import ResponseModel


METHODS = ("greedy_reference", "event_only_search", "coupled_discovery")


class ReferenceReplay:
    """Replay only the reference prefix whose feedback is already paid for."""
    def __init__(self, model, size, tie_break):
        self.model = model
        self.remaining = np.ones(size, dtype=bool)
        self.tie_break = tie_break
        self.order = []

    def head(self):
        return int(self.model.rank(self.remaining, tie_break=self.tie_break)[0])

    def advance(self, known):
        while self.remaining.any():
            index = self.head()
            if index not in known:
                break
            risk, collision = known[index]
            self.model.observe(index, risk, collision)
            self.remaining[index] = False
            self.order.append(index)

    def certificate(self, known):
        extra = [index for index in known if self.remaining[index]]
        negative = [index for index in extra if not known[index][1]]
        return {"reference_prefix_length": len(self.order), "extra_indices": extra,
                "negative_extra_indices": negative, "negative_extra_count": len(negative),
                "discovery_gain_lower": -len(negative)}


def run_policy(method, reference, candidate, oracle, budget, initial_queries):
    known, selected, observations, checks = {}, [], [], []
    available = np.ones(len(reference.remaining), dtype=bool)
    for step in range(budget):
        reference.advance(known)
        before = reference.certificate(known)
        head = reference.head()
        if (step < initial_queries or method == "greedy_reference"
                or method == "coupled_discovery" and before["negative_extra_count"] > 0):
            index = head
            role = "reference"
        else:
            index = int(candidate.rank(available, tie_break=reference.tie_break)[0])
            role = "alternative" if index != head else "reference"
        if not available[index]:
            raise ValueError("Coupled discovery repeats a paid query")
        observation = oracle.query(index)
        known[index] = (float(observation.risk), bool(observation.collision))
        selected.append(index)
        available[index] = False
        observations.append({"index": index, "risk": known[index][0], "collision": known[index][1],
                             "role": "initialization" if step < initial_queries else role})
        candidate.observe_event(index, known[index][1])
        reference.advance(known)
        check = reference.certificate(known)
        check.update(query=step + 1, chosen_index=index, reference_index=head,
                     scope="whole independent reference curve at this paid budget; no future labels")
        if method == "coupled_discovery" and check["negative_extra_count"] > 1:
            raise ValueError("Coupled policy exceeds one unresolved negative extra")
        checks.append(check)
    return {
        "selected_indices": selected, "queries": observations, "planning_checks": [], "audits": [],
        "coupling_checks": checks, "reference_prefix_indices": reference.order,
        "area_gain_lower": sum(check["discovery_gain_lower"] for check in checks),
        "terminal_gain_lower": checks[-1]["discovery_gain_lower"],
        "alternative_queries": sum(o["role"] == "alternative" for o in observations),
        "max_negative_extra_count": max(check["negative_extra_count"] for check in checks),
        "candidate_response_state": candidate.task_state() if hasattr(candidate, "task_state") else {},
        "reference_response_state": reference.model.task_state() if hasattr(reference.model, "task_state") else {},
        "certificate_scope": "deterministic counts relative to the independent adaptive reference, fixed response bank",
    }


def selector_worker(connection):
    try:
        with threadpool_limits(limits=1):
            while True:
                message, task = connection.recv()
                if message == "stop":
                    return
                if message != "task" or task["method"] not in METHODS:
                    raise ValueError("Invalid coupled discovery task")
                model = ResponseModel(task["x"], *task["predictions"])
                candidate = model.clone()
                tie = np.random.default_rng(task["seed"]).random(len(task["x"]))
                reference = ReferenceReplay(model, len(task["x"]), tie)
                result = run_policy(task["method"], reference, candidate, RemoteOracle(connection),
                                    BUDGET, INITIAL_QUERIES)
                connection.send(("result", result))
    except Exception as error:
        connection.send(("error", repr(error)))
        raise
    finally:
        connection.close()
