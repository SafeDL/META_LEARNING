"""Counterfactual payoff labels include paid queries and adaptive feedback."""
import copy

import numpy as np

from .payoff import continuation_return, fit_models, learned_values, payoff_choice
from .response import ResponseModel


class AdaptiveToy:
    def __init__(self):
        self.learned = False

    def clone(self):
        return copy.deepcopy(self)

    def observe(self, index, risk, collision):
        if risk > 0.5:
            self.learned = True

    def rank(self, remaining, *, tie_break):
        order = [2, 3, 0, 1] if self.learned else [0, 1, 2, 3]
        return np.asarray([index for index in order if remaining[index]])


def test_payoff_compares_equal_paid_budgets_and_adaptive_continuations():
    model = AdaptiveToy()
    remaining = np.ones(4, dtype=bool)
    risk = np.asarray([0., 0.9, 0.9, 0.9])
    collision = np.asarray([False, False, True, True])
    reference, reference_order = continuation_return(model, remaining, risk, collision, np.arange(4), 3, 0)
    candidate, candidate_order = continuation_return(model, remaining, risk, collision, np.arange(4), 3, 1)
    np.testing.assert_array_equal(reference, [1, 1])
    np.testing.assert_array_equal(candidate, [2, 3])
    assert reference_order == [0, 1, 2] and candidate_order == [1, 2, 3]
    assert not model.learned and remaining.all()


def test_response_clone_isolated_from_real_feedback_state():
    x = np.asarray([[0., 0., 0., 0., 0.], [1., 1., 1., 1., 0.]])
    calibration = {"risk_local_variance": [0.01, 0.01], "event_local_variance": [0.04, 0.04],
                   "risk_event_local_covariance": [0., 0.]}
    model = ResponseModel(x, np.full((2, 2), 0.5), np.full((2, 2), 0.5), calibration)
    mean, covariance = model.mean.clone(), model.covariance.clone()
    counterfactual = model.clone()
    counterfactual.observe(0, 0.1, False)
    assert (model.mean == mean).all() and (model.covariance == covariance).all()
    assert model.event_log_loss == 0 and counterfactual.event_log_loss > 0


def test_leave_task_support_models_are_fitted_only_from_supplied_rows():
    rows = []
    for task in ("a", "b", "c"):
        for point in range(8):
            rows.append({"training_task": task, "features": [point / 8, 0.5],
                         "normalized_gain": [0.01, -0.02], "actual_gain": [1, -2]})
    models = fit_models(rows)
    assert len(models["returns"]) == len(models["harm"]) == 4
    mean, lower, harm, margin = learned_values(models, np.asarray([[0.3, 0.5]]))
    np.testing.assert_allclose(mean, [[0.01, -0.02]], atol=1e-12)
    np.testing.assert_allclose(lower, [[0.01, -0.02]], atol=1e-12)
    np.testing.assert_allclose(harm, [1], atol=1e-12)
    np.testing.assert_allclose(margin, [[0.01, -0.02]], atol=1e-12)


def test_positive_mean_payoff_does_not_hide_observed_harm_probability():
    rows = []
    for task in ("a", "b", "c"):
        for i in range(12):
            gain = 3 if i % 2 else -1
            rows.append({"training_task": task, "features": [0.5, 0.5],
                         "normalized_gain": [gain / 100, gain / 100],
                         "actual_gain": [gain, gain]})
    models = fit_models(rows)
    mean, lower, harm, margin = learned_values(models, np.asarray([[0.5, 0.5]]))
    assert min(mean[0]) > 0 and min(lower[0]) > 0
    assert harm[0] > 0.3
    assert min(margin[0]) > 0


def test_sampler_and_deployment_share_the_same_loss_budget_rule():
    class Fixed:
        def __init__(self, values):
            self.values = values

        def predict(self, features):
            return np.tile(self.values, (len(features), 1))

    class NoHarm:
        classes_ = np.asarray([0])

    models = {"returns": [Fixed([1., 1.])] * 3, "harm": [NoHarm()] * 3,
              "benefit": [Fixed([1., 1.])] * 3, "loss": [Fixed([2., 0.])] * 3}
    candidates = [2, 0]
    features = np.zeros((2, 13))
    tie = np.arange(3)
    assert payoff_choice(candidates, features, models, tie, checked=False)[0] == 1
    assert payoff_choice(candidates, features, models, tie, checked=True)[0] == 0
