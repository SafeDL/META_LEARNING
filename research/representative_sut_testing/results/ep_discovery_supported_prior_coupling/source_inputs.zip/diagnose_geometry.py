"""Training-only screening of decision geometry with unchanged payoff labels."""
from collections import defaultdict
import pickle
from zipfile import ZipFile

import numpy as np

from methods.history_guided_testing.config import ROOT as HISTORY_ROOT
from methods.history_guided_testing.io import read_json, write_json

from .calibration import historical_calibration
from .cohort_payoff import RESULTS as BASELINE, SEED, TRAINING, load_bank
from .config import BUDGET, OUTPUT, PROFILES
from .decision_geometry import GEOMETRY_FEATURES, geometry_features
from .payoff import fit_models, proposal_features
from .response import ResponseModel, historical_predictions


RESULTS = OUTPUT / "decision_geometry_development"


def add_geometry(rows):
    grouped = defaultdict(list)
    for row in rows:
        grouped[row["training_task"]].append(row)
    names = [p.name for p in PROFILES]
    augmented = []
    with np.load(HISTORY_ROOT / "history/responses.npz") as history:
        calibration = historical_calibration(history, names)
        for task in TRAINING:
            bank = load_bank(task)
            model = ResponseModel(bank["x"], *historical_predictions(bank["x"], history, names), calibration)
            remaining = np.ones(len(bank["x"]), dtype=bool)
            tie = np.random.default_rng(SEED).random(len(remaining))
            prefix = []
            contexts = sorted({row["queried_prefix"] for row in grouped[task]})
            for context in contexts:
                local = [row for row in grouped[task] if row["queried_prefix"] == context]
                expected = local[0]["prefix_indices"]
                if expected[:len(prefix)] != prefix:
                    raise ValueError("Historical support prefixes are not nested")
                for index in expected[len(prefix):]:
                    model.observe(index, float(bank["risk"][index]), bool(bank["collision"][index]))
                    remaining[index] = False
                    prefix.append(index)
                if any(row["prefix_indices"] != prefix for row in local):
                    raise ValueError("Payoff labels at the same context use different feedback")
                reference = local[0]["reference"]
                if reference != int(model.rank(remaining, tie_break=tie)[0]):
                    raise ValueError("Replayed state has a different greedy reference")
                budget = BUDGET - context
                candidates = [row["candidate"] for row in local]
                base_features = np.asarray([row["features"] for row in local])
                gains = base_features[:, :2] * [budget, budget * (budget + 1) / 2]
                replayed = proposal_features(model, candidates, gains, reference, remaining, budget)
                if not np.allclose(replayed, base_features, rtol=0, atol=1e-9):
                    raise ValueError("Replayed state differs from the original pre-query features")
                geometry = geometry_features(model, candidates, reference, remaining, tie, budget)
                for row, feature in zip(local, geometry):
                    augmented.append({**row, "base_features": row["features"],
                                      "geometry_features": feature.tolist(),
                                      "features": row["features"] + feature.tolist()})
            write_json(RESULTS / "progress.json", {
                "status": "running", "task": task, "rows": len(augmented),
                "scope": "replay training prefixes only; no target validation outcomes"})
            print("GEOMETRY FEATURES", task, len(augmented), flush=True)
    return augmented


def leave_task_diagnostic(rows, models, feature_key):
    tasks = sorted({row["training_task"] for row in rows})
    x = np.asarray([row[feature_key] for row in rows])
    actual = np.asarray([row["normalized_gain"] for row in rows])
    prediction, margin = np.empty_like(actual), np.empty_like(actual)
    for position, task in enumerate(tasks, 1):
        mask = np.asarray([row["training_task"] == task for row in rows])
        prediction[mask] = models["returns"][position].predict(x[mask])
        margin[mask] = (models["benefit"][position].predict(x[mask])
                        - models["loss"][position].predict(x[mask]))
    groups = defaultdict(list)
    for position, row in enumerate(rows):
        groups[(row["training_task"], row["queried_prefix"])].append(position)
    choices = []
    for (task, context), indices in groups.items():
        eligible = [i for i in indices if np.all(prediction[i] >= 0) and np.all(margin[i] >= 0)
                    and tuple(prediction[i]) > (0., 0.)]
        if eligible:
            chosen = max(eligible, key=lambda i: tuple(prediction[i]))
            choices.append({"task": task, "context": context, "corrected": True,
                            "candidate": rows[chosen]["candidate"],
                            "gain": rows[chosen]["actual_gain"]})
        else:
            choices.append({"task": task, "context": context, "corrected": False, "gain": [0, 0]})
    changed = [choice for choice in choices if choice["corrected"]]
    harms = sum(min(choice["gain"]) < 0 for choice in changed)
    return {
        "normalized_gain_rmse": np.sqrt(np.mean((prediction - actual) ** 2, axis=0)).tolist(),
        "normalized_gain_r2": (1 - np.sum((prediction - actual) ** 2, axis=0)
                               / np.sum((actual - actual.mean(axis=0)) ** 2, axis=0)).tolist(),
        "states": len(choices), "corrections": len(changed), "harmful_corrections": harms,
        "harmful_fraction": harms / len(changed) if changed else 0,
        "mean_actual_gain": np.mean([choice["gain"] for choice in choices], axis=0).tolist(),
        "choices": choices,
        "predictions": [{"task": row["training_task"], "context": row["queried_prefix"],
                         "candidate": row["candidate"], "prediction": estimate.tolist(),
                         "actual": row["normalized_gain"]} for row, estimate in zip(rows, prediction)],
    }


def main():
    protocol = {
        "stage": "training-only geometry screening; not validation or confirmation",
        "training_systems": TRAINING, "validation_outcomes_used": False,
        "label_source": str(BASELINE / "payoff_training.json"),
        "response_prior": "unchanged original six sources and covariance calibration",
        "changed": "append twelve directional pre-query features; same forests and actual labels",
        "geometry_feature_names": GEOMETRY_FEATURES,
        "contrasts": "current candidate/reference, next head pair, remaining-budget membership boundary",
        "scaling": "current event marginal deviations; fixed locally for contrast information",
        "risk_information": "exact Gaussian contrast variance reduction",
        "event_information": "three-node untruncated Gaussian quadrature after risk conditioning",
        "gate": "both whole-task LOO R2 positive, both actual mean gains improve, harmful fraction does not increase",
        "budget": BUDGET, "seed": SEED, "new_physical_calls": 0,
    }
    write_json(RESULTS / "protocol.json", protocol)
    snapshot = RESULTS / "source_inputs.zip"
    if not snapshot.exists():
        with ZipFile(snapshot, "w") as archive:
            for path in sorted(OUTPUT.parent.glob("*.py")):
                archive.write(path, path.name)
    with ZipFile(snapshot) as archive:
        for name in archive.namelist():
            if archive.read(name) != (OUTPUT.parent / name).read_bytes():
                raise ValueError("Geometry screening source changed after freezing")
    data_path = RESULTS / "payoff_training.json"
    if data_path.exists():
        rows = read_json(data_path)["rows"]
    else:
        original = read_json(BASELINE / "payoff_training.json")
        rows = add_geometry(original["rows"])
        write_json(data_path, {"rows": rows, "training_systems": TRAINING,
                              "new_counterfactual_rollouts": 0, "new_physical_calls": 0})
    with (BASELINE / "payoff_models.pkl").open("rb") as stream:
        baseline_models = pickle.load(stream)
    models = fit_models(rows)
    with (RESULTS / "payoff_models.pkl").open("wb") as stream:
        pickle.dump(models, stream)
    baseline = leave_task_diagnostic(rows, baseline_models, "base_features")
    geometry = leave_task_diagnostic(rows, models, "features")
    passed = (min(geometry["normalized_gain_r2"]) > 0
              and all(a > b for a, b in zip(geometry["mean_actual_gain"], baseline["mean_actual_gain"]))
              and geometry["harmful_fraction"] <= baseline["harmful_fraction"])
    write_json(RESULTS / "summary.json", {
        "baseline": baseline, "geometry": geometry, "gate_passed": passed,
        "significant_advantage_established": False,
        "scope": "whole-training-configuration LOO diagnostics; not deployed adaptive policy performance"})
    lines = ["# 决策方向信息的训练内筛查", "",
             "固定 24 个训练配置、222 条原收益标签、72 个已查询支持状态。仅重放前缀，未读取验证结果，未新增反事实延续或物理仿真。",
             "原 13 项特征追加 12 项方向特征；模型规模、任务等权和整配置留出方式不变。", "",
             "| 特征 | 终点 R² | 早期 R² | 状态纠正数 | 有害纠正数 | 平均实际终点差 | 平均实际面积差 |",
             "|---|---:|---:|---:|---:|---:|---:|"]
    for name, result in (("原汇总特征", baseline), ("加入决策方向", geometry)):
        lines.append(f"| {name} | {result['normalized_gain_r2'][0]:.3f} | {result['normalized_gain_r2'][1]:.3f} | "
                     f"{result['corrections']} | {result['harmful_corrections']} | "
                     f"{result['mean_actual_gain'][0]:.3f} | {result['mean_actual_gain'][1]:.3f} |")
    lines += ["", "通过预先登记的筛查条件，可进入有限验证。" if passed else "未通过筛查条件，不进入新的验证实验。",
              "这里单次状态选择后延续同一贪心参照，收益来自原历史实测；整配置留出模型不等于部署时全部模型包络。",
              "方向信息采用当前事件标准差固定缩放；风险信息为工作高斯恒等式，联合信息含有限积分近似，不是真实收益或校准保证。"]
    (RESULTS / "report.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    write_json(RESULTS / "progress.json", {"status": "complete", "rows": len(rows),
                                         "gate_passed": passed, "new_physical_calls": 0})
    print({"baseline_r2": baseline["normalized_gain_r2"], "geometry_r2": geometry["normalized_gain_r2"],
           "gate_passed": passed}, flush=True)


if __name__ == "__main__":
    main()
