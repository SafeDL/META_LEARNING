"""Source exclusion and empirical covariance validity, including negative dependence."""
import numpy as np

from .calibration import historical_calibration


def test_coordinate_calibration_excludes_disallowed_target_values():
    class SourceBank(dict):
        def __getitem__(self, key):
            assert not key.startswith("held_target")
            return super().__getitem__(key)

    rng = np.random.default_rng(43)
    x = np.column_stack((rng.random((24, 4)), np.repeat([0, 1], 12)))
    bank = SourceBank(x=x, source_a=np.full(24, 0.2), source_b=np.full(24, 0.7),
                      source_a_collision=np.zeros(24), source_b_collision=np.ones(24),
                      held_target=np.arange(24), held_target_collision=np.arange(24))
    calibration = historical_calibration(bank, ["source_a", "source_b"])
    np.testing.assert_allclose(calibration["risk_local_variance"], 0, atol=1e-30)
    np.testing.assert_allclose(calibration["event_local_variance"], 0, atol=1e-20)
