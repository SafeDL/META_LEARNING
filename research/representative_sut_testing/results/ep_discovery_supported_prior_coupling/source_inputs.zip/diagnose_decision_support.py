"""Check decision support using only reconstructed paid online-prior prefixes."""
from zipfile import ZipFile

import numpy as np
from threadpoolctl import threadpool_limits
import torch

from methods.history_guided_testing.history import historical_risk, load_history, split_indices, subset
from methods.history_guided_testing.io import read_json, write_json
from methods.history_guided_testing.search import TestingSession

from .adaptive_margin_prior import AdaptiveMarginPrior
from .censored_margin_response import historical_margin_prior
from .config import BUDGET, INITIAL_QUERIES, OUTPUT, POOL_SEEDS, SUT_IDS
from .decision_support import SUPPORT_THRESHOLD, discovery_loss_support, ordering_support
from .frozen_coupling import FrozenReplay


SOURCE = OUTPUT / "adaptive_margin_prior_coupling"
RESULTS = OUTPUT / "discovery_equivalence_diagnostic"


def main():
    with ZipFile(SOURCE / "source_inputs.zip") as archive:
        for name in ("adaptive_margin_prior.py", "censored_margin_response.py", "frozen_coupling.py"):
            if archive.read(name) != (OUTPUT.parent / name).read_bytes():
                raise ValueError("Decision support diagnosis requires the archived online prior implementation")
    RESULTS.mkdir(parents=True, exist_ok=True)
    with ZipFile(RESULTS / "source_inputs.zip", "w") as archive:
        for path in sorted(OUTPUT.parent.glob("*.py")):
            archive.write(path, path.name)
    history = load_history()
    train, _ = split_indices(next(iter(history.values()))["x"])
    allowed = subset(history, train)
    rows = []
    torch.set_num_threads(1)
    with threadpool_limits(limits=1):
        for pool in range(len(POOL_SEEDS)):
            with np.load(OUTPUT / f"pool_{pool}" / SUT_IDS[0] / "responses.npz") as bank:
                x = bank["x"].copy()
            risk_prior, margin = historical_risk(allowed, x), historical_margin_prior(x)
            for sut in SUT_IDS:
                run = read_json(SOURCE / f"pool_{pool}" / sut / "online_prior_average_11.json")
                reference = FrozenReplay(TestingSession(x, 11, mode="global_feedback", prior=risk_prior))
                model = AdaptiveMarginPrior(reference, x[:, 4], margin, freeze_after_initialization=False)
                tie = np.random.default_rng(11).random(len(x))
                remaining = np.ones(len(x), dtype=bool)
                known, found, records = {}, 0, []
                for t, observation in enumerate(run["queries"]):
                    reference.advance(known)
                    head = int(reference.head())
                    scheduled = t >= INITIAL_QUERIES and (t - INITIAL_QUERIES) % 2 == 0
                    debt = reference.certificate(known)["negative_extra_count"]
                    allowed_probe = bool(debt + 1 <= 1 + found / np.sqrt(BUDGET) + 1e-12)
                    proposed = head if t < INITIAL_QUERIES else int(model.rank(remaining, tie_break=tie)[0])
                    planned = head if t < INITIAL_QUERIES or scheduled or not allowed_probe else proposed
                    if planned != observation["index"]:
                        raise ValueError("Support replay changes the actual online-prior query")
                    if t >= INITIAL_QUERIES:
                        support = ordering_support(model, proposed, head)
                        binary = discovery_loss_support(model, proposed, head) if proposed != head else None
                        support.update(query=t + 1, scheduled_reference=scheduled, probe_credit_available=allowed_probe,
                                       eligible_to_skip_reference=scheduled and allowed_probe and support["supported"],
                                       binary_loss_support=binary,
                                       eligible_binary_reference_skip=bool(scheduled and allowed_probe and binary is not None and binary["supported"]))
                        records.append(support)
                    index = observation["index"]
                    model.observe(index, observation["risk"], observation["collision"])
                    remaining[index] = False
                    known[index] = observation["risk"], observation["collision"]
                    found += int(observation["collision"])
                    reference.advance(known)
                if reference.order != run["reference_prefix_indices"]:
                    raise ValueError("Support replay changes the independent reference")
                row = {"pool": pool, "sut_id": sut, "states": len(records),
                       "nonreference_proposals": sum(r["proposed_index"] != r["reference_index"] for r in records),
                       "supported_nonreference": sum(r["supported"] for r in records),
                       "eligible_reference_skips": sum(r["eligible_to_skip_reference"] for r in records)}
                row["eligible_binary_reference_skips"] = sum(r["eligible_binary_reference_skip"] for r in records)
                rows.append(row)
                write_json(RESULTS / f"pool_{pool}" / f"{sut}.json", {"summary": row, "records": records})
                print("DECISION SUPPORT", pool, sut, row, flush=True)
    summary = {"rows": rows, "paths": 12, "states": sum(r["states"] for r in rows),
               "eligible_reference_skips": sum(r["eligible_reference_skips"] for r in rows),
               "eligible_binary_reference_skips": sum(r["eligible_binary_reference_skips"] for r in rows),
               "threshold": float(SUPPORT_THRESHOLD), "threshold_design": "1-1/sqrt(B), B locked at 200; no target threshold search",
               "scope": "working ADF propensity-order diagnostic, no future target labels read and no new strategy curve",
               "new_physical_calls": 0, "significant_advantage_established": False}
    write_json(RESULTS / "summary.json", summary)
    write_json(RESULTS / "progress.json", {"status": "complete", "paths": 12, "states": summary["states"], "new_physical_calls": 0})
    print(summary["eligible_reference_skips"], flush=True)


if __name__ == "__main__":
    main()
