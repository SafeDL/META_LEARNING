"""Identify decision-equivalent risk thresholds from paid risk/event pairs."""
import numpy as np
from scipy.special import ndtr

from methods.history_guided_testing.gp import RiskGP


class ThresholdResponse:
    def __init__(self, reference, family):
        original = reference.session.gp
        self.gp = RiskGP(original.covariance, original.mean, noise=original.noise)
        self.reference = reference
        self.family = np.asarray(family, dtype=int)
        self.lower = np.zeros(2)
        self.upper = np.ones(2)
        self.positive = np.zeros(2, dtype=int)
        self.negative = np.zeros(2, dtype=int)
        self.records = []
        self.checks = []

    def consistent(self, group):
        return self.positive[group] == 0 or self.lower[group] < self.upper[group]

    def rank(self, remaining, *, tie_break):
        head = self.reference.head()
        reference_group = self.family[head]
        indices = np.flatnonzero(remaining)
        scores = np.full(len(indices), -np.inf)
        if self.consistent(reference_group):
            mean = self.gp.mean
            deviation = np.sqrt(self.gp.variance + self.gp.noise)
            for group in (0, 1):
                local = np.flatnonzero(self.family[indices] == group)
                if not self.consistent(group) or not self.positive[group]:
                    continue
                queries = indices[local]
                if group == reference_group:
                    # Standardized-score differences are affine in threshold.
                    at_lower = ((mean[queries] - self.lower[group]) / deviation[queries]
                                - (mean[head] - self.lower[group]) / deviation[head])
                    at_upper = ((mean[queries] - self.upper[group]) / deviation[queries]
                                - (mean[head] - self.upper[group]) / deviation[head])
                    supported = (at_lower >= 0) & (at_upper >= 0)
                    lower_gain = (ndtr((mean[queries] - self.lower[group]) / deviation[queries])
                                  - ndtr((mean[head] - self.lower[group]) / deviation[head]))
                    upper_gain = (ndtr((mean[queries] - self.upper[group]) / deviation[queries])
                                  - ndtr((mean[head] - self.upper[group]) / deviation[head]))
                    scores[local[supported]] = np.minimum(lower_gain[supported], upper_gain[supported])
                else:
                    worst = ndtr((mean[queries] - self.upper[group]) / deviation[queries])
                    best_reference = (ndtr((mean[head] - self.lower[reference_group]) / deviation[head])
                                      if self.lower[reference_group] < 1 else 0.)
                    scores[local] = worst - best_reference
        order = np.lexsort((tie_break[indices], -scores))
        position = int(order[0])
        chosen = int(indices[position]) if scores[position] > 1e-12 else int(head)
        self.checks.append({"query": len(self.records) + 1, "reference_index": int(head), "chosen_index": chosen,
                            "worst_model_probability_gain": float(scores[position]) if np.isfinite(scores[position]) else None,
                            "lower": self.lower.tolist(), "upper": self.upper.tolist(),
                            "positive_counts": self.positive.tolist(),
                            "candidate_family": int(self.family[chosen]), "reference_family": int(reference_group),
                            "candidate_predictive_risk": [float(self.gp.mean[chosen]), float(np.sqrt(self.gp.variance[chosen] + self.gp.noise))],
                            "reference_predictive_risk": [float(self.gp.mean[head]), float(np.sqrt(self.gp.variance[head] + self.gp.noise))],
                            "reference_group_consistent": bool(self.consistent(reference_group)),
                            "scope": "decision agreement under predictive risk and compatible thresholds; not a true event-probability bound"})
        return np.asarray([chosen])

    def observe(self, index, risk, collision):
        group = self.family[index]
        self.gp.observe(index, risk)
        if collision:
            self.upper[group] = min(self.upper[group], risk)
            self.positive[group] += 1
        else:
            self.lower[group] = max(self.lower[group], risk)
            self.negative[group] += 1
        self.records.append({"index": int(index), "risk": float(risk), "collision": bool(collision),
                             "family": int(group), "lower": self.lower.tolist(), "upper": self.upper.tolist(),
                             "consistent": [bool(self.consistent(g)) for g in (0, 1)]})

    def diagnostics(self):
        return {"threshold_records": self.records, "decision_support_checks": self.checks,
                "threshold_lower": self.lower.tolist(), "threshold_upper": self.upper.tolist(),
                "threshold_consistent": [bool(self.consistent(g)) for g in (0, 1)],
                "threshold_scope": "C=1{R>theta_family} is a working hypothesis; empty sets trigger reference"}
