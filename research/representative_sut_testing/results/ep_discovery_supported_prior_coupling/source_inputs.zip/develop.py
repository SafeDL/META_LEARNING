"""Source-held-out development; full target labels stay in the evaluator."""
import multiprocessing as mp
import time

import numpy as np

from methods.history_guided_testing.config import ROOT as HISTORY_ROOT
from methods.history_guided_testing.io import read_json, write_json

from .config import BUDGET, CHECKPOINTS, DEVELOPMENT, DEVELOPMENT_SEEDS, PROFILES
from .calibration import historical_calibration
from .response import historical_predictions
from .payoff import train_payoff
from .selector import METHODS, selector_worker


def metrics(collisions, selected):
    positives = int(np.count_nonzero(collisions))
    found = np.cumsum(np.asarray(collisions)[selected])
    upper = np.minimum(np.arange(1, BUDGET + 1), positives)
    return {
        "total_collisions": positives,
        "area_200": float(found.sum() / (BUDGET * positives)) if positives else None,
        "recall_200": float(found[-1] / positives) if positives else None,
        "F200": int(found[-1]), "missed": positives - int(found[-1]),
        "checkpoints": {str(t): int(found[t - 1]) for t in CHECKPOINTS},
        "terminal_ceiling_attainment": float(found[-1] / upper[-1]) if positives else None,
        "area_ceiling": float(upper.sum() / (BUDGET * positives)) if positives else None,
        "curve": found.astype(int).tolist(),
    }


def disclose(connection, task, risk, collision):
    connection.send(("task", task))
    selected, observations = [], []
    while True:
        message, value = connection.recv()
        if message == "query":
            index = int(value)
            if index not in range(len(risk)) or index in selected or len(selected) >= BUDGET:
                raise ValueError("Invalid, duplicate or over-budget disclosure")
            selected.append(index)
            pair = (float(risk[index]), bool(collision[index]))
            observations.append({"index": index, "risk": pair[0], "collision": pair[1]})
            connection.send(pair)
        elif message == "result":
            if value["selected_indices"] != selected or len(selected) != BUDGET:
                raise ValueError("Result differs from the actual disclosure order")
            for reported, actual in zip(value["queries"], observations):
                if any(reported[key] != actual[key] for key in actual):
                    raise ValueError("Selector observation record differs from disclosures")
            for check in value["planning_checks"]:
                if selected[check["start_query"] - 1] != check["chosen_index"]:
                    raise ValueError("Planning record differs from actual query")
                gain = np.asarray(check["chosen_values"]) - check["reference_values"]
                if not np.allclose(gain, check["predicted_gain"], rtol=0, atol=1e-12):
                    raise ValueError("Planning gain differs from its saved values")
                if check["screen_applied"] and np.any(gain < -1e-10):
                    raise ValueError("Checked action violates the declared model-value screen")
                if check["screen_applied"] and min(check["support_lower"]) < -1e-12:
                    raise ValueError("Chosen correction lacks the declared historical subset support")
                if check["screen_applied"] and min(check["loss_budget_margin"]) < -1e-12:
                    raise ValueError("Chosen correction exceeds the declared modeled loss budget")
            for certificate in value["audits"]:
                start = certificate["start_query"] - 1
                end = start + certificate["comparison_budget"]
                executed = selected[start:end]
                if executed != certificate["executed_order"]:
                    raise ValueError("Certified local continuation differs from executed queries")
                if certificate["accepted"]:
                    reference_curve = np.cumsum(collision[certificate["reference"]])
                    executed_curve = np.cumsum(collision[executed])
                    gain = np.asarray([executed_curve[-1] - reference_curve[-1],
                                       executed_curve.sum() - reference_curve.sum()])
                    if np.any(gain < certificate["executable_gain_lower"]) or gain.sum() < certificate["strict_gain_lower"]:
                        raise ValueError("Local certificate contradicts actual full-pool event labels")
                    certificate["evaluated_actual_gain"] = gain.astype(int).tolist()
            return {**value, **metrics(collision, selected), "disclosures": observations}
        else:
            raise RuntimeError(value)


def main():
    names = [profile.name for profile in PROFILES]
    context = mp.get_context("spawn")
    parent, child = context.Pipe()
    process = context.Process(target=selector_worker, args=(child,))
    process.start()
    child.close()
    folder = DEVELOPMENT
    write_json(folder / "protocol.json", {
        "stage": "development; all historical systems are already public",
        "held_out": names, "historical_sources": "all original sources except the held-out source",
        "methods": METHODS, "seeds": DEVELOPMENT_SEEDS, "budget": BUDGET,
        "repetition_scope": "first-seed historical screening; main representative-SUT evaluation retains five seeds",
        "target_identity_provided_to_selector": False,
        "physical_target_calls": 0, "target_arrays_in_selector_process": False,
        "feedback": "queried risk and collision, identical for all mechanism controls",
        "initialization": "ten sequential greedy shared-response posterior queries",
        "audit": "post-query immediate comparison is descriptive, not a certificate for planned future",
        "reference": "same joint-response posterior, greedy event probability with feedback after every query",
        "ablation": "same learned payoff models and proposals; no leave-task support screen",
        "payoff_learning": "allowed historical tasks only; each internal task excluded from its response prior; candidate query then adaptive greedy to budget 200",
        "state_aggregation": "one allowed-history pass under correction policy; task's own payoff labels excluded from sampler",
        "proposal": "greedy top three plus two working-model branch heads",
        "planning": "predict correction payoff against adaptive greedy from historical counterfactual continuations",
        "support": "nonnegative return agreement; minimum fitted benefit covers maximum fitted loss on both objectives; not a confidence bound",
        "harm_learning": "either actual terminal or area difference below zero is a harmful historical correction",
        "branch_consistency": "largest affine contrast retention preserving pre-query event marginals and probability range",
        "commitment": "one query, then update response and replan; all queries count toward 200",
        "planning_limit": "no separate cap; computation consumes no simulated target queries",
        "fixed_settings": {"physical_kernel_lengthscale": 0.2,
                           "risk_observation": "deterministic exact conditioning; variance division floor 1e-12",
                           "historical_neighbors": 8,
                           "covariance": "shared response modes plus local two-channel covariance from coordinate-LOO; positive unexplained event residual",
                           "event_marginals": "clipped average historical event probability; unit latent event variance",
                           "calibration": "only allowed source labels; separate functional families; no held-out target outcomes",
                           "residual": "local joint error covariance plus positive diagonal floor, permitting different event outcomes at the same risk",
                           "task_state": "anonymous centered source-response coefficients; no fixed source weight or controller parameters",
                           "event_update": "Gaussian sign-constraint moments followed by ADF projection"},
    })
    try:
        with np.load(HISTORY_ROOT / "history/responses.npz") as bank:
            for target in names:
                allowed = [name for name in names if name != target]
                calibration = historical_calibration(bank, allowed)
                predictions = (*historical_predictions(bank["x"], bank, allowed), calibration)
                payoff_models = train_payoff(bank, allowed, folder / target)
                write_json(folder / target / "calibration.json", {
                    "historical_sources": allowed, **calibration,
                    "scope": "same-source coordinate leave-one-out, target source excluded",
                })
                for seed in DEVELOPMENT_SEEDS:
                    for method in METHODS:
                        path = folder / target / f"{method}_{seed}.json"
                        if path.exists():
                            continue
                        started = time.perf_counter()
                        # No held-out response or SUT name enters the process payload.
                        task = {"method": method, "seed": seed, "x": bank["x"],
                                "predictions": predictions, "payoff_models": payoff_models}
                        result = disclose(parent, task, bank[target], bank[target + "_collision"])
                        result.update(method=method, seed=seed, historical_sources=allowed,
                                      selector_elapsed_s=time.perf_counter() - started)
                        write_json(path, result)
                        write_json(folder / "progress.json", {
                            "status": "running", "latest": str(path.relative_to(folder)),
                            "expected_runs": len(names) * len(DEVELOPMENT_SEEDS) * len(METHODS),
                        })
                        print("DEVELOP", target, seed, method, result["F200"],
                                  "changed_reference", result["audit_query_count"], flush=True)
        write_json(folder / "progress.json", {
            "status": "complete", "runs": len(names) * len(DEVELOPMENT_SEEDS) * len(METHODS),
            "disclosures": len(names) * len(DEVELOPMENT_SEEDS) * len(METHODS) * BUDGET,
            "new_physical_calls": 0,
        })
    finally:
        if process.is_alive():
            parent.send(("stop", None))
        parent.close()
        process.join(timeout=10)
        if process.is_alive():
            process.terminate()
            process.join()
        if process.exitcode != 0:
            raise RuntimeError(f"Selector exited with code {process.exitcode}")


if __name__ == "__main__":
    main()
