"""Prequential evidence selects between risk-informed and event-only responses."""
import math

import numpy as np


class ModularResponse:
    def __init__(self, model):
        self.with_risk = model
        self.event_only = model.clone()
        self.log_weights = np.full(2, -math.log(2))
        self.expert_losses = np.zeros(2)
        self.mixture_loss = 0.
        self.records = []

    def weights(self):
        weights = np.exp(self.log_weights - self.log_weights.max())
        return weights / weights.sum()

    def rank(self, remaining, *, tie_break):
        weights = self.weights()
        probability = (weights[0] * self.with_risk.event_probabilities().cpu().numpy()
                       + weights[1] * self.event_only.event_probabilities().cpu().numpy())
        risk = (weights[0] * self.with_risk.mean[self.with_risk.risk_indices].cpu().numpy()
                + weights[1] * self.event_only.mean[self.event_only.risk_indices].cpu().numpy())
        indices = np.flatnonzero(remaining)
        order = np.lexsort((tie_break[indices], -risk[indices], -np.round(probability[indices], 12)))
        return indices[order]

    def observe(self, index, risk, collision):
        before = self.weights()
        probability = np.asarray([float(self.with_risk.event_probabilities()[index]),
                                  float(self.event_only.event_probabilities()[index])])
        likelihood = probability if collision else 1 - probability
        mixture = float(before @ likelihood)
        self.expert_losses -= np.log(likelihood)
        self.mixture_loss -= math.log(mixture)
        self.log_weights += np.log(likelihood)
        self.records.append({"index": int(index), "weights_before_query": before.tolist(),
                             "event_probabilities_before_risk": probability.tolist(),
                             "collision": bool(collision), "weights_after_query": self.weights().tolist()})
        self.with_risk.observe(index, risk, collision)
        self.event_only.observe_event(index, collision)

    def diagnostics(self):
        regret = float(self.mixture_loss - self.expert_losses.min())
        if regret > math.log(2) + 1e-10:
            raise ValueError("Prequential mixture violates its two-expert log-loss bound")
        return {"module_records": self.records, "module_weights": self.weights().tolist(),
                "expert_log_losses": self.expert_losses.tolist(), "mixture_log_loss": self.mixture_loss,
                "predictive_regret": regret, "predictive_regret_upper": math.log(2),
                "predictive_scope": "same actually queried sequence; not standalone policy discovery regret"}
