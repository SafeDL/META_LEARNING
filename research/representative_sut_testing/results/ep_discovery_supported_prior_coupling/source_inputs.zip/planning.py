"""Remaining-budget values from risk and event response branches."""
import numpy as np
import torch


@torch.no_grad()
def action_values(probability, weights, predictions, budget):
    values = torch.stack((probability, budget * probability), dim=1)
    if budget == 1:
        return values
    area_weights = torch.arange(budget - 1, 0, -1, dtype=probability.dtype,
                                device=probability.device)
    for branch in range(weights.shape[1]):
        future = predictions[:, branch, :].clone()
        future.fill_diagonal_(-torch.inf)
        best = torch.topk(future, budget - 1, dim=1, sorted=True).values
        values[:, 0] += weights[:, branch] * best.sum(dim=1)
        values[:, 1] += weights[:, branch] * (best @ area_weights)
    return values


def choose_action(values, reference, tie_break, *, checked):
    gains = values - values[reference]
    eligible = np.all(gains >= -1e-10, axis=1) if checked else np.ones(len(values), dtype=bool)
    indices = np.flatnonzero(eligible)
    order = np.lexsort((tie_break[indices], -np.round(values[indices, 1], 12),
                        -np.round(values[indices, 0], 12)))
    chosen = int(indices[order[0]])
    if np.all(np.abs(gains[chosen]) <= 1e-10):
        chosen = reference
    return chosen
