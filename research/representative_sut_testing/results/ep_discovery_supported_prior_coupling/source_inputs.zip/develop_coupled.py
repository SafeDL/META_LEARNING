"""Bounded development of full-curve reference coupling on reused records."""
import multiprocessing as mp
import time
from zipfile import ZipFile

import numpy as np

from methods.history_guided_testing.config import ROOT as HISTORY_ROOT
from methods.history_guided_testing.io import read_json, write_json

from .calibration import historical_calibration
from .cohort_payoff import SEED, TRAINING, VALIDATION, load_bank
from .config import OUTPUT, PROFILES
from .coupled_discovery import METHODS, selector_worker
from .develop import disclose
from .response import historical_predictions


RESULTS = OUTPUT / "coupled_discovery_development"


def summarize_phase(names, phase):
    rows = []
    for name in names:
        runs = {method: read_json(RESULTS / phase / name / f"{method}_{SEED}.json") for method in METHODS}
        reference = runs["greedy_reference"]
        initial = reference["selected_indices"][:10]
        bank = load_bank(name)
        for method, run in runs.items():
            if run["selected_indices"][:10] != initial:
                raise ValueError("Coupled mechanism controls differ in initialization")
            if len(run["coupling_checks"]) != 200:
                raise ValueError("Missing full-curve coupling checks")
            prefix = run["reference_prefix_indices"]
            if prefix != reference["selected_indices"][:len(prefix)]:
                raise ValueError("Independent replay differs from actual standalone reference")
            gain = np.asarray(run["curve"]) - reference["curve"]
            bounds = []
            for t, check in enumerate(run["coupling_checks"], 1):
                k = check["reference_prefix_length"]
                if not 0 <= k <= t:
                    raise ValueError("Reference replay received unpaid future results")
                expected = [index for index in run["selected_indices"][:t] if index not in prefix[:k]]
                negative = [index for index in expected if not bank["collision"][index]]
                if (expected != check["extra_indices"] or negative != check["negative_extra_indices"]
                        or len(negative) != check["negative_extra_count"]
                        or check["discovery_gain_lower"] != -len(negative)):
                    raise ValueError("Coupling certificate differs from already paid feedback")
                if gain[t - 1] < check["discovery_gain_lower"]:
                    raise ValueError("Full discovery curve violates the declared reference bound")
                bounds.append(check["discovery_gain_lower"])
            if (run["terminal_gain_lower"] != bounds[-1] or run["area_gain_lower"] != sum(bounds)
                    or gain[-1] < bounds[-1] or gain.sum() < sum(bounds)):
                raise ValueError("Terminal or cumulative-area coupling bound is invalid")
            if method == "coupled_discovery" and min(bounds) < -1:
                raise ValueError("Coupled curve exceeds one unresolved negative extra")
            rows.append({"target": name, "method": method,
                         "area_pct": 100 * run["area_200"], "recall_pct": 100 * run["recall_200"],
                         "F200": run["F200"], "alternative_queries": run["alternative_queries"],
                         "selector_elapsed_s": run["selector_elapsed_s"],
                         "minimum_pointwise_gain": int(gain.min()),
                         "terminal_gain_lower": bounds[-1], "area_gain_lower": sum(bounds)})
    keys = ("area_pct", "recall_pct", "F200", "alternative_queries", "selector_elapsed_s")
    aggregate = {method: {key: float(np.mean([r[key] for r in rows if r["method"] == method]))
                          for key in keys} for method in METHODS}
    full = aggregate["coupled_discovery"]
    changes = {method: {"area_pp": full["area_pct"] - aggregate[method]["area_pct"],
                        "recall_pp": full["recall_pct"] - aggregate[method]["recall_pct"]}
               for method in METHODS[:-1]}
    passed = all(value["area_pp"] > 0 and value["recall_pp"] > 0 for value in changes.values())
    return {"rows": rows, "aggregate": aggregate, "candidate_changes": changes,
            "gate_passed": passed, "audited_runs": len(rows), "audited_disclosures": len(rows) * 200,
            "full_curve_bounds_verified": True, "significant_advantage_established": False}


def evaluate_phase(connection, names, phase, history, calibration):
    names_source = [p.name for p in PROFILES]
    for name in names:
        bank = load_bank(name)
        predictions = (*historical_predictions(bank["x"], history, names_source), calibration)
        for method in METHODS:
            path = RESULTS / phase / name / f"{method}_{SEED}.json"
            if path.exists():
                continue
            started = time.perf_counter()
            task = {"method": method, "seed": SEED, "x": bank["x"], "predictions": predictions}
            run = disclose(connection, task, bank["risk"], bank["collision"])
            run.update(method=method, seed=SEED, historical_sources=names_source,
                       selector_elapsed_s=time.perf_counter() - started)
            write_json(path, run)
            write_json(RESULTS / "progress.json", {"status": "running", "phase": phase,
                                                  "latest": str(path.relative_to(RESULTS))})
            print("COUPLED", phase, name, method, run["F200"], flush=True)
    return summarize_phase(names, phase)


def main():
    write_json(RESULTS / "protocol.json", {
        "stage": "public configuration development, not blind confirmation",
        "training_configurations": TRAINING, "conditional_validation_configurations": VALIDATION,
        "methods": METHODS, "budget": 200, "initial_queries": 10, "pool": 0, "seed": SEED,
        "feedback": "same queried risk and event for all methods; no full target arrays in selector",
        "reference": "independent joint-response greedy policy using both risk and event",
        "alternative": "same prior; greedy event-only updates to avoid requiring a learned payoff",
        "coupling": "reference updates only its own paid/replayed prefix; candidate uses actual paid events",
        "fallback": "one unresolved negative extra triggers reference until replay resolves it",
        "full_curve_bound": "F_actual(t)-F_reference(t)>=-negative_extras(t)>=-1 for all paid prefixes",
        "area_bound": "sum_t[F_actual(t)-F_reference(t)]>=-sum_t negative_extras(t)",
        "gate": "positive mean Area and Recall relative to both reference and uncoupled alternative",
        "new_physical_calls": 0, "new_gain_regression": False,
    })
    snapshot = RESULTS / "source_inputs.zip"
    if not snapshot.exists():
        with ZipFile(snapshot, "w") as archive:
            for path in sorted(OUTPUT.parent.glob("*.py")):
                archive.write(path, path.name)
    with ZipFile(snapshot) as archive:
        for name in archive.namelist():
            if archive.read(name) != (OUTPUT.parent / name).read_bytes():
                raise ValueError("Coupled discovery source changed after freezing")
    context = mp.get_context("spawn")
    parent, child = context.Pipe()
    process = context.Process(target=selector_worker, args=(child,))
    process.start()
    child.close()
    try:
        with np.load(HISTORY_ROOT / "history/responses.npz") as history:
            calibration = historical_calibration(history, [p.name for p in PROFILES])
            training = evaluate_phase(parent, TRAINING, "training", history, calibration)
            validation = evaluate_phase(parent, VALIDATION, "validation", history, calibration) if training["gate_passed"] else None
    finally:
        if process.is_alive():
            parent.send(("stop", None))
        parent.close()
        process.join(timeout=10)
        if process.is_alive():
            process.terminate()
            process.join()
        if process.exitcode != 0:
            raise RuntimeError(f"Coupled selector exited {process.exitcode}")
    write_json(RESULTS / "summary.json", {"training": training, "validation": validation,
                                        "significant_advantage_established": False})
    lines = ["# 独立参照轨迹的全程发现损失约束", "",
             "固定六来源先验、两类场景、200 次预算和共同 10 次初始化；只使用已查询反馈。",
             "历史训练配置先筛查，双指标同时超过参照与去耦合对照后才开展既定验证配置。无新增物理执行。", ""]
    for label, phase in (("24 配置开发", training), ("12 配置验证", validation)):
        if phase is None:
            continue
        lines += [f"## {label}", "", "| 方法 | Area % | Recall % | F200 | 平均偏离参照查询数 | 平均选择秒 |",
                  "|---|---:|---:|---:|---:|---:|"]
        for method, value in phase["aggregate"].items():
            lines.append(f"| {method} | {value['area_pct']:.3f} | {value['recall_pct']:.3f} | "
                         f"{value['F200']:.2f} | {value['alternative_queries']:.2f} | {value['selector_elapsed_s']:.2f} |")
        lines += ["", f"{phase['audited_runs']} 条曲线、{phase['audited_disclosures']} 次披露核对通过；"
                  "独立参照回放顺序与实际参照相同，逐前缀、终点及累计面积界均通过实测核对。"]
        for method, value in phase["candidate_changes"].items():
            lines.append(f"相对 {method}：Area {value['area_pp']:+.3f}、Recall {value['recall_pp']:+.3f} 个百分点。")
    lines += ["", "计数界与模型校准分开：当前只保证相对匹配参照在任意已付费前缀最多少一个碰撞，允许实际收益更高。",
              "它不保证严格优势，也不证明相对所有既有基线不下降。风险和碰撞来自固定执行记录；自由回放仅使用已经付费测得的结果。",
              "开发门槛未通过，不推进下一实验。" if not training["gate_passed"] else "验证结论以完整表为准，尚未建立独立显著优势。"]
    (RESULTS / "report.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    write_json(RESULTS / "progress.json", {"status": "complete", "training_gate_passed": training["gate_passed"],
                                         "validation_run": validation is not None, "new_physical_calls": 0})
    print({"training_changes": training["candidate_changes"], "training_gate_passed": training["gate_passed"],
           "validation_changes": validation["candidate_changes"] if validation else None}, flush=True)


if __name__ == "__main__":
    main()
