"""One candidate and two matched mechanism controls, using queried feedback only."""
import numpy as np
from threadpoolctl import threadpool_limits

from methods.history_guided_testing.experiment import RemoteOracle

from .certificate import ExecutionCertificate
from .config import BUDGET, INITIAL_QUERIES
from .payoff import payoff_choice, proposals
from .response import ResponseModel


METHODS = ("greedy_reference", "unchecked_payoff", "loss_budget_payoff")


def select(method, x, predictions, payoff_models, oracle, seed):
    if method not in METHODS:
        raise ValueError(f"Unknown mechanism comparison: {method}")
    rng = np.random.default_rng(seed)
    tie_break = rng.random(len(x))
    model = ResponseModel(x, *predictions)
    remaining = np.ones(len(x), dtype=bool)
    selected, observations, audits, checks = [], [], [], []

    def query(index, role):
        observation = oracle.query(int(index))
        if observation.risk is None or observation.collision is None:
            raise ValueError("New protocol requires both queried risk and event feedback")
        if not remaining[index]:
            raise ValueError("Duplicate query in selector")
        model.observe(index, observation.risk, observation.collision)
        selected.append(int(index))
        remaining[index] = False
        observations.append({"index": int(index), "risk": observation.risk,
                             "collision": observation.collision, "role": role})
        return observation

    for _ in range(INITIAL_QUERIES):
        index = model.rank(remaining, tie_break=tie_break)[0]
        query(int(index), "initialization")
    audit_queries = 0
    while len(selected) < BUDGET:
        reference_rank = model.rank(remaining, tie_break=tie_break)
        reference = int(reference_rank[0])
        if method == "greedy_reference" or BUDGET - len(selected) == 1:
            query(reference, "greedy_discovery")
            continue
        candidates, features = proposals(model, remaining, tie_break, BUDGET - len(selected))
        chosen, values, lower, harm, margin = payoff_choice(
            candidates, features, payoff_models, tie_break, checked=method == "loss_budget_payoff")
        candidate = candidates[chosen]
        started_at = len(selected)
        checks.append({"start_query": started_at + 1, "reference_index": reference,
                       "chosen_index": candidate, "remaining_budget": BUDGET - started_at,
                       "reference_values": [0., 0.],
                       "chosen_values": values[chosen].tolist(),
                       "predicted_gain": values[chosen].tolist(),
                       "support_lower": lower[chosen].tolist(),
                       "harm_prediction": float(harm[chosen]),
                       "loss_budget_margin": margin[chosen].tolist(),
                       "screen_applied": method == "loss_budget_payoff",
                       "scope": "minimum fitted benefit covers maximum fitted loss; model envelope is not a confidence bound"})
        observation = query(candidate, "planned_query" if candidate != reference else "reference_discovery")
        if candidate != reference:
            audit_queries += 1
            # A known event certifies only this executed query against the
            # pre-query reference. It does not certify the imagined future.
            certificate = ExecutionCertificate([reference], [candidate], len(x))
            certificate.observe(candidate, observation.collision)
            decision = certificate.decision()
            decision.update(start_query=started_at + 1, executed_order=[candidate],
                            fallback=False, accepted=decision["non_decreasing"],
                            descriptive_only=True)
            audits.append(decision)
    return {
        "selected_indices": selected, "queries": observations,
        "audits": audits, "correction_supported": any(audit["supported"] for audit in audits),
        "correction_non_decreasing": any(audit["accepted"] for audit in audits),
        "audit_query_count": audit_queries,
        "planning_checks": checks,
        "task_posterior": model.task_state(),
        "certificate_scope": "one executed query only; planning values are model-dependent and not certified",
    }


def selector_worker(connection):
    try:
        with threadpool_limits(limits=1):
            while True:
                message, task = connection.recv()
                if message == "stop":
                    return
                if message != "task":
                    raise ValueError(f"Unexpected message: {message}")
                result = select(task["method"], task["x"], task["predictions"], task["payoff_models"],
                                RemoteOracle(connection), task["seed"])
                connection.send(("result", result))
    except Exception as error:
        connection.send(("error", repr(error)))
        raise
    finally:
        connection.close()
