"""Development-only continuations after the first paid negative extra query."""
import copy
from types import ModuleType
from zipfile import ZipFile

import numpy as np
from scipy.linalg import solve_triangular
from scipy.special import ndtr, ndtri
from threadpoolctl import threadpool_limits

from methods.history_guided_testing.history import historical_risk, load_history, split_indices, subset
from methods.history_guided_testing.io import read_json, write_json
from methods.history_guided_testing.search import TestingSession

from .config import BUDGET, INITIAL_QUERIES, OUTPUT, POOL_SEEDS, SUT_IDS
from .develop import metrics
from .frozen_coupling import FrozenReplay


SOURCE = OUTPUT / "calibrated_risk_event_coupling"
RESULTS = OUTPUT / "first_failure_diagnostic"
SEED = 11


def continuation(reference, candidate, known, prefix, available, tie, bank, use_candidate):
    reference, candidate = copy.deepcopy(reference), copy.deepcopy(candidate)
    known, selected, available = known.copy(), prefix.copy(), available.copy()
    while len(selected) < BUDGET:
        reference.advance(known)
        index = int(candidate.rank(available, tie_break=tie)[0]) if use_candidate else int(reference.head())
        if not available[index]:
            raise ValueError("Diagnostic continuation repeats a paid query")
        known[index] = float(bank["risk"][index]), bool(bank["collision"][index])
        selected.append(index)
        available[index] = False
        candidate.observe(index, *known[index])
        reference.advance(known)
    return {"selected_indices": selected, **metrics(bank["collision"], selected)}


def main():
    # The diagnostic concerns a frozen earlier model, not the active proposal.
    with ZipFile(SOURCE / "source_inputs.zip") as archive:
        source = archive.read("risk_event_response.py").decode("utf-8")
    frozen = ModuleType(f"{__package__}.diagnostic_frozen_response")
    frozen.__package__ = __package__
    exec(compile(source, str(SOURCE / "source_inputs.zip/risk_event_response.py"), "exec"), frozen.__dict__)
    history = load_history()
    train, _ = split_indices(next(iter(history.values()))["x"])
    allowed = subset(history, train)
    readout = frozen.fit_event_readout(RESULTS)
    rows = []
    with threadpool_limits(limits=1):
        for pool in range(len(POOL_SEEDS)):
            for sut in SUT_IDS:
                run = read_json(SOURCE / f"pool_{pool}" / sut / "coupled_response_11.json")
                baseline = read_json(OUTPUT / f"pool_{pool}" / sut / "baselines/frozen_original_11.json")
                with np.load(OUTPUT / f"pool_{pool}" / sut / "responses.npz") as bank:
                    prior = historical_risk(allowed, bank["x"])
                    reference = FrozenReplay(TestingSession(bank["x"], SEED, mode="global_feedback", prior=prior))
                    candidate = frozen.RiskEventResponse(reference, bank["x"][:, 4], readout)
                    available = np.ones(len(bank["x"]), dtype=bool)
                    tie = np.random.default_rng(SEED).random(len(available))
                    known, selected = {}, []
                    failure = None
                    for t, index in enumerate(run["selected_indices"]):
                        reference.advance(known)
                        debt = reference.certificate(known)["negative_extra_count"]
                        head = reference.head()
                        planned = head if t < INITIAL_QUERIES or debt else int(candidate.rank(available, tie_break=tie)[0])
                        if planned != index:
                            raise ValueError("First-failure replay differs from the executed policy")
                        is_negative_extra = index != head and not bool(bank["collision"][index]) and debt == 0
                        prediction = None
                        if is_negative_extra:
                            probability = float(candidate.probabilities()[index])
                            cross = candidate.kernel[index, candidate.indices]
                            residual_mean = float(cross @ candidate.alpha)
                            solved = solve_triangular(candidate.factor, candidate.root_precision * cross, lower=True)
                            residual_variance = max(1 - float(solved @ solved), 0)
                            group = int(bank["x"][index, 4])
                            real_risk = float(bank["risk"][index])
                            mapped = float(candidate.readout[group].predict([real_risk])[0])
                            conditional = float(ndtr((np.sqrt(2) * ndtri(np.clip(mapped, .01, .99))
                                                      + residual_mean) / np.sqrt(1 + residual_variance)))
                            sd = float(np.sqrt(candidate.gp.variance[index] + candidate.gp.noise))
                            prediction = {"risk_mean_before_query": float(candidate.gp.mean[index]),
                                          "risk_sd_before_query": sd, "actual_risk": real_risk,
                                          "standardized_risk_error": (real_risk - candidate.gp.mean[index]) / sd,
                                          "event_probability_before_query": probability,
                                          "event_probability_given_actual_risk": conditional,
                                          "negative_event_log_loss_before": float(-np.log(max(1 - probability, 1e-12))),
                                          "negative_event_log_loss_given_risk": float(-np.log(max(1 - conditional, 1e-12)))}
                        known[index] = float(bank["risk"][index]), bool(bank["collision"][index])
                        selected.append(index)
                        available[index] = False
                        candidate.observe(index, *known[index])
                        reference.advance(known)
                        after = reference.certificate(known)
                        if debt == 0 and after["negative_extra_count"] == 1:
                            failure = t + 1
                            break
                    row = {"pool": pool, "sut_id": sut, "first_negative_extra_query": failure,
                           "first_failure_prediction": prediction}
                    if failure is not None:
                        continued = continuation(reference, candidate, known, selected, available, tie, bank, True)
                        fallback = continuation(reference, candidate, known, selected, available, tie, bank, False)
                        for result in (continued, fallback):
                            if result["selected_indices"][:failure] != selected or len(set(result["selected_indices"])) != BUDGET:
                                raise ValueError("Counterfactual diagnostic changed the shared paid prefix")
                        row.update(prefix_indices=selected, candidate_continuation=continued,
                                   permanent_reference_continuation=fallback,
                                   actual_guarded_F200=run["F200"], actual_guarded_area=run["area_200"],
                                   original_reference_F200=baseline["F200"],
                                   candidate_minus_fallback_F200=continued["F200"] - fallback["F200"],
                                   candidate_minus_fallback_area_pp=100 * (continued["area_200"] - fallback["area_200"]),
                                   candidate_minus_actual_guarded_F200=continued["F200"] - run["F200"],
                                   candidate_minus_actual_guarded_area_pp=100 * (continued["area_200"] - run["area_200"]))
                    rows.append(row)
                    write_json(RESULTS / "progress.json", {"status": "running", "systems_completed": len(rows), "expected": 12})
                    print("FIRST FAILURE", pool, sut, failure, row.get("candidate_minus_fallback_F200"),
                          row.get("candidate_minus_fallback_area_pp"), flush=True)
    failures = [row for row in rows if row["first_negative_extra_query"] is not None]
    summary = {"scope": "development diagnosis; evaluator reuses full measured bank, models receive only sequential requested feedback",
               "rows": rows, "negative_extra_paths": len(failures), "new_physical_calls": 0,
               "joint_better_than_permanent_reference": sum(row["candidate_minus_fallback_F200"] > 0
                   and row["candidate_minus_fallback_area_pp"] > 0 for row in failures),
               "joint_worse_than_permanent_reference": sum(row["candidate_minus_fallback_F200"] < 0
                   and row["candidate_minus_fallback_area_pp"] < 0 for row in failures),
               "significant_advantage_established": False}
    write_json(RESULTS / "summary.json", summary)
    lines = ["# 首次负例后的共同状态延续诊断", "",
             "重放原实际前缀，直到首次新增非碰撞；之后分别永久执行参照和继续候选。两分支共享全部已付费反馈与剩余预算。",
             "这是使用完整缓存作评估的开发诊断，不是目标未查询标签作为选例输入，也不用于宣称新方法优势。", "",
             "| 池 | SUT | 首次负例查询 | 继续候选 ΔF200 | ΔArea（百分点） |", "|---|---|---:|---:|---:|"]
    for row in rows:
        if row["first_negative_extra_query"] is None:
            lines.append(f"| {row['pool']} | {row['sut_id']} | 无 | — | — |")
        else:
            lines.append(f"| {row['pool']} | {row['sut_id']} | {row['first_negative_extra_query']} | "
                         f"{row['candidate_minus_fallback_F200']:+d} | {row['candidate_minus_fallback_area_pp']:+.3f} |")
    lines += ["", f"{len(failures)} 条路径存在首次负例；继续候选双指标更好 {summary['joint_better_than_permanent_reference']} 条，"
              f"双指标更差 {summary['joint_worse_than_permanent_reference']} 条。混合变化逐项报告，不把局部恢复视作普遍收益。"]
    (RESULTS / "report.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    write_json(RESULTS / "progress.json", {"status": "complete", "paths": 12, "continuations": 2 * len(failures), "new_physical_calls": 0})


if __name__ == "__main__":
    main()
