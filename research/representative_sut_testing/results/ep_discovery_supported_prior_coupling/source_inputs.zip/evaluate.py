"""Representative-SUT mechanism development on already completed shared banks."""
import multiprocessing as mp
import time

import numpy as np

from methods.history_guided_testing.config import ROOT as HISTORY_ROOT
from methods.history_guided_testing.io import write_json

from .config import MECHANISM_FOLDER, OUTPUT, POOL_SEEDS, PROFILES, SEEDS, SUT_IDS
from .calibration import historical_calibration
from .develop import disclose
from .response import historical_predictions
from .payoff import train_payoff
from .selector import METHODS, selector_worker


def main():
    available, missing = [], []
    for pool_id in range(len(POOL_SEEDS)):
        for sut_id in SUT_IDS:
            folder = OUTPUT / f"pool_{pool_id}" / sut_id
            if (folder / "responses.npz").exists():
                available.append(folder)
            else:
                missing.append({"pool": pool_id, "sut_id": sut_id})
    write_json(OUTPUT / f"{MECHANISM_FOLDER}_protocol.json", {
        "stage": "representative-SUT development; not confirmation or promotion",
        "methods": METHODS, "historical_sources": [profile.name for profile in PROFILES],
        "shared_feedback": "queried risk and collision, all controls",
        "posterior": "shared response modes with distinct loadings, joint local residuals and positive unexplained event component",
        "planning": "historically learned correction returns against adaptive greedy continuation",
        "state_aggregation": "one history-only correction-policy pass; no target data",
        "support": "return agreement and fitted benefit covers fitted loss on both objectives; no coverage claim",
        "branch_consistency": "fixed event marginals and binary range; no global coverage claim",
        "historical_data": "same six original measured sources, all 2048 coordinates",
        "prior_covariance": "between-source response covariance plus coordinate-LOO local residual; event marginals preserved",
        "target_parameters_or_identity_provided_to_selector": False,
        "purpose": "measure cross-family behavior and gate futility, not claim novelty from a stronger reference",
        "certificate": "immediate executed query only; future planning values are working-model approximations",
    })
    context = mp.get_context("spawn")
    parent, child = context.Pipe()
    process = context.Process(target=selector_worker, args=(child,))
    process.start()
    child.close()
    try:
        with np.load(HISTORY_ROOT / "history/responses.npz") as history:
            calibration = historical_calibration(history, [profile.name for profile in PROFILES])
            payoff_models = train_payoff(history, [profile.name for profile in PROFILES],
                                         OUTPUT / "payoff_training")
            for folder in available:
                with np.load(folder / "responses.npz") as bank:
                    predictions = (*historical_predictions(
                        bank["x"], history, [profile.name for profile in PROFILES]), calibration)
                    for seed in SEEDS:
                        for method in METHODS:
                            path = folder / MECHANISM_FOLDER / f"{method}_{seed}.json"
                            if path.exists():
                                continue
                            started = time.perf_counter()
                            task = {"method": method, "seed": seed,
                                    "x": bank["x"], "predictions": predictions,
                                    "payoff_models": payoff_models}
                            result = disclose(parent, task, bank["risk"], bank["collision"])
                            result.update(method=method, seed=seed,
                                          selector_elapsed_s=time.perf_counter() - started)
                            write_json(path, result)
                            write_json(OUTPUT / f"{MECHANISM_FOLDER}_progress.json", {
                                "status": "running", "latest": str(path.relative_to(OUTPUT)),
                                "expected_full_runs": len(POOL_SEEDS) * len(SUT_IDS) * len(SEEDS) * len(METHODS),
                            })
                            print("MECHANISM", folder.parent.name, folder.name, seed, method,
                                  result["F200"], "changed_reference", result["audit_query_count"], flush=True)
    finally:
        if process.is_alive():
            parent.send(("stop", None))
        parent.close()
        process.join(timeout=10)
        if process.is_alive():
            process.terminate()
            process.join()
        if process.exitcode != 0:
            raise RuntimeError(f"Mechanism selector exited {process.exitcode}")
    write_json(OUTPUT / f"{MECHANISM_FOLDER}_progress.json", {
        "status": "incomplete_missing_banks" if missing else "complete",
        "evaluated_banks": [str(folder.relative_to(OUTPUT)) for folder in available],
        "missing_banks": missing, "rerun_after_measurement": bool(missing),
    })


if __name__ == "__main__":
    main()
