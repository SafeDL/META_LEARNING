"""Anonymous response-function prior from original and preassigned past records."""
from dataclasses import asdict

import numpy as np

from methods.history_guided_testing.config import ROOT as HISTORY_ROOT, TARGET
from methods.history_guided_testing.io import read_json, write_json

from .calibration import historical_calibration
from .cohort_payoff import COHORT, TRAINING, VALIDATION, load_bank
from .config import BOUNDS, PROFILES
from .response import historical_predictions


def load_population(folder):
    with np.load(HISTORY_ROOT / "history/responses.npz") as data:
        originals = {key: data[key].copy() for key in data.files}
    past_protocol = read_json(COHORT / "protocol.json")
    profiles = {p["name"]: p for p in past_protocol["profiles"]}
    signatures = {tuple(sorted((key, value) for key, value in asdict(p).items() if key != "name"))
                  for p in (*PROFILES, TARGET)}
    if set(TRAINING).intersection(VALIDATION):
        raise ValueError("Historical response population overlaps the validation split")
    extra = {}
    for name in TRAINING:
        signature = tuple(sorted((key, value) for key, value in profiles[name].items() if key != "name"))
        if signature in signatures:
            raise ValueError("Historical population duplicates another source or the original target")
        signatures.add(signature)
        bank = load_bank(name)
        scenarios = read_json(COHORT / name / "pool_0/scenarios.json")
        if not np.array_equal(bank["x"], [s["numeric_input"] for s in scenarios]):
            raise ValueError("Historical response coordinates differ from their measured scenes")
        for scene in scenarios:
            if (scene["fixed_context"] != {"duration_s": 12, "ego_speed_mps": 25,
                                          "desired_speed_mps": 23, "lane_count": 2}
                    or scene["simulator_seed"] != 4179941):
                raise ValueError("Historical scene context differs from the current protocol")
            coordinate = scene["numeric_input"]
            bounds = np.asarray(BOUNDS[int(coordinate[4])])
            physical = bounds[:, 0] + np.asarray(coordinate[:4]) * (bounds[:, 1] - bounds[:, 0])
            if not np.allclose(physical, list(scene["active_parameters"].values()), rtol=0, atol=1e-12):
                raise ValueError("Historical scene uses incompatible parameter bounds")
        if (bank["x"].shape != (2048, 5) or bank["collision"].dtype != np.bool_
                or not np.isfinite(bank["risk"]).all() or np.any((bank["risk"] < 0) | (bank["risk"] > 1))):
            raise ValueError("Invalid historical response record")
        extra[name] = bank
    names = [p.name for p in PROFILES]
    original_calibration = historical_calibration(originals, names)
    calibrations = {}
    for name, bank in extra.items():
        source = {"x": bank["x"], name: bank["risk"], name + "_collision": bank["collision"]}
        calibrations[name] = historical_calibration(source, [name])
    calibration = {
        key: ((len(names) * np.asarray(original_calibration[key])
               + sum(np.asarray(c[key]) for c in calibrations.values())) / (len(names) + len(extra))).tolist()
        for key in original_calibration
    }
    write_json(folder / "population_audit.json", {
        "original_sources": names, "added_historical_configurations": TRAINING,
        "excluded_validation_configurations": VALIDATION,
        "total_sources": len(names) + len(extra), "existing_extra_measurements": len(extra) * 2048,
        "new_physical_measurements": 0, "parameters_used_as_predictor_inputs": False,
        "calibration": calibration, "calibration_per_configuration": calibrations,
        "calibration_scope": "same-source coordinate leave-one-out; source equal weighting",
        "scenario_context_and_bounds_checked": True, "no_duplicate_configuration_or_original_target": True,
        "scope": "IDM/FVDM configurations, not thirty independent driving algorithm families"})
    return originals, extra, calibration


def population_predictions(x, originals, extra):
    names = [p.name for p in PROFILES]
    risk, event = historical_predictions(x, originals, names)
    risks, events = [risk], [event]
    for name in TRAINING:
        bank = extra[name]
        source = {"x": bank["x"], name: bank["risk"], name + "_collision": bank["collision"]}
        r, c = historical_predictions(x, source, [name])
        risks.append(r)
        events.append(c)
    return np.column_stack(risks), np.column_stack(events)
