"""Adaptive sharing identities hold for arbitrary causal expert sequences."""
import numpy as np
from scipy.special import logsumexp
from types import SimpleNamespace

from .evidence_scope import EvidenceScope
from .adaptive_margin_prior import AdaptiveMarginPrior
from .censored_margin_response import calibrated_margin_moments
from .ep_margin_response import ExpectationPropagatedMargin
from .rank_event_response import RankEventResponse
from .scoped_margin_prior import ScopedMarginPrior


def test_adaptive_scope_tracks_contextual_experts_and_checks_every_prefix():
    scope = EvidenceScope('adaptive', np.full(2, -np.log(2)))
    for t in range(40):
        family = t % 2
        likelihood = np.log([.9, .2] if family == 0 else [.2, .9])
        scope.update(family, likelihood)
    assert scope.weights(0)[0] > .999 and scope.weights(1)[1] > .999
    assert np.exp(scope.scope_logweights)[1] > .999
    assert scope.predictor_losses[2] <= scope.component_losses.min(axis=1).sum() + 3 * np.log(2) + 1e-8


def test_global_scope_reproduces_original_before_query_updates():
    global_weights = np.full(2, -np.log(2))
    scope = EvidenceScope('global', global_weights.copy())
    for t in range(30):
        probability = np.asarray([.2 + .01 * t, .8 - .01 * t])
        likelihood = np.log(probability if t % 3 else 1 - probability)
        before = np.exp(global_weights)
        record = scope.update(t % 2, likelihood)
        np.testing.assert_allclose(record['weights_before'], before, atol=1e-12)
        global_weights += likelihood
        global_weights -= logsumexp(global_weights)
        np.testing.assert_allclose(scope.weights(t % 2), np.exp(global_weights), atol=1e-12)


def test_family_update_does_not_change_other_family_evidence():
    scope = EvidenceScope('family', np.full(2, -np.log(2)))
    old = scope.weights(1).copy()
    scope.update(0, np.log([.8, .2]))
    np.testing.assert_array_equal(scope.weights(1), old)
    np.testing.assert_allclose(scope.weights(0)[0], .8, atol=1e-12)


def test_global_scoped_predictor_matches_original_report_mixture():
    reference = SimpleNamespace(session=SimpleNamespace(gp=SimpleNamespace(covariance=np.eye(5), noise=.1)), head=lambda: 4)
    probability, positive = np.full(5, .8), np.full(5, .4)
    mean, variance = calibrated_margin_moments(probability, positive)
    prior = {'probability': probability, 'positive_mean': positive, 'mean': mean,
             'report_variance': variance, 'modes': np.zeros((5, 6))}
    report = RankEventResponse(reference, [0] * 5, prior, use_ranks=False, device='cpu')
    base = AdaptiveMarginPrior(reference, [0] * 5, prior, freeze_after_initialization=False,
                               model_class=ExpectationPropagatedMargin, evidence_score='event', alternative_model=report, device='cpu')
    scoped = ScopedMarginPrior(reference, [0] * 5, prior, scope_mode='global', device='cpu')
    for i, (risk, collision) in enumerate([(.8, True), (.2, False), (.6, True)]):
        base.observe(i, risk, collision)
        scoped.observe(i, risk, collision)
        np.testing.assert_allclose(base.probabilities(), scoped.probabilities(), atol=1e-10)
        np.testing.assert_allclose(base.evidence_records[-1]['weights_after'], scoped.evidence_records[-1]['weights_after'], atol=1e-10)
    assert len(scoped.diagnostics()['scope_records']) == 3
