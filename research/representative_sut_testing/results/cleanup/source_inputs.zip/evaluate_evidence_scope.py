"""Bounded scene-specific versus adaptively shared credibility experiment."""
import numpy as np

from methods.history_guided_testing.io import read_json, write_json
from .config import BUDGET, OUTPUT, SUT_IDS
from .evaluate_ep_discovery_support import evaluate_stage


RESULTS = OUTPUT / 'evidence_scope_coupling'


def main():
    write_json(RESULTS / 'protocol.json', {'sut_ids': SUT_IDS, 'pools': [0, 1], 'seed': 11, 'budget': BUDGET,
               'new_curves': 24, 'reused_controls': 24, 'new_physical_calls': 0,
               'models': 'unchanged historical mixed EP and sign-only normalized report',
               'scopes': ['global', 'family', 'adaptive'],
               'change': 'credibility evidence sharing only; predictors still learn from all actual R/C',
               'guarantee': 'on actual shared query sequence, adaptive event log loss <= min(global,family) + log(2); discovery count guarantee unchanged',
               'expansion': 'no additional seeds without both discovery metrics exceeding matched and stronger controls'})
    write_json(RESULTS / 'progress.json', {'status': 'running', 'phase': 'family', 'new_curves': 24})
    evaluate_stage(RESULTS / 'family', 'family_evidence_prior', 'event',
                   'safe_risk_order_coupling/event_sign', 'report_binary_prior', report_mode=False, scope_mode='family')
    write_json(RESULTS / 'progress.json', {'status': 'running', 'phase': 'adaptive', 'new_curves': 24})
    evaluate_stage(RESULTS / 'adaptive', 'adaptive_scope_prior', 'event',
                   'evidence_scope_coupling/family', 'family_evidence_prior', report_mode=False, scope_mode='adaptive')
    rows = {}
    for folder in ['family', 'adaptive']:
        for r in read_json(RESULTS / folder / 'summary.json')['rows']:
            rows[r['pool'], r['sut_id'], r['method']] = r
    rows = list(rows.values())
    methods = ('frozen_reference', 'report_binary_prior', 'family_evidence_prior', 'adaptive_scope_prior')
    aggregate = {m: {k: float(np.mean([r[k] for r in rows if r['method'] == m])) for k in ('area_pct', 'recall_pct', 'F200')} for m in methods}
    changes = {m: {k: aggregate['adaptive_scope_prior'][k] - aggregate[m][k] for k in ('area_pct', 'recall_pct')} for m in methods[:-1]}
    matched = read_json(OUTPUT / 'matched_first_seed_comparison/summary.json')['aggregate']
    stronger = {m: {k: aggregate['adaptive_scope_prior'][k] - matched[m][k] for k in ('area_pct', 'recall_pct')}
                for m in ('student_protected', 'student_unprotected', 'adf_loss_supported')}
    gate = all(v['area_pct'] > 0 and v['recall_pct'] > 0 for v in [*changes.values(), *stronger.values()])
    write_json(RESULTS / 'summary.json', {'rows': rows, 'aggregate': aggregate, 'candidate_changes': changes,
               'stronger_method_changes': stronger, 'development_gate_passed': gate, 'new_curves': 24,
               'scope_prefix_identities_verified': True, 'significant_advantage_established': False})
    write_json(RESULTS / 'progress.json', {'status': 'complete', 'new_curves': 24, 'new_disclosures': 4800, 'new_physical_calls': 0})
    print({'aggregate': aggregate, 'candidate_changes': changes, 'development_gate_passed': gate}, flush=True)


if __name__ == '__main__':
    main()
