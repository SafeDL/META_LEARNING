# 代表 SUT 上的反馈纠正与失效发现

唯一主设计：[Failure_Discovery_Design.md](../../docs/Failure_Discovery_Design.md)。本目录保存实现、数据和结果；研究动机、方法与实验计划只维护在主设计。

## 职责

| 文件 | 用途 |
|---|---|
| `config.py` | 六 SUT、共享场景池、200 次预算与阶段路径 |
| `interface_audit.py`、`prepare.py`、`validate_banks.py` | 接口审计、物理执行与实测池核对 |
| `response.py`、`calibration.py` | 共享响应后验、历史误差与协方差估计 |
| `planning.py`、`payoff.py`、`selector.py` | 工作前瞻、历史纠正收益学习与选择 |
| `certificate.py` | 已执行单次查询的二元标签核对 |
| `develop.py`、`summarize_development.py` | 原六来源历史留出开发与汇总 |
| `cohort_payoff.py` | 既有 24 配置训练、12 配置开发验证；不新增物理执行 |
| `summarize_cohort.py` | 配置验证的完整对比、历史收益标签及披露核对 |
| `decision_geometry.py`、`diagnose_geometry.py` | 工作响应的方向信息、误差放大与训练内收益筛查 |
| `coupled_discovery.py`、`develop_coupled.py` | 独立参照回放、完整曲线损失界与有限开发 |
| `validate_response_channels.py` | 既定验证配置上的联合／仅事件更新比较 |
| `response_channels.py`、`evaluate_response_channels.py` | 六 SUT 的联合、共享事件、局部事件 GP 同反馈主比较 |
| `frozen_coupling.py`、`evaluate_frozen_coupling.py` | 冻结原方法的独立参照回放与当前有限筛查 |
| `threshold_response.py` | 以实际风险／事件反馈约束阈值解释，检验选择是否获得一致支持 |
| `response_population.py` | 原六来源及既定 24 个历史训练配置的响应先验、场景核对与校准 |
| `risk_event_response.py` | 历史风险／事件映射、目标共享与局部事件修正、分段概率积分 |
| `risk_task_prior.py` | 原六来源风险响应差异和目标场景类均值校准 |
| `student_risk_prior.py` | 同核同均值上的逆伽马风险尺度后验与 Student-t 预测 |
| `diagnose_correction_reliability.py` | 从额度阶段快照重放实际查询，分解风险与事件误差 |
| `diagnose_feedback_decision_value.py` | 实际反馈对同预算未来固定批次的影响诊断 |
| `censored_margin_response.py`、`evaluate_censored_margin.py` | 校准余量先验、连续安全代理与碰撞约束的同先验 GPU 对照 |
| `diagnose_margin_prior_evidence.py` | 同一付费轨迹的历史／中性先验证据及初始反馈选择重放 |
| `adaptive_margin_prior.py`、`evaluate_adaptive_margin_prior.py` | 十次反馈先验选择与持续预测平均的真实选择器 |
| `decision_support.py`、`diagnose_decision_support.py` | 联合倾向排序、局部二元发现损失及已付费前缀诊断 |
| `discovery_supported_coupling.py`、`evaluate_discovery_support.py` | 发现损失支持下的参照观测与实际策略评价 |
| `ep_margin_response.py`、`evaluate_ep_discovery_support.py` | 同观测与选择规则下的联合 EP 推断及最新有限对照 |
| `diagnose_evidence_channels.py`、`evaluate_event_evidence.py` | 已付费轨迹的证据通道诊断与仅事件评分的权重对照 |
| `binary_event_response.py`、`diagnose_independent_event.py` | 独立二元事件模型及匹配尺度的付费前缀对照 |
| `rank_event_response.py`、`diagnose_risk_order.py`、`evaluate_risk_order.py` | 安全风险顺序、线性约束 EP 与有限实际发现对照 |
| `evidence_scope.py`、`scoped_margin_prior.py`、`evaluate_evidence_scope.py` | 全局／分场景可信度及自适应证据共享的实际对照 |
| `diagnose_first_failure.py` | 从原快照重放首次负例后的共同状态延续，属于开发诊断 |
| `baselines.py`、`evaluate.py`、`summarize.py` | 冻结基线、主机制评价与汇总 |
| `results/` | 协议、曲线、阶段总结与冻结快照 |

## 入口

在项目根目录使用 `conda activate metadrive`。按所需阶段单独运行，不必顺序重跑已完成工作：

```powershell
python -B -m research.representative_sut_testing.interface_audit
python -B -m research.representative_sut_testing.prepare
python -B -m research.representative_sut_testing.validate_banks
python -B -m research.representative_sut_testing.develop
python -B -m research.representative_sut_testing.summarize_development
python -B -m research.representative_sut_testing.cohort_payoff
python -B -m research.representative_sut_testing.summarize_cohort
python -B -m research.representative_sut_testing.diagnose_geometry
python -B -m research.representative_sut_testing.develop_coupled
python -B -m research.representative_sut_testing.validate_response_channels
python -B -m research.representative_sut_testing.evaluate_response_channels
python -B -m research.representative_sut_testing.evaluate_frozen_coupling
python -B -m research.representative_sut_testing.evaluate_censored_margin
python -B -m research.representative_sut_testing.evaluate_adaptive_margin_prior
python -B -m research.representative_sut_testing.evaluate_discovery_support
python -B -m research.representative_sut_testing.diagnose_first_failure
python -B -m research.representative_sut_testing.baselines
python -B -m research.representative_sut_testing.evaluate
python -B -m research.representative_sut_testing.summarize
```

`prepare` 会执行物理仿真；评价读取固定实测池，按查询披露反馈。`develop` 的路径由 `config.py` 决定；`cohort_payoff` 使用独立子目录与既定配置划分。`evaluate` 仍使用原六来源收益训练入口，尚未接入扩展队列的收益模型，不能据此称已完成扩展方法的主实验。

## 状态与结果索引

12 个实测池、24576 次物理执行和 14 个基线的 840 条曲线已完成。响应通道主比较的 180 条曲线与核对完成，仍未形成双指标优势；参照回放的全程界已通过历史开发核对。当前仍未建立显著优势。各阶段结论集中维护于结果报告，不在此重复旧设计。

- [实测协议](results/protocol.json)、[接口审计](results/interface_audit.json)、[实测池核对](results/bank_audit.json)。
- [完整基线](results/baseline_comparison.md)、[主开发指标](results/comparison.md)、[阶段报告](results/stage_report.md)。
- [最新已完成历史筛查](results/unique_state_development/report.md)、[状态与数据边界核对](results/policy_state_audit.json)。
- [配置队列验证协议](results/cohort_payoff_development/protocol.json)、[训练进度](results/cohort_payoff_development/training_progress.json)、[验证进度](results/cohort_payoff_development/progress.json)。
- [配置验证完整对比](results/cohort_payoff_development/report.md)、[数据与指标核对](results/cohort_payoff_development/audit.json)、[收益迁移诊断](results/cohort_payoff_development/payoff_generalization.json)。
- [方向信息的训练筛查](results/decision_geometry_development/report.md)、[独立参照耦合开发](results/coupled_discovery_development/report.md)。
- [固定配置响应通道验证](results/response_channel_validation/report.md)、[六 SUT 通道与共享结构主比较](results/response_channel_main/report.md)。
- [强参照耦合](results/frozen_reference_coupling/report.md)、[复用训练核](results/learned_response_coupling/report.md)、[模块证据筛查](results/modular_reference_coupling/report.md)。
- [当前相容解释筛查](results/threshold_reference_coupling/report.md)、[辨别与失配诊断](results/threshold_reference_coupling/identification_diagnostic.json)。
- [扩展响应先验筛查](results/population_reference_coupling/report.md)、[历史记录核对](results/population_reference_coupling/population_audit.json)、[跨 SUT 迁移诊断](results/population_reference_coupling/population_transfer_diagnostic.json)。
- [当前风险／事件校准筛查](results/calibrated_risk_event_coupling/report.md)、[积分核查](results/calibrated_risk_event_coupling/integration_audit.json)、[残差修正积分核查](results/calibrated_risk_event_coupling/corrected_integration_audit.json)。
- [首次负例延续诊断](results/first_failure_diagnostic/report.md)、[风险任务变化](results/risk_task_coupling/report.md)、[目标风险均值校准](results/task_mean_risk_coupling/report.md)。
- [当前同类场景改序](results/regime_anchored_coupling/report.md)、[FVDM 漏检诊断](results/task_mean_risk_coupling/missed_collision_diagnostic.json)。
- [已发现数支持的探测额度](results/earned_discovery_credit_coupling/report.md)、[同模型额度机制对比](results/earned_discovery_credit_coupling/guard_comparison.json)。
- [实际查询的可靠性诊断](results/correction_reliability_diagnostic/report.md)、[Student-t 风险筛查](results/student_risk_coupling/report.md)、[尺度机制对比](results/student_risk_coupling/risk_scale_comparison.json)。
- [反馈决策诊断](results/feedback_decision_value_diagnostic/report.md)、[有限前瞻筛查](results/decision_value_coupling/report.md)、[同模型前瞻对比](results/decision_value_coupling/planning_comparison.json)。
- [参照可观测性诊断](results/reference_observability_diagnostic/report.md)、[两步反馈筛查](results/paired_reference_coupling/report.md)、[同模型反馈安排对照](results/paired_reference_coupling/feedback_schedule_comparison.json)。
- [直接参照反馈的模型作用](results/reference_feedback_ablation/report.md)、[反馈贡献核查](results/reference_feedback_ablation/feedback_contribution_audit.json)、[风险与事件语义核查](results/reference_feedback_ablation/feedback_semantics_audit.json)。
- [混合余量观测筛查](results/censored_margin_coupling/report.md)、[历史事件先验迁移诊断](results/censored_margin_coupling/transfer_diagnostic.json)。
- [历史／中性先验对照](results/neutral_margin_prior_coupling/report.md)、[同轨迹先验证据](results/margin_prior_evidence_diagnostic/report.md)、[初始反馈选择重放](results/margin_prior_evidence_diagnostic/prefix_map_policy_replay.json)。
- [真实先验选择与平均](results/adaptive_margin_prior_coupling/report.md)、[更强既有方法对比](results/adaptive_margin_prior_coupling/stronger_method_comparison.json)。
- [选择等效性诊断](results/discovery_equivalence_diagnostic/report.md)、[发现损失支持实验](results/discovery_supported_prior_coupling/report.md)、[条件观测安排对照](results/discovery_supported_prior_coupling/observation_schedule_comparison.json)。

当前 `evaluate_frozen_coupling` 输出到 `results/reference_feedback_ablation/`，只对照固定参照时段反馈是否训练候选模型。两个候选共享两步排程、发现额度和实际 200 次预算，模型记录分别为 200 和 105 条；本轮固定 36 条核对曲线，不自动扩展种子。此前各轮的原数值代码保存在各自 `source_inputs.zip`，不将当前代码称为旧方案复现。首次负例与可靠性诊断从原快照读取实现，可独立重放旧轨迹；固定批次反馈诊断保存自己的源码快照。

该轮 36 条筛查曲线及核对已完成。IDM 第一池恢复到原参照发现数，但 VI-TTC 等部分条目下降；相对 Student-t 贪心版本两项平均指标均下降，未晋升，不补种子。首项等待与前缀覆盖界核对通过，具体收益和代价见本轮报告。

最新遮罩对照也已完成。IDM 的恢复在忽略参照直接模型反馈时保持；全反馈早期略好、终点略差，不能据此宣称稳定学习收益。原参照／全反馈的 24 条控制轨迹准确重放，21 项当前检查及反馈使用核对通过。

当前 `evaluate_censored_margin` 输出到 `results/neutral_margin_prior_coupling/`，对照历史／中性事件先验，保持安全代理条件均值、相关性、混合似然及两步排程。36 条曲线核对完成，中性先验更好但仍低于原参照，未晋升、不补种子。之前二元／混合阶段按原代码快照保留。

同轨迹证据诊断的 2400 条已付费记录表明，十次反馈可以区分部分先验适配；初始 MAP 选择的曲线重放只有小幅均值增量，尚待真实选择器验证，不能称为独立确认。

真实选择器验证现已完成：新增 24 条曲线、复用 36 条控制，初始选择轨迹与对应纯策略一致。持续平均仅增加少量早期面积，终点数不变；两项仍低于此前 Student-t 方法，未建立显著优势，不自动补种子。16 项当前检查及证据时序、动作概率和原参照计数界核对通过。

`evaluate_discovery_support` 以同一持续平均模型检查局部二元发现损失，再决定参照时段能否继续候选。新增 12 条曲线、复用 24 条控制，只有很小的均值增量；23 项当前检查及联合概率、实际反馈、条件观测和全程界核对通过。跳过参照后不再承诺固定 105 项前缀，原计数损失保护保留；尚无显著优势，不自动扩展种子。

最新入口为 `python -B -m research.representative_sut_testing.evaluate_ep_discovery_support`，阶段结果已完成，见 [EP 报告](results/ep_discovery_supported_prior_coupling/report.md)。仅替换推断，Recall 略升、Area 略降，未晋升；当前设计与后续计划统一维护在主设计文档，不在此另写一套方案。

事件评分阶段入口为 `python -B -m research.representative_sut_testing.evaluate_event_evidence`，固定协议见 [event_evidence_prior_coupling/protocol.json](results/event_evidence_prior_coupling/protocol.json)。只改变模型可信度的评分通道，组件仍用全部 R/C 更新；复用原 EP 及冻结参照，不自动追加种子。是否完成与结果以该阶段 `progress.json`、`summary.json` 为准。

事件评分阶段已完成 12 条新曲线。Area 53.051%、Recall 77.067%，相对原 EP 仅 Area +0.010 个百分点，12 个终点数全部不变，未晋升。27 项检查及逐前缀事件评分恒等式通过，见 [报告](results/event_evidence_prior_coupling/report.md)。全部 14 个冻结基线和较强机制的同种子对比见 [比较核查](results/matched_first_seed_comparison/report.md)，下一项结构修改只在主设计中维护。

独立事件响应已完成两轮付费前缀诊断，合计 120 个状态、无新增目标查询，未支持策略扩展。当前 `python -B -m research.representative_sut_testing.diagnose_independent_event` 对应 [匹配尺度报告](results/event_geometry_scale_matched_diagnostic/report.md)；旧单位尺度配置以 [原报告](results/independent_event_diagnostic/report.md) 及其源码快照为准。下一观测候选与验证条件仅在主设计中维护。

风险顺序已完成 [60 个前缀状态核查](results/safe_risk_order_diagnostic/report.md)，其实际曲线入口为 `python -B -m research.representative_sut_testing.evaluate_risk_order`。本轮最多新增 24 条仅符号／安全顺序曲线，复用原数值版本与参照，不改变对象、场景和预算；主设计维护机制及进展。

该轮 24 条实际曲线已完成。顺序版本比仅符号版本两项均低，两种新方法均未超过原数值版本的终点召回；38 项检查及实际约束、账本核查通过，未晋升，不追加种子。[完整报告](results/safe_risk_order_coupling/report.md)。

未获收益的前瞻实现、专用测试与未使用协方差列计算已退出活动代码，原文件逐字核对后保存在 `decision_value_coupling/source_inputs.zip`。

`comparison.md` 的既有完整主比较属于风险关系阶段，不代表当前收益学习方法已经完成六 SUT 主实验。旧曲线与源代码快照仍在各阶段目录保存。
