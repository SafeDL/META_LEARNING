"""Choose how much credibility evidence to share between functional scenes."""
import numpy as np

from .adaptive_margin_prior import AdaptiveMarginPrior
from .ep_margin_response import ExpectationPropagatedMargin
from .evidence_scope import EvidenceScope
from .rank_event_response import RankEventResponse


class ScopedMarginPrior(AdaptiveMarginPrior):
    def __init__(self, reference, family, prior, *, scope_mode, device="cuda"):
        report = RankEventResponse(reference, family, prior, use_ranks=False, device=device)
        super().__init__(reference, family, prior, freeze_after_initialization=False, device=device,
                         model_class=ExpectationPropagatedMargin, evidence_score="event", alternative_model=report)
        self.scope = EvidenceScope(scope_mode, self.logweights)
        self.scope_records = []

    def selection_weights(self):
        return self.scope.weights(int(self.family[self.reference.head()]))

    def probabilities(self):
        components = np.asarray([m.probabilities() for m in self.models])
        result = np.empty(len(self.family))
        for family in (0, 1):
            mask = self.family == family
            result[mask] = self.scope.weights(family) @ components[:, mask]
        return result

    def update_evidence(self, index, likelihoods):
        record = self.scope.update(int(self.family[index]), likelihoods)
        self.scope_records.append(record)
        before = np.asarray(record['weights_before'])
        return before, before, np.asarray(record['weights_after'])

    def diagnostics(self):
        return {**super().diagnostics(), "evidence_scope": self.scope.mode,
                "scope_records": self.scope_records,
                "scope": "sharing applies to model credibility only; both predictors still use every paid R/C observation"}
