"""Event-score aggregation with shared, contextual or learned sharing scope."""
import numpy as np
from scipy.special import logsumexp


class EvidenceScope:
    def __init__(self, mode, global_logweights):
        self.mode = mode
        self.global_logweights = global_logweights
        self.family_logweights = np.full((2, 2), -np.log(2))
        self.scope_logweights = np.full(2, -np.log(2))
        self.component_losses = np.zeros((2, 2))
        self.predictor_losses = np.zeros(3)

    def weights(self, family):
        global_weights = np.exp(self.global_logweights)
        family_weights = np.exp(self.family_logweights[family])
        if self.mode == "global":
            return global_weights
        if self.mode == "family":
            return family_weights
        if self.mode == "adaptive":
            return np.exp(self.scope_logweights) @ np.asarray([global_weights, family_weights])
        raise ValueError(f"Unknown evidence scope: {self.mode}")

    def update(self, family, likelihood):
        before = self.weights(family)
        scope_before = np.exp(self.scope_logweights)
        forecasts = np.asarray([logsumexp(self.global_logweights + likelihood),
                                logsumexp(self.family_logweights[family] + likelihood)])
        meta = logsumexp(self.scope_logweights + forecasts)
        self.predictor_losses -= np.r_[forecasts, meta]
        self.component_losses[family] -= likelihood
        self.global_logweights += likelihood
        self.global_logweights -= logsumexp(self.global_logweights)
        self.family_logweights[family] += likelihood
        self.family_logweights[family] -= logsumexp(self.family_logweights[family])
        self.scope_logweights += forecasts
        self.scope_logweights -= logsumexp(self.scope_logweights)
        global_loss = -logsumexp(-self.component_losses.sum(axis=0)) + np.log(2)
        family_loss = float((-logsumexp(-self.component_losses, axis=1) + np.log(2)).sum())
        meta_loss = -logsumexp(-np.asarray([global_loss, family_loss])) + np.log(2)
        if not np.allclose(self.predictor_losses, [global_loss, family_loss, meta_loss], atol=1e-8, rtol=0):
            raise ValueError("Sharing-scope mixture identity failed")
        if meta_loss > min(global_loss, family_loss) + np.log(2) + 1e-8:
            raise ValueError("Adaptive sharing exceeded its event-log-loss bound")
        return {"family": int(family), "weights_before": before.tolist(),
                "weights_after": self.weights(family).tolist(), "scope_weights_before": scope_before.tolist(),
                "scope_weights_after": np.exp(self.scope_logweights).tolist(),
                "global_weights_after": np.exp(self.global_logweights).tolist(),
                "family_weights_after": np.exp(self.family_logweights[family]).tolist(),
                "predictor_log_losses": self.predictor_losses.tolist()}
