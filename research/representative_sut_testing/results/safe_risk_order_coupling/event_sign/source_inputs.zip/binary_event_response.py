"""Independent probit event response with historical or coordinate geometry."""
import numpy as np
from scipy.spatial.distance import cdist
import torch

from .censored_margin_response import margin_correlation
from .ep_margin_response import ExpectationPropagatedMargin


COORDINATE_LENGTHSCALE = .15


class BinaryEventResponse(ExpectationPropagatedMargin):
    def __init__(self, reference, x, prior, *, geometry, device="cuda"):
        self.reference = reference
        self.family = np.asarray(x[:, 4], dtype=int)
        self.continuous_safe = False
        self.geometry = geometry
        same_family = self.family[:, None] == self.family[None, :]
        if geometry == "historical":
            correlation = margin_correlation(reference, prior)
        elif geometry == "coordinate":
            distance = cdist(x[:, :4], x[:, :4], "sqeuclidean")
            correlation = np.exp(-distance / (2 * COORDINATE_LENGTHSCALE ** 2))
        else:
            raise ValueError(f"Unknown event-response geometry: {geometry}")
        ratio = np.diag(reference.session.gp.covariance) / reference.session.gp.noise
        deviation = np.sqrt(ratio)
        covariance = (.5 * same_family + .5 * correlation * same_family) * deviation[:, None] * deviation[None, :]
        self.mean = torch.zeros(len(x), dtype=torch.float64, device=device)
        self.covariance = torch.as_tensor(covariance, dtype=torch.float64, device=device)
        self.noise = torch.ones_like(self.mean)
        self.indices, self.records, self.selection_checks = [], [], []
        self.initialize_sites()

    def diagnostics(self):
        return {**super().diagnostics(), "geometry": self.geometry,
                "observation": "probit event only; risk logged but does not update this component"}
