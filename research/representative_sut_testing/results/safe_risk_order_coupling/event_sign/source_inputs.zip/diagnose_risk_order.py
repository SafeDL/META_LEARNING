"""Compare exact safe values, event signs and safe-risk order at paid prefixes."""
import numpy as np

from .censored_margin_response import neutral_margin_prior
from .config import OUTPUT
from .diagnose_independent_event import evaluate_diagnostic
from .ep_margin_response import ExpectationPropagatedMargin
from .rank_event_response import RankEventResponse


MODELS = ("neutral_margin", "neutral_binary", "report_binary", "safe_risk_order")


def make_models(reference, x, prior):
    return [ExpectationPropagatedMargin(reference, x[:, 4], neutral_margin_prior(prior), continuous_safe=True),
            ExpectationPropagatedMargin(reference, x[:, 4], neutral_margin_prior(prior), continuous_safe=False),
            RankEventResponse(reference, x[:, 4], prior, use_ranks=False),
            RankEventResponse(reference, x[:, 4], prior, use_ranks=True)]


def validate_models(models, available):
    error = float(np.max(np.abs(models[1].probabilities()[available] - models[2].probabilities()[available])))
    if error > 2e-5:
        raise ValueError(f"Sign-only report EP differs from probit EP at unqueried points: {error}")
    for model in models[2:]:
        update = model.ep_updates[-1]
        if update['relative_site_change'] >= 1e-7:
            raise ValueError("Report projection EP did not converge")
    return {"sign_only_probability_max_error": error,
            "rank_constraints": models[3].ep_updates[-1]['rank_constraints'],
            "rank_ep_iterations": models[3].ep_updates[-1]['iterations']}


def main():
    evaluate_diagnostic(OUTPUT / "safe_risk_order_diagnostic", MODELS, make_models,
                        "Same normalized Gaussian report covariance and original white-noise fraction; event signs plus adjacent safe-risk ordering; no numeric safe value likelihood",
                        validate_models)


if __name__ == "__main__":
    main()
