"""Paid-prefix event forecasting and ranking, without new target disclosures."""
from zipfile import ZipFile

import numpy as np
from scipy.special import logsumexp
from threadpoolctl import threadpool_limits
import torch

from methods.history_guided_testing.history import historical_risk, load_history, split_indices, subset
from methods.history_guided_testing.io import read_json, write_json
from methods.history_guided_testing.search import TestingSession
from research.risk_conditioned_response_testing.confirmation import CONFIRMATION

from .adaptive_margin_prior import event_log_likelihood
from .baselines import verify_baseline_inputs
from .binary_event_response import BinaryEventResponse
from .censored_margin_response import historical_margin_prior, neutral_margin_prior
from .config import OUTPUT, POOL_SEEDS, SUT_IDS
from .ep_margin_response import ExpectationPropagatedMargin
from .frozen_coupling import FrozenReplay


SOURCE = OUTPUT / "event_evidence_prior_coupling"
RESULTS = OUTPUT / "event_geometry_scale_matched_diagnostic"
PREFIXES = (10, 30, 50, 100, 150)
MODELS = ("neutral_margin", "neutral_binary", "historical_binary", "coordinate_binary")


def evaluate_diagnostic(results, model_names, make_models, description, validate_models=None):
    torch.set_num_threads(1)
    verify_baseline_inputs(read_json(CONFIRMATION / "protocol.json"))
    results.mkdir(parents=True, exist_ok=True)
    write_json(results / "protocol.json", {
        "source": str(SOURCE), "prefixes": PREFIXES, "states": 60,
        "models": model_names, "budget_of_source_runs": 200, "new_target_disclosures": 0,
        "model_design": description,
        "neutral_binary_ablation": "same neutral prior, original correlation and noise as neutral_margin; only safe numeric reports removed",
        "scope": "forecast the next already-paid event and compare pure-component ranks at identical prefixes; no changed-policy Area or Recall",
        "target_label_permission": "only source queries; response banks read for x only",
        "batch_inference": "joint EP refitting of all paid-prefix sites; not hypothetical future updates",
        "next_stage": "consider actual strategies only if forecasting and ranking justify them; no target-dependent hyperparameter sweep"})
    snapshot = results / "source_inputs.zip"
    if not snapshot.exists():
        with ZipFile(snapshot, "w") as archive:
            for p in sorted(OUTPUT.parent.glob("*.py")):
                archive.write(p, p.name)
    with ZipFile(snapshot) as archive:
        if any(archive.read(n) != (OUTPUT.parent / n).read_bytes() for n in archive.namelist()):
            raise ValueError("Independent-event diagnostic source changed after freezing")
    history = load_history()
    train, _ = split_indices(next(iter(history.values()))["x"])
    allowed = subset(history, train)
    rows = []
    with threadpool_limits(limits=1):
        for pool in range(len(POOL_SEEDS)):
            with np.load(OUTPUT / f"pool_{pool}" / SUT_IDS[0] / "responses.npz") as bank:
                x = bank["x"].copy()
            risk_prior = historical_risk(allowed, x)
            prior = historical_margin_prior(x)
            for sut in SUT_IDS:
                run = read_json(SOURCE / f"pool_{pool}" / sut / "event_evidence_prior_11.json")
                states = []
                for n in PREFIXES:
                    reference = FrozenReplay(TestingSession(x, 11, mode="global_feedback", prior=risk_prior))
                    paid = run["queries"][:n]
                    reference.advance({q["index"]: (q["risk"], q["collision"]) for q in paid})
                    if reference.order != run["reference_prefix_indices"][:len(reference.order)]:
                        raise ValueError("Paid-prefix reference differs from actual source replay")
                    available = np.ones(len(x), dtype=bool)
                    available[[q["index"] for q in paid]] = False
                    next_query = run["queries"][n]
                    tie = np.random.default_rng(11).random(len(x))
                    models = make_models(reference, x, prior)
                    forecasts = {}
                    for name, model in zip(model_names, models):
                        model.condition(paid)
                        index = next_query["index"]
                        mean = float(model.mean[index])
                        variance = float(model.covariance[index, index] + model.noise[index])
                        if name == "neutral_margin":
                            original = run["component_margin_records"][1][n]
                            if not np.allclose([mean, variance], [original["predictive_mean_before"], original["predictive_variance_before"]], atol=2e-5, rtol=1e-5):
                                raise ValueError("Batch neutral EP does not reconstruct the paid-prefix posterior")
                        log_probability = float(event_log_likelihood(np.asarray([mean]), np.asarray([variance]), next_query["collision"])[0])
                        probability = float(model.probabilities()[index])
                        proposal = int(model.rank(available, tie_break=tie)[0])
                        forecasts[name] = {"event_log_loss": -log_probability,
                                           "brier_loss": (probability - next_query["collision"]) ** 2,
                                           "next_paid_collision_probability": probability,
                                           "proposed_index": proposal, "reference_index": int(reference.head()),
                                           "max_ep_iterations": model.ep_updates[-1]["iterations"]}
                    evidence = run["prior_evidence_records"][n]
                    original_mix_loss = -float(logsumexp(np.log(evidence["weights_before"]) + evidence["log_predictive_likelihoods"]))
                    checks = validate_models(models, available) if validate_models else {}
                    states.append({"inference_checks": checks, "prefix": n, "next_paid_index": next_query["index"],
                                   "next_paid_collision": next_query["collision"], "original_mixture_log_loss": original_mix_loss,
                                   "models": forecasts})
                    del models
                row = {"pool": pool, "sut": sut, "states": states}
                rows.append(row)
                write_json(results / f"pool_{pool}" / f"{sut}.json", row)
                print("PAID PREFIX", pool, sut,
                      {m: round(float(np.mean([s["models"][m]["event_log_loss"] for s in states])), 4) for m in model_names}, flush=True)
                write_json(results / "progress.json", {"status": "running", "complete_paths": len(rows), "expected_paths": 12})
    states = [s for row in rows for s in row["states"]]
    aggregate = {m: {metric: float(np.mean([s["models"][m][metric] for s in states]))
                     for metric in ("event_log_loss", "brier_loss")} for m in model_names}
    changes = {m: sum(s["models"][m]["proposed_index"] != s["models"]["neutral_margin"]["proposed_index"] for s in states)
               for m in model_names[1:]}
    write_json(results / "summary.json", {"rows": rows, "aggregate": aggregate,
               "original_mixture_log_loss": float(np.mean([s["original_mixture_log_loss"] for s in states])),
               "changed_component_proposals": changes, "states": len(states),
               "scope": "same already-paid prefixes; selected validation points are not iid and component ranking is not a new policy trajectory",
               "new_target_disclosures": 0, "significant_advantage_established": False})
    write_json(results / "progress.json", {"status": "complete", "complete_paths": 12, "states": len(states)})
    print({"aggregate": aggregate, "changed_component_proposals": changes}, flush=True)


def independent_models(reference, x, prior):
    return [ExpectationPropagatedMargin(reference, x[:, 4], neutral_margin_prior(prior), continuous_safe=True),
            ExpectationPropagatedMargin(reference, x[:, 4], neutral_margin_prior(prior), continuous_safe=False),
            BinaryEventResponse(reference, x, prior, geometry="historical"),
            BinaryEventResponse(reference, x, prior, geometry="coordinate")]


def main():
    evaluate_diagnostic(RESULTS, MODELS, independent_models,
                        "Matched signal/noise ratio, half family intercept and half correlation; coordinate RBF lengthscale .15")


if __name__ == "__main__":
    main()
