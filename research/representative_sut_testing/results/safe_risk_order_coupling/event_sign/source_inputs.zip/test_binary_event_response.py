"""Binary semantics, geometry covariance and batch EP diagnostic fidelity."""
from types import SimpleNamespace

import numpy as np

from .binary_event_response import BinaryEventResponse
from .test_ep_margin_response import build as mixed_model


def build(geometry):
    x = np.asarray([[.1, .1, .2, .3, 0], [.3, .2, .1, .4, 0],
                    [.7, .8, .5, .2, 1], [.8, .6, .1, .4, 1]])
    reference = SimpleNamespace(session=SimpleNamespace(gp=SimpleNamespace(covariance=np.eye(4), noise=1.)), head=lambda: 3)
    return BinaryEventResponse(reference, x, {"modes": np.zeros((4, 6))}, geometry=geometry, device="cpu")


def test_binary_prior_and_single_event_match_exact_probit_moments():
    model = build("coordinate")
    np.testing.assert_array_equal(model.probabilities(), [.5] * 4)
    model.observe(0, .9, True)
    np.testing.assert_allclose(float(model.mean[0]), -1 / np.sqrt(np.pi), atol=2e-6)
    np.testing.assert_allclose(float(model.covariance[0, 0]), 1 - 1 / np.pi, atol=2e-6)
    assert model.records[0]['observed_proxy'] is None


def test_numeric_risk_does_not_update_independent_binary_component():
    first, second = build("historical"), build("historical")
    for i, c in enumerate([False, True, False]):
        first.observe(i, .1, c)
        second.observe(i, .9, c)
    np.testing.assert_array_equal(first.mean.numpy(), second.mean.numpy())
    np.testing.assert_array_equal(first.covariance.numpy(), second.covariance.numpy())
    assert first.records[0]['likelihood'] == 'positive_censor'


def test_both_geometries_have_matching_scale_and_no_cross_family_covariance():
    for geometry in ['historical', 'coordinate']:
        model = build(geometry)
        np.testing.assert_array_equal(model.covariance.diag().numpy(), np.ones(4))
        np.testing.assert_array_equal(model.noise.numpy(), np.ones(4))
        np.testing.assert_array_equal(model.covariance[:2, 2:].numpy(), np.zeros((2, 2)))
        assert np.linalg.eigvalsh(model.covariance.numpy()).min() > 0


def test_batch_conditioning_matches_sequential_binary_and_mixed_ep():
    records = [{"index": 0, "risk": 1., "collision": True},
               {"index": 1, "risk": .2, "collision": False},
               {"index": 2, "risk": .7, "collision": True}]
    for maker in [lambda: build("coordinate"), mixed_model]:
        online, batch = maker(), maker()
        for q in records:
            online.observe(q['index'], q['risk'], q['collision'])
        batch.condition(records)
        np.testing.assert_allclose(online.mean.numpy(), batch.mean.numpy(), atol=2e-6)
        np.testing.assert_allclose(online.covariance.numpy(), batch.covariance.numpy(), atol=2e-6)


def test_binary_latent_variance_matches_frozen_signal_to_noise_ratio():
    x = np.asarray([[.1, .2, .3, .4, 0], [.2, .1, .3, .4, 0]])
    covariance = np.asarray([[2., .3], [.3, 5.]])
    reference = SimpleNamespace(session=SimpleNamespace(gp=SimpleNamespace(covariance=covariance, noise=.2)))
    for geometry in ['historical', 'coordinate']:
        model = BinaryEventResponse(reference, x, {"modes": np.zeros((2, 6))}, geometry=geometry, device="cpu")
        np.testing.assert_allclose(model.covariance.diag().numpy(), [10., 25.])
        np.testing.assert_array_equal(model.noise.numpy(), [1., 1.])
