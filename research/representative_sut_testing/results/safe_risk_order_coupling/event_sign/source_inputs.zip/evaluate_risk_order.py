"""One bounded strategy comparison of numeric, binary and ordinal feedback."""
import numpy as np

from methods.history_guided_testing.io import read_json, write_json
from .config import BUDGET, OUTPUT, SUT_IDS
from .evaluate_ep_discovery_support import evaluate_stage


RESULTS = OUTPUT / "safe_risk_order_coupling"


def main():
    write_json(RESULTS / 'protocol.json', {'sut_ids': SUT_IDS, 'pools': [0, 1], 'seed': 11, 'budget': BUDGET,
               'new_curves': 24, 'reused_controls': 24, 'new_physical_calls': 0,
               'methods': ['event_evidence_prior', 'report_binary_prior', 'safe_risk_order_prior'],
               'change': 'historical mixed EP retained; replace neutral mixed response by normalized report signs, then add safe-risk order only',
               'unchanged': 'shared initialization, six original sources, two scene families, priors, event scoring and actual discovery-credit protection',
               'scope': 'bounded development test of real Area and Recall; predictive log-loss diagnostic is not a discovery-efficiency gate',
               'expansion': 'none unless both discovery means beat matched controls and stronger existing Pareto methods'})
    write_json(RESULTS / 'progress.json', {'status': 'running', 'new_curves': 24, 'phase': 'event_sign'})
    evaluate_stage(RESULTS / "event_sign", "report_binary_prior", "event",
                   "event_evidence_prior_coupling", "event_evidence_prior", report_mode=False)
    write_json(RESULTS / 'progress.json', {'status': 'running', 'new_curves': 24, 'phase': 'safe_order'})
    evaluate_stage(RESULTS / "safe_order", "safe_risk_order_prior", "event",
                   "safe_risk_order_coupling/event_sign", "report_binary_prior", report_mode=True)
    rows = {}
    for folder in ["event_sign", "safe_order"]:
        for row in read_json(RESULTS / folder / "summary.json")["rows"]:
            rows[row['pool'], row['sut_id'], row['method']] = row
    rows = list(rows.values())
    methods = ("frozen_reference", "event_evidence_prior", "report_binary_prior", "safe_risk_order_prior")
    aggregate = {m: {k: float(np.mean([r[k] for r in rows if r['method'] == m]))
                     for k in ('area_pct', 'recall_pct', 'F200')} for m in methods}
    changes = {m: {k: aggregate['safe_risk_order_prior'][k] - aggregate[m][k]
                   for k in ('area_pct', 'recall_pct')} for m in methods[:-1]}
    matched = read_json(OUTPUT / 'matched_first_seed_comparison/summary.json')['aggregate']
    frontier = ('student_protected', 'student_unprotected', 'adf_loss_supported')
    strong = {m: {k: aggregate['safe_risk_order_prior'][k] - matched[m][k]
                  for k in ('area_pct', 'recall_pct')} for m in frontier}
    gate = all(v['area_pct'] > 0 and v['recall_pct'] > 0 for v in [*changes.values(), *strong.values()])
    write_json(RESULTS / 'summary.json', {'rows': rows, 'aggregate': aggregate, 'candidate_changes': changes,
               'stronger_method_changes': strong, 'new_curves': 24, 'reused_controls': 24,
               'development_gate_passed': gate, 'significant_advantage_established': False})
    write_json(RESULTS / 'progress.json', {'status': 'complete', 'new_curves': 24, 'new_disclosures': 4800,
                                        'new_physical_calls': 0})
    print({'aggregate': aggregate, 'candidate_changes': changes, 'development_gate_passed': gate}, flush=True)


if __name__ == '__main__':
    main()
